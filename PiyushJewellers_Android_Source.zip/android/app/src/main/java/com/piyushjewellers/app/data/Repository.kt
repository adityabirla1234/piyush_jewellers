package com.piyushjewellers.app.data

import com.piyushjewellers.app.AppContainer
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.local.CachedRecord
import com.piyushjewellers.app.data.local.LocalReminder
import com.piyushjewellers.app.data.local.OutboxOp
import com.piyushjewellers.app.data.remote.*
import com.piyushjewellers.app.sync.EntityTypes
import com.piyushjewellers.app.sync.Submit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.KSerializer
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.serializer
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.ResponseBody
import java.io.File
import java.io.IOException
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

/** Data returned to the UI together with whether it came from the offline cache. */
data class Fetched<T>(val data: T, val fromCache: Boolean = false, val savedAt: Long? = null)

class Repository(private val c: AppContainer) {
    private val api get() = c.api
    private val cache get() = c.db.cache()
    private val outbox get() = c.outbox

    // ---------- Generic helpers ----------

    private suspend fun <T> read(key: String?, type: String, serializer: KSerializer<T>, fetch: suspend () -> T): Fetched<T> {
        try {
            val v = apiCall { fetch() }
            if (key != null) cache.put(CachedRecord(key, type, AppJson.encodeToString(serializer, v)))
            return Fetched(v)
        } catch (e: AppException) {
            if (e.isOffline && key != null) {
                cache.get(key)?.let { return Fetched(AppJson.decodeFromString(serializer, it.json), true, it.updatedAt) }
            }
            throw e
        }
    }

    suspend fun <T> cachedOnly(key: String, serializer: KSerializer<T>): Fetched<T>? =
        cache.get(key)?.let { runCatching { Fetched(AppJson.decodeFromString(serializer, it.json), true, it.updatedAt) }.getOrNull() }

    private suspend fun <T> write(block: suspend () -> T): T = apiCall(block)

    private inline fun <reified T> json(v: T): String = AppJson.encodeToString(serializer<T>(), v)

    private suspend fun downloadTo(name: String, fetch: suspend () -> ResponseBody): File = withContext(Dispatchers.IO) {
        val body = apiCall { fetch() }
        val dir = File(c.context.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, name)
        try {
            body.use { b -> file.outputStream().use { out -> b.byteStream().copyTo(out) } }
        } catch (e: IOException) {
            file.delete()
            throw AppException.offline()
        }
        file
    }

    // ---------- Auth ----------

    suspend fun login(baseUrl: String, username: String, password: String) {
        c.session.setBaseUrl(baseUrl)
        val tokens = write { api.login(LoginRequest(username.trim(), password)) }
        c.session.saveTokens(tokens)
        outbox.scheduleSync()
        runCatching { pullReminders() }
    }

    /** Revokes the refresh token on the server when reachable; local unsynced work is kept for the next sign-in. */
    suspend fun logout() {
        val refresh = c.session.refreshToken
        if (refresh != null) runCatching { apiCall { api.logout(RefreshRequest(refresh)) } }
        c.session.clear()
    }

    suspend fun refreshProfile() = runCatching { write { api.me() }.also { c.session.updateUser(it) } }

    suspend fun updateProfile(fullName: String): UserDto =
        write {
            val r = api.updateProfile(ProfileRequest(fullName.trim()))
            c.session.updateAccessToken(r.accessToken)
            r.user
        }.also { c.session.updateUser(it) }

    // ---------- Settings & dashboard ----------

    suspend fun settings() = read("settings", "settings", SettingsDto.serializer()) { api.settings() }
    suspend fun updateSettings(r: UpdateSettingsRequest) = write { api.updateSettings(r) }.also {
        cache.put(CachedRecord("settings", "settings", json(it)))
    }

    suspend fun dashboard() = read("dashboard", "dashboard", DashboardDto.serializer()) { api.dashboard() }

    // ---------- Sell & Purchase, Turnover, Notifications ----------

    suspend fun sellPurchase(metal: String?, from: String?, to: String?, kind: String?, source: String?) =
        read("sp:$metal:$from:$to:$kind:$source", "sellpurchase", SellPurchaseDto.serializer()) { api.sellPurchase(metal, from, to, kind, source) }

    suspend fun turnover(from: String?, to: String?) = read("turnover:$from:$to", "turnover", TurnoverDto.serializer()) { api.turnover(from, to) }

    suspend fun notifications(unreadOnly: Boolean, page: Int = 0) =
        read(if (page == 0) "notifications:$unreadOnly" else null, "notifications", Page.serializer(NotificationDto.serializer())) {
            api.notifications(unreadOnly, page, 50)
        }

    suspend fun unreadNotificationCount(): Long = runCatching { apiCall { api.unreadNotifications() }.count }.getOrDefault(0)
    suspend fun markNotificationRead(id: Long) = write { api.markNotificationRead(id) }
    suspend fun markAllNotificationsRead() = write { api.markAllNotificationsRead() }

    // ---------- People ----------

    suspend fun people(q: String?, type: String?, page: Int, size: Int = 50): Fetched<Page<PersonDto>> {
        try {
            val p = apiCall { api.people(q?.takeIf { it.isNotBlank() }, type, page, size) }
            cache.putAll(p.content.map { CachedRecord("person:${it.id}", "person", json(it), personSearch(it)) })
            return Fetched(p)
        } catch (e: AppException) {
            if (!e.isOffline) throw e
            val list = cache.search("person", q.orEmpty().trim().lowercase()).mapNotNull {
                runCatching { AppJson.decodeFromString(PersonDto.serializer(), it.json) }.getOrNull()
            }.filter { p ->
                when (type) {
                    "CUSTOMER" -> p.customer
                    "SUPPLIER" -> p.supplier
                    "DEALER" -> p.dealer
                    else -> true
                }
            }.sortedBy { it.name.lowercase() }
            return Fetched(Page(list, 0, list.size, list.size.toLong(), 1, true), fromCache = true)
        }
    }

    private fun personSearch(p: PersonDto) = listOfNotNull(p.name, p.phone, p.alternatePhone, p.idReference).joinToString(" ").lowercase()

    suspend fun person(id: Long) = read("person:$id", "person", PersonDto.serializer()) { api.person(id) }

    suspend fun createPerson(r: PersonRequest): Submit<PersonDto?> =
        outbox.submit(EntityTypes.PERSON, r.name, "POST", "api/v1/people", json(r), PersonDto.serializer(), createsRecord = true).also {
            if (it is Submit.Done) it.value?.let { p -> cache.put(CachedRecord("person:${p.id}", "person", json(p), personSearch(p))) }
        }

    suspend fun updatePerson(id: Long, r: PersonRequest) = write { api.updatePerson(id, r) }.also {
        cache.put(CachedRecord("person:${it.id}", "person", json(it), personSearch(it)))
    }

    suspend fun timeline(id: Long) = read("timeline:$id", "timeline", ListSerializer(TimelineEntry.serializer())) { api.timeline(id) }

    /** People created offline that have not reached the server yet; their ids are negative placeholders. */
    suspend fun pendingPeople(): List<PersonDto> = c.db.outbox().unsynced(EntityTypes.PERSON).mapNotNull { op ->
        val localId = op.localId ?: return@mapNotNull null
        val r = op.body?.let { runCatching { AppJson.decodeFromString(PersonRequest.serializer(), it) }.getOrNull() }
        PersonDto(id = localId, name = r?.name ?: op.summary, phone = r?.phone, customer = r?.customer ?: true, supplier = r?.supplier ?: false)
    }

    fun observeUnsynced(type: String): Flow<List<OutboxOp>> = c.db.outbox().observeUnsynced(type)

    // ---------- Transactions ----------

    suspend fun transactions(from: String?, to: String?, direction: String?, method: String?, personId: Long?, sourceType: String?, q: String?, page: Int) =
        read(
            if (page == 0) "tx:$from:$to:$direction:$method:$personId:$sourceType:${q.orEmpty()}" else null,
            "transactions", Page.serializer(TransactionDto.serializer()),
        ) { api.transactions(from, to, direction, method, personId, sourceType, q?.takeIf { it.isNotBlank() }, page, 50) }

    suspend fun summary(from: String?, to: String?) = read("summary:$from:$to", "summary", SummaryDto.serializer()) { api.summary(from, to) }
    suspend fun transaction(id: Long) = read("tx:$id", "transaction", TransactionDto.serializer()) { api.transaction(id) }

    suspend fun createTransaction(r: TransactionRequest): Submit<TransactionDto?> {
        val label = "${if (r.direction == "IN") "Money in" else "Money out"} ${Fmt.rupees(r.amount)} · ${Fmt.method(r.method)}"
        return outbox.submit(EntityTypes.TRANSACTION, label, "POST", "api/v1/transactions", json(r), TransactionDto.serializer(), createsRecord = true)
    }

    suspend fun reverseTransaction(id: Long, reason: String) = write { api.reverseTransaction(id, ReasonRequest(reason)) }
    suspend fun transfer(r: TransferRequest) = write { api.transfer(r) }
    suspend fun cheques(status: String?) = read("cheques:$status", "cheques", ListSerializer(ChequeDto.serializer())) { api.cheques(status) }
    suspend fun clearCheque(id: Long, date: String?) = write { api.clearCheque(id, ChequeActionRequest(date)) }
    suspend fun bounceCheque(id: Long, date: String?, reason: String?) = write { api.bounceCheque(id, ChequeActionRequest(date, reason)) }

    // ---------- Inventory ----------

    suspend fun products(q: String?, category: String?, metal: String?, availability: String?, page: Int, size: Int = 40): Fetched<Page<ProductDto>> {
        try {
            val p = apiCall { api.products(q?.takeIf { it.isNotBlank() }, category, metal, null, availability, page, size) }
            cache.putAll(p.content.map { CachedRecord("product:${it.id}", "product", json(it), productSearch(it)) })
            return Fetched(p)
        } catch (e: AppException) {
            if (!e.isOffline) throw e
            val list = cache.search("product", q.orEmpty().trim().lowercase()).mapNotNull {
                runCatching { AppJson.decodeFromString(ProductDto.serializer(), it.json) }.getOrNull()
            }.filter { (category == null || it.category == category) && (metal == null || it.metal == metal) }
                .sortedBy { it.name.lowercase() }
            return Fetched(Page(list, 0, list.size, list.size.toLong(), 1, true), fromCache = true)
        }
    }

    private fun productSearch(p: ProductDto) = listOfNotNull(p.code, p.name, p.purity, p.description).joinToString(" ").lowercase()

    suspend fun product(id: Long) = read("product:$id", "product", ProductDto.serializer()) { api.product(id) }
    suspend fun createProduct(r: ProductRequest) = write { api.createProduct(r) }
    suspend fun updateProduct(id: Long, r: ProductRequest) = write { api.updateProduct(id, r) }
    suspend fun movements(id: Long, page: Int) = read(if (page == 0) "movements:$id" else null, "movements", Page.serializer(MovementDto.serializer())) { api.movements(id, page, 50) }
    suspend fun stockOperation(id: Long, r: StockOperationRequest) = write { api.stockOperation(id, r) }
    suspend fun images(productId: Long) = read("images:$productId", "images", ListSerializer(ImageDto.serializer())) { api.images(productId) }

    /** Tries an immediate upload; if that is not possible the prepared file waits in the outbox. */
    suspend fun uploadPhoto(productId: Long, file: File, label: String): Submit<ImageDto?> {
        try {
            val part = MultipartBody.Part.createFormData("file", file.name, file.asRequestBody("image/jpeg".toMediaType()))
            val dto = apiCall { api.uploadImage(productId, part) }
            file.delete()
            return Submit.Done(dto)
        } catch (e: AppException) {
            if (e.isOffline || e.kind == AppException.Kind.SERVER) {
                return Submit.Queued(outbox.enqueuePhoto(productId, file, label))
            }
            file.delete()
            throw e
        }
    }

    suspend fun reorderImages(productId: Long, ids: List<Long>) = write { api.reorderImages(productId, ReorderRequest(ids)) }
    suspend fun setPrimaryImage(productId: Long, imageId: Long) = write { api.setPrimaryImage(productId, imageId) }
    suspend fun deleteImage(productId: Long, imageId: Long) = write { api.deleteImage(productId, imageId) }

    suspend fun barLots(metal: String?, availableOnly: Boolean) = read("bars:$metal:$availableOnly", "bars", ListSerializer(BarLotDto.serializer())) { api.barLots(metal, availableOnly) }
    suspend fun createBarLot(r: BarLotRequest) = write { api.createBarLot(r) }
    suspend fun barMovements(id: Long) = read("barmov:$id", "barmov", ListSerializer(BarMovementDto.serializer())) { api.barMovements(id) }
    suspend fun adjustBarLot(id: Long, delta: java.math.BigDecimal, reason: String) = write { api.adjustBarLot(id, BarAdjustRequest(delta, reason)) }

    // ---------- Customer billing ----------

    suspend fun bills(type: String?, status: String?, personId: Long?, from: String?, to: String?, q: String?, page: Int) =
        read(if (page == 0) "bills:$type:$status:$personId:$from:$to:${q.orEmpty()}" else null, "bills", Page.serializer(BillDto.serializer())) {
            api.bills(type, status, personId, from, to, q?.takeIf { it.isNotBlank() }, page, 40)
        }

    suspend fun bill(id: Long) = read("bill:$id", "bill", BillDto.serializer()) { api.bill(id) }

    suspend fun createBillDraft(r: BillRequest): Submit<BillDto?> {
        val who = r.customerName ?: "customer"
        val label = "${if (r.type == "SALES") "Sales" else "Purchase"} bill draft · $who · ${r.lines.size} item(s)"
        return outbox.submit(EntityTypes.BILL_DRAFT, label, "POST", "api/v1/customer-bills", json(r), BillDto.serializer(), createsRecord = true)
    }

    suspend fun updateBill(id: Long, r: BillRequest) = write { api.updateBill(id, r) }
    suspend fun deleteBill(id: Long) {
        val resp = write { api.deleteBill(id) }
        if (!resp.isSuccessful) throw AppException.fromHttp(resp.code(), resp.errorBody()?.string())
    }
    suspend fun finalizeBill(id: Long) = write { api.finalizeBill(id) }
    suspend fun addBillPayment(id: Long, r: BillPaymentRequest) = write { api.addBillPayment(id, r) }
    suspend fun reverseBill(id: Long, reason: String) = write { api.reverseBill(id, ReasonRequest(reason)) }
    suspend fun billPdf(id: Long, number: String): File = downloadTo("Bill-${number.replace(Regex("[^A-Za-z0-9-]"), "_")}.pdf") { api.billPdf(id) }

    // ---------- Dealers ----------

    suspend fun dealers(q: String?, page: Int) = read(if (page == 0) "dealers:${q.orEmpty()}" else null, "dealers", Page.serializer(DealerDto.serializer())) {
        api.dealers(q?.takeIf { it.isNotBlank() }, page, 50)
    }
    suspend fun dealer(id: Long) = read("dealer:$id", "dealer", DealerDto.serializer()) { api.dealer(id) }
    suspend fun createDealer(r: DealerRequest) = write { api.createDealer(r) }
    suspend fun updateDealer(id: Long, r: DealerRequest) = write { api.updateDealer(id, r) }
    suspend fun shops(dealerId: Long) = read("shops:$dealerId", "shops", ListSerializer(ShopDto.serializer())) { api.shops(dealerId) }
    suspend fun addShop(dealerId: Long, r: ShopRequest) = write { api.addShop(dealerId, r) }
    suspend fun updateShop(dealerId: Long, shopId: Long, r: ShopRequest) = write { api.updateShop(dealerId, shopId, r) }
    suspend fun ledger(dealerId: Long, shopId: Long?) = read("ledger:$dealerId:$shopId", "ledger", DealerLedger.serializer()) { api.ledger(dealerId, shopId) }
    suspend fun dealerBills(dealerId: Long?, shopId: Long?, metal: String?, status: String?, q: String?, page: Int) =
        read(if (page == 0) "dbills:$dealerId:$shopId:$metal:$status:${q.orEmpty()}" else null, "dbills", Page.serializer(DealerBillDto.serializer())) {
            api.dealerBills(dealerId, shopId, metal, status, q?.takeIf { it.isNotBlank() }, page, 40)
        }
    suspend fun dealerBill(id: Long) = read("dbill:$id", "dbill", DealerBillDto.serializer()) { api.dealerBill(id) }
    suspend fun createDealerBill(r: DealerBillRequest) = write { api.createDealerBill(r) }
    suspend fun settle(billId: Long, r: SettlementRequest) = write { api.settle(billId, r) }
    suspend fun reverseSettlement(billId: Long, settlementId: Long, reason: String) = write { api.reverseSettlement(billId, settlementId, ReasonRequest(reason)) }
    suspend fun reverseDealerBill(billId: Long, reason: String) = write { api.reverseDealerBill(billId, ReasonRequest(reason)) }
    suspend fun dealerBillPdf(id: Long, number: String): File =
        downloadTo("DealerBill-${number.replace(Regex("[^A-Za-z0-9-]"), "_")}.pdf") { api.dealerBillPdf(id) }

    // ---------- Loans ----------

    suspend fun loans(kind: String?, status: String?, personId: Long?, q: String?, page: Int) =
        read(if (page == 0) "loans:$kind:$status:$personId:${q.orEmpty()}" else null, "loans", Page.serializer(LoanDto.serializer())) {
            api.loans(kind, status, personId, q?.takeIf { it.isNotBlank() }, page, 50)
        }
    suspend fun loan(id: Long) = read("loan:$id", "loan", LoanDto.serializer()) { api.loan(id) }

    suspend fun createLoan(r: LoanRequest, personName: String): Submit<LoanDto?> {
        val label = "${if (r.kind == "LENT") "Lent to" else "Borrowed from"} $personName · ${Fmt.rupees(r.principal)}"
        return outbox.submit(EntityTypes.LOAN, label, "POST", "api/v1/loans", json(r), LoanDto.serializer(), createsRecord = true)
    }

    suspend fun repay(loanId: Long, r: RepaymentRequest, label: String): Submit<LoanDto?> =
        outbox.submit(EntityTypes.REPAYMENT, label, "POST", "api/v1/loans/$loanId/repayments", json(r), LoanDto.serializer())

    suspend fun loanExpectedDate(id: Long, date: String?) = write { api.loanExpectedDate(id, ExpectedDateRequest(date)) }
    suspend fun reverseLoan(id: Long, reason: String) = write { api.reverseLoan(id, ReasonRequest(reason)) }

    // ---------- Mortgages ----------

    suspend fun mortgageAccounts(q: String?, page: Int) = read(if (page == 0) "maccounts:${q.orEmpty()}" else null, "maccounts", Page.serializer(AccountDto.serializer())) {
        api.mortgageAccounts(q?.takeIf { it.isNotBlank() }, page, 50)
    }
    suspend fun mortgageAccount(id: Long) = read("maccount:$id", "maccount", AccountDto.serializer()) { api.mortgageAccount(id) }
    suspend fun createMortgageAccount(r: AccountRequest) = write { api.createMortgageAccount(r) }
    suspend fun mortgages(kind: String?, status: String?, accountId: Long?, personId: Long?, q: String?, page: Int) =
        read(if (page == 0) "mortgages:$kind:$status:$accountId:$personId:${q.orEmpty()}" else null, "mortgages", Page.serializer(MortgageDto.serializer())) {
            api.mortgages(kind, status, accountId, personId, q?.takeIf { it.isNotBlank() }, page, 50)
        }
    suspend fun mortgage(id: Long) = read("mortgage:$id", "mortgage", MortgageDto.serializer()) { api.mortgage(id) }
    suspend fun createMortgage(r: MortgageRequest) = write { api.createMortgage(r) }
    suspend fun calculateInterest(id: Long, through: String?) = write { api.calculateInterest(id, CalculateRequest(through)) }
    suspend fun mortgagePayment(id: Long, r: MortgagePaymentRequest) = write { api.mortgagePayment(id, r) }
    suspend fun fullFinal(id: Long, r: FullFinalRequest) = write { api.fullFinal(id, r) }
    suspend fun jewelleryReturn(id: Long, r: JewelleryReturnRequest) = write { api.jewelleryReturn(id, r) }
    suspend fun mortgageReminderDate(id: Long, date: String?) = write { api.mortgageReminderDate(id, ReminderDateRequest(date)) }

    // ---------- Exchange ----------

    suspend fun exchanges(status: String?, personId: Long?, q: String?, page: Int) =
        read(if (page == 0) "exchanges:$status:$personId:${q.orEmpty()}" else null, "exchanges", Page.serializer(ExchangeDto.serializer())) {
            api.exchanges(status, personId, q?.takeIf { it.isNotBlank() }, page, 40)
        }
    suspend fun exchange(id: Long) = read("exchange:$id", "exchange", ExchangeDto.serializer()) { api.exchange(id) }

    suspend fun createExchangeDraft(r: ExchangeRequest): Submit<ExchangeDto?> {
        val label = "Exchange draft · ${r.partyName ?: "customer"} · ${r.lines.size} line(s)"
        return outbox.submit(EntityTypes.EXCHANGE_DRAFT, label, "POST", "api/v1/exchanges", json(r), ExchangeDto.serializer(), createsRecord = true)
    }
    suspend fun updateExchange(id: Long, r: ExchangeRequest) = write { api.updateExchange(id, r) }
    suspend fun deleteExchange(id: Long) {
        val resp = write { api.deleteExchange(id) }
        if (!resp.isSuccessful) throw AppException.fromHttp(resp.code(), resp.errorBody()?.string())
    }
    suspend fun finalizeExchange(id: Long) = write { api.finalizeExchange(id) }
    suspend fun reverseExchange(id: Long, reason: String) = write { api.reverseExchange(id, ReasonRequest(reason)) }

    // ---------- Dues ----------

    suspend fun dues(q: String?, direction: String?, source: String?, state: String, page: Int) =
        read(if (page == 0) "dues:${q.orEmpty()}:$direction:$source:$state" else null, "dues", DueOverview.serializer()) {
            api.dues(q?.takeIf { it.isNotBlank() }, direction, source, state, null, null, null, page, 50)
        }
    suspend fun dueAccount(personId: Long) = read("dueacct:$personId", "dueacct", PersonDueAccount.serializer()) { api.dueAccount(personId) }

    // ---------- Reminders (local notifications, mirrored to the server for backup) ----------

    fun observeReminders() = c.db.reminders().observeAll()

    suspend fun saveReminder(r: LocalReminder) {
        val stamped = r.copy(updatedAt = System.currentTimeMillis(), firedAt = null)
        c.db.reminders().upsert(stamped)
        c.reminderScheduler.schedule(stamped)
        val remindAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(r.remindAt), ZoneId.systemDefault()).withNano(0).toString()
        val body = ReminderRequest(r.sourceType, r.sourceId, r.personId, r.title, r.notes, remindAt, r.enabled)
        outbox.enqueue(EntityTypes.REMINDER, "Reminder · ${r.title}", "PUT", "api/v1/reminders/${r.key}", json(body))
    }

    suspend fun deleteReminder(key: String) {
        c.db.reminders().delete(key)
        c.reminderScheduler.cancel(key)
        outbox.enqueue(EntityTypes.REMINDER, "Delete reminder", "DELETE", "api/v1/reminders/$key", null)
    }

    /** Restores reminders saved on the server (for example after reinstalling) and schedules them locally. */
    suspend fun pullReminders() {
        val remote = apiCall { api.reminders() }
        for (r in remote) {
            val local = c.db.reminders().get(r.key)
            val at = runCatching { LocalDateTime.parse(r.remindAt).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() }.getOrNull() ?: continue
            val serverUpdated = r.updatedAt?.let { runCatching { Instant.parse(it).toEpochMilli() }.getOrNull() } ?: 0L
            if (local == null || local.updatedAt < serverUpdated) {
                val lr = LocalReminder(r.key, r.sourceType, r.sourceId, r.personId, r.title, r.notes, at, r.enabled, local?.firedAt, serverUpdated)
                c.db.reminders().upsert(lr)
                c.reminderScheduler.schedule(lr)
            }
        }
    }

    // ---------- Reports ----------

    suspend fun requestReport(r: ReportRequest) = write { api.requestReport(r) }
    suspend fun reportHistory(page: Int) = read(if (page == 0) "reports" else null, "reports", Page.serializer(ReportJobDto.serializer())) { api.reportHistory(page, 30) }
    suspend fun report(id: Long) = write { api.report(id) }
    suspend fun retryReport(id: Long) = write { api.retryReport(id) }
    suspend fun downloadReport(job: ReportJobDto): File = downloadTo("PiyushJewellers-${job.type.lowercase()}-${job.id}.pdf") { api.downloadReport(job.id) }

    // ---------- Audit ----------

    suspend fun audit(entityType: String?, entityId: Long?, page: Int) = read(null, "audit", Page.serializer(AuditEventDto.serializer())) {
        api.audit(entityType, entityId, page, 50)
    }
}
