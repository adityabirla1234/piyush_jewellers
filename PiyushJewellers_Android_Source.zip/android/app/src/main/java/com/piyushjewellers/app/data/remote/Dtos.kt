package com.piyushjewellers.app.data.remote

import kotlinx.serialization.KSerializer
import kotlinx.serialization.Serializable
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonEncoder
import kotlinx.serialization.json.JsonUnquotedLiteral
import kotlinx.serialization.json.jsonPrimitive
import java.math.BigDecimal

/** Reads JSON numbers or strings exactly (no Double round-trip) and writes plain decimal literals. */
object BigDecimalSerializer : KSerializer<BigDecimal> {
    override val descriptor: SerialDescriptor = PrimitiveSerialDescriptor("BigDecimal", PrimitiveKind.STRING)

    override fun deserialize(decoder: Decoder): BigDecimal =
        if (decoder is JsonDecoder) BigDecimal(decoder.decodeJsonElement().jsonPrimitive.content)
        else BigDecimal(decoder.decodeString())

    override fun serialize(encoder: Encoder, value: BigDecimal) {
        if (encoder is JsonEncoder) encoder.encodeJsonElement(JsonUnquotedLiteral(value.toPlainString()))
        else encoder.encodeString(value.toPlainString())
    }
}

typealias Dec = @Serializable(with = BigDecimalSerializer::class) BigDecimal

@Serializable
data class Page<T>(
    val content: List<T> = emptyList(),
    val page: Int = 0,
    val size: Int = 0,
    val totalElements: Long = 0,
    val totalPages: Int = 0,
    val last: Boolean = true,
)

@Serializable
data class FieldViolation(val field: String? = null, val message: String? = null)

@Serializable
data class ApiErrorDto(
    val status: Int = 0,
    val code: String? = null,
    val message: String? = null,
    val retryable: Boolean = false,
    val fieldErrors: List<FieldViolation>? = null,
)

// ---------- Auth ----------
@Serializable data class LoginRequest(val username: String, val password: String)
@Serializable data class RefreshRequest(val refreshToken: String)
@Serializable data class UserDto(val id: Long = 0, val username: String = "", val fullName: String? = null, val role: String = "")
@Serializable data class ProfileRequest(val fullName: String)
@Serializable data class ProfileUpdateResponse(val user: UserDto, val accessToken: String)
@Serializable data class TokenResponse(val accessToken: String, val refreshToken: String, val expiresInSeconds: Long = 0, val user: UserDto)
@Serializable data class ReasonRequest(val reason: String)

// ---------- Settings ----------
@Serializable data class PurityDto(val carat: String, val percent: Int)
@Serializable
data class SettingsDto(
    val openingBalance: Dec = BigDecimal.ZERO,
    val crossMetalSettlementAllowed: Boolean = false,
    val shopName: String? = null,
    val shopAddress: String? = null,
    val shopPhone: String? = null,
    val maxPhotosPerProduct: Int = 10,
    val maxPhotoBytes: Long = 0,
    val purities: List<PurityDto> = emptyList(),
    val version: Long? = null,
)

@Serializable
data class UpdateSettingsRequest(
    val openingBalance: Dec? = null,
    val crossMetalSettlementAllowed: Boolean? = null,
    val shopName: String? = null,
    val shopAddress: String? = null,
    val shopPhone: String? = null,
)

// ---------- People ----------
@Serializable
data class PersonDto(
    val id: Long,
    val name: String,
    val phone: String? = null,
    val alternatePhone: String? = null,
    val address: String? = null,
    val idReference: String? = null,
    val notes: String? = null,
    val customer: Boolean = false,
    val supplier: Boolean = false,
    val dealer: Boolean = false,
    val version: Long? = null,
    val createdAt: String? = null,
    val updatedAt: String? = null,
)

@Serializable
data class PersonRequest(
    val name: String,
    val phone: String? = null,
    val alternatePhone: String? = null,
    val address: String? = null,
    val idReference: String? = null,
    val notes: String? = null,
    val customer: Boolean = true,
    val supplier: Boolean = false,
    val version: Long? = null,
    val allowDuplicatePhone: Boolean = false,
)

// ---------- Transactions ----------
@Serializable
data class ChequeDto(
    val id: Long,
    val chequeNumber: String? = null,
    val bankName: String? = null,
    val chequeDate: String? = null,
    val direction: String = "IN",
    val status: String = "PENDING",
    val clearedDate: String? = null,
    val bouncedDate: String? = null,
    val bounceReason: String? = null,
    val bounceReversalTransactionId: Long? = null,
    val transactionId: Long? = null,
    val amount: Dec = BigDecimal.ZERO,
    val personName: String? = null,
    val businessDate: String? = null,
)

@Serializable
data class TransactionDto(
    val id: Long,
    val businessDate: String,
    val direction: String,
    val amount: Dec,
    val category: String? = null,
    val description: String? = null,
    val method: String,
    val personId: Long? = null,
    val personName: String? = null,
    val reference: String? = null,
    val notes: String? = null,
    val sourceType: String = "MANUAL",
    val sourceId: Long? = null,
    val transferGroup: String? = null,
    val approxReturnDate: String? = null,
    val status: String = "ACTIVE",
    val reversalOfId: Long? = null,
    val reversalReason: String? = null,
    val cheque: ChequeDto? = null,
    val createdAt: String? = null,
    val createdBy: String? = null,
)

@Serializable
data class TransactionRequest(
    val businessDate: String,
    val direction: String,
    val amount: Dec,
    val category: String? = null,
    val description: String? = null,
    val method: String,
    val personId: Long? = null,
    val reference: String? = null,
    val notes: String? = null,
    val approxReturnDate: String? = null,
    val chequeNumber: String? = null,
    val chequeBank: String? = null,
    val chequeDate: String? = null,
)

@Serializable
data class TransferRequest(val fromMethod: String, val toMethod: String, val amount: Dec, val businessDate: String, val notes: String? = null)

@Serializable
data class ChequeActionRequest(val date: String? = null, val reason: String? = null)

@Serializable
data class MethodSummary(val method: String, val moneyIn: Dec = BigDecimal.ZERO, val moneyOut: Dec = BigDecimal.ZERO, val net: Dec = BigDecimal.ZERO)

@Serializable
data class SummaryDto(
    val from: String? = null,
    val to: String? = null,
    val openingBalance: Dec = BigDecimal.ZERO,
    val moneyIn: Dec = BigDecimal.ZERO,
    val moneyOut: Dec = BigDecimal.ZERO,
    val combinedBalance: Dec = BigDecimal.ZERO,
    val availableBalance: Dec = BigDecimal.ZERO,
    val pendingChequesIn: Dec = BigDecimal.ZERO,
    val pendingChequesOut: Dec = BigDecimal.ZERO,
    val byMethod: List<MethodSummary> = emptyList(),
)

// ---------- Dashboard ----------
@Serializable data class CountAmount(val count: Long = 0, val amount: Dec = BigDecimal.ZERO)

@Serializable
data class InventorySummary(
    val productCount: Long = 0,
    val outOfStockCount: Long = 0,
    val goldNetWeight: Dec = BigDecimal.ZERO,
    val silverNetWeight: Dec = BigDecimal.ZERO,
    val goldBarWeight: Dec = BigDecimal.ZERO,
    val silverBarWeight: Dec = BigDecimal.ZERO,
)

@Serializable
data class DashboardDto(
    val allTime: SummaryDto = SummaryDto(),
    val today: SummaryDto = SummaryDto(),
    val totalReceivable: Dec = BigDecimal.ZERO,
    val totalPayable: Dec = BigDecimal.ZERO,
    val activeMortgages: CountAmount = CountAmount(),
    val activeLent: CountAmount = CountAmount(),
    val activeBorrowed: CountAmount = CountAmount(),
    val inventory: InventorySummary = InventorySummary(),
    val recentTransactions: List<TransactionDto> = emptyList(),
    val generatedAt: String? = null,
)

// ---------- Inventory ----------
@Serializable data class ImageRef(val id: Long, val url: String, val thumbnailUrl: String)

@Serializable
data class ProductDto(
    val id: Long,
    val code: String,
    val name: String,
    val description: String? = null,
    val category: String,
    val metal: String,
    val purity: String? = null,
    val grossWeight: Dec = BigDecimal.ZERO,
    val lessWeight: Dec = BigDecimal.ZERO,
    val netWeight: Dec = BigDecimal.ZERO,
    val pieces: Int = 0,
    val availability: String = "",
    val primaryImage: ImageRef? = null,
    val imageCount: Long = 0,
    val version: Long? = null,
    val updatedAt: String? = null,
)

@Serializable
data class ProductRequest(
    val code: String? = null,
    val name: String,
    val description: String? = null,
    val category: String,
    val metal: String,
    val purity: String? = null,
    val openingGrossWeight: Dec? = null,
    val openingLessWeight: Dec? = null,
    val openingNetWeight: Dec? = null,
    val openingPieces: Int? = null,
    val version: Long? = null,
)

@Serializable
data class StockOperationRequest(
    val type: String,
    val grossWeight: Dec? = null,
    val lessWeight: Dec? = null,
    val netWeight: Dec? = null,
    val pieces: Int? = null,
    val reason: String,
    val businessDate: String? = null,
)

@Serializable
data class MovementDto(
    val id: Long,
    val productId: Long,
    val productName: String? = null,
    val type: String,
    val grossDelta: Dec = BigDecimal.ZERO,
    val lessDelta: Dec = BigDecimal.ZERO,
    val netDelta: Dec = BigDecimal.ZERO,
    val piecesDelta: Int = 0,
    val netAfter: Dec = BigDecimal.ZERO,
    val piecesAfter: Int = 0,
    val sourceType: String? = null,
    val sourceId: Long? = null,
    val reason: String? = null,
    val businessDate: String? = null,
    val createdAt: String? = null,
    val createdBy: String? = null,
)

@Serializable
data class ImageDto(
    val id: Long,
    val productId: Long,
    val url: String,
    val thumbnailUrl: String,
    val displayOrder: Int = 0,
    val primary: Boolean = false,
    val contentType: String? = null,
    val byteSize: Long = 0,
    val width: Int? = null,
    val height: Int? = null,
    val createdAt: String? = null,
)

@Serializable data class ReorderRequest(val imageIds: List<Long>)

@Serializable
data class BarLotDto(
    val id: Long,
    val lotCode: String,
    val metal: String,
    val label: String,
    val receivedWeight: Dec = BigDecimal.ZERO,
    val remainingWeight: Dec = BigDecimal.ZERO,
    val purity: String? = null,
    val rate: Dec? = null,
    val receivedDate: String? = null,
    val source: String? = null,
    val notes: String? = null,
    val status: String = "AVAILABLE",
    val version: Long? = null,
)

@Serializable
data class BarLotRequest(
    val metal: String,
    val lotCode: String? = null,
    val weight: Dec,
    val purity: String? = null,
    val rate: Dec? = null,
    val receivedDate: String? = null,
    val source: String? = null,
    val notes: String? = null,
)

@Serializable
data class BarMovementDto(
    val id: Long,
    val barLotId: Long,
    val lotCode: String,
    val type: String,
    val weightDelta: Dec = BigDecimal.ZERO,
    val remainingAfter: Dec = BigDecimal.ZERO,
    val rate: Dec? = null,
    val sourceType: String? = null,
    val sourceId: Long? = null,
    val reason: String? = null,
    val businessDate: String? = null,
    val createdAt: String? = null,
    val createdBy: String? = null,
)

@Serializable data class BarAdjustRequest(val weightDelta: Dec, val reason: String)

// ---------- Customer billing ----------
@Serializable
data class BillLineRequest(
    val description: String,
    val productId: Long? = null,
    val newProductCategory: String? = null,
    val purity: String? = null,
    val grossWeight: Dec? = null,
    val lessWeight: Dec? = null,
    val netWeight: Dec? = null,
    val pieces: Int? = null,
    val rate: Dec,
    val makingCharges: Dec? = null,
    val metal: String? = null,
    val pairs: Int? = null,
)

/** kind MONEY uses method + amount; kind WEIGHT uses metal + weight + rate (+ barLotId on purchase bills). */
@Serializable
data class BillPaymentRequest(
    val method: String? = null,
    val amount: Dec? = null,
    val reference: String? = null,
    val chequeNumber: String? = null,
    val chequeBank: String? = null,
    val paidAt: String? = null,
    val kind: String = "MONEY",
    val metal: String? = null,
    val weight: Dec? = null,
    val rate: Dec? = null,
    val purity: String? = null,
    val barLotId: Long? = null,
)

@Serializable
data class BillRequest(
    val type: String,
    val billNumber: String? = null,
    val billDate: String,
    val personId: Long? = null,
    val customerName: String? = null,
    val customerContact: String? = null,
    val notes: String? = null,
    val lines: List<BillLineRequest>,
    val makingChargesZeroConfirmed: Boolean = false,
    val payments: List<BillPaymentRequest>? = null,
    val version: Long? = null,
)

@Serializable
data class BillLineDto(
    val id: Long? = null,
    val lineNo: Int = 0,
    val description: String = "",
    val productId: Long? = null,
    val productCode: String? = null,
    val newProductCategory: String? = null,
    val purity: String? = null,
    val grossWeight: Dec? = null,
    val lessWeight: Dec? = null,
    val netWeight: Dec = BigDecimal.ZERO,
    val pieces: Int = 0,
    val rate: Dec = BigDecimal.ZERO,
    val makingCharges: Dec? = null,
    val metalValue: Dec = BigDecimal.ZERO,
    val lineTotal: Dec = BigDecimal.ZERO,
    val metal: String? = null,
    val pairs: Int? = null,
)

@Serializable
data class BillPaymentDto(
    val id: Long? = null,
    val method: String,
    val amount: Dec,
    val reference: String? = null,
    val chequeNumber: String? = null,
    val chequeBank: String? = null,
    val paidAt: String? = null,
    val transactionId: Long? = null,
    val posted: Boolean = false,
    val effective: Boolean = false,
    val kind: String = "MONEY",
    val metal: String? = null,
    val weight: Dec? = null,
    val rate: Dec? = null,
    val purity: String? = null,
    val barLotId: Long? = null,
    val barLotCode: String? = null,
) {
    val isWeight: Boolean get() = kind == "WEIGHT"
}

@Serializable
data class BillDto(
    val id: Long,
    val type: String,
    val billNumber: String,
    val billDate: String,
    val personId: Long? = null,
    val personName: String? = null,
    val customerName: String? = null,
    val customerContact: String? = null,
    val notes: String? = null,
    val status: String,
    val makingChargesZeroConfirmed: Boolean = false,
    val lines: List<BillLineDto> = emptyList(),
    val subtotal: Dec = BigDecimal.ZERO,
    val makingChargesTotal: Dec = BigDecimal.ZERO,
    val grandTotal: Dec = BigDecimal.ZERO,
    val paidAmount: Dec = BigDecimal.ZERO,
    val outstandingAmount: Dec = BigDecimal.ZERO,
    val paymentState: String? = null,
    val payments: List<BillPaymentDto> = emptyList(),
    val finalizedAt: String? = null,
    val reversalReason: String? = null,
    val reversedAt: String? = null,
    val version: Long? = null,
    val createdAt: String? = null,
    val createdBy: String? = null,
    val totalNetWeight: Dec = BigDecimal.ZERO,
    val settledWeight: Dec = BigDecimal.ZERO,
)

// ---------- Dealers ----------
@Serializable
data class DealerDto(
    val id: Long,
    val name: String,
    val phone: String? = null,
    val address: String? = null,
    val notes: String? = null,
    val personId: Long? = null,
    val shopCount: Long = 0,
    val version: Long? = null,
)

@Serializable
data class DealerRequest(val name: String, val phone: String? = null, val address: String? = null, val notes: String? = null, val version: Long? = null)

@Serializable data class ShopDto(val id: Long, val dealerId: Long, val name: String, val location: String? = null, val phone: String? = null)
@Serializable data class ShopRequest(val name: String, val location: String? = null, val phone: String? = null)

@Serializable
data class DealerLineRequest(
    val description: String? = null,
    val grossWeight: Dec,
    val lessWeight: Dec? = null,
    val pieces: Int? = null,
    val carat: String? = null,
    val labourPercent: Dec,
    val pairs: Int? = null,
)

@Serializable
data class BarAllocationRequest(
    val barLotId: Long? = null,
    val weight: Dec,
    val rate: Dec? = null,
    val newLotCode: String? = null,
    val purity: String? = null,
    val barMetal: String? = null,
)

@Serializable
data class MoneyAllocationRequest(val method: String, val amount: Dec, val reference: String? = null, val rate: Dec? = null)

@Serializable
data class SettlementRequest(
    val settlementDate: String? = null,
    val notes: String? = null,
    val bars: List<BarAllocationRequest> = emptyList(),
    val money: List<MoneyAllocationRequest> = emptyList(),
    val crossMetalAuthorized: Boolean = false,
)

@Serializable
data class DealerBillRequest(
    val dealerId: Long,
    val shopId: Long,
    val billNumber: String,
    val dealDate: String,
    val type: String,
    val metal: String,
    val description: String? = null,
    val rate: Dec? = null,
    val lines: List<DealerLineRequest>,
    val settlement: SettlementRequest? = null,
)

@Serializable
data class DealerLineDto(
    val id: Long? = null,
    val lineNo: Int = 0,
    val description: String? = null,
    val grossWeight: Dec = BigDecimal.ZERO,
    val lessWeight: Dec = BigDecimal.ZERO,
    val netWeight: Dec = BigDecimal.ZERO,
    val pieces: Int = 0,
    val carat: String? = null,
    val caratPercent: Int? = null,
    val labourPercent: Dec = BigDecimal.ZERO,
    val finalWeight: Dec = BigDecimal.ZERO,
    val pairs: Int? = null,
)

@Serializable
data class AllocationDto(
    val id: Long? = null,
    val kind: String,
    val barLotId: Long? = null,
    val barLotCode: String? = null,
    val barLabel: String? = null,
    val weight: Dec? = null,
    val rate: Dec? = null,
    val value: Dec = BigDecimal.ZERO,
    val weightEquivalent: Dec? = null,
    val method: String? = null,
    val reference: String? = null,
    val transactionId: Long? = null,
)

@Serializable
data class SettlementDto(
    val id: Long,
    val settlementDate: String? = null,
    val totalValue: Dec = BigDecimal.ZERO,
    val totalWeightEquivalent: Dec? = null,
    val notes: String? = null,
    val status: String = "ACTIVE",
    val reversalReason: String? = null,
    val allocations: List<AllocationDto> = emptyList(),
    val createdAt: String? = null,
)

@Serializable
data class DealerBillDto(
    val id: Long,
    val billNumber: String,
    val dealDate: String,
    val enteredAt: String? = null,
    val dealerId: Long,
    val dealerName: String? = null,
    val shopId: Long,
    val shopName: String? = null,
    val type: String,
    val metal: String,
    val description: String? = null,
    val rate: Dec? = null,
    val lines: List<DealerLineDto> = emptyList(),
    val totalNetWeight: Dec = BigDecimal.ZERO,
    val totalFinalWeight: Dec = BigDecimal.ZERO,
    val amount: Dec? = null,
    val settledValue: Dec = BigDecimal.ZERO,
    val settledWeight: Dec = BigDecimal.ZERO,
    val outstandingAmount: Dec? = null,
    val outstandingWeight: Dec = BigDecimal.ZERO,
    val status: String,
    val reversalReason: String? = null,
    val settlements: List<SettlementDto> = emptyList(),
    val version: Long? = null,
    val dealerPhone: String? = null,
    val shopPhone: String? = null,
) {
    val contactPhone: String? get() = shopPhone?.takeIf { it.isNotBlank() } ?: dealerPhone
}

@Serializable
data class LedgerEntry(
    val date: String? = null,
    val kind: String,
    val reference: String? = null,
    val billId: Long? = null,
    val shopId: Long? = null,
    val shopName: String? = null,
    val metal: String? = null,
    val description: String? = null,
    val weight: Dec? = null,
    val amount: Dec? = null,
    val direction: String? = null,
)

@Serializable
data class MetalBalance(
    val metal: String,
    val receivableWeight: Dec = BigDecimal.ZERO,
    val payableWeight: Dec = BigDecimal.ZERO,
    val receivableAmount: Dec = BigDecimal.ZERO,
    val payableAmount: Dec = BigDecimal.ZERO,
)

@Serializable
data class DealerLedger(
    val dealerId: Long,
    val dealerName: String? = null,
    val shopId: Long? = null,
    val balances: List<MetalBalance> = emptyList(),
    val totalReceivableAmount: Dec = BigDecimal.ZERO,
    val totalPayableAmount: Dec = BigDecimal.ZERO,
    val entries: List<LedgerEntry> = emptyList(),
)

// ---------- Loans ----------
@Serializable
data class LoanRequest(
    val personId: Long,
    val kind: String,
    val principal: Dec,
    val loanDate: String,
    val method: String,
    val reference: String? = null,
    val notes: String? = null,
    val expectedReturnDate: String? = null,
)

@Serializable
data class RepaymentRequest(val amount: Dec, val repaymentDate: String, val method: String, val reference: String? = null, val notes: String? = null)

@Serializable data class ExpectedDateRequest(val expectedReturnDate: String?)

@Serializable
data class RepaymentDto(
    val id: Long? = null,
    val amount: Dec,
    val repaymentDate: String,
    val method: String,
    val reference: String? = null,
    val notes: String? = null,
    val transactionId: Long? = null,
    val effective: Boolean = true,
    val createdAt: String? = null,
)

@Serializable
data class LoanDto(
    val id: Long,
    val personId: Long,
    val personName: String? = null,
    val personPhone: String? = null,
    val kind: String,
    val principal: Dec,
    val repaidAmount: Dec = BigDecimal.ZERO,
    val outstanding: Dec = BigDecimal.ZERO,
    val loanDate: String,
    val expectedReturnDate: String? = null,
    val method: String,
    val reference: String? = null,
    val notes: String? = null,
    val status: String,
    val transactionId: Long? = null,
    val repayments: List<RepaymentDto> = emptyList(),
    val version: Long? = null,
)

// ---------- Mortgages ----------
@Serializable
data class AccountRequest(
    val personId: Long? = null,
    val name: String? = null,
    val phone: String? = null,
    val address: String? = null,
    val idReference: String? = null,
    val reference: String? = null,
)

@Serializable
data class AccountDto(
    val id: Long,
    val serial: String,
    val personId: Long,
    val name: String,
    val phone: String? = null,
    val address: String? = null,
    val idReference: String? = null,
    val reference: String? = null,
    val activeCount: Long = 0,
    val totalCount: Long = 0,
    val activePrincipal: Dec = BigDecimal.ZERO,
    val version: Long? = null,
)

@Serializable
data class MortgageRequest(
    val accountId: Long,
    val kind: String,
    val issueDate: String,
    val principal: Dec,
    val monthlyRate: Dec,
    val approxReminderDate: String? = null,
    val jewelleryName: String? = null,
    val netWeight: Dec? = null,
    val pieces: Int? = null,
    val metal: String? = null,
    val issueMethod: String,
    val notes: String? = null,
)

@Serializable data class CalculateRequest(val effectiveThrough: String?)

@Serializable
data class MortgagePaymentRequest(val amount: Dec, val paymentDate: String, val method: String, val reference: String? = null, val notes: String? = null)

@Serializable
data class FullFinalRequest(
    val fullAmountReceived: Boolean,
    val amount: Dec? = null,
    val paymentDate: String? = null,
    val method: String? = null,
    val reference: String? = null,
    val notes: String? = null,
)

@Serializable data class JewelleryReturnRequest(val returnDate: String, val returnedTo: String? = null, val notes: String? = null)
@Serializable data class ReminderDateRequest(val approxReminderDate: String?)

@Serializable
data class InterestPeriod(
    val index: Int = 0,
    val from: String? = null,
    val to: String? = null,
    val openingPrincipal: Dec = BigDecimal.ZERO,
    val fullMonths: Int = 0,
    val extraDays: Long = 0,
    val prorationDetail: String? = null,
    val interest: Dec = BigDecimal.ZERO,
    val completedYear: Boolean = false,
    val capitalizedAfter: Dec? = null,
)

@Serializable
data class MortgagePaymentDto(
    val id: Long? = null,
    val amount: Dec,
    val paymentDate: String,
    val method: String,
    val reference: String? = null,
    val notes: String? = null,
    val finalSettlement: Boolean = false,
    val transactionId: Long? = null,
    val effective: Boolean = true,
    val createdAt: String? = null,
)

@Serializable
data class CalculationDto(
    val id: Long? = null,
    val effectiveThrough: String,
    val calculatedAt: String? = null,
    val calculatedBy: String? = null,
    val principal: Dec = BigDecimal.ZERO,
    val monthlyRate: Dec = BigDecimal.ZERO,
    val totalInterest: Dec = BigDecimal.ZERO,
    val capitalizedPrincipal: Dec = BigDecimal.ZERO,
    val totalDue: Dec = BigDecimal.ZERO,
    val amountReceived: Dec = BigDecimal.ZERO,
    val remainingBalance: Dec = BigDecimal.ZERO,
    val periods: List<InterestPeriod> = emptyList(),
    val policyNotes: List<String> = emptyList(),
)

@Serializable
data class MortgageDto(
    val id: Long,
    val serial: String,
    val accountId: Long,
    val accountSerial: String? = null,
    val personId: Long,
    val personName: String? = null,
    val personPhone: String? = null,
    val kind: String,
    val issueDate: String,
    val principal: Dec,
    val monthlyRate: Dec,
    val approxReminderDate: String? = null,
    val status: String,
    val jewelleryName: String? = null,
    val netWeight: Dec? = null,
    val pieces: Int? = null,
    val metal: String? = null,
    val issueMethod: String? = null,
    val notes: String? = null,
    val amountReceived: Dec = BigDecimal.ZERO,
    val fullPaymentConfirmed: Boolean = false,
    val settledDate: String? = null,
    val jewelleryReturned: Boolean = false,
    val jewelleryReturnDate: String? = null,
    val jewelleryReturnedTo: String? = null,
    val jewelleryReturnNotes: String? = null,
    val completionState: String? = null,
    val lastCalculation: CalculationDto? = null,
    val payments: List<MortgagePaymentDto> = emptyList(),
    val calculations: List<CalculationDto> = emptyList(),
    val version: Long? = null,
)

@Serializable data class FullFinalResult(val outcome: String, val message: String, val mortgage: MortgageDto)

// ---------- Exchange ----------
@Serializable
data class ExchangeLineRequest(
    val side: String,
    val description: String,
    val productId: Long? = null,
    val newProductCategory: String? = null,
    val metal: String,
    val purity: String? = null,
    val grossWeight: Dec? = null,
    val lessWeight: Dec? = null,
    val netWeight: Dec? = null,
    val pieces: Int? = null,
    val rate: Dec,
)

@Serializable
data class ExchangeRequest(
    val personId: Long? = null,
    val partyName: String? = null,
    val exchangeDate: String,
    val notes: String? = null,
    val differenceMethod: String? = null,
    val differenceReference: String? = null,
    val lines: List<ExchangeLineRequest>,
    val version: Long? = null,
)

@Serializable
data class ExchangeLineDto(
    val id: Long? = null,
    val lineNo: Int = 0,
    val side: String,
    val description: String = "",
    val productId: Long? = null,
    val productCode: String? = null,
    val newProductCategory: String? = null,
    val metal: String = "GOLD",
    val purity: String? = null,
    val grossWeight: Dec? = null,
    val lessWeight: Dec? = null,
    val netWeight: Dec = BigDecimal.ZERO,
    val pieces: Int = 0,
    val rate: Dec = BigDecimal.ZERO,
    val value: Dec = BigDecimal.ZERO,
)

@Serializable
data class ExchangeDto(
    val id: Long,
    val exchangeNumber: String,
    val personId: Long? = null,
    val personName: String? = null,
    val partyName: String? = null,
    val exchangeDate: String,
    val notes: String? = null,
    val status: String,
    val lines: List<ExchangeLineDto> = emptyList(),
    val receivedValue: Dec = BigDecimal.ZERO,
    val issuedValue: Dec = BigDecimal.ZERO,
    val cashDifference: Dec = BigDecimal.ZERO,
    val cashDirection: String? = null,
    val differenceMethod: String? = null,
    val differenceReference: String? = null,
    val transactionId: Long? = null,
    val finalizedAt: String? = null,
    val reversalReason: String? = null,
    val version: Long? = null,
)

// ---------- Dues ----------
@Serializable
data class DueItem(
    val source: String,
    val sourceId: Long,
    val reference: String? = null,
    val title: String? = null,
    val personId: Long? = null,
    val direction: String,
    val originalAmount: Dec? = null,
    val outstandingAmount: Dec? = null,
    val outstandingWeight: Dec? = null,
    val metal: String? = null,
    val date: String? = null,
    val expectedDate: String? = null,
    val state: String? = null,
    val lastCalculatedDue: Dec? = null,
)

@Serializable
data class PersonDueSummary(
    val personId: Long,
    val name: String,
    val phone: String? = null,
    val serial: String? = null,
    val receivable: Dec = BigDecimal.ZERO,
    val payable: Dec = BigDecimal.ZERO,
    val net: Dec = BigDecimal.ZERO,
    val receivableWeight: Dec = BigDecimal.ZERO,
    val payableWeight: Dec = BigDecimal.ZERO,
    val activeItems: Int = 0,
    val nextExpectedDate: String? = null,
    val sources: List<String> = emptyList(),
)

@Serializable
data class DueOverview(
    val totalReceivable: Dec = BigDecimal.ZERO,
    val totalPayable: Dec = BigDecimal.ZERO,
    val net: Dec = BigDecimal.ZERO,
    val persons: Page<PersonDueSummary> = Page(),
)

@Serializable
data class TimelineEntry(
    val date: String? = null,
    val kind: String,
    val title: String? = null,
    val reference: String? = null,
    val amount: Dec? = null,
    val direction: String? = null,
    val sourceType: String? = null,
    val sourceId: Long? = null,
    val status: String? = null,
)

@Serializable
data class PersonDueAccount(
    val person: PersonDto,
    val mortgageSerial: String? = null,
    val receivable: Dec = BigDecimal.ZERO,
    val payable: Dec = BigDecimal.ZERO,
    val net: Dec = BigDecimal.ZERO,
    val items: List<DueItem> = emptyList(),
    val timeline: List<TimelineEntry> = emptyList(),
)

// ---------- Reminders ----------
@Serializable
data class ReminderRequest(
    val sourceType: String,
    val sourceId: Long? = null,
    val personId: Long? = null,
    val title: String,
    val notes: String? = null,
    val remindAt: String,
    val enabled: Boolean = true,
)

@Serializable
data class ReminderDto(
    val key: String,
    val sourceType: String,
    val sourceId: Long? = null,
    val personId: Long? = null,
    val title: String,
    val notes: String? = null,
    val remindAt: String,
    val enabled: Boolean = true,
    val updatedAt: String? = null,
)

// ---------- Reports ----------
@Serializable
data class ReportRequest(
    val type: String,
    val from: String? = null,
    val to: String? = null,
    val personId: Long? = null,
    val dealerId: Long? = null,
    val shopId: Long? = null,
    val metal: String? = null,
    val status: String? = null,
    val filterLabel: String? = null,
)

@Serializable
data class ReportJobDto(
    val id: Long,
    val type: String,
    val title: String,
    val status: String,
    val from: String? = null,
    val to: String? = null,
    val filterSummary: String? = null,
    val fileSize: Long? = null,
    val available: Boolean = false,
    val error: String? = null,
    val createdAt: String? = null,
    val completedAt: String? = null,
)

// ---------- Audit ----------
@Serializable
data class AuditEventDto(
    val id: Long,
    val action: String,
    val entityType: String? = null,
    val entityId: Long? = null,
    val actor: String? = null,
    val reason: String? = null,
    val details: String? = null,
    val occurredAt: String? = null,
)

// ---------- Sell & Purchase ----------
@Serializable
data class SpRow(
    val source: String,
    val id: Long,
    val billNumber: String? = null,
    val date: String,
    val kind: String,
    val partyName: String? = null,
    val partyPhone: String? = null,
    val metal: String? = null,
    val netWeight: Dec? = null,
    val fineWeight: Dec? = null,
    val amount: Dec = BigDecimal.ZERO,
    val outstanding: Dec? = null,
    val status: String? = null,
)

@Serializable
data class SpBucket(
    val count: Int = 0,
    val amount: Dec = BigDecimal.ZERO,
    val netWeight: Dec = BigDecimal.ZERO,
    val fineWeight: Dec = BigDecimal.ZERO,
)

@Serializable
data class SpMetalTotals(val metal: String, val sales: SpBucket = SpBucket(), val purchase: SpBucket = SpBucket())

@Serializable
data class SellPurchaseDto(
    val from: String? = null,
    val to: String? = null,
    val metal: String? = null,
    val kind: String? = null,
    val source: String? = null,
    val sales: SpBucket = SpBucket(),
    val purchase: SpBucket = SpBucket(),
    val net: Dec = BigDecimal.ZERO,
    val totalAmount: Dec = BigDecimal.ZERO,
    val byMetal: List<SpMetalTotals> = emptyList(),
    val rows: List<SpRow> = emptyList(),
)

// ---------- Turnover ----------
@Serializable
data class TurnoverLine(val category: String, val moneyIn: Dec = BigDecimal.ZERO, val moneyOut: Dec = BigDecimal.ZERO, val count: Long = 0)

@Serializable
data class TurnoverComponent(
    val source: String,
    val label: String,
    val moneyIn: Dec = BigDecimal.ZERO,
    val moneyOut: Dec = BigDecimal.ZERO,
    val net: Dec = BigDecimal.ZERO,
    val count: Long = 0,
    val lines: List<TurnoverLine> = emptyList(),
)

@Serializable
data class TurnoverDto(
    val from: String? = null,
    val to: String? = null,
    val openingBalance: Dec = BigDecimal.ZERO,
    val moneyIn: Dec = BigDecimal.ZERO,
    val moneyOut: Dec = BigDecimal.ZERO,
    val net: Dec = BigDecimal.ZERO,
    val closingBalance: Dec = BigDecimal.ZERO,
    val availableBalance: Dec = BigDecimal.ZERO,
    val pendingChequesIn: Dec = BigDecimal.ZERO,
    val pendingChequesOut: Dec = BigDecimal.ZERO,
    val transfersMoved: Dec = BigDecimal.ZERO,
    val components: List<TurnoverComponent> = emptyList(),
    val byMethod: List<MethodSummary> = emptyList(),
    val salesTurnover: Dec = BigDecimal.ZERO,
    val purchaseTurnover: Dec = BigDecimal.ZERO,
    val grossTurnover: Dec = BigDecimal.ZERO,
    val byMetal: List<SpMetalTotals> = emptyList(),
    val sales: SpBucket = SpBucket(),
    val purchase: SpBucket = SpBucket(),
)

// ---------- Notifications ----------
@Serializable
data class NotificationDto(
    val id: Long,
    val category: String,
    val title: String,
    val body: String? = null,
    val sourceType: String? = null,
    val sourceId: Long? = null,
    val personId: Long? = null,
    val dueAt: String? = null,
    val read: Boolean = false,
    val readAt: String? = null,
    val createdAt: String? = null,
)

@Serializable data class CountDto(val count: Long = 0)
