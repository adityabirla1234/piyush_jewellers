package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.piyushjewellers.app.AppContainer
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.Repository
import com.piyushjewellers.app.data.local.ReportHistory
import com.piyushjewellers.app.data.remote.AppException
import com.piyushjewellers.app.data.remote.PersonDto
import com.piyushjewellers.app.data.remote.ReportJobDto
import com.piyushjewellers.app.data.remote.ReportRequest
import com.piyushjewellers.app.reports.ProvisionalPdf
import com.piyushjewellers.app.reports.rememberPdfExporter
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.theme.PJColors
import kotlinx.coroutines.delay
import java.io.File
import java.time.LocalDate

private val reportTypes = listOf(
    "FINANCIAL", "TURNOVER", "SELL_PURCHASE", "INVENTORY", "CUSTOMER_BILLING", "DEALER", "MORTGAGE", "DUES", "LENDING", "EXCHANGE",
)

private fun reportLabel(type: String) = when (type) {
    "FINANCIAL" -> "Financial (daily transactions)"
    "TURNOVER" -> "Shop turnover (all money in & out)"
    "SELL_PURCHASE" -> "Sell & Purchase (gold / silver)"
    "INVENTORY" -> "Inventory & stock"
    "CUSTOMER_BILLING" -> "Customer billing"
    "DEALER" -> "Dealer & shop"
    "MORTGAGE" -> "Mortgage & interest"
    "DUES" -> "Due management"
    "LENDING" -> "Lending & borrowing"
    "EXCHANGE" -> "Jewellery exchange"
    else -> Fmt.humanize(type)
}

private fun usesPerson(type: String) = type in setOf("CUSTOMER_BILLING", "MORTGAGE", "DUES", "LENDING", "EXCHANGE", "FINANCIAL")
private fun usesMetal(type: String) = type in setOf("INVENTORY", "DEALER", "SELL_PURCHASE")
private fun usesDates(type: String) = type != "INVENTORY" && type != "DUES"

internal data class ReadyPdf(val file: File, val title: String, val provisional: Boolean)

/** Requests a server report, waits for it and downloads the PDF; records it in local history. */
internal suspend fun Repository.generateServerReport(c: AppContainer, req: ReportRequest, progress: (String?) -> Unit): ReadyPdf {
    try {
        progress("Requesting report…")
        var job = requestReport(req)
        var waited = 0
        while (job.status == "QUEUED" || job.status == "RUNNING") {
            if (waited >= 120) throw AppException(AppException.Kind.SERVER, "The report is taking longer than expected. Check Reports → History in a minute.", retryable = true)
            progress("Generating… (${Fmt.humanize(job.status)})")
            delay(2000)
            waited += 2
            job = report(job.id)
        }
        if (job.status != "COMPLETED") throw AppException(AppException.Kind.SERVER, job.error ?: "The report could not be generated (${Fmt.humanize(job.status)}).", retryable = true)
        progress("Downloading…")
        val file = downloadReport(job)
        c.db.reports().insert(ReportHistory(reportType = req.type, title = job.title, filterSummary = req.filterLabel, provisional = false, filePath = file.absolutePath, serverJobId = job.id))
        return ReadyPdf(file, job.title, false)
    } finally {
        progress(null)
    }
}

@Composable
internal fun ReadyPdfDialog(ready: ReadyPdf?, onDismiss: () -> Unit) {
    val pdf = rememberPdfExporter()
    ready?.let { r ->
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(r.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (r.provisional) "PROVISIONAL report built from saved data. Generate again online for the final version." else "Report ready.")
                    Text(r.file.name, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { Button(onClick = { pdf.save(r.file); onDismiss() }) { Text("Save to device") } },
            dismissButton = { TextButton(onClick = { pdf.share(r.file); onDismiss() }) { Text("Share") } },
        )
    }
}

@Composable
fun ReportsScreen() {
    val c = container()
    val pdf = rememberPdfExporter()
    val actions = actionVm("reports")
    val history = loadVm("reports") { reportHistory(0) }
    val local by c.db.reports().observeAll().collectAsState(initial = emptyList())
    var tab by rememberSaveable { mutableStateOf(0) }
    var type by rememberSaveable { mutableStateOf("FINANCIAL") }
    var from by rememberSaveable { mutableStateOf<String?>(Fmt.today().withDayOfMonth(1).toString()) }
    var to by rememberSaveable { mutableStateOf<String?>(Fmt.today().toString()) }
    var metal by rememberSaveable { mutableStateOf<String?>(null) }
    var person by remember { mutableStateOf<PersonDto?>(null) }
    var progress by remember { mutableStateOf<String?>(null) }
    var ready by remember { mutableStateOf<ReadyPdf?>(null) }
    var deleting by remember { mutableStateOf<ReportHistory?>(null) }

    fun filterSummary(): String = listOfNotNull(
        if (usesDates(type)) "${Fmt.date(from)} – ${Fmt.date(to)}" else null,
        person?.takeIf { usesPerson(type) }?.name,
        metal?.takeIf { usesMetal(type) }?.let(Fmt::humanize),
    ).joinToString(" · ").ifBlank { "No filters" }

    fun downloadJob(job: ReportJobDto) {
        actions.run({ downloadReport(job) }) { f ->
            ready = ReadyPdf(f, job.title, false)
        }
    }

    PJScaffold(title = "Reports & PDF", topLevel = true, busy = actions.busy) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Generate") })
                Tab(tab == 1, { tab = 1 }, text = { Text("History") })
            }
            if (tab == 0) {
                FormColumn(PaddingValues(0.dp)) {
                    DropdownField("Report", reportTypes, type, ::reportLabel, { type = it })
                    if (usesDates(type)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DateInput("From", Fmt.parseDate(from), { from = it?.toString() }, Modifier.weight(1f), clearable = true)
                            DateInput("To", Fmt.parseDate(to), { to = it?.toString() }, Modifier.weight(1f), clearable = true)
                        }
                    }
                    if (usesPerson(type)) PersonPickerField("Person (optional)", person, { person = it })
                    if (usesMetal(type)) ChoiceChips(listOf(null, "GOLD", "SILVER"), metal, { it?.let(Fmt::humanize) ?: "All metals" }, { metal = it })
                    Text("Reports are generated when you ask. Offline, a PROVISIONAL report is built from data saved on this device.", style = MaterialTheme.typography.bodySmall)
                    progress?.let { Text(it, color = PJColors.GoldDeep) }
                    PrimaryButton(if (actions.busy) "Working…" else "Generate PDF", {
                        val f = Fmt.parseDate(from); val t = Fmt.parseDate(to)
                        if (usesDates(type) && f != null && t != null && f.isAfter(t)) { c.toast("From date is after To date"); return@PrimaryButton }
                        val summary = filterSummary()
                        val req = ReportRequest(
                            type = type,
                            from = from.takeIf { usesDates(type) }, to = to.takeIf { usesDates(type) },
                            personId = person?.id?.takeIf { usesPerson(type) && it > 0 },
                            metal = metal.takeIf { usesMetal(type) },
                            filterLabel = summary,
                        )
                        val chosenType = type
                        actions.run(
                            block = {
                                try {
                                    progress = "Requesting report…"
                                    var job = requestReport(req)
                                    var waited = 0
                                    while (job.status == "QUEUED" || job.status == "RUNNING") {
                                        if (waited >= 120) throw AppException(AppException.Kind.SERVER, "The report is taking longer than expected. Check History in a minute.", retryable = true)
                                        progress = "Generating… (${Fmt.humanize(job.status)})"
                                        delay(2000)
                                        waited += 2
                                        job = report(job.id)
                                    }
                                    if (job.status != "COMPLETED") throw AppException(AppException.Kind.SERVER, job.error ?: "The report could not be generated (${Fmt.humanize(job.status)}).", retryable = true)
                                    progress = "Downloading…"
                                    val file = downloadReport(job)
                                    c.db.reports().insert(ReportHistory(reportType = chosenType, title = job.title, filterSummary = summary, provisional = false, filePath = file.absolutePath, serverJobId = job.id))
                                    ReadyPdf(file, job.title, false)
                                } catch (e: AppException) {
                                    if (!e.isOffline) throw e
                                    progress = "Offline — building provisional report from saved data…"
                                    val content = ProvisionalPdf.fromCache(c, chosenType)
                                        ?: throw AppException(AppException.Kind.NOT_FOUND, "No saved data for this report yet. Open the related screen once while online, then try again.")
                                    val file = ProvisionalPdf.write(c.context, content)
                                    c.db.reports().insert(ReportHistory(reportType = chosenType, title = content.title, filterSummary = content.filterSummary, provisional = true, filePath = file.absolutePath, dataAsOf = content.dataAsOf))
                                    ReadyPdf(file, content.title, true)
                                } finally {
                                    progress = null
                                }
                            },
                        ) { r -> ready = r; history.reload(silent = true) }
                    }, enabled = !actions.busy)
                }
            } else {
                LoadContent(history.state, onRetry = { history.reload() }, refreshing = history.refreshing, onRefresh = { history.reload() }) { page ->
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                        item { SectionHeader("On this device") }
                        if (local.isEmpty()) item { Text("No reports saved on this device yet", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        items(local, key = { "l${it.id}" }) { h ->
                            val file = h.filePath?.let(::File)?.takeIf { it.exists() }
                            ListRow(
                                title = h.title,
                                subtitle = listOfNotNull(Fmt.epoch(h.createdAt), h.filterSummary, h.dataAsOf?.let { "data as of ${Fmt.epoch(it)}" }, if (file == null) "file no longer on device" else null).joinToString(" · "),
                                leading = { Icon(Icons.Filled.PictureAsPdf, null, tint = if (h.provisional) PJColors.Warning else MaterialTheme.colorScheme.tertiary) },
                                trailingBottom = {
                                    Row {
                                        StatusChip(if (h.provisional) "PENDING" else "COMPLETED", if (h.provisional) "Provisional" else "Final")
                                        IconButton(onClick = { deleting = h }) { Icon(Icons.Filled.Delete, "Delete") }
                                    }
                                },
                                onClick = file?.let { f -> { ready = ReadyPdf(f, h.title, h.provisional) } },
                            )
                        }
                        item { SectionHeader("Generated on server") }
                        if (page.content.isEmpty()) item { Text("No server reports yet", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        items(page.content, key = { "s${it.id}" }) { j ->
                            ListRow(
                                title = j.title,
                                subtitle = listOfNotNull(Fmt.dateTime(j.createdAt), j.filterSummary, j.error).joinToString(" · "),
                                trailingBottom = {
                                    Row {
                                        StatusChip(j.status)
                                        if (j.status == "FAILED" || j.status == "EXPIRED") TextButton(onClick = { actions.run({ retryReport(j.id) }) { history.reload(silent = true); c.toast("Report requested again") } }) { Text("Retry") }
                                    }
                                },
                                onClick = if (j.available && j.status == "COMPLETED") ({ downloadJob(j) }) else null,
                            )
                        }
                    }
                }
            }
        }
    }
    ready?.let { r ->
        AlertDialog(
            onDismissRequest = { ready = null },
            title = { Text(r.title) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (r.provisional) "PROVISIONAL report built from saved data. Generate again online for the final version." else "Report ready.")
                    Text(r.file.name, style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { Button(onClick = { pdf.save(r.file); ready = null }) { Text("Save to device") } },
            dismissButton = { TextButton(onClick = { pdf.share(r.file); ready = null }) { Text("Share") } },
        )
    }
    deleting?.let { h ->
        ConfirmDialog("Delete from history?", "The saved PDF file on this device is removed. Server reports are not affected.", "Delete", destructive = true,
            onConfirm = {
                deleting = null
                actions.run({ h.filePath?.let { File(it).delete() }; c.db.reports().delete(h.id) })
            }, onDismiss = { deleting = null })
    }
    ActionErrorDialog(actions)
}