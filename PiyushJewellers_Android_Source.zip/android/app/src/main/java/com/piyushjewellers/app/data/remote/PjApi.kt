package com.piyushjewellers.app.data.remote

import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query
import retrofit2.http.Streaming

interface PjApi {
    // Auth
    @POST("api/v1/auth/login") suspend fun login(@Body r: LoginRequest): TokenResponse
    @POST("api/v1/auth/logout") suspend fun logout(@Body r: RefreshRequest): Response<Unit>
    @GET("api/v1/auth/me") suspend fun me(): UserDto
    @PATCH("api/v1/auth/profile") suspend fun updateProfile(@Body r: ProfileRequest): ProfileUpdateResponse

    // Settings
    @GET("api/v1/settings") suspend fun settings(): SettingsDto
    @PUT("api/v1/settings") suspend fun updateSettings(@Body r: UpdateSettingsRequest): SettingsDto

    // Dashboard
    @GET("api/v1/dashboard") suspend fun dashboard(): DashboardDto

    // People
    @GET("api/v1/people") suspend fun people(@Query("q") q: String?, @Query("type") type: String?, @Query("page") page: Int, @Query("size") size: Int): Page<PersonDto>
    @GET("api/v1/people/{id}") suspend fun person(@Path("id") id: Long): PersonDto
    @POST("api/v1/people") suspend fun createPerson(@Body r: PersonRequest): PersonDto
    @PUT("api/v1/people/{id}") suspend fun updatePerson(@Path("id") id: Long, @Body r: PersonRequest): PersonDto
    @GET("api/v1/people/{id}/timeline") suspend fun timeline(@Path("id") id: Long): List<TimelineEntry>

    // Transactions
    @GET("api/v1/transactions") suspend fun transactions(
        @Query("from") from: String?, @Query("to") to: String?, @Query("direction") direction: String?,
        @Query("method") method: String?, @Query("personId") personId: Long?, @Query("sourceType") sourceType: String?,
        @Query("q") q: String?, @Query("page") page: Int, @Query("size") size: Int,
    ): Page<TransactionDto>
    @GET("api/v1/transactions/summary") suspend fun summary(@Query("from") from: String?, @Query("to") to: String?): SummaryDto
    @GET("api/v1/transactions/{id}") suspend fun transaction(@Path("id") id: Long): TransactionDto
    @POST("api/v1/transactions") suspend fun createTransaction(@Body r: TransactionRequest): TransactionDto
    @POST("api/v1/transactions/{id}/reverse") suspend fun reverseTransaction(@Path("id") id: Long, @Body r: ReasonRequest): TransactionDto
    @POST("api/v1/transfers") suspend fun transfer(@Body r: TransferRequest): List<TransactionDto>
    @GET("api/v1/cheques") suspend fun cheques(@Query("status") status: String?): List<ChequeDto>
    @POST("api/v1/cheques/{id}/clear") suspend fun clearCheque(@Path("id") id: Long, @Body r: ChequeActionRequest): ChequeDto
    @POST("api/v1/cheques/{id}/bounce") suspend fun bounceCheque(@Path("id") id: Long, @Body r: ChequeActionRequest): ChequeDto

    // Inventory
    @GET("api/v1/products") suspend fun products(
        @Query("q") q: String?, @Query("category") category: String?, @Query("metal") metal: String?,
        @Query("purity") purity: String?, @Query("availability") availability: String?,
        @Query("page") page: Int, @Query("size") size: Int,
    ): Page<ProductDto>
    @GET("api/v1/products/{id}") suspend fun product(@Path("id") id: Long): ProductDto
    @POST("api/v1/products") suspend fun createProduct(@Body r: ProductRequest): ProductDto
    @PUT("api/v1/products/{id}") suspend fun updateProduct(@Path("id") id: Long, @Body r: ProductRequest): ProductDto
    @GET("api/v1/products/{id}/movements") suspend fun movements(@Path("id") id: Long, @Query("page") page: Int, @Query("size") size: Int): Page<MovementDto>
    @POST("api/v1/products/{id}/movements") suspend fun stockOperation(@Path("id") id: Long, @Body r: StockOperationRequest): MovementDto
    @GET("api/v1/products/{id}/images") suspend fun images(@Path("id") id: Long): List<ImageDto>
    @Multipart @POST("api/v1/products/{id}/images") suspend fun uploadImage(@Path("id") id: Long, @Part file: MultipartBody.Part): ImageDto
    @PUT("api/v1/products/{id}/images/order") suspend fun reorderImages(@Path("id") id: Long, @Body r: ReorderRequest): List<ImageDto>
    @PUT("api/v1/products/{id}/images/{imageId}/primary") suspend fun setPrimaryImage(@Path("id") id: Long, @Path("imageId") imageId: Long): List<ImageDto>
    @DELETE("api/v1/products/{id}/images/{imageId}") suspend fun deleteImage(@Path("id") id: Long, @Path("imageId") imageId: Long): List<ImageDto>
    @GET("api/v1/bar-lots") suspend fun barLots(@Query("metal") metal: String?, @Query("availableOnly") availableOnly: Boolean): List<BarLotDto>
    @POST("api/v1/bar-lots") suspend fun createBarLot(@Body r: BarLotRequest): BarLotDto
    @GET("api/v1/bar-lots/{id}/movements") suspend fun barMovements(@Path("id") id: Long): List<BarMovementDto>
    @POST("api/v1/bar-lots/{id}/adjust") suspend fun adjustBarLot(@Path("id") id: Long, @Body r: BarAdjustRequest): BarLotDto

    // Customer bills
    @GET("api/v1/customer-bills") suspend fun bills(
        @Query("type") type: String?, @Query("status") status: String?, @Query("personId") personId: Long?,
        @Query("from") from: String?, @Query("to") to: String?, @Query("q") q: String?,
        @Query("page") page: Int, @Query("size") size: Int,
    ): Page<BillDto>
    @GET("api/v1/customer-bills/{id}") suspend fun bill(@Path("id") id: Long): BillDto
    @POST("api/v1/customer-bills") suspend fun createBill(@Body r: BillRequest): BillDto
    @PUT("api/v1/customer-bills/{id}") suspend fun updateBill(@Path("id") id: Long, @Body r: BillRequest): BillDto
    @DELETE("api/v1/customer-bills/{id}") suspend fun deleteBill(@Path("id") id: Long): Response<Unit>
    @POST("api/v1/customer-bills/{id}/finalize") suspend fun finalizeBill(@Path("id") id: Long): BillDto
    @POST("api/v1/customer-bills/{id}/payments") suspend fun addBillPayment(@Path("id") id: Long, @Body r: BillPaymentRequest): BillDto
    @POST("api/v1/customer-bills/{id}/reverse") suspend fun reverseBill(@Path("id") id: Long, @Body r: ReasonRequest): BillDto

    // Dealers
    @GET("api/v1/dealers") suspend fun dealers(@Query("q") q: String?, @Query("page") page: Int, @Query("size") size: Int): Page<DealerDto>
    @GET("api/v1/dealers/{id}") suspend fun dealer(@Path("id") id: Long): DealerDto
    @POST("api/v1/dealers") suspend fun createDealer(@Body r: DealerRequest): DealerDto
    @PUT("api/v1/dealers/{id}") suspend fun updateDealer(@Path("id") id: Long, @Body r: DealerRequest): DealerDto
    @GET("api/v1/dealers/{id}/shops") suspend fun shops(@Path("id") id: Long): List<ShopDto>
    @POST("api/v1/dealers/{id}/shops") suspend fun addShop(@Path("id") id: Long, @Body r: ShopRequest): ShopDto
    @PUT("api/v1/dealers/{id}/shops/{shopId}") suspend fun updateShop(@Path("id") id: Long, @Path("shopId") shopId: Long, @Body r: ShopRequest): ShopDto
    @GET("api/v1/dealers/{id}/ledger") suspend fun ledger(@Path("id") id: Long, @Query("shopId") shopId: Long?): DealerLedger
    @GET("api/v1/dealer-bills") suspend fun dealerBills(
        @Query("dealerId") dealerId: Long?, @Query("shopId") shopId: Long?, @Query("metal") metal: String?,
        @Query("status") status: String?, @Query("q") q: String?, @Query("page") page: Int, @Query("size") size: Int,
    ): Page<DealerBillDto>
    @GET("api/v1/dealer-bills/{id}") suspend fun dealerBill(@Path("id") id: Long): DealerBillDto
    @POST("api/v1/dealer-bills") suspend fun createDealerBill(@Body r: DealerBillRequest): DealerBillDto
    @POST("api/v1/dealer-bills/{id}/settlements") suspend fun settle(@Path("id") id: Long, @Body r: SettlementRequest): DealerBillDto
    @POST("api/v1/dealer-bills/{id}/settlements/{sid}/reverse") suspend fun reverseSettlement(@Path("id") id: Long, @Path("sid") sid: Long, @Body r: ReasonRequest): DealerBillDto
    @POST("api/v1/dealer-bills/{id}/reverse") suspend fun reverseDealerBill(@Path("id") id: Long, @Body r: ReasonRequest): DealerBillDto
    @Streaming @GET("api/v1/dealer-bills/{id}/pdf") suspend fun dealerBillPdf(@Path("id") id: Long): ResponseBody

    // Loans
    @GET("api/v1/loans") suspend fun loans(@Query("kind") kind: String?, @Query("status") status: String?, @Query("personId") personId: Long?, @Query("q") q: String?, @Query("page") page: Int, @Query("size") size: Int): Page<LoanDto>
    @GET("api/v1/loans/{id}") suspend fun loan(@Path("id") id: Long): LoanDto
    @POST("api/v1/loans") suspend fun createLoan(@Body r: LoanRequest): LoanDto
    @POST("api/v1/loans/{id}/repayments") suspend fun repay(@Path("id") id: Long, @Body r: RepaymentRequest): LoanDto
    @PUT("api/v1/loans/{id}/expected-date") suspend fun loanExpectedDate(@Path("id") id: Long, @Body r: ExpectedDateRequest): LoanDto
    @POST("api/v1/loans/{id}/reverse") suspend fun reverseLoan(@Path("id") id: Long, @Body r: ReasonRequest): LoanDto

    // Mortgages
    @GET("api/v1/mortgage-accounts") suspend fun mortgageAccounts(@Query("q") q: String?, @Query("page") page: Int, @Query("size") size: Int): Page<AccountDto>
    @GET("api/v1/mortgage-accounts/{id}") suspend fun mortgageAccount(@Path("id") id: Long): AccountDto
    @POST("api/v1/mortgage-accounts") suspend fun createMortgageAccount(@Body r: AccountRequest): AccountDto
    @GET("api/v1/mortgages") suspend fun mortgages(@Query("kind") kind: String?, @Query("status") status: String?, @Query("accountId") accountId: Long?, @Query("personId") personId: Long?, @Query("q") q: String?, @Query("page") page: Int, @Query("size") size: Int): Page<MortgageDto>
    @GET("api/v1/mortgages/{id}") suspend fun mortgage(@Path("id") id: Long): MortgageDto
    @POST("api/v1/mortgages") suspend fun createMortgage(@Body r: MortgageRequest): MortgageDto
    @POST("api/v1/mortgages/{id}/calculate-interest") suspend fun calculateInterest(@Path("id") id: Long, @Body r: CalculateRequest): CalculationDto
    @POST("api/v1/mortgages/{id}/payments") suspend fun mortgagePayment(@Path("id") id: Long, @Body r: MortgagePaymentRequest): MortgageDto
    @POST("api/v1/mortgages/{id}/full-final") suspend fun fullFinal(@Path("id") id: Long, @Body r: FullFinalRequest): FullFinalResult
    @POST("api/v1/mortgages/{id}/jewellery-return") suspend fun jewelleryReturn(@Path("id") id: Long, @Body r: JewelleryReturnRequest): MortgageDto
    @PUT("api/v1/mortgages/{id}/reminder-date") suspend fun mortgageReminderDate(@Path("id") id: Long, @Body r: ReminderDateRequest): MortgageDto

    // Exchange
    @GET("api/v1/exchanges") suspend fun exchanges(@Query("status") status: String?, @Query("personId") personId: Long?, @Query("q") q: String?, @Query("page") page: Int, @Query("size") size: Int): Page<ExchangeDto>
    @GET("api/v1/exchanges/{id}") suspend fun exchange(@Path("id") id: Long): ExchangeDto
    @POST("api/v1/exchanges") suspend fun createExchange(@Body r: ExchangeRequest): ExchangeDto
    @PUT("api/v1/exchanges/{id}") suspend fun updateExchange(@Path("id") id: Long, @Body r: ExchangeRequest): ExchangeDto
    @DELETE("api/v1/exchanges/{id}") suspend fun deleteExchange(@Path("id") id: Long): Response<Unit>
    @POST("api/v1/exchanges/{id}/finalize") suspend fun finalizeExchange(@Path("id") id: Long): ExchangeDto
    @POST("api/v1/exchanges/{id}/reverse") suspend fun reverseExchange(@Path("id") id: Long, @Body r: ReasonRequest): ExchangeDto

    // Dues
    @GET("api/v1/dues") suspend fun dues(
        @Query("q") q: String?, @Query("direction") direction: String?, @Query("source") source: String?,
        @Query("state") state: String?, @Query("minAmount") minAmount: String?, @Query("expectedFrom") expectedFrom: String?,
        @Query("expectedTo") expectedTo: String?, @Query("page") page: Int, @Query("size") size: Int,
    ): DueOverview
    @GET("api/v1/dues/persons/{id}") suspend fun dueAccount(@Path("id") id: Long): PersonDueAccount

    // Reminders
    @GET("api/v1/reminders") suspend fun reminders(): List<ReminderDto>

    // Reports
    @POST("api/v1/reports") suspend fun requestReport(@Body r: ReportRequest): ReportJobDto
    @GET("api/v1/reports") suspend fun reportHistory(@Query("page") page: Int, @Query("size") size: Int): Page<ReportJobDto>
    @GET("api/v1/reports/{id}") suspend fun report(@Path("id") id: Long): ReportJobDto
    @POST("api/v1/reports/{id}/retry") suspend fun retryReport(@Path("id") id: Long): ReportJobDto
    @Streaming @GET("api/v1/reports/{id}/download") suspend fun downloadReport(@Path("id") id: Long): ResponseBody
    @Streaming @GET("api/v1/customer-bills/{id}/pdf") suspend fun billPdf(@Path("id") id: Long): ResponseBody

    // Audit
    @GET("api/v1/audit") suspend fun audit(@Query("entityType") entityType: String?, @Query("entityId") entityId: Long?, @Query("page") page: Int, @Query("size") size: Int): Page<AuditEventDto>
}
