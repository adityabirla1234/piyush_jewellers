package com.piyushjewellers.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.piyushjewellers.app.BuildConfig
import com.piyushjewellers.app.data.remote.TokenResponse
import com.piyushjewellers.app.data.remote.UserDto
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Tokens and the server address live in EncryptedSharedPreferences, never in plain storage or logs. */
class SessionStore(context: Context) {

    data class User(val username: String, val fullName: String?, val role: String)

    private val prefs: SharedPreferences = run {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context,
            "pj_session",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    private val _loggedIn = MutableStateFlow(prefs.getString(K_REFRESH, null) != null)
    val loggedIn: StateFlow<Boolean> = _loggedIn.asStateFlow()

    private val _expired = MutableStateFlow(false)
    /** True when the server rejected the refresh token; the UI shows a sign-in prompt. */
    val expired: StateFlow<Boolean> = _expired.asStateFlow()

    private val _baseUrl = MutableStateFlow(normalize(prefs.getString(K_BASE, null) ?: BuildConfig.DEFAULT_BASE_URL))
    val baseUrlFlow: StateFlow<String> = _baseUrl.asStateFlow()

    val accessToken: String? get() = prefs.getString(K_ACCESS, null)
    val refreshToken: String? get() = prefs.getString(K_REFRESH, null)
    val baseUrl: String get() = _baseUrl.value

    val user: User?
        get() = prefs.getString(K_USER, null)?.let { User(it, prefs.getString(K_NAME, null), prefs.getString(K_ROLE, "") ?: "") }

    fun saveTokens(t: TokenResponse) {
        prefs.edit()
            .putString(K_ACCESS, t.accessToken)
            .putString(K_REFRESH, t.refreshToken)
            .apply()
        updateUser(t.user)
        _expired.value = false
        _loggedIn.value = true
    }

    fun updateUser(user: UserDto) {
        prefs.edit()
            .putString(K_USER, user.username)
            .putString(K_NAME, user.fullName)
            .putString(K_ROLE, user.role)
            .apply()
    }

    fun updateAccessToken(accessToken: String) {
        prefs.edit().putString(K_ACCESS, accessToken).apply()
    }

    fun expire() {
        prefs.edit().remove(K_ACCESS).remove(K_REFRESH).apply()
        _expired.value = true
        _loggedIn.value = false
    }

    fun clear() {
        prefs.edit().remove(K_ACCESS).remove(K_REFRESH).remove(K_USER).remove(K_NAME).remove(K_ROLE).apply()
        _expired.value = false
        _loggedIn.value = false
    }

    fun setBaseUrl(url: String) {
        val n = normalize(url)
        prefs.edit().putString(K_BASE, n).apply()
        _baseUrl.value = n
    }

    var lastSyncAt: Long
        get() = prefs.getLong(K_LAST_SYNC, 0L)
        set(v) {
            prefs.edit().putLong(K_LAST_SYNC, v).apply()
        }

    companion object {
        private const val K_ACCESS = "access"
        private const val K_REFRESH = "refresh"
        private const val K_USER = "user"
        private const val K_NAME = "name"
        private const val K_ROLE = "role"
        private const val K_BASE = "base_url"
        private const val K_LAST_SYNC = "last_sync"

        fun normalize(url: String): String {
            val t = url.trim()
            if (t.isEmpty()) return ""
            return if (t.endsWith("/")) t else "$t/"
        }

        /** Release builds only talk HTTPS; debug builds may use the emulator loopback over HTTP. */
        fun validate(url: String): String? {
            val t = url.trim()
            if (t.isEmpty()) return "Enter the server address"
            val parsed = runCatching { java.net.URI(t) }.getOrNull() ?: return "Invalid address"
            if (parsed.host.isNullOrBlank()) return "Invalid address"
            if (parsed.scheme == "https") return null
            if (parsed.scheme == "http" && BuildConfig.ALLOW_CLEARTEXT) return null
            return "The server address must start with https://"
        }
    }
}
