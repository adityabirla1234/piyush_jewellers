package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.remote.NotificationDto
import com.piyushjewellers.app.data.remote.ReportRequest
import com.piyushjewellers.app.data.remote.SpBucket
import com.piyushjewellers.app.data.remote.SpRow
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.theme.PJColors

// ---------------------------------------------------------------- Shared

@Composable
private fun DateRangeRow(from: String?, to: String?, onFrom: (String?) -> Unit, onTo: (String?) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DateInput("From", Fmt.parseDate(from), { onFrom(it?.toString()) }, Modifier.weight(1f))
        DateInput("To", Fmt.parseDate(to), { onTo(it?.toString()) }, Modifier.weight(1f))
    }
}

@Composable
private fun QuickRanges(onPick: (String, String) -> Unit) {
    val today = Fmt.today()
    val ranges = listOf(
        "Today" to (today to today),
        "This month" to (today.withDayOfMonth(1) to today),
        "Last month" to (today.minusMonths(1).withDayOfMonth(1) to today.withDayOfMonth(1).minusDays(1)),
        "This FY" to ((if (today.monthValue >= 4) today.withMonth(4).withDayOfMonth(1) else today.minusYears(1).withMonth(4).withDayOfMonth(1)) to today),
    )
    ChoiceChips(ranges.map { it.first }, null, { it }, { label ->
        ranges.first { it.first == label }.second.let { (f, t) -> onPick(f.toString(), t.toString()) }
    })
}

private fun bucketHint(b: SpBucket) = "${b.count} bill(s) · ${Fmt.grams(b.netWeight)}"

// ---------------------------------------------------------------- Sell & Purchase

@Composable
fun SellPurchaseScreen() {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("sell-purchase")
    var metal by rememberSaveable { mutableStateOf<String?>(null) }
    var kind by rememberSaveable { mutableStateOf<String?>(null) }
    var source by rememberSaveable { mutableStateOf<String?>(null) }
    var from by rememberSaveable { mutableStateOf<String?>(Fmt.today().withDayOfMonth(1).toString()) }
    var to by rememberSaveable { mutableStateOf<String?>(Fmt.today().toString()) }
    var progress by remember { mutableStateOf<String?>(null) }
    var ready by remember { mutableStateOf<ReadyPdf?>(null) }
    val vm = loadVm("sp:$metal:$kind:$source:$from:$to") { sellPurchase(metal, from, to, kind, source) }

    PJScaffold(
        title = "Sell & Purchase",
        subtitle = "${Fmt.date(from)} – ${Fmt.date(to)}",
        topLevel = true,
        busy = actions.busy,
        actions = {
            IconButton(onClick = {
                val f = Fmt.parseDate(from); val t = Fmt.parseDate(to)
                if (f != null && t != null && f.isAfter(t)) { c.toast("From date is after To date"); return@IconButton }
                val label = listOfNotNull("${Fmt.date(from)} – ${Fmt.date(to)}", metal?.let(Fmt::humanize) ?: "Gold & Silver").joinToString(" · ")
                actions.run({ generateServerReport(c, ReportRequest("SELL_PURCHASE", from, to, metal = metal, filterLabel = label)) { progress = it } }) { ready = it }
            }, enabled = !actions.busy) { Icon(Icons.Filled.PictureAsPdf, "Generate PDF") }
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ChoiceChips(listOf(null, "GOLD", "SILVER"), metal, { it?.let(Fmt::humanize) ?: "Gold & Silver" }, { metal = it })
                ChoiceChips(listOf(null, "SALES", "PURCHASE"), kind, { when (it) { "SALES" -> "Sell"; "PURCHASE" -> "Purchase"; else -> "Sell & Purchase" } }, { kind = it })
                ChoiceChips(listOf(null, "CUSTOMER", "DEALER"), source, { when (it) { "CUSTOMER" -> "Customers"; "DEALER" -> "Dealers"; else -> "Everyone" } }, { source = it })
                DateRangeRow(from, to, { from = it }, { to = it })
                QuickRanges { f, t -> from = f; to = t }
                progress?.let { Text(it, color = PJColors.GoldDeep, style = MaterialTheme.typography.bodySmall) }
            }
            LoadContent(vm.state, onRetry = { vm.reload() }, refreshing = vm.refreshing, onRefresh = { vm.reload() }) { r ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("Total sell", Fmt.rupees(r.sales.amount), Modifier.weight(1f), hint = bucketHint(r.sales), accent = PJColors.Success)
                            StatCard("Total purchase", Fmt.rupees(r.purchase.amount), Modifier.weight(1f), hint = bucketHint(r.purchase), accent = PJColors.Danger)
                        }
                    }
                    item {
                        SectionCard("Totals") {
                            InfoRow("Total amount (sell + purchase)", Fmt.rupees(r.totalAmount), emphasize = true)
                            InfoRow("Sell − purchase", Fmt.rupees(r.net), valueColor = if (r.net.signum() < 0) PJColors.Danger else PJColors.Success)
                            if (r.sales.fineWeight.signum() > 0 || r.purchase.fineWeight.signum() > 0) {
                                InfoRow("Dealer fine weight sold / bought", "${Fmt.grams(r.sales.fineWeight)} / ${Fmt.grams(r.purchase.fineWeight)}")
                            }
                            if (metal == null && r.byMetal.isNotEmpty()) {
                                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                                r.byMetal.forEach { m ->
                                    InfoRow("${Fmt.humanize(m.metal)} sell", "${Fmt.rupees(m.sales.amount)} · ${Fmt.grams(m.sales.netWeight)}")
                                    InfoRow("${Fmt.humanize(m.metal)} purchase", "${Fmt.rupees(m.purchase.amount)} · ${Fmt.grams(m.purchase.netWeight)}")
                                }
                            }
                        }
                    }
                    item { Text("BILLS (${r.rows.size})", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary) }
                    if (r.rows.isEmpty()) item { EmptyState("No bills in this range", "Change the metal or dates. Only finalized customer bills and active dealer bills are counted.", Icons.Filled.SwapVert) }
                    items(r.rows, key = { "${it.source}-${it.id}" }) { row ->
                        SpRowCard(row) {
                            if (row.source == "CUSTOMER") nav.navigate(R.BillDetail(row.id)) else nav.navigate(R.DealerBillDetail(row.id))
                        }
                    }
                }
            }
        }
    }
    ReadyPdfDialog(ready) { ready = null }
    ActionErrorDialog(actions)
}

@Composable
private fun SpRowCard(row: SpRow, onClick: () -> Unit) {
    val sell = row.kind == "SALES"
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row {
                Text("${row.billNumber ?: "—"} · ${row.partyName ?: "—"}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(Fmt.rupees(row.amount), color = if (sell) PJColors.Success else PJColors.Danger, fontWeight = FontWeight.SemiBold)
            }
            Text(
                listOfNotNull(
                    if (sell) "Sell" else "Purchase", if (row.source == "CUSTOMER") "Customer" else "Dealer", Fmt.date(row.date),
                    row.metal?.let(Fmt::humanize), row.netWeight?.let { "Net ${Fmt.grams(it)}" }, row.fineWeight?.let { "Fine ${Fmt.grams(it)}" },
                ).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row {
                Text(row.outstanding?.takeIf { it.signum() > 0 }?.let { "Due ${Fmt.rupees(it)}" } ?: "Settled", Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall, color = if ((row.outstanding?.signum() ?: 0) > 0) PJColors.Warning else PJColors.Success)
                StatusChip(row.status)
            }
        }
    }
}

// ---------------------------------------------------------------- Turnover

@Composable
fun TurnoverScreen() {
    val c = container()
    val actions = actionVm("turnover")
    var from by rememberSaveable { mutableStateOf<String?>(Fmt.today().withDayOfMonth(1).toString()) }
    var to by rememberSaveable { mutableStateOf<String?>(Fmt.today().toString()) }
    var progress by remember { mutableStateOf<String?>(null) }
    var ready by remember { mutableStateOf<ReadyPdf?>(null) }
    val expanded = remember { mutableStateListOf<String>() }
    val vm = loadVm("turnover:$from:$to") { turnover(from, to) }

    PJScaffold(
        title = "Shop Turnover",
        subtitle = "${Fmt.date(from)} – ${Fmt.date(to)}",
        topLevel = true,
        busy = actions.busy,
        actions = {
            IconButton(onClick = {
                val f = Fmt.parseDate(from); val t = Fmt.parseDate(to)
                if (f != null && t != null && f.isAfter(t)) { c.toast("From date is after To date"); return@IconButton }
                actions.run({ generateServerReport(c, ReportRequest("TURNOVER", from, to, filterLabel = "${Fmt.date(from)} – ${Fmt.date(to)}")) { progress = it } }) { ready = it }
            }, enabled = !actions.busy) { Icon(Icons.Filled.PictureAsPdf, "Generate PDF") }
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                DateRangeRow(from, to, { from = it }, { to = it })
                QuickRanges { f, t -> from = f; to = t }
                progress?.let { Text(it, color = PJColors.GoldDeep, style = MaterialTheme.typography.bodySmall) }
            }
            LoadContent(vm.state, onRetry = { vm.reload() }, refreshing = vm.refreshing, onRefresh = { vm.reload() }) { t ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        SectionCard("Turnover") {
                            InfoRow("Gross turnover", Fmt.rupees(t.grossTurnover), emphasize = true)
                            InfoRow("Sales turnover", "${Fmt.rupees(t.salesTurnover)} · ${t.sales.count} bill(s)", valueColor = PJColors.Success)
                            InfoRow("Purchase turnover", "${Fmt.rupees(t.purchaseTurnover)} · ${t.purchase.count} bill(s)", valueColor = PJColors.Danger)
                            t.byMetal.forEach { m ->
                                InfoRow(Fmt.humanize(m.metal), "Sell ${Fmt.rupees(m.sales.amount)} · Buy ${Fmt.rupees(m.purchase.amount)}")
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("Money in", Fmt.rupees(t.moneyIn), Modifier.weight(1f), accent = PJColors.Success)
                            StatCard("Money out", Fmt.rupees(t.moneyOut), Modifier.weight(1f), accent = PJColors.Danger)
                        }
                    }
                    item {
                        SectionCard("Balance") {
                            InfoRow("Opening balance", Fmt.rupees(t.openingBalance))
                            InfoRow("Net cash flow", Fmt.rupees(t.net, showSign = true), valueColor = if (t.net.signum() < 0) PJColors.Danger else PJColors.Success)
                            InfoRow("Closing balance", Fmt.rupees(t.closingBalance), emphasize = true)
                            InfoRow("Available (cleared)", Fmt.rupees(t.availableBalance))
                            InfoRow("Pending cheques in / out", "${Fmt.rupees(t.pendingChequesIn)} / ${Fmt.rupees(t.pendingChequesOut)}")
                            if (t.transfersMoved.signum() > 0) InfoRow("Moved between own accounts", Fmt.rupees(t.transfersMoved) + " (not counted)")
                        }
                    }
                    item { Text("MONEY IN & OUT BY COMPONENT", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary) }
                    if (t.components.isEmpty()) item { EmptyState("No money movement", "Nothing came in or went out in this range.", Icons.Filled.Insights) }
                    items(t.components, key = { it.source }) { comp ->
                        val open = comp.source in expanded
                        SectionCard(
                            comp.label,
                            trailing = {
                                androidx.compose.material3.TextButton(onClick = { if (open) expanded.remove(comp.source) else expanded.add(comp.source) }) {
                                    Text(if (open) "Hide" else "Details")
                                }
                            },
                        ) {
                            InfoRow("In", Fmt.rupees(comp.moneyIn), valueColor = PJColors.Success)
                            InfoRow("Out", Fmt.rupees(comp.moneyOut), valueColor = PJColors.Danger)
                            InfoRow("Net · ${comp.count} entr${if (comp.count == 1L) "y" else "ies"}", Fmt.rupees(comp.net, showSign = true))
                            if (open) {
                                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                                comp.lines.forEach { l ->
                                    InfoRow(l.category, listOfNotNull(
                                        l.moneyIn.takeIf { it.signum() > 0 }?.let { "+${Fmt.rupees(it)}" },
                                        l.moneyOut.takeIf { it.signum() > 0 }?.let { "−${Fmt.rupees(it)}" },
                                    ).joinToString(" / ").ifBlank { "—" })
                                }
                            }
                        }
                    }
                    if (t.byMethod.isNotEmpty()) {
                        item {
                            SectionCard("By payment method") {
                                t.byMethod.forEach { m -> InfoRow(Fmt.method(m.method), "In ${Fmt.rupees(m.moneyIn)} · Out ${Fmt.rupees(m.moneyOut)}") }
                                Text("Includes transfers between your own accounts.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    item { Spacer(Modifier.height(8.dp)) }
                }
            }
        }
    }
    ReadyPdfDialog(ready) { ready = null }
    ActionErrorDialog(actions)
}

// ---------------------------------------------------------------- Notifications

private fun categoryLabel(cat: String) = when (cat) {
    "REMINDER" -> "Reminder"
    "LOAN" -> "Loan due"
    "MORTGAGE" -> "Mortgage"
    "CHEQUE" -> "Cheque"
    else -> Fmt.humanize(cat)
}

@Composable
fun NotificationsScreen() {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("notifications")
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var version by remember { mutableIntStateOf(0) }
    val unreadOnly = tab == 0
    val vm = loadVm("notifications:$unreadOnly:$version") { notifications(unreadOnly) }

    fun open(n: NotificationDto) {
        if (!n.read) actions.run({ markNotificationRead(n.id) }) { version++ }
        when (n.category) {
            "LOAN" -> n.sourceId?.let { nav.navigate(R.LoanDetail(it)) }
            "MORTGAGE" -> n.sourceId?.let { nav.navigate(R.MortgageDetail(it)) }
            "CHEQUE" -> nav.navigate(R.Cheques)
            else -> n.personId?.let { nav.navigate(R.PersonDetail(it)) }
        }
    }

    PJScaffold(
        title = "Notifications",
        topLevel = true,
        busy = actions.busy,
        actions = {
            IconButton(onClick = { actions.run({ markAllNotificationsRead() }) { version++; c.toast("All marked as read") } }, enabled = !actions.busy) {
                Icon(Icons.Filled.DoneAll, "Mark all read")
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Unread") })
                Tab(tab == 1, { tab = 1 }, text = { Text("All") })
            }
            LoadContent(vm.state, onRetry = { vm.reload() }, refreshing = vm.refreshing, onRefresh = { vm.reload() }) { page ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                    if (page.content.isEmpty()) {
                        item {
                            EmptyState(
                                if (unreadOnly) "You're all caught up" else "No notifications yet",
                                "Due reminders, overdue loans, mortgage reminder dates and cheques due for deposit appear here.",
                                Icons.Filled.NotificationsNone,
                            )
                        }
                    }
                    items(page.content, key = { it.id }) { n ->
                        ListRow(
                            title = n.title,
                            subtitle = listOfNotNull(categoryLabel(n.category), n.dueAt?.let(Fmt::dateTime), n.body).joinToString(" · "),
                            leading = {
                                Icon(
                                    if (n.read) Icons.Filled.NotificationsNone else Icons.Filled.Notifications, null,
                                    tint = if (n.read) MaterialTheme.colorScheme.onSurfaceVariant else PJColors.Gold,
                                )
                            },
                            trailingBottom = if (!n.read) ({
                                androidx.compose.material3.TextButton(onClick = { actions.run({ markNotificationRead(n.id) }) { version++ } }) { Text("Mark read") }
                            }) else null,
                            onClick = { open(n) },
                        )
                        HorizontalDivider(Modifier.padding(horizontal = 16.dp))
                    }
                }
            }
        }
    }
    ActionErrorDialog(actions)
}
