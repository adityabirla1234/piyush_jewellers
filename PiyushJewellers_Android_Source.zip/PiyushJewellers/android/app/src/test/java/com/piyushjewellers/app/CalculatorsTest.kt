package com.piyushjewellers.app

import com.piyushjewellers.app.core.BillCalc
import com.piyushjewellers.app.core.Carat
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.MetalCalc
import com.piyushjewellers.app.core.Num
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal

class CalculatorsTest {

    private fun bd(s: String) = BigDecimal(s)

    @Test
    fun goldFinalWeightMatchesSpecExample() {
        val final = MetalCalc.goldFinal(bd("1.440"), Carat.K20, bd("4"))
        assertEquals(0, final.compareTo(bd("1.2672")))
    }

    @Test
    fun silverFinalWeightMatchesSpecExample() {
        val net = MetalCalc.net(bd("1000"), bd("20"))
        assertEquals(0, net.compareTo(bd("980")))
        assertEquals(0, MetalCalc.silverFinal(net, bd("4")).compareTo(bd("1019.2")))
    }

    @Test
    fun amountIsFinalWeightTimesRate() {
        assertEquals(0, MetalCalc.amount(bd("8.8"), bd("7000"))!!.compareTo(bd("61600")))
        assertNull(MetalCalc.amount(bd("8.8"), null))
    }

    @Test
    fun settlementExampleBalancesExactly() {
        val bar = MetalCalc.barValue(bd("5"), bd("7000"))
        val cashWeight = MetalCalc.weightEquivalent(bd("26600"), bd("7000"))!!
        assertEquals(0, bar.compareTo(bd("35000")))
        assertEquals(0, bd("5").add(cashWeight).compareTo(bd("8.8")))
    }

    @Test
    fun netNeverNegative() {
        assertEquals(0, MetalCalc.net(bd("1"), bd("2")).signum())
    }

    @Test
    fun indianGrouping() {
        assertEquals("₹12,34,567.89", Fmt.rupees(bd("1234567.89")))
        assertEquals("₹999.00", Fmt.rupees(bd("999")))
        assertEquals("−₹1,00,000.00", Fmt.rupees(bd("-100000")))
    }

    @Test
    fun billBlankMakingIsDetectedAndNotAssumedZeroSilently() {
        val lines = listOf(BillCalc.Line(bd("10"), bd("6000"), null), BillCalc.Line(bd("2"), bd("6000"), bd("500")))
        assertTrue(BillCalc.hasBlankMaking(lines))
        assertEquals(0, BillCalc.grandTotal(lines).compareTo(bd("72500")))
    }

    @Test
    fun parseRejectsGarbage() {
        assertNull(Num.parse("12.3.4"))
        assertNull(Num.parse(" "))
        assertEquals(0, Num.parse("₹1,200.50")!!.compareTo(bd("1200.50")))
    }
}
