package com.piyushjewellers.app.data.remote

import com.piyushjewellers.app.BuildConfig
import com.piyushjewellers.app.data.SessionStore
import kotlinx.serialization.json.Json
import okhttp3.Authenticator
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.Route
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit

val AppJson: Json = Json {
    ignoreUnknownKeys = true
    explicitNulls = false
    encodeDefaults = true
    coerceInputValues = true
    isLenient = true
}

val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

/** A user-presentable error. [kind] drives whether the UI offers retry or offline queueing. */
class AppException(
    val kind: Kind,
    override val message: String,
    val code: String? = null,
    val status: Int = 0,
    val fieldErrors: Map<String, String> = emptyMap(),
    val retryable: Boolean = false,
) : Exception(message) {
    enum class Kind { OFFLINE, UNAUTHORIZED, VALIDATION, CONFLICT, NOT_FOUND, SERVER, UNKNOWN }

    val isOffline get() = kind == Kind.OFFLINE

    companion object {
        fun fromHttp(status: Int, body: String?): AppException {
            val parsed = body?.takeIf { it.isNotBlank() }?.let { runCatching { AppJson.decodeFromString(ApiErrorDto.serializer(), it) }.getOrNull() }
            val kind = when (status) {
                401 -> Kind.UNAUTHORIZED
                400, 422 -> Kind.VALIDATION
                404 -> Kind.NOT_FOUND
                409 -> Kind.CONFLICT
                in 500..599 -> Kind.SERVER
                else -> Kind.UNKNOWN
            }
            val message = parsed?.message?.takeIf { it.isNotBlank() } ?: when (kind) {
                Kind.UNAUTHORIZED -> "Your session has expired. Please sign in again."
                Kind.NOT_FOUND -> "This record no longer exists."
                Kind.CONFLICT -> "This record was changed elsewhere. Reload and try again."
                Kind.SERVER -> "The server had a problem. Please try again."
                else -> "Request failed ($status)."
            }
            val fields = parsed?.fieldErrors.orEmpty().mapNotNull { f -> f.field?.let { it to (f.message ?: "Invalid") } }.toMap()
            return AppException(kind, message, parsed?.code, status, fields, parsed?.retryable ?: (status >= 500 || status == 429))
        }

        fun offline() = AppException(Kind.OFFLINE, "You are offline. Check the internet connection.", retryable = true)
    }
}

/** Converts transport and HTTP failures into [AppException]. */
suspend fun <T> apiCall(block: suspend () -> T): T = try {
    block()
} catch (e: AppException) {
    throw e
} catch (e: HttpException) {
    throw AppException.fromHttp(e.code(), runCatching { e.response()?.errorBody()?.string() }.getOrNull())
} catch (e: IOException) {
    throw AppException.offline()
} catch (e: kotlinx.serialization.SerializationException) {
    throw AppException(AppException.Kind.UNKNOWN, "Unexpected response from the server.")
}

/** Adds the bearer token and an Idempotency-Key on every mutating request that does not already carry one. */
class AuthInterceptor(private val session: SessionStore) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val b = original.newBuilder()
        val token = session.accessToken
        val isAuthEndpoint = original.url.encodedPath.contains("/api/v1/auth/login") || original.url.encodedPath.contains("/api/v1/auth/refresh")
        if (token != null && !isAuthEndpoint && original.header("Authorization") == null) {
            b.header("Authorization", "Bearer $token")
        }
        if (original.method != "GET" && original.header("Idempotency-Key") == null && !isAuthEndpoint) {
            b.header("Idempotency-Key", UUID.randomUUID().toString())
        }
        b.header("Accept", "application/json, application/pdf, image/*")
        return chain.proceed(b.build())
    }
}

/** On 401, refreshes once using the stored refresh token; clears the session if that fails. */
class TokenAuthenticator(private val session: SessionStore, private val baseUrl: () -> String) : Authenticator {
    private val plain = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    override fun authenticate(route: Route?, response: Response): Request? {
        if (response.request.url.encodedPath.contains("/api/v1/auth/")) return null
        if (responseCount(response) >= 2) return null
        synchronized(this) {
            val sentToken = response.request.header("Authorization")?.removePrefix("Bearer ")
            val current = session.accessToken
            if (current != null && current != sentToken) {
                return response.request.newBuilder().header("Authorization", "Bearer $current").build()
            }
            val refresh = session.refreshToken ?: run { session.expire(); return null }
            val body = AppJson.encodeToString(RefreshRequest.serializer(), RefreshRequest(refresh)).toRequestBody(JSON_MEDIA)
            val req = Request.Builder().url(baseUrl().trimEnd('/') + "/api/v1/auth/refresh").post(body).build()
            return try {
                plain.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) {
                        if (r.code == 401 || r.code == 400) session.expire()
                        return null
                    }
                    val tokens = AppJson.decodeFromString(TokenResponse.serializer(), r.body!!.string())
                    session.saveTokens(tokens)
                    response.request.newBuilder().header("Authorization", "Bearer ${tokens.accessToken}").build()
                }
            } catch (e: IOException) {
                null
            }
        }
    }

    private fun responseCount(response: Response): Int {
        var r: Response? = response
        var count = 1
        while (r?.priorResponse != null) {
            count++
            r = r.priorResponse
        }
        return count
    }
}

object NetworkFactory {
    fun client(session: SessionStore, baseUrl: () -> String): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .addInterceptor(AuthInterceptor(session))
            .authenticator(TokenAuthenticator(session, baseUrl))
        if (BuildConfig.DEBUG) {
            // Headers only would leak tokens; BASIC logs method, path and status without bodies or personal data.
            builder.addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BASIC })
        }
        return builder.build()
    }

    fun api(client: OkHttpClient, baseUrl: String): PjApi = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(client)
        .addConverterFactory(AppJson.asConverterFactory(JSON_MEDIA))
        .build()
        .create(PjApi::class.java)
}
