package com.piyushjewellers.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.piyushjewellers.app.R

object PJColors {
    val Onyx = Color(0xFF0B0908)
    val OnyxRaised = Color(0xFF1E1815)
    val OnyxLine = Color(0xFF3A302A)
    val Gold = Color(0xFFD4AF37)
    val GoldBright = Color(0xFFF1D27A)
    val GoldDeep = Color(0xFF8C6D1F)
    val GoldSoft = Color(0xFFF3E3B0)
    val Champagne = Color(0xFFF7EEDB)
    val Ivory = Color(0xFFFFFBF3)
    val IvoryDeep = Color(0xFFF6EEDF)
    val Ink = Color(0xFF1F1915)
    val Success = Color(0xFF2E7D32)
    val Warning = Color(0xFFB26A00)
    val Danger = Color(0xFFB3261E)
    val Info = Color(0xFF1F5FA8)
}

object PJBrush {
    val GoldFoil = Brush.linearGradient(listOf(Color(0xFFB8892B), PJColors.GoldBright, Color(0xFFD4AF37), Color(0xFFA67C1E)))
    val GoldHairline = Brush.horizontalGradient(listOf(Color.Transparent, PJColors.GoldDeep, PJColors.GoldBright, PJColors.GoldDeep, Color.Transparent))
    val OnyxBar = Brush.verticalGradient(listOf(PJColors.OnyxRaised, PJColors.Onyx))
    val OnyxHero = Brush.linearGradient(listOf(Color(0xFF241C17), PJColors.Onyx, Color(0xFF16110D)))
    val Scrim = Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC0B0908)))
}

private val LightColors = lightColorScheme(
    primary = PJColors.Ink,
    onPrimary = PJColors.GoldBright,
    primaryContainer = PJColors.GoldSoft,
    onPrimaryContainer = Color(0xFF3A2C05),
    secondary = PJColors.GoldDeep,
    onSecondary = Color.White,
    secondaryContainer = PJColors.GoldSoft,
    onSecondaryContainer = Color(0xFF2B1D00),
    tertiary = Color(0xFF7A5C10),
    onTertiary = Color.White,
    background = PJColors.Ivory,
    onBackground = PJColors.Ink,
    surface = PJColors.Ivory,
    onSurface = PJColors.Ink,
    surfaceVariant = PJColors.IvoryDeep,
    onSurfaceVariant = Color(0xFF5E5249),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFFFF8EC),
    surfaceContainer = Color(0xFFFBF2E4),
    surfaceContainerHigh = Color(0xFFF6EBDA),
    surfaceContainerHighest = Color(0xFFF0E3CF),
    outline = Color(0xFFB8A48A),
    outlineVariant = Color(0xFFE8DCC4),
    error = PJColors.Danger,
    onError = Color.White,
)

private val DarkColors = darkColorScheme(
    primary = PJColors.Gold,
    onPrimary = Color(0xFF1A1305),
    primaryContainer = Color(0xFF3A2E12),
    onPrimaryContainer = PJColors.GoldSoft,
    secondary = Color(0xFFE0C060),
    onSecondary = Color(0xFF2B1D00),
    secondaryContainer = Color(0xFF4A3A12),
    onSecondaryContainer = PJColors.GoldSoft,
    tertiary = Color(0xFFE6C66A),
    onTertiary = Color(0xFF2B1D00),
    background = Color(0xFF0E0B0A),
    onBackground = Color(0xFFF3EADF),
    surface = Color(0xFF0E0B0A),
    onSurface = Color(0xFFF3EADF),
    surfaceVariant = Color(0xFF2A221D),
    onSurfaceVariant = Color(0xFFCDBFAE),
    surfaceContainerLowest = Color(0xFF17120F),
    surfaceContainerLow = Color(0xFF1A1411),
    surfaceContainer = Color(0xFF1C1613),
    surfaceContainerHigh = Color(0xFF241D19),
    surfaceContainerHighest = Color(0xFF2C241F),
    outline = Color(0xFF8F8170),
    outlineVariant = PJColors.OnyxLine,
)

@OptIn(ExperimentalTextApi::class)
private fun variable(res: Int, weight: Int) =
    Font(res, FontWeight(weight), variationSettings = FontVariation.Settings(FontVariation.weight(weight)))

val Playfair = FontFamily(
    variable(R.font.playfair_display, 400),
    variable(R.font.playfair_display, 500),
    variable(R.font.playfair_display, 600),
    variable(R.font.playfair_display, 700),
)

val Cinzel = FontFamily(
    variable(R.font.cinzel, 400),
    variable(R.font.cinzel, 600),
    variable(R.font.cinzel, 700),
)

private val AppTypography = Typography().let { t ->
    t.copy(
        displaySmall = t.displaySmall.copy(fontFamily = Playfair, fontWeight = FontWeight.SemiBold),
        headlineLarge = t.headlineLarge.copy(fontFamily = Playfair, fontWeight = FontWeight.SemiBold),
        headlineMedium = t.headlineMedium.copy(fontFamily = Playfair, fontWeight = FontWeight.SemiBold),
        headlineSmall = t.headlineSmall.copy(fontFamily = Playfair, fontWeight = FontWeight.SemiBold),
        titleLarge = t.titleLarge.copy(fontFamily = Playfair, fontWeight = FontWeight.SemiBold),
        titleMedium = t.titleMedium.copy(fontFamily = Playfair, fontWeight = FontWeight.SemiBold, fontSize = 17.sp),
        labelLarge = t.labelLarge.copy(letterSpacing = 0.4.sp),
    )
}

val MoneyStyle = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp)

/** Brand wordmark lettering, matching the logo. */
val BrandStyle = TextStyle(fontFamily = Cinzel, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)

@Composable
fun PJTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, typography = AppTypography, content = content)
}
