package com.piyushjewellers.app.ui.screens

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.local.LocalReminder
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.theme.PJColors
import java.time.Instant
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.util.UUID

/** Tracks notification permission and exact-alarm access, refreshing when the user returns from system settings. */
@Composable
private fun rememberNotificationAccess(): Triple<Boolean, Boolean, () -> Unit> {
    val c = container()
    val context = LocalContext.current
    var granted by remember { mutableStateOf(c.reminderScheduler.canNotify()) }
    var exact by remember { mutableStateOf(exactAlarmsAllowed(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                granted = c.reminderScheduler.canNotify()
                exact = exactAlarmsAllowed(context)
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val request: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    return Triple(granted, exact, request)
}

private fun exactAlarmsAllowed(context: android.content.Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.S || context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

@Composable
private fun NotificationBanners(granted: Boolean, exact: Boolean, request: () -> Unit) {
    val context = LocalContext.current
    if (!granted) {
        Column(Modifier.fillMaxWidth().background(PJColors.GoldSoft.copy(alpha = 0.6f)).padding(16.dp)) {
            Text("Notifications are off", style = MaterialTheme.typography.titleSmall)
            Text("Reminders are saved but you won't be alerted until notifications are allowed.", style = MaterialTheme.typography.bodySmall)
            Row {
                TextButton(onClick = request) { Text("Allow") }
                TextButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
                }) { Text("Open settings") }
            }
        }
    } else if (!exact && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(16.dp)) {
            Text("Reminders may arrive a few minutes late. Allow exact alarms for on-time alerts.", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")))
            }) { Text("Allow exact alarms") }
        }
    }
}

@Composable
fun RemindersScreen() {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("reminders")
    val reminders by c.repo.observeReminders().collectAsState(initial = null)
    val (granted, exact, request) = rememberNotificationAccess()
    var deleting by remember { mutableStateOf<LocalReminder?>(null) }
    LaunchedEffect(Unit) { if (!granted) request() }
    PJScaffold(
        title = "Reminders",
        topLevel = true,
        busy = actions.busy,
        actions = {
            IconButton(onClick = { actions.run({ pullReminders() }) { c.toast("Reminders restored from server") } }) { Icon(Icons.Filled.CloudDownload, "Restore from server") }
        },
        fab = { ExtendedFloatingActionButton(onClick = { nav.navigate(R.ReminderEditor()) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Reminder") }) },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            NotificationBanners(granted, exact, request)
            val list = reminders
            if (list == null) {
                LoadingState()
            } else {
                val now = System.currentTimeMillis()
                val upcoming = list.filter { it.remindAt >= now }
                val past = list.filter { it.remindAt < now }.sortedByDescending { it.remindAt }
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                    if (list.isEmpty()) item { EmptyState("No reminders", "Set reminders for dues, mortgages and follow-ups. They alert you on this device.", Icons.Filled.Notifications) }
                    if (upcoming.isNotEmpty()) item { SectionHeader("Upcoming") }
                    items(upcoming, key = { it.key }) { r -> ReminderRow(r, onToggle = { on -> actions.run({ saveReminder(r.copy(enabled = on)) }) }, onDelete = { deleting = r }) { nav.navigate(R.ReminderEditor(key = r.key)) } }
                    if (past.isNotEmpty()) item { SectionHeader("Past") }
                    items(past, key = { it.key }) { r -> ReminderRow(r, onToggle = null, onDelete = { deleting = r }) { nav.navigate(R.ReminderEditor(key = r.key)) } }
                }
            }
        }
    }
    deleting?.let { r ->
        ConfirmDialog("Delete reminder?", "\"${r.title}\" will be removed from this device and the server backup.", "Delete", destructive = true,
            onConfirm = { actions.run({ deleteReminder(r.key) }) { deleting = null } }, onDismiss = { deleting = null })
    }
    ActionErrorDialog(actions)
}

@Composable
private fun ReminderRow(r: LocalReminder, onToggle: ((Boolean) -> Unit)?, onDelete: () -> Unit, onClick: () -> Unit) {
    ListRow(
        title = r.title,
        subtitle = listOfNotNull(Fmt.epoch(r.remindAt), Fmt.humanize(r.sourceType).takeIf { r.sourceType != "CUSTOM" }, r.notes, r.firedAt?.let { "Alerted ${Fmt.epoch(it)}" }).joinToString(" · "),
        leading = { Icon(Icons.Filled.Notifications, null, tint = if (r.enabled) PJColors.Gold else MaterialTheme.colorScheme.outline) },
        trailingBottom = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onToggle != null) Switch(checked = r.enabled, onCheckedChange = onToggle)
                IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete") }
            }
        },
        onClick = onClick,
    )
}

@Composable
fun ReminderEditorScreen(route: R.ReminderEditor) {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("reminder-editor")
    val key = rememberSaveable { route.key ?: UUID.randomUUID().toString() }
    val zone = ZoneId.systemDefault()
    var loaded by rememberSaveable { mutableStateOf(route.key == null) }
    var title by rememberSaveable { mutableStateOf(route.title.orEmpty()) }
    var notes by rememberSaveable { mutableStateOf("") }
    var enabled by rememberSaveable { mutableStateOf(true) }
    var sourceType by rememberSaveable { mutableStateOf(route.sourceType) }
    var sourceId by rememberSaveable { mutableStateOf(route.sourceId) }
    var personId by rememberSaveable { mutableStateOf(route.personId) }
    var at by rememberSaveable {
        mutableStateOf(
            Fmt.parseDate(route.date)?.atTime(LocalTime.of(10, 0))?.takeIf { it.isAfter(LocalDateTime.now()) }
                ?: LocalDateTime.now().plusHours(1).withMinute(0).withSecond(0).withNano(0),
        )
    }
    var error by remember { mutableStateOf<String?>(null) }
    val (granted, _, request) = rememberNotificationAccess()

    LaunchedEffect(route.key) {
        val k = route.key ?: return@LaunchedEffect
        if (loaded) return@LaunchedEffect
        c.db.reminders().get(k)?.let { r ->
            title = r.title; notes = r.notes.orEmpty(); enabled = r.enabled
            sourceType = r.sourceType; sourceId = r.sourceId; personId = r.personId
            at = LocalDateTime.ofInstant(Instant.ofEpochMilli(r.remindAt), zone)
        }
        loaded = true
    }

    PJScaffold(title = if (route.key == null) "New reminder" else "Edit reminder", busy = actions.busy) { pad ->
        FormColumn(pad) {
            if (!granted) {
                Text("Notifications are off. The reminder is saved but won't alert you.", color = PJColors.Warning, style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = request) { Text("Allow notifications") }
            }
            TextInput("Title *", title, { title = it; error = null }, error = error)
            DateTimeInput("Remind on", at, { at = it })
            TextInput("Notes", notes, { notes = it }, singleLine = false, minLines = 2)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Enabled", Modifier.weight(1f))
                Switch(checked = enabled, onCheckedChange = { enabled = it })
            }
            if (sourceType != "CUSTOM") Text("Linked to ${Fmt.humanize(sourceType)}${sourceId?.let { " #$it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
            Text("Alerts are local notifications on this device. A copy is backed up to the server when online.", style = MaterialTheme.typography.bodySmall)
            PrimaryButton(if (actions.busy) "Saving…" else "Save reminder", {
                if (title.isBlank()) { error = "Enter a title"; return@PrimaryButton }
                val ms = at.atZone(zone).toInstant().toEpochMilli()
                if (enabled && ms <= System.currentTimeMillis()) { error = "Choose a time in the future"; return@PrimaryButton }
                val r = LocalReminder(key, sourceType, sourceId, personId, title.trim(), notes.ifBlank { null }, ms, enabled)
                actions.run({ saveReminder(r) }) {
                    if (!granted) request()
                    c.toast("Reminder set for ${Fmt.epoch(ms)}")
                    nav.popBackStack()
                }
            }, enabled = !actions.busy && loaded)
            if (route.key != null) {
                SecondaryButton("Delete reminder", { actions.run({ deleteReminder(key) }) { c.toast("Reminder deleted"); nav.popBackStack() } })
            }
        }
    }
    ActionErrorDialog(actions)
}
