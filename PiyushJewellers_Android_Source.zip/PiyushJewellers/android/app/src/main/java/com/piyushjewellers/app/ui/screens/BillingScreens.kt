package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import com.piyushjewellers.app.core.BillCalc
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.MetalCalc
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.remote.*
import com.piyushjewellers.app.reports.rememberPdfExporter
import com.piyushjewellers.app.sync.EntityTypes
import com.piyushjewellers.app.sync.Submit
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.appViewModel
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors
import java.math.BigDecimal
import java.time.LocalDate

data class BillQuery(val q: String = "", val type: String? = null, val status: String? = null)

@Composable
fun BillsScreen() {
    val nav = LocalNav.current
    val c = container()
    val vm = pagedVm<BillQuery, BillDto>("bills", BillQuery()) { q, p -> bills(q.type, q.status, null, null, null, q.q, p) }
    val pending by c.repo.observeUnsynced(EntityTypes.BILL_DRAFT).collectAsState(initial = emptyList())
    PJScaffold(
        title = "Customer Billing",
        subtitle = "Sales & Purchase",
        topLevel = true,
        fab = {
            ExtendedFloatingActionButton(
                onClick = { nav.navigate(R.BillEditor(type = if (vm.query.type == "PURCHASE") "PURCHASE" else "SALES")) },
                icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(if (vm.query.type == "PURCHASE") "New purchase" else "New sale") },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = vm.query.q, onValueChange = { vm.update(vm.query.copy(q = it)) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search bill number, customer or phone") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
            )
            ChoiceChips(listOf(null, "SALES", "PURCHASE"), vm.query.type, { it?.let(Fmt::humanize) ?: "All bills" }, { vm.update(vm.query.copy(type = it), false) }, Modifier.padding(horizontal = 16.dp))
            ChoiceChips(listOf(null, "DRAFT", "FINALIZED", "REVERSED"), vm.query.status, { it?.let(Fmt::humanize) ?: "Any status" }, { vm.update(vm.query.copy(status = it), false) }, Modifier.padding(horizontal = 16.dp))
            LoadContent(vm.state, onRetry = vm::refresh, refreshing = vm.refreshing, onRefresh = vm::refresh) { list ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                    pendingOpsSection(pending) { nav.navigate(R.Sync) }
                    items(list, key = { it.id }) { b -> BillRow(b) { nav.navigate(R.BillDetail(b.id)) } }
                    if (list.isEmpty() && pending.isEmpty()) item { EmptyState("No bills", "Create a sales or purchase bill.", Icons.AutoMirrored.Filled.ReceiptLong) }
                    loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                }
            }
        }
    }
}

@Composable
fun BillRow(b: BillDto, onClick: () -> Unit) {
    ListRow(
        title = "${b.billNumber} · ${b.personName ?: b.customerName ?: "Walk-in"}",
        subtitle = "${Fmt.humanize(b.type)} · ${Fmt.date(b.billDate)} · ${b.lines.size} item(s)" +
            if (b.status == "FINALIZED" && b.outstandingAmount.signum() > 0) " · Due ${Fmt.rupees(b.outstandingAmount)}" else "",
        trailingTop = Fmt.rupees(b.grandTotal),
        trailingBottom = { StatusChip(if (b.status == "FINALIZED") b.paymentState ?: b.status else b.status) },
        onClick = onClick,
    )
}

// ---------------------------------------------------------------- Editor

class BillLineState(
    description: String = "",
    productId: Long? = null,
    productCode: String? = null,
    newCategory: String? = null,
    purity: String = "",
    gross: String = "",
    less: String = "",
    pieces: String = "",
    rate: String = "",
    making: String = "",
) {
    var description by mutableStateOf(description)
    var productId by mutableStateOf(productId)
    var productCode by mutableStateOf(productCode)
    var newCategory by mutableStateOf(newCategory)
    var purity by mutableStateOf(purity)
    var gross by mutableStateOf(gross)
    var less by mutableStateOf(less)
    var pieces by mutableStateOf(pieces)
    var rate by mutableStateOf(rate)
    var making by mutableStateOf(making)

    val net: BigDecimal get() = MetalCalc.net(Num.parse(gross), Num.parse(less))
    val calc: BillCalc.Line get() = BillCalc.Line(net, Num.parse(rate), Num.parse(making))
}

class PaymentState(val method: String, val amount: BigDecimal, val reference: String?, val chequeNumber: String?, val chequeBank: String?)

class BillEditorVm : ViewModel() {
    var loadedFor by mutableStateOf<Long?>(null)
    var type by mutableStateOf("SALES")
    var billNumber by mutableStateOf("")
    var billDate by mutableStateOf<LocalDate>(Fmt.today())
    var person by mutableStateOf<PersonDto?>(null)
    var walkInName by mutableStateOf("")
    var walkInContact by mutableStateOf("")
    var notes by mutableStateOf("")
    var zeroConfirmed by mutableStateOf(false)
    var version by mutableStateOf<Long?>(null)
    val lines = mutableStateListOf(BillLineState())
    val payments = mutableStateListOf<PaymentState>()
    var initialised = false

    fun loadFrom(b: BillDto) {
        type = b.type; billNumber = b.billNumber; billDate = Fmt.parseDate(b.billDate) ?: Fmt.today()
        person = b.personId?.let { PersonDto(it, b.personName ?: b.customerName ?: "", b.customerContact) }
        walkInName = if (b.personId == null) b.customerName.orEmpty() else ""
        walkInContact = if (b.personId == null) b.customerContact.orEmpty() else ""
        notes = b.notes.orEmpty(); zeroConfirmed = b.makingChargesZeroConfirmed; version = b.version
        lines.clear()
        b.lines.forEach { l ->
            lines.add(BillLineState(l.description, l.productId, l.productCode, l.newProductCategory, l.purity.orEmpty(),
                Fmt.plain(l.grossWeight), Fmt.plain(l.lessWeight), l.pieces.takeIf { it > 0 }?.toString().orEmpty(), Fmt.plain(l.rate), Fmt.plain(l.makingCharges)))
        }
        if (lines.isEmpty()) lines.add(BillLineState())
        payments.clear()
        b.payments.forEach { payments.add(PaymentState(it.method, it.amount, it.reference, it.chequeNumber, it.chequeBank)) }
        loadedFor = b.id
    }

    fun validate(): String? {
        if (person == null && walkInName.isBlank()) return "Select a customer or enter a walk-in name"
        if (lines.isEmpty()) return "Add at least one item"
        lines.forEachIndexed { i, l ->
            if (l.description.isBlank()) return "Item ${i + 1}: enter a description"
            val g = Num.parse(l.gross); val le = Num.parse(l.less)
            if (g != null && le != null && le > g) return "Item ${i + 1}: less weight can't exceed gross weight"
            if (Num.parse(l.rate) == null) return "Item ${i + 1}: enter the rate (use 0 if none)"
        }
        return null
    }

    fun request(): BillRequest = BillRequest(
        type = type,
        billNumber = billNumber.trim().ifBlank { null },
        billDate = billDate.toString(),
        personId = person?.id,
        customerName = person?.name ?: walkInName.trim(),
        customerContact = person?.phone ?: walkInContact.trim().ifBlank { null },
        notes = notes.trim().ifBlank { null },
        lines = lines.map { l ->
            BillLineRequest(
                description = l.description.trim(),
                productId = l.productId,
                newProductCategory = if (type == "PURCHASE" && l.productId == null) l.newCategory else null,
                purity = l.purity.trim().ifBlank { null },
                grossWeight = Num.parse(l.gross),
                lessWeight = Num.parse(l.less),
                netWeight = if (Num.parse(l.gross) != null) l.net else null,
                pieces = l.pieces.toIntOrNull(),
                rate = Num.parse(l.rate) ?: BigDecimal.ZERO,
                makingCharges = Num.parse(l.making),
            )
        },
        makingChargesZeroConfirmed = zeroConfirmed && BillCalc.hasBlankMaking(lines.map { it.calc }),
        payments = payments.map { BillPaymentRequest(it.method, it.amount, it.reference, it.chequeNumber, it.chequeBank) },
        version = version,
    )
}

@Composable
fun BillEditorScreen(id: Long?, initialType: String, personId: Long?) {
    val nav = LocalNav.current
    val c = container()
    val vm = appViewModel("bill-editor:$id:$initialType:$personId") { BillEditorVm() }
    val actions = actionVm("bill-editor:$id")
    val existing = if (id != null) loadVm("bill-edit:$id") { bill(id) } else null
    val presetPerson = if (personId != null && id == null) loadVm("person:$personId") { person(personId) } else null
    var error by remember { mutableStateOf<String?>(null) }
    var pickProductFor by remember { mutableStateOf<BillLineState?>(null) }
    var addPayment by rememberSaveable { mutableStateOf(false) }
    var confirmZero by remember { mutableStateOf<(() -> Unit)?>(null) }

    LaunchedEffect(Unit) {
        if (!vm.initialised && id == null) { vm.type = initialType; vm.initialised = true }
    }
    val loadedBill = existing?.state?.dataOrNull()
    LaunchedEffect(loadedBill) { if (loadedBill != null && vm.loadedFor != loadedBill.id) vm.loadFrom(loadedBill) }
    val pp = presetPerson?.state?.dataOrNull()
    LaunchedEffect(pp) { if (pp != null && vm.person == null) vm.person = pp }

    val calcLines = vm.lines.map { it.calc }
    val subtotal = BillCalc.subtotal(calcLines)
    val making = BillCalc.makingTotal(calcLines)
    val grand = BillCalc.grandTotal(calcLines)
    val paid = vm.payments.fold(BigDecimal.ZERO) { a, p -> a + p.amount }
    val blankMaking = BillCalc.hasBlankMaking(calcLines)

    fun save(finalize: Boolean) {
        error = vm.validate()
        if (error != null) return
        if (finalize && blankMaking && !vm.zeroConfirmed) {
            confirmZero = { vm.zeroConfirmed = true; save(true) }
            return
        }
        val req = vm.request()
        if (id == null) {
            actions.run({
                when (val r = createBillDraft(req)) {
                    is Submit.Done -> {
                        val b = r.value!!
                        Submit.Done(if (finalize) finalizeBill(b.id) else b)
                    }
                    is Submit.Queued -> r
                }
            }) { res ->
                when (res) {
                    is Submit.Done -> {
                        c.toast(if (finalize) "Bill ${res.value.billNumber} finalized" else "Draft saved")
                        nav.popBackStack(); nav.navigate(R.BillDetail(res.value.id))
                    }
                    is Submit.Queued -> {
                        c.toast(if (finalize) "Offline: saved as a draft. Finalize after it syncs." else "Draft saved offline — it will sync automatically")
                        nav.popBackStack()
                    }
                }
            }
        } else {
            actions.run({ val b = updateBill(id, req); if (finalize) finalizeBill(b.id) else b }) { b ->
                c.toast(if (finalize) "Bill ${b.billNumber} finalized" else "Draft updated")
                nav.popBackStack()
            }
        }
    }

    PJScaffold(
        title = if (id == null) "New ${if (vm.type == "SALES") "sales" else "purchase"} bill" else "Edit draft ${vm.billNumber}",
        busy = actions.busy,
    ) { pad ->
        if (existing != null && existing.state !is Load.Ready) {
            LoadContent(existing.state, onRetry = { existing.reload() }, modifier = Modifier.padding(pad)) {}
            return@PJScaffold
        }
        if (loadedBill != null && loadedBill.status != "DRAFT") {
            Column(Modifier.padding(pad)) { EmptyState("Bill is ${Fmt.humanize(loadedBill.status)}", "Finalized bills can't be edited. Reverse it and create a corrected bill.") }
            return@PJScaffold
        }
        FormColumn(pad) {
            if (id == null) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(vm.type == "SALES", { vm.type = "SALES" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Sales") }
                    SegmentedButton(vm.type == "PURCHASE", { vm.type = "PURCHASE" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Purchase") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Bill number", vm.billNumber, { vm.billNumber = it }, Modifier.weight(1f), supporting = "Blank = automatic")
                DateInput("Bill date", vm.billDate, { it?.let { d -> vm.billDate = d } }, Modifier.weight(1f))
            }
            PersonPickerField(
                if (vm.type == "SALES") "Customer" else "Supplier / seller", vm.person, { vm.person = it },
                supporting = if (vm.person == null) "Or enter a walk-in name below" else null,
            )
            if (vm.person == null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextInput("Walk-in name", vm.walkInName, { vm.walkInName = it }, Modifier.weight(1f))
                    TextInput("Contact", vm.walkInContact, { vm.walkInContact = it }, Modifier.weight(1f), keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone)
                }
            }

            SectionHeader("Items", Modifier.padding(0.dp))
            vm.lines.forEachIndexed { i, line ->
                BillLineCard(i, line, vm.type, canRemove = vm.lines.size > 1, onRemove = { vm.lines.remove(line) }, onPickProduct = { pickProductFor = line })
            }
            OutlinedButton(onClick = { vm.lines.add(BillLineState()) }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.Add, null); Text(" Add item") }

            SectionCard("Totals") {
                InfoRow("Metal value", Fmt.rupees(subtotal))
                InfoRow("Making charges", Fmt.rupees(making) + if (blankMaking) " (some blank)" else "")
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                InfoRow("Grand total", Fmt.rupees(grand), emphasize = true)
                if (vm.payments.isNotEmpty()) {
                    InfoRow("Payments entered", Fmt.rupees(paid))
                    InfoRow("Balance", Fmt.rupees(grand - paid), valueColor = if ((grand - paid).signum() > 0) PJColors.Warning else PJColors.Success)
                }
            }
            if (blankMaking) {
                SectionCard {
                    Text("Making charges are blank on ${calcLines.count { it.making == null }} item(s).", color = PJColors.Warning, fontWeight = FontWeight.SemiBold)
                    Text("Enter them, or confirm there are no making charges. Blank is never treated as zero without confirmation.", style = MaterialTheme.typography.bodySmall)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(vm.zeroConfirmed, { vm.zeroConfirmed = it })
                        Text("Confirm: no making charges on blank items")
                    }
                }
            }

            SectionCard("Payments", trailing = { TextButton(onClick = { addPayment = true }) { Text("Add") } }) {
                if (vm.payments.isEmpty()) Text("No payment yet. Payments post to Daily Transactions when the bill is finalized.", style = MaterialTheme.typography.bodySmall)
                vm.payments.forEachIndexed { i, p ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${Fmt.method(p.method)}${p.chequeNumber?.let { " #$it" } ?: ""}${p.reference?.let { " · $it" } ?: ""}", Modifier.weight(1f))
                        Text(Fmt.rupees(p.amount), fontWeight = FontWeight.SemiBold)
                        IconButton(onClick = { vm.payments.removeAt(i) }) { Icon(Icons.Filled.Delete, "Remove payment") }
                    }
                }
            }
            TextInput("Notes", vm.notes, { vm.notes = it }, singleLine = false, minLines = 2)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SecondaryButton("Save draft", { save(false) }, Modifier.weight(1f), enabled = !actions.busy)
                PrimaryButton("Finalize", { save(true) }, Modifier.weight(1f), enabled = !actions.busy)
            }
            Spacer(Modifier.padding(16.dp))
        }
    }

    pickProductFor?.let { line ->
        ProductPickerDialog(onDismiss = { pickProductFor = null }, onPick = { p ->
            line.productId = p.id; line.productCode = p.code; line.description = p.name; line.purity = p.purity.orEmpty()
            if (line.gross.isBlank()) { line.gross = Fmt.plain(p.grossWeight); line.less = Fmt.plain(p.lessWeight) }
            if (line.pieces.isBlank() && p.pieces > 0) line.pieces = if (p.category == "FINISHED_JEWELLERY") "1" else ""
            pickProductFor = null
        })
    }
    if (addPayment) PaymentDialog(onDismiss = { addPayment = false }) { m, a, ref, chq, bank ->
        vm.payments.add(PaymentState(m, a, ref, chq, bank)); addPayment = false
    }
    confirmZero?.let { proceed ->
        ConfirmDialog(
            "No making charges?", "Some items have blank making charges. Confirm there are no making charges on those items to finalize.",
            "Confirm & finalize", onConfirm = { confirmZero = null; proceed() }, onDismiss = { confirmZero = null },
        )
    }
    ActionErrorDialog(actions)
}

@Composable
private fun BillLineCard(index: Int, l: BillLineState, type: String, canRemove: Boolean, onRemove: () -> Unit, onPickProduct: () -> Unit) {
    SectionCard("Item ${index + 1}", trailing = { if (canRemove) IconButton(onClick = onRemove) { Icon(Icons.Filled.Delete, "Remove item") } }) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PickerField(
                if (type == "SALES") "From inventory" else "Existing product (optional)",
                l.productCode?.let { "$it · ${l.description}" }, "Select product", onOpen = onPickProduct,
                onClear = { l.productId = null; l.productCode = null },
            )
            if (type == "PURCHASE" && l.productId == null) {
                DropdownField("Add to stock as", listOf<String?>(null) + Options.categories, l.newCategory, { it?.let(Fmt::humanize) ?: "Don't add to stock" }, { l.newCategory = it })
            }
            TextInput("Description *", l.description, { l.description = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Purity", l.purity, { l.purity = it }, Modifier.weight(1f))
                IntInput("Pieces", l.pieces, { l.pieces = it }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DecimalInput("Gross wt", l.gross, { l.gross = it }, Modifier.weight(1f), scale = 4, suffix = "g")
                DecimalInput("Less wt", l.less, { l.less = it }, Modifier.weight(1f), scale = 4, suffix = "g")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DecimalInput("Rate /g", l.rate, { l.rate = it }, Modifier.weight(1f), prefix = "₹")
                DecimalInput("Making", l.making, { l.making = it }, Modifier.weight(1f), prefix = "₹", placeholder = "Not entered")
            }
            Row {
                Text("Net ${Fmt.grams(l.net)}", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Line total ${Fmt.rupees(BillCalc.lineTotal(l.calc))}", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun PaymentDialog(
    title: String = "Add payment",
    initialAmount: BigDecimal? = null,
    onDismiss: () -> Unit,
    onConfirm: (method: String, amount: BigDecimal, reference: String?, chequeNumber: String?, chequeBank: String?) -> Unit,
) {
    var method by rememberSaveable { mutableStateOf("CASH") }
    var amount by rememberSaveable { mutableStateOf(initialAmount?.let(Fmt::plain).orEmpty()) }
    var reference by rememberSaveable { mutableStateOf("") }
    var cheque by rememberSaveable { mutableStateOf("") }
    var bank by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.dialogScroll(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                MethodField(method, { method = it })
                DecimalInput("Amount", amount, { amount = it; error = null }, prefix = "₹", error = error)
                if (method == "CHEQUE") {
                    TextInput("Cheque number", cheque, { cheque = it })
                    TextInput("Bank", bank, { bank = it })
                    Text("Pending cheques count in the combined balance but not in available funds until cleared.", style = MaterialTheme.typography.bodySmall)
                } else {
                    TextInput("Reference (UPI / bank ref)", reference, { reference = it })
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val a = Num.parse(amount)
                when {
                    a == null || a.signum() <= 0 -> error = "Enter the amount"
                    method == "CHEQUE" && cheque.isBlank() -> error = "Enter the cheque number"
                    else -> onConfirm(method, a, reference.ifBlank { null }, cheque.ifBlank { null }, bank.ifBlank { null })
                }
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Detail

fun BillDto.toRequest(confirmZero: Boolean) = BillRequest(
    type, billNumber, billDate, personId, customerName, customerContact, notes,
    lines.map { BillLineRequest(it.description, it.productId, it.newProductCategory, it.purity, it.grossWeight, it.lessWeight, it.netWeight, it.pieces, it.rate, it.makingCharges) },
    confirmZero, null, version,
)

@Composable
fun BillDetailScreen(id: Long) {
    val nav = LocalNav.current
    val c = container()
    val vm = loadVm("bill:$id") { bill(id) }
    val actions = actionVm("bill:$id")
    val pdf = rememberPdfExporter()
    var addPayment by rememberSaveable { mutableStateOf(false) }
    var reverse by rememberSaveable { mutableStateOf(false) }
    var delete by rememberSaveable { mutableStateOf(false) }
    var confirmZero by rememberSaveable { mutableStateOf(false) }
    val b = vm.state.dataOrNull()

    PJScaffold(
        title = b?.let { "${Fmt.humanize(it.type)} bill ${it.billNumber}" } ?: "Bill",
        subtitle = b?.let { Fmt.date(it.billDate) },
        busy = actions.busy,
        actions = {
            if (b?.status == "DRAFT") IconButton(onClick = { nav.navigate(R.BillEditor(id = id, type = b.type)) }) { Icon(Icons.Filled.Edit, "Edit draft") }
        },
    ) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { bill ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    SectionCard(bill.personName ?: bill.customerName ?: "Walk-in", trailing = { StatusChip(bill.status) }) {
                        InfoRow("Contact", bill.customerContact)
                        InfoRow("Payment", bill.paymentState?.let(Fmt::humanize))
                        if (bill.finalizedAt != null) InfoRow("Finalized", Fmt.dateTime(bill.finalizedAt))
                        if (bill.status == "REVERSED") InfoRow("Reversal reason", bill.reversalReason, valueColor = PJColors.Danger)
                        if (!bill.notes.isNullOrBlank()) InfoRow("Notes", bill.notes)
                        InfoRow("Created by", bill.createdBy)
                    }
                }
                item { SectionHeader("Items", Modifier.padding(0.dp)) }
                items(bill.lines, key = { "l${it.lineNo}" }) { l ->
                    SectionCard {
                        Row {
                            Text("${l.lineNo}. ${l.description}", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                            Text(Fmt.rupees(l.lineTotal), color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            listOfNotNull(l.productCode, l.purity, "Gross ${Fmt.grams(l.grossWeight)}", "Less ${Fmt.grams(l.lessWeight)}", "Net ${Fmt.grams(l.netWeight)}",
                                "${l.pieces} pc".takeIf { l.pieces > 0 }).joinToString(" · "),
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Text(
                            "Rate ${Fmt.rupees(l.rate)}/g · Metal ${Fmt.rupees(l.metalValue)} · Making " +
                                (l.makingCharges?.let(Fmt::rupees) ?: if (bill.makingChargesZeroConfirmed) "none (confirmed)" else "not entered"),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                item {
                    SectionCard("Totals") {
                        InfoRow("Metal value", Fmt.rupees(bill.subtotal))
                        InfoRow("Making charges", Fmt.rupees(bill.makingChargesTotal))
                        InfoRow("Grand total", Fmt.rupees(bill.grandTotal), emphasize = true)
                        InfoRow("Paid", Fmt.rupees(bill.paidAmount), valueColor = PJColors.Success)
                        InfoRow("Outstanding", Fmt.rupees(bill.outstandingAmount), valueColor = if (bill.outstandingAmount.signum() > 0) PJColors.Warning else PJColors.Success)
                    }
                }
                item {
                    SectionCard("Payments", trailing = {
                        if (bill.status == "FINALIZED" && bill.outstandingAmount.signum() > 0) TextButton(onClick = { addPayment = true }) { Text("Record payment") }
                    }) {
                        if (bill.payments.isEmpty()) Text("No payments", style = MaterialTheme.typography.bodySmall)
                        bill.payments.forEach { p ->
                            Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${Fmt.method(p.method)}${p.chequeNumber?.let { " #$it" } ?: ""}")
                                    Text(listOfNotNull(Fmt.dateTime(p.paidAt), p.reference, p.chequeBank, if (!p.posted) "posts on finalize" else if (!p.effective) "not counted (pending/bounced/reversed)" else null).joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                                }
                                Text(Fmt.rupees(p.amount), fontWeight = FontWeight.SemiBold, color = if (p.effective || !p.posted) androidx.compose.ui.graphics.Color.Unspecified else PJColors.Warning)
                            }
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (bill.status) {
                            "DRAFT" -> {
                                PrimaryButton("Finalize bill", {
                                    val blank = bill.lines.any { it.makingCharges == null }
                                    if (blank && !bill.makingChargesZeroConfirmed) confirmZero = true
                                    else actions.run({ finalizeBill(id) }) { vm.replace(it); c.toast("Bill finalized") }
                                }, enabled = !actions.busy)
                                SecondaryButton("Delete draft", { delete = true }, enabled = !actions.busy)
                            }
                            "FINALIZED" -> {
                                SecondaryButton("Reverse bill", { reverse = true }, enabled = !actions.busy)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SecondaryButton("Save PDF", { actions.run({ billPdf(id, bill.billNumber) }) { pdf.save(it) } }, Modifier.weight(1f), enabled = !actions.busy)
                            SecondaryButton("Share PDF", { actions.run({ billPdf(id, bill.billNumber) }) { pdf.share(it) } }, Modifier.weight(1f), enabled = !actions.busy)
                        }
                    }
                }
            }
        }
    }
    if (addPayment && b != null) {
        PaymentDialog(title = "Record payment", initialAmount = b.outstandingAmount, onDismiss = { addPayment = false }) { m, a, ref, chq, bank ->
            actions.run({ addBillPayment(id, BillPaymentRequest(m, a, ref, chq, bank, Fmt.now().toString())) }) { vm.replace(it); addPayment = false; c.toast("Payment recorded") }
        }
    }
    if (reverse) {
        ReasonDialog(
            "Reverse bill?", "The bill stays on record as Reversed. Stock and linked payments are reversed with opposite entries.",
            onConfirm = { reason -> actions.run({ reverseBill(id, reason) }) { vm.replace(it); reverse = false; c.toast("Bill reversed") } },
            onDismiss = { reverse = false },
        )
    }
    if (delete) {
        ConfirmDialog("Delete draft?", "Drafts have no stock or money effect, so they can be deleted.", "Delete", destructive = true,
            onConfirm = { delete = false; actions.run({ deleteBill(id) }) { c.toast("Draft deleted"); nav.popBackStack() } },
            onDismiss = { delete = false })
    }
    if (confirmZero && b != null) {
        ConfirmDialog(
            "No making charges?", "Making charges are blank on some items. Confirm there are no making charges on those items, then finalize.",
            "Confirm & finalize",
            onConfirm = {
                confirmZero = false
                actions.run({ updateBill(id, b.toRequest(true)); finalizeBill(id) }) { vm.replace(it); c.toast("Bill finalized") }
            },
            onDismiss = { confirmZero = false },
        )
    }
    ActionErrorDialog(actions)
}