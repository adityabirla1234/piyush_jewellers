package com.piyushjewellers.app.ui.components

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.remote.PersonDto
import com.piyushjewellers.app.data.remote.PersonRequest
import com.piyushjewellers.app.data.remote.ProductDto
import com.piyushjewellers.app.sync.Submit
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors
import kotlinx.coroutines.launch

object Options {
    val methods = listOf("CASH", "BANK", "UPI", "CHEQUE", "OTHER")
    val nonChequeMethods = listOf("CASH", "BANK", "UPI", "OTHER")
    val metals = listOf("GOLD", "SILVER", "OTHER")
    val dealerMetals = listOf("GOLD", "SILVER")
    val categories = listOf("FINISHED_JEWELLERY", "GOLD", "SILVER", "RAW_METAL")
}

@Composable
fun PickerField(label: String, value: String?, placeholder: String, onOpen: () -> Unit, onClear: (() -> Unit)?, error: String? = null, supporting: String? = null) {
    val source = remember { MutableInteractionSource() }
    LaunchedEffect(source) { source.interactions.collect { if (it is PressInteraction.Release) onOpen() } }
    OutlinedTextField(
        value = value ?: "",
        onValueChange = {},
        readOnly = true,
        label = { Text(label) },
        placeholder = { Text(placeholder) },
        modifier = Modifier.fillMaxWidth(),
        isError = error != null,
        supportingText = (error ?: supporting)?.let { { Text(it) } },
        trailingIcon = {
            if (value != null && onClear != null) IconButton(onClick = onClear) { Icon(Icons.Filled.Close, "Clear") }
            else Icon(Icons.Filled.Search, null)
        },
        interactionSource = source,
        singleLine = true,
    )
}

@Composable
fun PersonPickerField(
    label: String,
    selected: PersonDto?,
    onSelect: (PersonDto?) -> Unit,
    type: String? = null,
    error: String? = null,
    supporting: String? = null,
    clearable: Boolean = true,
) {
    var open by rememberSaveable { mutableStateOf(false) }
    PickerField(
        label = label,
        value = selected?.let { p -> p.name + (p.phone?.let { " · $it" } ?: "") + if (p.id < 0) " (pending sync)" else "" },
        placeholder = "Search name or phone",
        onOpen = { open = true },
        onClear = if (clearable) ({ onSelect(null) }) else null,
        error = error,
        supporting = supporting,
    )
    if (open) PersonPickerDialog(type = type, onDismiss = { open = false }, onPick = { onSelect(it); open = false })
}

@Composable
fun PersonPickerDialog(type: String?, onDismiss: () -> Unit, onPick: (PersonDto) -> Unit) {
    val c = container()
    val vm = pagedVm<String, PersonDto>("person-picker:$type", "") { q, p -> people(q, type, p) }
    var pending by remember { mutableStateOf<List<PersonDto>>(emptyList()) }
    LaunchedEffect(Unit) { pending = c.repo.pendingPeople() }
    var creating by rememberSaveable { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Close") }
                    Text("Select person", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = { creating = true }) {
                        Icon(Icons.Filled.PersonAdd, null)
                        Spacer(Modifier.padding(2.dp))
                        Text("New")
                    }
                }
                OutlinedTextField(
                    value = vm.query,
                    onValueChange = { vm.update(it) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Search name, phone or ID") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    singleLine = true,
                )
                Spacer(Modifier.height(8.dp))
                LoadContent(vm.state, onRetry = vm::refresh) { list ->
                    val q = vm.query.trim().lowercase()
                    val localMatches = pending.filter { q.isEmpty() || it.name.lowercase().contains(q) || (it.phone ?: "").contains(q) }
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(localMatches, key = { "l${it.id}" }) { p ->
                            ListRow(p.name, listOfNotNull(p.phone, "Created offline · pending sync").joinToString(" · "), onClick = { onPick(p) })
                        }
                        items(list, key = { it.id }) { p ->
                            ListRow(
                                p.name,
                                listOfNotNull(p.phone, p.address?.take(40), roles(p)).joinToString(" · "),
                                onClick = { onPick(p) },
                            )
                        }
                        if (list.isEmpty() && localMatches.isEmpty()) {
                            item { EmptyState("No matches", "Add this person with the New button.") }
                        }
                        loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                    }
                }
            }
        }
    }
    if (creating) {
        QuickPersonDialog(
            defaultSupplier = type == "SUPPLIER",
            onDismiss = { creating = false },
            onCreated = { creating = false; onPick(it) },
        )
    }
}

fun roles(p: PersonDto): String? = listOfNotNull(
    "Customer".takeIf { p.customer },
    "Supplier".takeIf { p.supplier },
    "Dealer".takeIf { p.dealer },
).joinToString(", ").ifEmpty { null }

/** Minimal create form; offline it saves locally and returns a placeholder person that syncs later. */
@Composable
fun QuickPersonDialog(defaultSupplier: Boolean, onDismiss: () -> Unit, onCreated: (PersonDto) -> Unit) {
    val actions = actionVm("quick-person")
    val c = container()
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var address by rememberSaveable { mutableStateOf("") }
    var supplier by rememberSaveable { mutableStateOf(defaultSupplier) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var duplicateMessage by remember { mutableStateOf<String?>(null) }

    fun submit(allowDuplicate: Boolean) {
        if (name.isBlank()) {
            nameError = "Enter a name"
            return
        }
        val req = PersonRequest(
            name = name.trim(), phone = phone.trim().ifBlank { null }, address = address.trim().ifBlank { null },
            customer = true, supplier = supplier, allowDuplicatePhone = allowDuplicate,
        )
        actions.run(
            block = { createPerson(req) },
            onError = { e -> if (e.code == "DUPLICATE_CONTACT") { duplicateMessage = e.message; true } else false },
        ) { res ->
            when (res) {
                is Submit.Done -> res.value?.let(onCreated)
                is Submit.Queued -> {
                    c.toast("Saved offline. ${req.name} will sync when online.")
                    onCreated(PersonDto(id = res.op.localId ?: 0, name = req.name, phone = req.phone, customer = req.customer, supplier = req.supplier))
                }
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New person") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Name", name, { name = it; nameError = null }, error = nameError)
                TextInput("Phone", phone, { phone = it }, keyboardType = KeyboardType.Phone)
                TextInput("Address", address, { address = it }, singleLine = false)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = supplier, onCheckedChange = { supplier = it })
                    Text("Also a supplier")
                }
            }
        },
        confirmButton = { Button(onClick = { submit(false) }, enabled = !actions.busy) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    duplicateMessage?.let { msg ->
        ConfirmDialog(
            title = "Possible duplicate",
            text = "$msg\n\nPeople are never merged automatically. Create a separate record anyway?",
            confirmText = "Create anyway",
            onConfirm = { duplicateMessage = null; submit(true) },
            onDismiss = { duplicateMessage = null },
        )
    }
    ActionErrorDialog(actions)
}

@Composable
fun ProductPickerDialog(onDismiss: () -> Unit, onPick: (ProductDto) -> Unit, metal: String? = null) {
    val vm = pagedVm<String, ProductDto>("product-picker:$metal", "") { q, p -> products(q, null, metal, null, p) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Close") }
                    Text("Select product", style = MaterialTheme.typography.titleLarge)
                }
                OutlinedTextField(
                    value = vm.query,
                    onValueChange = { vm.update(it) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Search code or name") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    singleLine = true,
                )
                Spacer(Modifier.height(8.dp))
                LoadContent(vm.state, onRetry = vm::refresh) { list ->
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(list, key = { it.id }) { p ->
                            ListRow(
                                "${p.code} · ${p.name}",
                                "${Fmt.humanize(p.metal)} ${p.purity.orEmpty()} · Net ${Fmt.grams(p.netWeight)} · ${p.pieces} pc",
                                trailingBottom = { StatusChip(p.availability) },
                                onClick = { onPick(p) },
                            )
                        }
                        if (list.isEmpty()) item { EmptyState("No products", "Try a different search.") }
                        loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                    }
                }
            }
        }
    }
}

@Composable
fun MethodField(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, allowCheque: Boolean = true, label: String = "Payment method") {
    DropdownField(label, if (allowCheque) Options.methods else Options.nonChequeMethods, value, Fmt::method, onChange, modifier)
}

@Composable
fun RequiredNote(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = PJColors.Warning)
}

@Composable
fun rememberLaunch(): (suspend () -> Unit) -> Unit {
    val scope = rememberCoroutineScope()
    return { block -> scope.launch { block() } }
}
