package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import com.piyushjewellers.app.core.ExchangeCalc
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.MetalCalc
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.remote.*
import com.piyushjewellers.app.sync.EntityTypes
import com.piyushjewellers.app.sync.Submit
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.appViewModel
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors
import java.math.BigDecimal
import java.time.LocalDate

data class ExchangeQuery(val q: String = "", val status: String? = null)

@Composable
fun ExchangesScreen() {
    val nav = LocalNav.current
    val c = container()
    val vm = pagedVm<ExchangeQuery, ExchangeDto>("exchanges", ExchangeQuery()) { q, p -> exchanges(q.status, null, q.q, p) }
    val pending by c.repo.observeUnsynced(EntityTypes.EXCHANGE_DRAFT).collectAsState(initial = emptyList())
    PJScaffold(
        title = "Jewellery Exchange",
        topLevel = true,
        fab = { ExtendedFloatingActionButton(onClick = { nav.navigate(R.ExchangeEditor()) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("New exchange") }) },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = vm.query.q, onValueChange = { vm.update(vm.query.copy(q = it)) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search number or customer") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
            )
            ChoiceChips(listOf(null, "DRAFT", "FINALIZED", "REVERSED"), vm.query.status, { it?.let(Fmt::humanize) ?: "Any status" },
                { vm.update(vm.query.copy(status = it), false) }, Modifier.padding(horizontal = 16.dp))
            LoadContent(vm.state, onRetry = vm::refresh, refreshing = vm.refreshing, onRefresh = vm::refresh) { list ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                    pendingOpsSection(pending) { nav.navigate(R.Sync) }
                    items(list, key = { it.id }) { e ->
                        ListRow(
                            title = "${e.exchangeNumber} · ${e.personName ?: e.partyName ?: "Walk-in"}",
                            subtitle = "${Fmt.date(e.exchangeDate)} · Received ${Fmt.rupees(e.receivedValue)} · Issued ${Fmt.rupees(e.issuedValue)}",
                            trailingTop = differenceLabel(e.cashDifference, e.cashDirection),
                            trailingColor = if (e.cashDirection == "IN") PJColors.Success else if (e.cashDirection == "OUT") PJColors.Danger else PJColors.Info,
                            trailingBottom = { StatusChip(e.status) },
                            onClick = { nav.navigate(R.ExchangeDetail(e.id)) },
                        )
                    }
                    if (list.isEmpty()) item { EmptyState("No exchanges", "Exchange old jewellery for new and settle the difference.") }
                    loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                }
            }
        }
    }
}

private fun differenceLabel(diff: BigDecimal, direction: String?): String = when (direction) {
    "IN" -> "Customer pays ${Fmt.rupees(diff.abs())}"
    "OUT" -> "We pay ${Fmt.rupees(diff.abs())}"
    else -> "No difference"
}

class ExchangeLineState(side: String) {
    var side by mutableStateOf(side)
    var description by mutableStateOf("")
    var product by mutableStateOf<Pair<Long, String>?>(null)
    var newCategory by mutableStateOf<String?>(null)
    var metal by mutableStateOf("GOLD")
    var purity by mutableStateOf("")
    var gross by mutableStateOf("")
    var less by mutableStateOf("")
    var pieces by mutableStateOf("")
    var rate by mutableStateOf("")
    val net: BigDecimal get() = MetalCalc.net(Num.parse(gross), Num.parse(less))
    val value: BigDecimal get() = ExchangeCalc.value(net, Num.parse(rate))
}

class ExchangeEditorVm : ViewModel() {
    var loaded by mutableStateOf(false)
    var version: Long? = null
    var person by mutableStateOf<PersonDto?>(null)
    var partyName by mutableStateOf("")
    var date by mutableStateOf<LocalDate>(Fmt.today())
    var notes by mutableStateOf("")
    var method by mutableStateOf("CASH")
    var reference by mutableStateOf("")
    val lines = mutableStateListOf(ExchangeLineState("RECEIVED"), ExchangeLineState("ISSUED"))

    fun loadFrom(e: ExchangeDto) {
        version = e.version
        person = e.personId?.let { PersonDto(it, e.personName ?: "") }
        partyName = e.partyName.orEmpty()
        date = Fmt.parseDate(e.exchangeDate) ?: Fmt.today()
        notes = e.notes.orEmpty()
        method = e.differenceMethod ?: "CASH"
        reference = e.differenceReference.orEmpty()
        lines.clear()
        e.lines.forEach { l ->
            lines.add(ExchangeLineState(l.side).also { s ->
                s.description = l.description
                s.product = l.productId?.let { it to (l.productCode ?: "#$it") }
                s.newCategory = l.newProductCategory
                s.metal = l.metal
                s.purity = l.purity.orEmpty()
                s.gross = l.grossWeight?.let(Fmt::plain) ?: Fmt.plain(l.netWeight)
                s.less = l.lessWeight?.let(Fmt::plain).orEmpty()
                s.pieces = if (l.pieces > 0) l.pieces.toString() else ""
                s.rate = Fmt.plain(l.rate)
            })
        }
        loaded = true
    }

    fun request(): ExchangeRequest = ExchangeRequest(
        personId = person?.id, partyName = partyName.ifBlank { null } ?: person?.name, exchangeDate = date.toString(), notes = notes.ifBlank { null },
        differenceMethod = method, differenceReference = reference.ifBlank { null },
        lines = lines.map { l ->
            ExchangeLineRequest(
                side = l.side, description = l.description.trim(), productId = l.product?.first,
                newProductCategory = l.newCategory.takeIf { l.side == "RECEIVED" }, metal = l.metal, purity = l.purity.ifBlank { null },
                grossWeight = Num.parse(l.gross), lessWeight = Num.parse(l.less), netWeight = l.net, pieces = l.pieces.toIntOrNull(), rate = Num.parse(l.rate) ?: BigDecimal.ZERO,
            )
        },
        version = version,
    )
}

@Composable
fun ExchangeEditorScreen(id: Long?, personId: Long?) {
    val nav = LocalNav.current
    val c = container()
    val vm = appViewModel("exchange-editor:$id:$personId") { ExchangeEditorVm() }
    val actions = actionVm("exchange-editor")
    val existing = id?.let { eid -> loadVm("exchange:$eid") { exchange(eid) } }
    val preset = personId?.let { pid -> loadVm("person:$pid") { person(pid) } }
    var pickProductFor by remember { mutableStateOf<ExchangeLineState?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val existingData = existing?.state?.dataOrNull()
    LaunchedEffect(existingData) { if (existingData != null && !vm.loaded) vm.loadFrom(existingData) }
    val presetPerson = preset?.state?.dataOrNull()
    LaunchedEffect(presetPerson) { if (vm.person == null && presetPerson != null) vm.person = presetPerson }

    val received = vm.lines.filter { it.side == "RECEIVED" }.fold(BigDecimal.ZERO) { a, l -> a + l.value }
    val issued = vm.lines.filter { it.side == "ISSUED" }.fold(BigDecimal.ZERO) { a, l -> a + l.value }
    val diff = Num.money(issued - received)

    PJScaffold(title = if (id == null) "New exchange" else "Edit exchange", busy = actions.busy) { pad ->
        if (id != null && existingData == null) {
            existing?.let { LoadContent(it.state, onRetry = { it.reload() }, modifier = Modifier.padding(pad)) {} }
            return@PJScaffold
        }
        FormColumn(pad) {
            PersonPickerField("Customer", vm.person, { vm.person = it })
            if (vm.person == null) TextInput("Walk-in customer name", vm.partyName, { vm.partyName = it })
            DateInput("Date", vm.date, { it?.let { d -> vm.date = d } })
            listOf("RECEIVED" to "Received from customer (old)", "ISSUED" to "Given to customer (new)").forEach { (side, title) ->
                SectionHeader(title, Modifier.padding(0.dp))
                vm.lines.filter { it.side == side }.forEach { l ->
                    SectionCard(trailing = { IconButton(onClick = { vm.lines.remove(l) }) { Icon(Icons.Filled.Delete, "Remove line") } }) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextInput("Description *", l.description, { l.description = it })
                            if (side == "ISSUED") {
                                Row {
                                    Text(l.product?.let { "From stock: ${it.second}" } ?: "Not linked to stock", Modifier.weight(1f).padding(top = 12.dp), style = MaterialTheme.typography.bodySmall)
                                    TextButton(onClick = { pickProductFor = l }) { Text(if (l.product == null) "Pick product" else "Change") }
                                    if (l.product != null) TextButton(onClick = { l.product = null }) { Text("Unlink") }
                                }
                            } else {
                                DropdownField("Add to inventory as", listOf<String?>(null) + Options.categories, l.newCategory, { it?.let(Fmt::humanize) ?: "Don't add to stock" }, { l.newCategory = it })
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DropdownField("Metal", Options.metals, l.metal, Fmt::humanize, { l.metal = it }, Modifier.weight(1f))
                                TextInput("Purity", l.purity, { l.purity = it }, Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DecimalInput("Gross wt *", l.gross, { l.gross = it }, Modifier.weight(1f), scale = 4, suffix = "g")
                                DecimalInput("Less wt", l.less, { l.less = it }, Modifier.weight(1f), scale = 4, suffix = "g")
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DecimalInput("Rate /g *", l.rate, { l.rate = it }, Modifier.weight(1f), prefix = "₹")
                                IntInput("Pieces", l.pieces, { l.pieces = it }, Modifier.weight(1f))
                            }
                            Row {
                                Text("Net ${Fmt.grams(l.net)}", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(Fmt.rupees(l.value), color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
                OutlinedButton(onClick = { vm.lines.add(ExchangeLineState(side)) }, Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.Add, null); Text(if (side == "RECEIVED") " Add received item" else " Add issued item")
                }
            }
            SectionCard("Difference") {
                InfoRow("Received value", Fmt.rupees(received))
                InfoRow("Issued value", Fmt.rupees(issued))
                InfoRow("Difference", differenceLabel(diff, if (diff.signum() > 0) "IN" else if (diff.signum() < 0) "OUT" else null), emphasize = true,
                    valueColor = if (diff.signum() > 0) PJColors.Success else if (diff.signum() < 0) PJColors.Danger else PJColors.Info)
                if (diff.signum() != 0) {
                    MethodField(vm.method, { vm.method = it }, label = "Difference settled by")
                    TextInput(if (vm.method == "CHEQUE") "Cheque number" else "Reference", vm.reference, { vm.reference = it })
                }
            }
            TextInput("Notes", vm.notes, { vm.notes = it }, singleLine = false)
            Text("Saved as a draft. Stock and money move only when you finalize.", style = MaterialTheme.typography.bodySmall)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            PrimaryButton(if (actions.busy) "Saving…" else "Save draft", {
                error = when {
                    vm.lines.isEmpty() -> "Add at least one item"
                    vm.lines.any { it.description.isBlank() } -> "Enter a description for every item"
                    vm.lines.any { Num.parse(it.gross) == null } -> "Enter gross weight for every item"
                    vm.lines.any { (Num.parse(it.less) ?: BigDecimal.ZERO) > (Num.parse(it.gross) ?: BigDecimal.ZERO) } -> "Less weight can't exceed gross weight"
                    vm.lines.any { Num.parse(it.rate) == null } -> "Enter a rate for every item"
                    vm.person == null && vm.partyName.isBlank() -> "Select a customer or enter a name"
                    else -> null
                }
                if (error != null) return@PrimaryButton
                val req = vm.request()
                if (id == null) {
                    actions.run({ createExchangeDraft(req) }) { res ->
                        when (res) {
                            is Submit.Done -> { c.toast("Draft saved"); nav.popBackStack(); res.value?.let { nav.navigate(R.ExchangeDetail(it.id)) } }
                            is Submit.Queued -> { c.toast("Saved offline — will sync when online"); nav.popBackStack() }
                        }
                    }
                } else {
                    actions.run({ updateExchange(id, req) }) { c.toast("Draft updated"); nav.popBackStack() }
                }
            }, enabled = !actions.busy)
            Spacer(Modifier.padding(12.dp))
        }
    }
    pickProductFor?.let { line ->
        ProductPickerDialog(onDismiss = { pickProductFor = null }, onPick = { p ->
            line.product = p.id to "${p.code} · ${p.name}"
            if (line.description.isBlank()) line.description = p.name
            line.metal = p.metal
            line.purity = p.purity.orEmpty()
            line.gross = Fmt.plain(p.grossWeight)
            line.less = if (p.lessWeight.signum() > 0) Fmt.plain(p.lessWeight) else ""
            if (p.pieces > 0) line.pieces = "1"
            pickProductFor = null
        })
    }
    ActionErrorDialog(actions)
}

@Composable
fun ExchangeDetailScreen(id: Long) {
    val nav = LocalNav.current
    val c = container()
    val vm = loadVm("exchange:$id") { exchange(id) }
    val actions = actionVm("exchange:$id")
    var finalize by rememberSaveable { mutableStateOf(false) }
    var delete by rememberSaveable { mutableStateOf(false) }
    var reverse by rememberSaveable { mutableStateOf(false) }
    val e = vm.state.dataOrNull()
    PJScaffold(title = e?.let { "Exchange ${it.exchangeNumber}" } ?: "Exchange", subtitle = e?.let { it.personName ?: it.partyName }, busy = actions.busy) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { ex ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    SectionCard("Summary", trailing = { StatusChip(ex.status) }) {
                        InfoRow("Date", Fmt.date(ex.exchangeDate))
                        InfoRow("Customer", ex.personName ?: ex.partyName)
                        InfoRow("Received value", Fmt.rupees(ex.receivedValue))
                        InfoRow("Issued value", Fmt.rupees(ex.issuedValue))
                        InfoRow("Difference", differenceLabel(ex.cashDifference, ex.cashDirection), emphasize = true)
                        if (ex.cashDirection != null) InfoRow("Settled by", Fmt.method(ex.differenceMethod) + (ex.differenceReference?.let { " · $it" } ?: ""))
                        if (!ex.notes.isNullOrBlank()) InfoRow("Notes", ex.notes)
                        if (ex.finalizedAt != null) InfoRow("Finalized", Fmt.dateTime(ex.finalizedAt))
                        if (ex.status == "REVERSED") InfoRow("Reversal reason", ex.reversalReason, valueColor = PJColors.Danger)
                    }
                }
                listOf("RECEIVED" to "Received from customer", "ISSUED" to "Given to customer").forEach { (side, title) ->
                    val lines = ex.lines.filter { it.side == side }
                    if (lines.isNotEmpty()) {
                        item {
                            SectionCard(title) {
                                lines.forEachIndexed { i, l ->
                                    if (i > 0) HorizontalDivider(Modifier.padding(vertical = 6.dp))
                                    Row {
                                        Text(l.description, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                                        Text(Fmt.rupees(l.value), color = MaterialTheme.colorScheme.tertiary)
                                    }
                                    Text(
                                        listOfNotNull(l.productCode, Fmt.humanize(l.metal), l.purity, "Net ${Fmt.grams(l.netWeight)}", "@ ${Fmt.rupees(l.rate)}/g",
                                            l.newProductCategory?.let { "→ stock as ${Fmt.humanize(it)}" }).joinToString(" · "),
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                }
                            }
                        }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (ex.status == "DRAFT") {
                            PrimaryButton("Finalize", { finalize = true })
                            SecondaryButton("Edit draft", { nav.navigate(R.ExchangeEditor(id = ex.id)) })
                            SecondaryButton("Delete draft", { delete = true })
                        }
                        if (ex.status == "FINALIZED") SecondaryButton("Reverse", { reverse = true })
                        ex.transactionId?.let { tid -> SecondaryButton("Open money entry", { nav.navigate(R.TransactionDetail(tid)) }) }
                    }
                }
            }
        }
    }
    if (finalize && e != null) ConfirmDialog("Finalize exchange?", "Stock moves for both sides and the difference (${differenceLabel(e.cashDifference, e.cashDirection)}) is posted to daily transactions. Finalized exchanges can only be reversed.",
        "Finalize", onConfirm = { actions.run({ finalizeExchange(id) }) { vm.replace(it); finalize = false; c.toast("Exchange finalized") } }, onDismiss = { finalize = false })
    if (delete) ConfirmDialog("Delete draft?", "Drafts have no effect on stock or money. This cannot be undone.", "Delete", destructive = true,
        onConfirm = { actions.run({ deleteExchange(id) }) { delete = false; c.toast("Draft deleted"); nav.popBackStack() } }, onDismiss = { delete = false })
    if (reverse) ReasonDialog("Reverse exchange?", "Stock and money movements are reversed with opposite entries. The exchange stays on record as Reversed.",
        onConfirm = { r -> actions.run({ reverseExchange(id, r) }) { vm.replace(it); reverse = false; c.toast("Exchange reversed") } }, onDismiss = { reverse = false })
    ActionErrorDialog(actions)
}
