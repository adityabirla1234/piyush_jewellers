package com.piyushjewellers.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.piyushjewellers.app.ui.nav.AppRoot
import com.piyushjewellers.app.ui.theme.PJTheme

class MainActivity : ComponentActivity() {
    private var openTarget by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        openTarget = intent?.getStringExtra(EXTRA_OPEN)
        setContent {
            PJTheme {
                AppRoot(openTarget = openTarget, onTargetHandled = { openTarget = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(EXTRA_OPEN)?.let { openTarget = it }
    }

    companion object {
        const val EXTRA_OPEN = "open"
    }
}
