package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.piyushjewellers.app.BuildConfig
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.SessionStore
import com.piyushjewellers.app.data.local.OutboxOp
import com.piyushjewellers.app.data.local.SyncState
import com.piyushjewellers.app.data.remote.AuditEventDto
import com.piyushjewellers.app.data.remote.UpdateSettingsRequest
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors

@Composable
fun SettingsScreen() {
    val nav = LocalNav.current
    val c = container()
    val vm = loadVm("settings") { settings() }
    val actions = actionVm("settings")
    val baseUrl by c.session.baseUrlFlow.collectAsState()
    val unsynced by c.db.outbox().observeUnsyncedCount().collectAsState(initial = 0)
    var shopName by rememberSaveable { mutableStateOf("") }
    var shopAddress by rememberSaveable { mutableStateOf("") }
    var shopPhone by rememberSaveable { mutableStateOf("") }
    var opening by rememberSaveable { mutableStateOf("") }
    var crossMetal by rememberSaveable { mutableStateOf(false) }
    var initialized by rememberSaveable { mutableStateOf(false) }
    var editUrl by rememberSaveable { mutableStateOf(false) }
    var confirmOpening by rememberSaveable { mutableStateOf(false) }
    val s = vm.state.dataOrNull()
    LaunchedEffect(s) {
        if (s != null && !initialized) {
            shopName = s.shopName.orEmpty(); shopAddress = s.shopAddress.orEmpty(); shopPhone = s.shopPhone.orEmpty()
            opening = Fmt.plain(s.openingBalance); crossMetal = s.crossMetalSettlementAllowed
            initialized = true
        }
    }

    fun save() {
        val req = UpdateSettingsRequest(Num.parse(opening)?.let(Num::money), crossMetal, shopName.trim(), shopAddress.trim(), shopPhone.trim())
        actions.run({ updateSettings(req) }) { vm.replace(it); c.toast("Settings saved") }
    }

    PJScaffold(title = "Settings", topLevel = true, busy = actions.busy) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad)) { settings ->
            FormColumn(PaddingValues(0.dp)) {
                SectionCard("Shop") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextInput("Shop name", shopName, { shopName = it })
                        TextInput("Address", shopAddress, { shopAddress = it }, singleLine = false)
                        TextInput("Phone", shopPhone, { shopPhone = it }, keyboardType = KeyboardType.Phone)
                    }
                }
                SectionCard("Money & dealings") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DecimalInput("Opening balance", opening, { opening = it }, prefix = "₹", supporting = "Starting combined balance before the first recorded transaction")
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Allow cross-metal settlement")
                                Text("Even when on, each settlement needs explicit authorization.", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = crossMetal, onCheckedChange = { crossMetal = it })
                        }
                    }
                }
                PrimaryButton("Save settings", {
                    val newOpening = Num.parse(opening)
                    if (newOpening != null && newOpening.compareTo(settings.openingBalance) != 0) confirmOpening = true else save()
                }, enabled = !actions.busy)
                SectionCard("Gold purity table") {
                    settings.purities.forEach { p -> InfoRow(Fmt.carat(p.carat), "${p.percent}%") }
                    Text("Used in dealer gold formulas: final = net × (carat % + labour %) ÷ 100.", style = MaterialTheme.typography.bodySmall)
                }
                SectionCard("Photos") {
                    InfoRow("Max photos per product", settings.maxPhotosPerProduct.toString())
                    if (settings.maxPhotoBytes > 0) InfoRow("Max photo size", "${settings.maxPhotoBytes / (1024 * 1024)} MB")
                }
                SectionCard("Server & sync") {
                    InfoRow("Server", baseUrl)
                    InfoRow("Unsynced entries", unsynced.toString(), valueColor = if (unsynced > 0) PJColors.Warning else PJColors.Success)
                    InfoRow("Last sync", c.session.lastSyncAt.takeIf { it > 0 }?.let(Fmt::epoch) ?: "Never")
                    Row {
                        TextButton(onClick = { editUrl = true }) { Text("Change server") }
                        TextButton(onClick = { nav.navigate(R.Sync) }) { Text("Sync status") }
                        TextButton(onClick = { nav.navigate(R.Audit) }) { Text("Audit log") }
                    }
                }
                SectionCard("Account") {
                    val u = c.session.user
                    InfoRow("Signed in as", u?.let { it.fullName ?: it.username })
                    InfoRow("Role", u?.role?.let(Fmt::humanize))
                    InfoRow("App version", BuildConfig.VERSION_NAME)
                }
            }
        }
    }
    if (confirmOpening) ConfirmDialog("Change opening balance?", "This changes the combined and available balance shown everywhere. The change is recorded in the audit log.",
        "Change", onConfirm = { confirmOpening = false; save() }, onDismiss = { confirmOpening = false })
    if (editUrl) ServerUrlDialog(baseUrl, unsynced, onDismiss = { editUrl = false }) { url ->
        c.session.setBaseUrl(url); editUrl = false; c.toast("Server address updated"); vm.reload()
    }
    ActionErrorDialog(actions)
}

@Composable
private fun ServerUrlDialog(current: String, unsynced: Int, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var url by rememberSaveable { mutableStateOf(current) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Server address") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("https://…", url, { url = it; error = null }, error = error, keyboardType = KeyboardType.Uri)
                if (unsynced > 0) Text("$unsynced unsynced entries will be sent to the new address.", color = PJColors.Warning, style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(onClick = {
                val e = SessionStore.validate(url)
                if (e != null) error = e else onSave(url.trim())
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun SyncScreen() {
    val c = container()
    val launch = rememberLaunch()
    val ops by c.db.outbox().observeAll().collectAsState(initial = emptyList())
    val online by c.connectivity.online.collectAsState()
    var syncing by remember { mutableStateOf(false) }
    var lastSync by remember { mutableStateOf(c.session.lastSyncAt) }
    var discarding by remember { mutableStateOf<OutboxOp?>(null) }
    val unsynced = ops.filter { it.state != SyncState.SYNCED }
    val synced = ops.filter { it.state == SyncState.SYNCED }
    PJScaffold(
        title = "Sync status",
        busy = syncing,
        actions = {
            IconButton(enabled = !syncing, onClick = {
                syncing = true
                launch {
                    try {
                        val ok = c.outbox.runSync()
                        lastSync = c.session.lastSyncAt
                        c.toast(if (ok) "Everything is synced" else if (!online) "Offline — will sync when connected" else "Some entries need attention")
                    } catch (e: Exception) {
                        if (e is kotlinx.coroutines.CancellationException) throw e
                        c.toast("Sync couldn't run: ${e.message ?: "unknown error"}")
                    } finally {
                        syncing = false
                    }
                }
            }) { Icon(Icons.Filled.Sync, "Sync now") }
        },
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Column(Modifier.padding(16.dp)) {
                    InfoRow("Connection", if (online) "Online" else "Offline", valueColor = if (online) PJColors.Success else PJColors.Warning)
                    InfoRow("Last sync", lastSync.takeIf { it > 0 }?.let(Fmt::epoch) ?: "Never")
                    InfoRow("Waiting", unsynced.size.toString(), emphasize = true)
                    Text("Entries saved offline are sent in order with a unique key, so retrying never creates duplicates.", style = MaterialTheme.typography.bodySmall)
                }
            }
            if (unsynced.isEmpty()) item { EmptyState("All caught up", "Nothing is waiting to sync.", Icons.Filled.Sync) }
            items(unsynced, key = { it.id }) { op ->
                Column {
                    ListRow(
                        title = op.summary,
                        subtitle = listOfNotNull(Fmt.humanize(op.entityType), Fmt.epoch(op.createdAt), "attempts ${op.attempts}".takeIf { op.attempts > 0 }, op.lastError).joinToString(" · "),
                        trailingBottom = { StatusChip(op.state, syncLabel(op.state)) },
                    )
                    Row(Modifier.padding(horizontal = 8.dp)) {
                        when (op.state) {
                            SyncState.PENDING_SYNC -> TextButton(onClick = { launch { c.outbox.pause(op.id) } }) { Text("Hold") }
                            SyncState.DRAFT -> TextButton(onClick = { launch { c.outbox.retry(op.id) } }) { Text("Resume") }
                            SyncState.FAILED, SyncState.CONFLICT -> TextButton(onClick = { launch { c.outbox.retry(op.id) } }) { Text("Retry") }
                            else -> Unit
                        }
                        if (op.state != SyncState.SYNCING) TextButton(onClick = { discarding = op }) { Text("Discard", color = PJColors.Danger) }
                    }
                }
            }
            if (synced.isNotEmpty()) {
                item { SectionHeader("Recently synced") }
                items(synced, key = { it.id }) { op ->
                    ListRow(op.summary, "${Fmt.humanize(op.entityType)} · ${Fmt.epoch(op.updatedAt)}", trailingBottom = { StatusChip(op.state, syncLabel(op.state)) })
                }
            }
        }
    }
    discarding?.let { op ->
        ConfirmDialog("Discard this entry?", "\"${op.summary}\" was saved only on this device and will be lost. Entries that depend on it will fail.", "Discard", destructive = true,
            onConfirm = { discarding = null; launch { c.outbox.discard(op.id) } }, onDismiss = { discarding = null })
    }
}

@Composable
fun AuditScreen() {
    val types = listOf(null, "Person", "DailyTransaction", "ChequeRecord", "CustomerBill", "Dealer", "DealerBill", "Loan", "MortgageAccount", "Mortgage", "Exchange", "Product", "BarLot", "Reminder", "ShopSettings")
    val vm = pagedVm<String?, AuditEventDto>("audit", null) { t, p -> audit(t, null, p) }
    PJScaffold(title = "Audit log") { pad ->
        Column(Modifier.padding(pad)) {
            ChoiceChips(types, vm.query, { it?.replace(Regex("([a-z])([A-Z])"), "$1 $2") ?: "All" }, { vm.update(it, false) }, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            LoadContent(vm.state, onRetry = vm::refresh, refreshing = vm.refreshing, onRefresh = vm::refresh) { list ->
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.id }) { e ->
                        ListRow(
                            title = Fmt.humanize(e.action),
                            subtitle = listOfNotNull(Fmt.dateTime(e.occurredAt), e.actor, e.entityType?.let { t -> t + (e.entityId?.let { " #$it" } ?: "") }, e.reason?.let { "Reason: $it" }, e.details).joinToString(" · "),
                        )
                    }
                    if (list.isEmpty()) item { EmptyState("No audit events", "Changes, reversals and settlements are recorded here.") }
                    loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                }
            }
        }
    }
}
