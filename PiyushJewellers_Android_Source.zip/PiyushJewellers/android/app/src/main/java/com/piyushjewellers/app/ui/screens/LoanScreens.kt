package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.remote.LoanDto
import com.piyushjewellers.app.data.remote.LoanRequest
import com.piyushjewellers.app.data.remote.PersonDto
import com.piyushjewellers.app.data.remote.RepaymentRequest
import com.piyushjewellers.app.sync.EntityTypes
import com.piyushjewellers.app.sync.Submit
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors

data class LoanQuery(val q: String = "", val kind: String? = null, val status: String? = null)

@Composable
fun LoansScreen() {
    val nav = LocalNav.current
    val c = container()
    val vm = pagedVm<LoanQuery, LoanDto>("loans", LoanQuery()) { q, p -> loans(q.kind, q.status, null, q.q, p) }
    val pendingLoans by c.repo.observeUnsynced(EntityTypes.LOAN).collectAsState(initial = emptyList())
    val pendingRepay by c.repo.observeUnsynced(EntityTypes.REPAYMENT).collectAsState(initial = emptyList())
    PJScaffold(
        title = "Lending & Borrowing",
        topLevel = true,
        fab = {
            ExtendedFloatingActionButton(onClick = { nav.navigate(R.LoanForm(kind = vm.query.kind ?: "LENT")) }, icon = { Icon(Icons.Filled.Add, null) },
                text = { Text(if (vm.query.kind == "BORROWED") "Borrow" else "Lend") })
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = vm.query.q, onValueChange = { vm.update(vm.query.copy(q = it)) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search person or reference") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
            )
            ChoiceChips(listOf(null, "LENT", "BORROWED"), vm.query.kind, { when (it) { "LENT" -> "Lent (to receive)"; "BORROWED" -> "Borrowed (to pay)"; else -> "All" } },
                { vm.update(vm.query.copy(kind = it), false) }, Modifier.padding(horizontal = 16.dp))
            ChoiceChips(listOf(null, "ACTIVE", "SETTLED", "REVERSED"), vm.query.status, { it?.let(Fmt::humanize) ?: "Any status" },
                { vm.update(vm.query.copy(status = it), false) }, Modifier.padding(horizontal = 16.dp))
            LoadContent(vm.state, onRetry = vm::refresh, refreshing = vm.refreshing, onRefresh = vm::refresh) { list ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                    pendingOpsSection(pendingLoans + pendingRepay) { nav.navigate(R.Sync) }
                    items(list, key = { it.id }) { l -> LoanRow(l) { nav.navigate(R.LoanDetail(l.id)) } }
                    if (list.isEmpty()) item { EmptyState("No lending or borrowing", "Record money lent to or borrowed from people.") }
                    loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                }
            }
        }
    }
}

@Composable
private fun LoanRow(l: LoanDto, onClick: () -> Unit) {
    val lent = l.kind == "LENT"
    ListRow(
        title = "${if (lent) "Lent to" else "Borrowed from"} ${l.personName.orEmpty()}",
        subtitle = listOfNotNull(Fmt.date(l.loanDate), "Principal ${Fmt.rupees(l.principal)}", l.expectedReturnDate?.let { "Expected ${Fmt.date(it)}" }).joinToString(" · "),
        trailingTop = Fmt.rupees(l.outstanding),
        trailingColor = if (lent) PJColors.Success else PJColors.Danger,
        trailingBottom = { StatusChip(l.status) },
        onClick = onClick,
    )
}

@Composable
fun LoanDetailScreen(id: Long) {
    val nav = LocalNav.current
    val c = container()
    val vm = loadVm("loan:$id") { loan(id) }
    val actions = actionVm("loan:$id")
    var repay by rememberSaveable { mutableStateOf(false) }
    var reverse by rememberSaveable { mutableStateOf(false) }
    var editDate by rememberSaveable { mutableStateOf(false) }
    val loan = vm.state.dataOrNull()
    PJScaffold(
        title = loan?.let { if (it.kind == "LENT") "Lent to ${it.personName.orEmpty()}" else "Borrowed from ${it.personName.orEmpty()}" } ?: "Loan",
        busy = actions.busy,
        actions = {
            if (loan != null && loan.status == "ACTIVE") IconButton(onClick = {
                nav.navigate(R.ReminderEditor(
                    title = "${if (loan.kind == "LENT") "Collect from" else "Repay to"} ${loan.personName.orEmpty()} · ${Fmt.rupees(loan.outstanding)}",
                    sourceType = "LOAN", sourceId = loan.id, personId = loan.personId, date = loan.expectedReturnDate,
                ))
            }) { Icon(Icons.Filled.NotificationsActive, "Set reminder") }
        },
    ) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { l ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    SectionCard(if (l.kind == "LENT") "Money lent" else "Money borrowed", trailing = { StatusChip(l.status) }) {
                        Text(Fmt.rupees(l.outstanding), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold,
                            color = if (l.kind == "LENT") PJColors.Success else PJColors.Danger)
                        Text(if (l.kind == "LENT") "outstanding to receive" else "outstanding to pay", style = MaterialTheme.typography.bodySmall)
                        InfoRow("Person", listOfNotNull(l.personName, l.personPhone).joinToString(" · "))
                        InfoRow("Principal", Fmt.rupees(l.principal))
                        InfoRow("Repaid", Fmt.rupees(l.repaidAmount))
                        InfoRow("Date", Fmt.date(l.loanDate))
                        InfoRow("Method", Fmt.method(l.method))
                        InfoRow("Reference", l.reference)
                        InfoRow("Expected return", l.expectedReturnDate?.let(Fmt::date) ?: "Not set")
                        if (!l.notes.isNullOrBlank()) InfoRow("Notes", l.notes)
                        Text("No interest is calculated on lending or borrowing.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                item { SectionHeader("Repayments", Modifier.padding(0.dp)) }
                if (l.repayments.isEmpty()) item { Text("No repayments yet", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(l.repayments.size, key = { "r$it" }) { i ->
                    val r = l.repayments[i]
                    ListRow(
                        title = Fmt.rupees(r.amount),
                        subtitle = listOfNotNull(Fmt.date(r.repaymentDate), Fmt.method(r.method), r.reference, r.notes).joinToString(" · "),
                        trailingBottom = if (!r.effective) ({ StatusChip("REVERSED") }) else null,
                        onClick = r.transactionId?.let { tid -> { nav.navigate(R.TransactionDetail(tid)) } },
                    )
                }
                if (l.status == "ACTIVE") {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton(if (l.kind == "LENT") "Record money received" else "Record repayment made", { repay = true })
                            SecondaryButton("Change expected return date", { editDate = true })
                            SecondaryButton("Reverse", { reverse = true })
                        }
                    }
                }
                item { SecondaryButton("Open ${l.personName ?: "person"}", { nav.navigate(R.PersonDetail(l.personId)) }) }
            }
        }
    }
    if (repay && loan != null) {
        PaymentDialog(
            title = if (loan.kind == "LENT") "Money received" else "Repayment made",
            initialAmount = loan.outstanding,
            onDismiss = { repay = false },
        ) { method, amount, ref, chequeNo, _ ->
            if (amount > loan.outstanding) { c.toast("Amount is more than the outstanding ${Fmt.rupees(loan.outstanding)}"); return@PaymentDialog }
            val req = RepaymentRequest(Num.money(amount), Fmt.today().toString(), method, (chequeNo ?: ref)?.ifBlank { null })
            val label = "Repayment ${Fmt.rupees(amount)} · ${loan.personName.orEmpty()}"
            actions.run({ repay(id, req, label) }) { res ->
                repay = false
                when (res) {
                    is Submit.Done -> { res.value?.let { vm.replace(it) }; c.toast("Repayment recorded") }
                    is Submit.Queued -> c.toast("Saved offline — will sync when online")
                }
            }
        }
    }
    if (editDate && loan != null) {
        var d by remember { mutableStateOf(Fmt.parseDate(loan.expectedReturnDate)) }
        AlertDialog(
            onDismissRequest = { editDate = false },
            title = { Text("Expected return date") },
            text = { DateInput("Date", d, { d = it }, clearable = true) },
            confirmButton = { Button(onClick = { actions.run({ loanExpectedDate(id, d?.toString()) }) { vm.replace(it); editDate = false } }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { editDate = false }) { Text("Cancel") } },
        )
    }
    if (reverse) ReasonDialog("Reverse this record?", "The original money entry and any repayments are reversed with opposite entries. Nothing is deleted.",
        onConfirm = { r -> actions.run({ reverseLoan(id, r) }) { vm.replace(it); reverse = false; c.toast("Reversed") } }, onDismiss = { reverse = false })
    ActionErrorDialog(actions)
}

@Composable
fun LoanFormScreen(kind: String, personId: Long?) {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("loan-form")
    val preset = personId?.let { pid -> loadVm("person:$pid") { person(pid) } }
    var k by rememberSaveable { mutableStateOf(kind) }
    var person by remember { mutableStateOf<PersonDto?>(null) }
    var amount by rememberSaveable { mutableStateOf("") }
    var method by rememberSaveable { mutableStateOf("CASH") }
    var date by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var expected by rememberSaveable { mutableStateOf<String?>(null) }
    var reference by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var errors by remember { mutableStateOf(mapOf<String, String>()) }
    val presetPerson = preset?.state?.dataOrNull()
    LaunchedEffect(presetPerson) { if (person == null && presetPerson != null) person = presetPerson }
    PJScaffold(title = if (k == "LENT") "Lend money" else "Borrow money", busy = actions.busy) { pad ->
        FormColumn(pad) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(k == "LENT", { k = "LENT" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Lend") }
                SegmentedButton(k == "BORROWED", { k = "BORROWED" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Borrow") }
            }
            PersonPickerField("Person *", person, { person = it; errors = errors - "person" }, error = errors["person"])
            DecimalInput("Amount *", amount, { amount = it; errors = errors - "amount" }, prefix = "₹", error = errors["amount"])
            MethodField(method, { method = it })
            DateInput("Date", Fmt.parseDate(date), { it?.let { d -> date = d.toString() } })
            DateInput("Expected return date", Fmt.parseDate(expected), { expected = it?.toString() }, clearable = true)
            TextInput(if (method == "CHEQUE") "Cheque number" else "Reference", reference, { reference = it })
            TextInput("Notes", notes, { notes = it }, singleLine = false)
            Text("No interest is applied. Money ${if (k == "LENT") "goes out" else "comes in"} as a daily transaction.", style = MaterialTheme.typography.bodySmall)
            PrimaryButton(if (actions.busy) "Saving…" else "Save", {
                val amt = Num.parse(amount)
                val e = mutableMapOf<String, String>()
                val p = person
                if (p == null) e["person"] = "Select a person"
                if (amt == null || amt.signum() <= 0) e["amount"] = "Enter an amount greater than zero"
                errors = e
                if (e.isNotEmpty() || p == null || amt == null) return@PrimaryButton
                val req = LoanRequest(p.id, k, Num.money(amt), date, method, reference.ifBlank { null }, notes.ifBlank { null }, expected)
                actions.run({ createLoan(req, p.name) }) { res ->
                    when (res) {
                        is Submit.Done -> { c.toast("Saved"); nav.popBackStack(); res.value?.let { nav.navigate(R.LoanDetail(it.id)) } }
                        is Submit.Queued -> { c.toast("Saved offline — will sync when online"); nav.popBackStack() }
                    }
                }
            }, enabled = !actions.busy)
        }
    }
    ActionErrorDialog(actions)
}
