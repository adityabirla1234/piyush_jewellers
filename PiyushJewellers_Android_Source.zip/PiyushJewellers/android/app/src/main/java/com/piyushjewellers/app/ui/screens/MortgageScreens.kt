package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.Surface
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.remote.*
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors
import java.math.BigDecimal
import java.math.RoundingMode

data class MortgageQuery(val q: String = "", val kind: String? = null, val status: String? = null)

@Composable
fun MortgagesScreen() {
    val nav = LocalNav.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var newAccount by rememberSaveable { mutableStateOf(false) }
    var chooseAccount by rememberSaveable { mutableStateOf(false) }
    val pledges = pagedVm<MortgageQuery, MortgageDto>("mortgages", MortgageQuery()) { q, p -> mortgages(q.kind, q.status, null, null, q.q, p) }
    val accounts = pagedVm<String, AccountDto>("maccounts", "") { q, p -> mortgageAccounts(q, p) }
    PJScaffold(
        title = "Mortgages (Jewellery/Cash)",
        topLevel = true,
        fab = {
            if (tab == 0) ExtendedFloatingActionButton(onClick = { chooseAccount = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("New mortgage") })
            else ExtendedFloatingActionButton(onClick = { newAccount = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("New account") })
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Mortgages") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Accounts") })
            }
            if (tab == 0) {
                OutlinedTextField(
                    value = pledges.query.q, onValueChange = { pledges.update(pledges.query.copy(q = it)) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Search serial, name or phone") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
                ChoiceChips(listOf(null, "JEWELLERY", "CASH"), pledges.query.kind, { it?.let(Fmt::humanize) ?: "Jewellery & Cash" },
                    { pledges.update(pledges.query.copy(kind = it), false) }, Modifier.padding(horizontal = 16.dp))
                ChoiceChips(listOf(null, "ACTIVE", "PAID"), pledges.query.status, { it?.let(Fmt::humanize) ?: "Any status" },
                    { pledges.update(pledges.query.copy(status = it), false) }, Modifier.padding(horizontal = 16.dp))
                LoadContent(pledges.state, onRetry = pledges::refresh, refreshing = pledges.refreshing, onRefresh = pledges::refresh) { list ->
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(list, key = { it.id }) { m -> MortgageRow(m) { nav.navigate(R.MortgageDetail(m.id)) } }
                        if (list.isEmpty()) item { EmptyState("No mortgages", "Create a mortgage account for a person, then add jewellery or cash mortgages.") }
                        loadMoreItem(pledges.hasMore, pledges.loadingMore, pledges::loadMore)
                    }
                }
            } else {
                OutlinedTextField(
                    value = accounts.query, onValueChange = { accounts.update(it) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Search serial, name or phone") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
                LoadContent(accounts.state, onRetry = accounts::refresh, refreshing = accounts.refreshing, onRefresh = accounts::refresh) { list ->
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(list, key = { it.id }) { a -> AccountRow(a) { nav.navigate(R.MortgageAccountDetail(a.id)) } }
                        if (list.isEmpty()) item { EmptyState("No accounts", "Each person has one mortgage account with a serial number.") }
                        loadMoreItem(accounts.hasMore, accounts.loadingMore, accounts::loadMore)
                    }
                }
            }
        }
    }
    if (newAccount) AccountCreateDialog(onDismiss = { newAccount = false }) { a -> newAccount = false; accounts.refresh(); nav.navigate(R.MortgageAccountDetail(a.id)) }
    if (chooseAccount) AccountPickerDialog(onDismiss = { chooseAccount = false }) { a -> chooseAccount = false; nav.navigate(R.MortgageForm(a.id)) }
}

@Composable
private fun MortgageRow(m: MortgageDto, onClick: () -> Unit) {
    ListRow(
        title = "${m.serial} · ${m.personName.orEmpty()}",
        subtitle = listOfNotNull(
            Fmt.humanize(m.kind),
            m.jewelleryName,
            m.netWeight?.let(Fmt::grams),
            "Issued ${Fmt.date(m.issueDate)}",
            "${Fmt.percent(m.monthlyRate)}/month",
        ).joinToString(" · "),
        trailingTop = Fmt.rupees(m.principal),
        trailingBottom = { StatusChip(m.completionState ?: m.status) },
        onClick = onClick,
    )
}

@Composable
private fun AccountRow(a: AccountDto, onClick: () -> Unit) {
    ListRow(
        title = "${a.serial} · ${a.name}",
        subtitle = listOfNotNull(a.phone, "${a.activeCount} active of ${a.totalCount}").joinToString(" · "),
        trailingTop = Fmt.rupees(a.activePrincipal),
        onClick = onClick,
    )
}

@Composable
private fun AccountPickerDialog(onDismiss: () -> Unit, onPick: (AccountDto) -> Unit) {
    val vm = pagedVm<String, AccountDto>("maccount-picker", "") { q, p -> mortgageAccounts(q, p) }
    var creating by rememberSaveable { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column {
                Row(Modifier.fillMaxWidth().padding(8.dp)) {
                    TextButton(onClick = onDismiss) { Text("Close") }
                    Text("Select mortgage account", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f).padding(top = 8.dp))
                    TextButton(onClick = { creating = true }) { Text("New") }
                }
                OutlinedTextField(
                    value = vm.query, onValueChange = { vm.update(it) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Search serial, name or phone") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
                Spacer(Modifier.height(8.dp))
                LoadContent(vm.state, onRetry = vm::refresh) { list ->
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(list, key = { it.id }) { a -> AccountRow(a) { onPick(a) } }
                        if (list.isEmpty()) item { EmptyState("No accounts", "Create one with New.") }
                        loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                    }
                }
            }
        }
    }
    if (creating) AccountCreateDialog(onDismiss = { creating = false }) { a -> creating = false; onPick(a) }
}

@Composable
private fun AccountCreateDialog(onDismiss: () -> Unit, onCreated: (AccountDto) -> Unit) {
    val actions = actionVm("maccount-create")
    var existing by rememberSaveable { mutableStateOf(true) }
    var person by remember { mutableStateOf<PersonDto?>(null) }
    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var address by rememberSaveable { mutableStateOf("") }
    var idRef by rememberSaveable { mutableStateOf("") }
    var reference by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New mortgage account") },
        text = {
            Column(Modifier.dialogScroll(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(existing, { existing = true }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Existing person") }
                    SegmentedButton(!existing, { existing = false }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("New person") }
                }
                if (existing) {
                    PersonPickerField("Person *", person, { person = it; error = null })
                } else {
                    TextInput("Name *", name, { name = it; error = null })
                    TextInput("Phone", phone, { phone = it }, keyboardType = KeyboardType.Phone)
                    TextInput("Address", address, { address = it }, singleLine = false)
                    TextInput("ID reference", idRef, { idRef = it })
                }
                TextInput("Reference / ledger note", reference, { reference = it })
                Text("A serial number is assigned automatically.", style = MaterialTheme.typography.bodySmall)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !actions.busy, onClick = {
                val p = person
                val req = if (existing) {
                    if (p == null) { error = "Select a person"; return@Button }
                    if (p.id < 0) { error = "This person hasn't synced yet. Try again once online."; return@Button }
                    AccountRequest(personId = p.id, reference = reference.ifBlank { null })
                } else {
                    if (name.isBlank()) { error = "Enter a name"; return@Button }
                    AccountRequest(name = name.trim(), phone = phone.ifBlank { null }, address = address.ifBlank { null }, idReference = idRef.ifBlank { null }, reference = reference.ifBlank { null })
                }
                actions.run({ createMortgageAccount(req) }) { onCreated(it) }
            }) { Text("Create") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    ActionErrorDialog(actions)
}

@Composable
fun MortgageAccountScreen(id: Long) {
    val nav = LocalNav.current
    val account = loadVm("maccount:$id") { mortgageAccount(id) }
    val list = pagedVm<Int, MortgageDto>("mortgages-acct:$id", 0) { _, p -> mortgages(null, null, id, null, null, p) }
    val a = account.state.dataOrNull()
    PJScaffold(
        title = a?.let { "${it.serial} · ${it.name}" } ?: "Mortgage account",
        subtitle = a?.phone,
        fab = { ExtendedFloatingActionButton(onClick = { nav.navigate(R.MortgageForm(id)) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("New mortgage") }) },
    ) { pad ->
        LoadContent(account.state, onRetry = { account.reload(); list.refresh() }, modifier = Modifier.padding(pad), refreshing = list.refreshing,
            onRefresh = { account.reload(); list.refresh() }) { acc ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                item {
                    Column(Modifier.padding(16.dp)) {
                        SectionCard("Account") {
                            InfoRow("Serial", acc.serial, emphasize = true)
                            InfoRow("Name", acc.name)
                            InfoRow("Phone", acc.phone)
                            InfoRow("Address", acc.address)
                            InfoRow("ID reference", acc.idReference)
                            InfoRow("Reference", acc.reference)
                            InfoRow("Active mortgages", "${acc.activeCount} of ${acc.totalCount}")
                            InfoRow("Active principal", Fmt.rupees(acc.activePrincipal), emphasize = true)
                            TextButton(onClick = { nav.navigate(R.DueAccount(acc.personId)) }) { Text("Open due account") }
                        }
                    }
                }
                when (val s = list.state) {
                    is com.piyushjewellers.app.ui.Load.Ready -> {
                        items(s.data, key = { it.id }) { m -> MortgageRow(m) { nav.navigate(R.MortgageDetail(m.id)) } }
                        if (s.data.isEmpty()) item { EmptyState("No mortgages yet", "Add a jewellery or cash mortgage for this account.") }
                    }
                    is com.piyushjewellers.app.ui.Load.Failed -> item { ErrorState(s.error, list::refresh) }
                    com.piyushjewellers.app.ui.Load.Loading -> item { LoadingState(Modifier.height(80.dp)) }
                }
                loadMoreItem(list.hasMore, list.loadingMore, list::loadMore)
            }
        }
    }
}

@Composable
fun MortgageFormScreen(accountId: Long) {
    val nav = LocalNav.current
    val c = container()
    val account = loadVm("maccount:$accountId") { mortgageAccount(accountId) }
    val actions = actionVm("mortgage-form:$accountId")
    var kind by rememberSaveable { mutableStateOf("JEWELLERY") }
    var issueDate by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var principal by rememberSaveable { mutableStateOf("") }
    var rate by rememberSaveable { mutableStateOf("") }
    var reminder by rememberSaveable { mutableStateOf<String?>(null) }
    var jewellery by rememberSaveable { mutableStateOf("") }
    var weight by rememberSaveable { mutableStateOf("") }
    var pieces by rememberSaveable { mutableStateOf("") }
    var metal by rememberSaveable { mutableStateOf("GOLD") }
    var method by rememberSaveable { mutableStateOf("CASH") }
    var notes by rememberSaveable { mutableStateOf("") }
    var errors by remember { mutableStateOf(mapOf<String, String>()) }
    val p = Num.parse(principal); val r = Num.parse(rate)
    val monthly = if (p != null && r != null) Num.money(p.multiply(r).divide(Num.HUNDRED, 10, RoundingMode.HALF_UP)) else null
    PJScaffold(title = "New mortgage", subtitle = account.state.dataOrNull()?.let { "${it.serial} · ${it.name}" }, busy = actions.busy) { pad ->
        FormColumn(pad) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(kind == "JEWELLERY", { kind = "JEWELLERY" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Jewellery") }
                SegmentedButton(kind == "CASH", { kind = "CASH" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Cash") }
            }
            DateInput("Issue date", Fmt.parseDate(issueDate), { it?.let { d -> issueDate = d.toString() } })
            DecimalInput("Principal *", principal, { principal = it; errors = errors - "principal" }, prefix = "₹", error = errors["principal"])
            DecimalInput("Monthly interest rate *", rate, { rate = it; errors = errors - "rate" }, scale = 4, suffix = "% / month", error = errors["rate"],
                supporting = monthly?.let { "≈ ${Fmt.rupees(it)} per full month" })
            if (kind == "JEWELLERY") {
                SectionCard("Pledged jewellery") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextInput("Jewellery description *", jewellery, { jewellery = it; errors = errors - "jewellery" }, error = errors["jewellery"])
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalInput("Net weight", weight, { weight = it }, Modifier.weight(1f), scale = 4, suffix = "g")
                            IntInput("Pieces", pieces, { pieces = it }, Modifier.weight(1f))
                        }
                        DropdownField("Metal", Options.metals, metal, Fmt::humanize, { metal = it })
                    }
                }
            }
            MethodField(method, { method = it }, label = "Amount given by")
            DateInput("Approx. reminder date", Fmt.parseDate(reminder), { reminder = it?.toString() }, clearable = true)
            TextInput("Notes", notes, { notes = it }, singleLine = false)
            SectionCard("How interest works") {
                Text("• Monthly rate on principal; part months are prorated by actual calendar days.", style = MaterialTheme.typography.bodySmall)
                Text("• Interest is added to principal at the end of each completed year.", style = MaterialTheme.typography.bodySmall)
                Text("• Calculated only when you ask; Full & Final never calculates automatically.", style = MaterialTheme.typography.bodySmall)
            }
            PrimaryButton(if (actions.busy) "Saving…" else "Save mortgage", {
                val e = mutableMapOf<String, String>()
                if (p == null || p.signum() <= 0) e["principal"] = "Enter the principal"
                if (r == null || r.signum() < 0) e["rate"] = "Enter the monthly rate"
                if (kind == "JEWELLERY" && jewellery.isBlank()) e["jewellery"] = "Describe the pledged jewellery"
                errors = e
                if (e.isNotEmpty() || p == null || r == null) return@PrimaryButton
                val req = MortgageRequest(
                    accountId, kind, issueDate, Num.money(p), r, reminder,
                    jewellery.ifBlank { null }.takeIf { kind == "JEWELLERY" },
                    Num.parse(weight).takeIf { kind == "JEWELLERY" },
                    pieces.toIntOrNull().takeIf { kind == "JEWELLERY" },
                    metal.takeIf { kind == "JEWELLERY" },
                    method, notes.ifBlank { null },
                )
                actions.run({ createMortgage(req) }) { m -> c.toast("Mortgage ${m.serial} created"); nav.popBackStack(); nav.navigate(R.MortgageDetail(m.id)) }
            }, enabled = !actions.busy)
        }
    }
    ActionErrorDialog(actions)
}

@Composable
fun MortgageDetailScreen(id: Long) {
    val nav = LocalNav.current
    val c = container()
    val vm = loadVm("mortgage:$id") { mortgage(id) }
    val actions = actionVm("mortgage:$id")
    var through by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var shownCalc by remember { mutableStateOf<CalculationDto?>(null) }
    var payment by rememberSaveable { mutableStateOf(false) }
    var fullFinalStep by rememberSaveable { mutableStateOf(0) }
    var outcome by remember { mutableStateOf<FullFinalResult?>(null) }
    var returning by rememberSaveable { mutableStateOf(false) }
    var reminderDialog by rememberSaveable { mutableStateOf(false) }
    val m = vm.state.dataOrNull()
    PJScaffold(
        title = m?.let { "${it.serial} · ${it.personName.orEmpty()}" } ?: "Mortgage",
        subtitle = m?.let { Fmt.humanize(it.kind) + " mortgage" },
        busy = actions.busy,
        actions = {
            if (m != null && m.status == "ACTIVE") IconButton(onClick = {
                nav.navigate(R.ReminderEditor(title = "Mortgage ${m.serial} · ${m.personName.orEmpty()}", sourceType = "MORTGAGE", sourceId = m.id, personId = m.personId, date = m.approxReminderDate))
            }) { Icon(Icons.Filled.NotificationsActive, "Set reminder") }
        },
    ) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { md ->
            val calc = shownCalc ?: md.lastCalculation
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    SectionCard("Details", trailing = { StatusChip(md.completionState ?: md.status) }) {
                        InfoRow("Account", md.accountSerial)
                        InfoRow("Person", listOfNotNull(md.personName, md.personPhone).joinToString(" · "))
                        InfoRow("Issue date", Fmt.date(md.issueDate))
                        InfoRow("Principal", Fmt.rupees(md.principal), emphasize = true)
                        InfoRow("Monthly rate", Fmt.percent(md.monthlyRate))
                        InfoRow("Given by", Fmt.method(md.issueMethod))
                        if (md.kind == "JEWELLERY") {
                            InfoRow("Jewellery", md.jewelleryName)
                            InfoRow("Net weight", md.netWeight?.let(Fmt::grams))
                            InfoRow("Pieces", md.pieces?.toString())
                            InfoRow("Metal", Fmt.humanize(md.metal))
                        }
                        InfoRow("Received so far", Fmt.rupees(md.amountReceived))
                        InfoRow("Reminder date", md.approxReminderDate?.let(Fmt::date) ?: "Not set")
                        if (md.settledDate != null) InfoRow("Settled", Fmt.date(md.settledDate))
                        if (md.jewelleryReturned) InfoRow("Jewellery returned", "${Fmt.date(md.jewelleryReturnDate)}${md.jewelleryReturnedTo?.let { " to $it" } ?: ""}")
                        if (!md.notes.isNullOrBlank()) InfoRow("Notes", md.notes)
                    }
                }
                if (md.status == "ACTIVE") {
                    item {
                        SectionCard("Calculate interest") {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                DateInput("Calculate through", Fmt.parseDate(through), { it?.let { d -> through = d.toString() } })
                                PrimaryButton("Calculate", {
                                    actions.run({ calculateInterest(id, through) }) { r -> shownCalc = r; vm.reload(silent = true) }
                                }, enabled = !actions.busy)
                            }
                        }
                    }
                }
                if (calc != null) {
                    item {
                        SectionCard("Interest through ${Fmt.date(calc.effectiveThrough)}") {
                            InfoRow("Principal", Fmt.rupees(calc.principal))
                            InfoRow("Total interest", Fmt.rupees(calc.totalInterest))
                            InfoRow("Capitalized principal", Fmt.rupees(calc.capitalizedPrincipal))
                            InfoRow("Total due", Fmt.rupees(calc.totalDue), emphasize = true)
                            InfoRow("Received", Fmt.rupees(calc.amountReceived))
                            InfoRow("Remaining", Fmt.rupees(calc.remainingBalance), emphasize = true, valueColor = MaterialTheme.colorScheme.tertiary)
                            if (calc.calculatedAt != null) Text("Calculated ${Fmt.dateTime(calc.calculatedAt)}${calc.calculatedBy?.let { " by $it" } ?: ""}", style = MaterialTheme.typography.labelSmall)
                            if (calc.periods.isNotEmpty()) {
                                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                                calc.periods.forEach { p ->
                                    Text("Period ${p.index}: ${Fmt.date(p.from)} → ${Fmt.date(p.to)}", fontWeight = FontWeight.Medium)
                                    Text(
                                        listOfNotNull("On ${Fmt.rupees(p.openingPrincipal)}", "${p.fullMonths} month(s)", "${p.extraDays} day(s)".takeIf { p.extraDays > 0 }, p.prorationDetail).joinToString(" · "),
                                        style = MaterialTheme.typography.bodySmall,
                                    )
                                    InfoRow("Interest", Fmt.rupees(p.interest))
                                    if (p.completedYear && p.capitalizedAfter != null) InfoRow("Capitalized to", Fmt.rupees(p.capitalizedAfter), valueColor = PJColors.GoldDeep)
                                }
                            }
                            calc.policyNotes.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
                item { SectionHeader("Payments", Modifier.padding(0.dp)) }
                if (md.payments.isEmpty()) item { Text("No payments yet", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(md.payments.size, key = { "mp$it" }) { i ->
                    val p = md.payments[i]
                    ListRow(
                        title = Fmt.rupees(p.amount) + if (p.finalSettlement) " · Full & Final" else "",
                        subtitle = listOfNotNull(Fmt.date(p.paymentDate), Fmt.method(p.method), p.reference, p.notes).joinToString(" · "),
                        trailingBottom = if (!p.effective) ({ StatusChip("REVERSED") }) else null,
                        onClick = p.transactionId?.let { tid -> { nav.navigate(R.TransactionDetail(tid)) } },
                    )
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (md.status == "ACTIVE" && !md.fullPaymentConfirmed) {
                            PrimaryButton("Full & Final", { fullFinalStep = 1 })
                            SecondaryButton("Record part payment", { payment = true })
                            SecondaryButton("Change reminder date", { reminderDialog = true })
                        }
                        if (md.kind == "JEWELLERY" && md.fullPaymentConfirmed && !md.jewelleryReturned) {
                            Text("Full amount received. Record the jewellery return to complete this mortgage.", color = PJColors.Warning)
                            PrimaryButton("Record jewellery return", { returning = true })
                        }
                        SecondaryButton("Open account ${md.accountSerial.orEmpty()}", { nav.navigate(R.MortgageAccountDetail(md.accountId)) })
                    }
                }
            }
        }
    }
    if (payment && m != null) {
        PaymentDialog(title = "Part payment received", onDismiss = { payment = false }) { method, amount, ref, chequeNo, _ ->
            actions.run({ mortgagePayment(id, MortgagePaymentRequest(Num.money(amount), Fmt.today().toString(), method, chequeNo ?: ref)) }) {
                vm.replace(it); payment = false; c.toast("Payment recorded")
            }
        }
    }
    if (fullFinalStep == 1) {
        AlertDialog(
            onDismissRequest = { fullFinalStep = 0 },
            title = { Text("Full & Final") },
            text = { Text("Was the full amount received?\n\nNo interest is calculated automatically here. Use Calculate interest first if you need a reference figure.") },
            confirmButton = { Button(onClick = { fullFinalStep = 2 }) { Text("Yes, received") } },
            dismissButton = {
                TextButton(onClick = {
                    actions.run({ fullFinal(id, FullFinalRequest(fullAmountReceived = false)) }) { r -> fullFinalStep = 0; vm.replace(r.mortgage); outcome = r }
                }) { Text("No") }
            },
        )
    }
    if (fullFinalStep == 2 && m != null) {
        FullFinalDialog(m, onDismiss = { fullFinalStep = 0 }) { req ->
            actions.run({ fullFinal(id, req) }) { r -> fullFinalStep = 0; vm.replace(r.mortgage); outcome = r }
        }
    }
    outcome?.let { r ->
        AlertDialog(
            onDismissRequest = { outcome = null },
            title = { Text(Fmt.humanize(r.outcome)) },
            text = { Text(r.message) },
            confirmButton = {
                if (r.outcome == "AWAITING_JEWELLERY_RETURN") Button(onClick = { outcome = null; returning = true }) { Text("Record return now") }
                else Button(onClick = { outcome = null }) { Text("OK") }
            },
            dismissButton = if (r.outcome == "AWAITING_JEWELLERY_RETURN") ({ TextButton(onClick = { outcome = null }) { Text("Later") } }) else null,
        )
    }
    if (returning && m != null) {
        JewelleryReturnDialog(m.personName, onDismiss = { returning = false }) { req ->
            actions.run({ jewelleryReturn(id, req) }) { vm.replace(it); returning = false; c.toast("Jewellery return recorded") }
        }
    }
    if (reminderDialog && m != null) {
        var d by remember { mutableStateOf(Fmt.parseDate(m.approxReminderDate)) }
        AlertDialog(
            onDismissRequest = { reminderDialog = false },
            title = { Text("Approx. reminder date") },
            text = { DateInput("Date", d, { d = it }, clearable = true) },
            confirmButton = { Button(onClick = { actions.run({ mortgageReminderDate(id, d?.toString()) }) { vm.replace(it); reminderDialog = false } }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { reminderDialog = false }) { Text("Cancel") } },
        )
    }
    ActionErrorDialog(actions)
}

@Composable
private fun FullFinalDialog(m: MortgageDto, onDismiss: () -> Unit, onConfirm: (FullFinalRequest) -> Unit) {
    var amount by rememberSaveable { mutableStateOf("") }
    var method by rememberSaveable { mutableStateOf("CASH") }
    var date by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var reference by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Final amount received") },
        text = {
            Column(Modifier.dialogScroll(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DecimalInput("Amount received now *", amount, { amount = it; error = null }, prefix = "₹", error = error)
                m.lastCalculation?.let { Text("Last calculated remaining (reference only): ${Fmt.rupees(it.remainingBalance)} through ${Fmt.date(it.effectiveThrough)}", style = MaterialTheme.typography.bodySmall) }
                MethodField(method, { method = it })
                DateInput("Date", Fmt.parseDate(date), { it?.let { d -> date = d.toString() } })
                TextInput(if (method == "CHEQUE") "Cheque number" else "Reference", reference, { reference = it })
                TextInput("Notes", notes, { notes = it })
                if (m.kind == "JEWELLERY") Text("The mortgage completes after the jewellery return is recorded.", style = MaterialTheme.typography.bodySmall, color = PJColors.Warning)
            }
        },
        confirmButton = {
            Button(onClick = {
                val a = Num.parse(amount)
                if (a == null || a.signum() <= 0) { error = "Enter the amount received"; return@Button }
                onConfirm(FullFinalRequest(true, Num.money(a), date, method, reference.ifBlank { null }, notes.ifBlank { null }))
            }) { Text("Confirm") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun JewelleryReturnDialog(defaultTo: String?, onDismiss: () -> Unit, onConfirm: (JewelleryReturnRequest) -> Unit) {
    var date by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var to by rememberSaveable { mutableStateOf(defaultTo.orEmpty()) }
    var notes by rememberSaveable { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Jewellery return") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateInput("Return date", Fmt.parseDate(date), { it?.let { d -> date = d.toString() } })
                TextInput("Returned to", to, { to = it })
                TextInput("Notes", notes, { notes = it })
            }
        },
        confirmButton = { Button(onClick = { onConfirm(JewelleryReturnRequest(date, to.ifBlank { null }, notes.ifBlank { null })) }) { Text("Record return") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}