package com.piyushjewellers.app.ui.nav

import kotlinx.serialization.Serializable

object R {
    // Top-level (drawer) destinations
    @Serializable data object Dashboard
    @Serializable data object People
    @Serializable data object Inventory
    @Serializable data object Bills
    @Serializable data object Dealers
    @Serializable data object Transactions
    @Serializable data object Loans
    @Serializable data object Mortgages
    @Serializable data object Exchanges
    @Serializable data object Dues
    @Serializable data object Reminders
    @Serializable data object Reports
    @Serializable data object Settings

    // Detail and form destinations
    @Serializable data class PersonDetail(val id: Long)
    @Serializable data class PersonForm(val id: Long? = null)
    @Serializable data class ProductDetail(val id: Long)
    @Serializable data class ProductForm(val id: Long? = null)
    @Serializable data class PhotoViewer(val productId: Long, val index: Int = 0)
    @Serializable data class BarLotDetail(val id: Long)
    @Serializable data class BillDetail(val id: Long)
    @Serializable data class BillEditor(val id: Long? = null, val type: String = "SALES", val personId: Long? = null)
    @Serializable data class DealerDetail(val id: Long)
    @Serializable data class DealerBillDetail(val id: Long)
    @Serializable data class DealerBillEditor(val dealerId: Long? = null, val shopId: Long? = null)
    @Serializable data class Settlement(val billId: Long)
    @Serializable data class TransactionDetail(val id: Long)
    @Serializable data class TransactionEntry(val personId: Long? = null, val direction: String = "IN")
    @Serializable data object Transfer
    @Serializable data object Cheques
    @Serializable data class LoanDetail(val id: Long)
    @Serializable data class LoanForm(val kind: String = "LENT", val personId: Long? = null)
    @Serializable data class MortgageAccountDetail(val id: Long)
    @Serializable data class MortgageDetail(val id: Long)
    @Serializable data class MortgageForm(val accountId: Long)
    @Serializable data class ExchangeDetail(val id: Long)
    @Serializable data class ExchangeEditor(val id: Long? = null, val personId: Long? = null)
    @Serializable data class DueAccount(val personId: Long)
    @Serializable data class ReminderEditor(
        val key: String? = null,
        val title: String? = null,
        val sourceType: String = "CUSTOM",
        val sourceId: Long? = null,
        val personId: Long? = null,
        val date: String? = null,
    )
    @Serializable data object Sync
    @Serializable data object Audit
}
