package com.piyushjewellers.app.core

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Money and weight helpers. All arithmetic stays in BigDecimal; Float/Double are never used for values. */
object Num {
    val ZERO: BigDecimal = BigDecimal.ZERO
    val HUNDRED: BigDecimal = BigDecimal(100)

    fun money(v: BigDecimal): BigDecimal = v.setScale(2, RoundingMode.HALF_UP)
    fun weight(v: BigDecimal): BigDecimal = v.setScale(4, RoundingMode.HALF_UP)
    fun nz(v: BigDecimal?): BigDecimal = v ?: ZERO

    /** Parses user input. Returns null for blank or invalid text; never guesses. */
    fun parse(text: String?): BigDecimal? {
        val t = text?.trim()?.replace(",", "")?.removePrefix("₹")?.trim() ?: return null
        if (t.isEmpty()) return null
        return try {
            BigDecimal(t)
        } catch (e: NumberFormatException) {
            null
        }
    }

    fun isValidDecimalInput(text: String, maxScale: Int): Boolean {
        if (text.isEmpty()) return true
        val regex = Regex("^\\d{0,12}(\\.\\d{0,$maxScale})?$")
        return regex.matches(text)
    }
}

object Fmt {
    private val zone: ZoneId = ZoneId.of("Asia/Kolkata")
    private val dateFmt = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)
    private val dateTimeFmt = DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.ENGLISH)

    fun zone(): ZoneId = zone

    /** Indian digit grouping: 12,34,567.89 */
    fun rupees(v: BigDecimal?, showSign: Boolean = false): String {
        if (v == null) return "—"
        val scaled = v.setScale(2, RoundingMode.HALF_UP)
        val negative = scaled.signum() < 0
        val plain = scaled.abs().toPlainString()
        val intPart = plain.substringBefore('.')
        val frac = plain.substringAfter('.', "00")
        val grouped = groupIndian(intPart)
        val sign = when {
            negative -> "−"
            showSign && scaled.signum() > 0 -> "+"
            else -> ""
        }
        return "$sign₹$grouped.$frac"
    }

    fun groupIndian(digits: String): String {
        if (digits.length <= 3) return digits
        val last3 = digits.takeLast(3)
        var rest = digits.dropLast(3)
        val parts = ArrayList<String>()
        while (rest.length > 2) {
            parts.add(0, rest.takeLast(2))
            rest = rest.dropLast(2)
        }
        if (rest.isNotEmpty()) parts.add(0, rest)
        return parts.joinToString(",") + "," + last3
    }

    /** Weight in grams, up to 4 decimals without trailing zeros (minimum 3 shown for readability). */
    fun grams(v: BigDecimal?): String {
        if (v == null) return "—"
        val s = v.setScale(4, RoundingMode.HALF_UP).stripTrailingZeros()
        val scaled = if (s.scale() < 3) s.setScale(3) else s
        return scaled.toPlainString() + " g"
    }

    fun plain(v: BigDecimal?): String = v?.stripTrailingZeros()?.toPlainString() ?: ""

    fun percent(v: BigDecimal?): String = if (v == null) "—" else v.stripTrailingZeros().toPlainString() + "%"

    fun date(iso: String?): String {
        if (iso.isNullOrBlank()) return "—"
        return runCatching { LocalDate.parse(iso.take(10)).format(dateFmt) }.getOrDefault(iso)
    }

    fun date(d: LocalDate?): String = d?.format(dateFmt) ?: "—"

    fun dateTime(iso: String?): String {
        if (iso.isNullOrBlank()) return "—"
        return runCatching {
            if (iso.endsWith("Z") || iso.contains('+')) {
                Instant.parse(iso).atZone(zone).format(dateTimeFmt)
            } else {
                LocalDateTime.parse(iso).format(dateTimeFmt)
            }
        }.getOrElse { date(iso) }
    }

    fun epoch(ms: Long): String = Instant.ofEpochMilli(ms).atZone(zone).format(dateTimeFmt)

    fun today(): LocalDate = LocalDate.now(zone)
    fun now(): LocalDateTime = LocalDateTime.now(zone).withNano(0)

    fun parseDate(iso: String?): LocalDate? = iso?.takeIf { it.length >= 10 }?.let { runCatching { LocalDate.parse(it.take(10)) }.getOrNull() }

    fun humanize(enumName: String?): String {
        if (enumName.isNullOrBlank()) return "—"
        return enumName.split('_').joinToString(" ") { part ->
            part.lowercase().replaceFirstChar { it.titlecase(Locale.ENGLISH) }
        }
    }

    fun method(m: String?): String = when (m) {
        "CASH" -> "Cash"
        "BANK" -> "Bank"
        "UPI" -> "UPI"
        "CHEQUE" -> "Cheque"
        "OTHER" -> "Other"
        else -> humanize(m)
    }

    fun carat(c: String?): String = c?.removePrefix("K")?.let { "${it}K" } ?: "—"
}
