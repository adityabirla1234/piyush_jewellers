package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.piyushjewellers.app.AppContainer
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.remote.PersonDueSummary
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.appViewModel
import com.piyushjewellers.app.ui.asApp
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.theme.PJColors
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.math.BigDecimal

data class DueQuery(val q: String = "", val direction: String? = null, val source: String? = null, val state: String = "ACTIVE")

data class DueTotals(val receivable: BigDecimal, val payable: BigDecimal, val net: BigDecimal)

/** Due overview carries totals alongside a page of people, so it pages manually instead of using PagedVm. */
class DuesVm(private val c: AppContainer) : ViewModel() {
    var query by mutableStateOf(DueQuery())
        private set
    var state by mutableStateOf<Load<List<PersonDueSummary>>>(Load.Loading)
        private set
    var totals by mutableStateOf<DueTotals?>(null)
        private set
    var hasMore by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var refreshing by mutableStateOf(false)
        private set
    private var page = 0
    private var job: Job? = null

    init { load(false) }

    fun update(q: DueQuery, debounce: Boolean = true) {
        if (q == query) return
        query = q
        load(debounce)
    }

    fun refresh() {
        refreshing = state is Load.Ready
        load(false)
    }

    private fun load(debounce: Boolean) {
        job?.cancel()
        if (state !is Load.Ready) state = Load.Loading
        job = viewModelScope.launch {
            if (debounce) delay(300)
            try {
                val q = query
                val f = c.repo.dues(q.q, q.direction, q.source, q.state, 0)
                page = 0
                totals = DueTotals(f.data.totalReceivable, f.data.totalPayable, f.data.net)
                hasMore = !f.data.persons.last
                state = Load.Ready(f.data.persons.content, f.fromCache, f.savedAt)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                state = Load.Failed(e.asApp())
            } finally {
                refreshing = false
            }
        }
    }

    fun loadMore() {
        if (!hasMore || loadingMore) return
        loadingMore = true
        viewModelScope.launch {
            try {
                val q = query
                val f = c.repo.dues(q.q, q.direction, q.source, q.state, page + 1)
                page += 1
                hasMore = !f.data.persons.last
                state = Load.Ready(state.dataOrNull().orEmpty() + f.data.persons.content, f.fromCache, f.savedAt)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
            } finally {
                loadingMore = false
            }
        }
    }
}

private val sources = listOf("CUSTOMER_BILL", "DEALER_BILL", "LOAN", "JEWELLERY_MORTGAGE", "CASH_MORTGAGE")

@Composable
fun DuesScreen() {
    val nav = LocalNav.current
    val vm = appViewModel("dues") { DuesVm(it) }
    PJScaffold(title = "Due Management", topLevel = true) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = vm.query.q, onValueChange = { vm.update(vm.query.copy(q = it)) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search name, phone or serial") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
            )
            Column(Modifier.padding(horizontal = 16.dp)) {
                ChoiceChips(listOf(null, "RECEIVABLE", "PAYABLE"), vm.query.direction, { when (it) { "RECEIVABLE" -> "To receive"; "PAYABLE" -> "To pay"; else -> "Both" } },
                    { vm.update(vm.query.copy(direction = it), false) })
                ChoiceChips(listOf<String?>(null) + sources, vm.query.source, { it?.let(Fmt::humanize) ?: "All sources" }, { vm.update(vm.query.copy(source = it), false) })
                ChoiceChips(listOf("ACTIVE", "SETTLED", "ALL"), vm.query.state, { Fmt.humanize(it) }, { vm.update(vm.query.copy(state = it), false) })
            }
            LoadContent(vm.state, onRetry = vm::refresh, refreshing = vm.refreshing, onRefresh = vm::refresh) { list ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
                    vm.totals?.let { t ->
                        item {
                            Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                StatCard("To receive", Fmt.rupees(t.receivable), Modifier.weight(1f), accent = PJColors.Success)
                                StatCard("To pay", Fmt.rupees(t.payable), Modifier.weight(1f), accent = PJColors.Danger)
                                StatCard("Net", Fmt.rupees(t.net), Modifier.weight(1f))
                            }
                        }
                    }
                    items(list, key = { it.personId }) { p ->
                        ListRow(
                            title = p.name + (p.serial?.let { " · $it" } ?: ""),
                            subtitle = listOfNotNull(
                                p.phone,
                                "${p.activeItems} open",
                                p.sources.joinToString(", ") { Fmt.humanize(it) }.ifBlank { null },
                                p.nextExpectedDate?.let { "Next ${Fmt.date(it)}" },
                                if (p.receivableWeight.signum() != 0 || p.payableWeight.signum() != 0) "Metal ${Fmt.grams(p.receivableWeight)} / ${Fmt.grams(p.payableWeight)}" else null,
                            ).joinToString(" · "),
                            trailingTop = Fmt.rupees(p.net),
                            trailingColor = if (p.net.signum() >= 0) PJColors.Success else PJColors.Danger,
                            trailingBottom = { Text(if (p.net.signum() >= 0) "Net receivable" else "Net payable", style = MaterialTheme.typography.labelSmall) },
                            onClick = { nav.navigate(R.DueAccount(p.personId)) },
                        )
                    }
                    if (list.isEmpty()) item { EmptyState("Nothing due", "Outstanding bills, dealer balances, loans and mortgages appear here once per person.", Icons.Filled.AccountBalanceWallet) }
                    loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                }
            }
        }
    }
}

@Composable
fun DueAccountScreen(personId: Long) {
    val nav = LocalNav.current
    val vm = loadVm("dueacct:$personId") { dueAccount(personId) }
    val a = vm.state.dataOrNull()
    PJScaffold(
        title = a?.person?.name ?: "Due account",
        subtitle = a?.person?.phone,
        actions = {
            if (a != null) IconButton(onClick = {
                nav.navigate(R.ReminderEditor(title = "Dues: ${a.person.name} · net ${Fmt.rupees(a.net)}", sourceType = "PERSON", sourceId = personId, personId = personId))
            }) { Icon(Icons.Filled.NotificationsActive, "Remind me") }
        },
    ) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { acc ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                personAccountItems(acc, onOpen = { src, sid -> openSource(nav, src, sid) })
                item { SecondaryButton("Open person", { nav.navigate(R.PersonDetail(personId)) }) }
            }
        }
    }
}
