package com.piyushjewellers.app.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import coil.compose.AsyncImage
import com.piyushjewellers.app.data.remote.ImageDto
import com.piyushjewellers.app.data.remote.SettingsDto
import com.piyushjewellers.app.sync.EntityTypes
import com.piyushjewellers.app.sync.Submit
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.theme.PJColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Downscales to at most 2048 px, applies EXIF rotation and writes a JPEG ready for upload. */
object PhotoPrep {
    private const val MAX_EDGE = 2048

    fun prepare(context: Context, uri: Uri): File? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= MAX_EDGE || bounds.outHeight / (sample * 2) >= MAX_EDGE) sample *= 2
        val decoded = resolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val rotation = resolver.openInputStream(uri)?.use {
            when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } ?: 0f
        var bmp: Bitmap = decoded
        val longest = maxOf(bmp.width, bmp.height)
        if (longest > MAX_EDGE) {
            val scale = MAX_EDGE.toFloat() / longest
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        }
        if (rotation != 0f) {
            val m = Matrix().apply { postRotate(rotation) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val dir = File(context.filesDir, "pending_photos").apply { mkdirs() }
        val out = File(dir, "${UUID.randomUUID()}.jpg")
        out.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return out
    }

    fun cameraTarget(context: Context): Pair<File, Uri> {
        val dir = File(context.cacheDir, "camera").apply { mkdirs() }
        val file = File(dir, "capture-${System.currentTimeMillis()}.jpg")
        return file to FileProvider.getUriForFile(context, context.packageName + ".files", file)
    }
}

@Composable
fun ProductGallery(productId: Long, onChanged: () -> Unit) {
    val c = container()
    val nav = LocalNav.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val images = loadVm("images:$productId") { images(productId) }
    val settings = loadVm("settings") { settings() }
    val actions = actionVm("photos:$productId")
    val pendingAll by c.repo.observeUnsynced(EntityTypes.PHOTO).collectAsState(initial = emptyList())
    val pending = pendingAll.filter { it.path.endsWith("/products/$productId/images") }
    var confirmDelete by remember { mutableStateOf<ImageDto?>(null) }
    var preparing by remember { mutableStateOf(false) }
    var cameraFile by rememberSaveable { mutableStateOf<String?>(null) }
    val maxPhotos = (settings.state.dataOrNull() as SettingsDto?)?.maxPhotosPerProduct ?: 10
    val list = images.state.dataOrNull().orEmpty().sortedBy { it.displayOrder }
    val remaining = maxPhotos - list.size - pending.size

    fun upload(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val allowed = uris.take(remaining.coerceAtLeast(0))
        if (allowed.size < uris.size) c.toast("Only $maxPhotos photos are allowed per product")
        if (allowed.isEmpty()) return
        preparing = true
        scope.launch {
            var queued = 0
            var failed = 0
            for (uri in allowed) {
                val file = withContext(Dispatchers.IO) { runCatching { PhotoPrep.prepare(context, uri) }.getOrNull() }
                if (file == null) { failed++; continue }
                try {
                    when (c.repo.uploadPhoto(productId, file, "Photo for product #$productId")) {
                        is Submit.Done -> Unit
                        is Submit.Queued -> queued++
                    }
                } catch (e: Exception) {
                    failed++
                    c.toast(e.message ?: "Upload failed")
                }
            }
            preparing = false
            images.reload(silent = true)
            onChanged()
            when {
                queued > 0 -> c.toast("$queued photo(s) saved on this device and will upload when online")
                failed > 0 -> c.toast("$failed photo(s) could not be added")
                else -> c.toast("Photos added")
            }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(10)) { uris -> upload(uris) }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val path = cameraFile
        cameraFile = null
        if (ok && path != null) {
            val f = File(path)
            upload(listOf(FileProvider.getUriForFile(context, context.packageName + ".files", f)))
        }
    }

    Column {
        val pager = rememberPagerState { list.size.coerceAtLeast(1) }
        Box(Modifier.fillMaxWidth().aspectRatio(1.2f).background(MaterialTheme.colorScheme.surfaceVariant)) {
            when {
                images.state is Load.Loading -> LoadingState()
                list.isEmpty() -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Diamond, null, Modifier.size(56.dp), tint = PJColors.Gold)
                    Text("No photos yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> {
                    HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
                        val img = list.getOrNull(page) ?: return@HorizontalPager
                        AsyncImage(
                            model = c.absoluteUrl(img.url),
                            contentDescription = "Photo ${page + 1}",
                            imageLoader = c.imageLoader,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clickable { nav.navigate(R.PhotoViewer(productId, page)) },
                        )
                    }
                    Surface(Modifier.align(Alignment.BottomEnd).padding(10.dp), shape = RoundedCornerShape(50), color = PJColors.Ink.copy(alpha = 0.7f)) {
                        Text("${pager.currentPage + 1} of ${list.size}", Modifier.padding(horizontal = 10.dp, vertical = 4.dp), color = PJColors.Ivory, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(enabled = remaining > 0 && !preparing, onClick = {
                val (file, uri) = PhotoPrep.cameraTarget(context)
                cameraFile = file.absolutePath
                camera.launch(uri)
            }) {
                Icon(Icons.Filled.PhotoCamera, null); Spacer(Modifier.width(6.dp)); Text("Camera")
            }
            OutlinedButton(enabled = remaining > 0 && !preparing, onClick = {
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }) {
                Icon(Icons.Filled.PhotoLibrary, null); Spacer(Modifier.width(6.dp)); Text("Gallery")
            }
            Spacer(Modifier.weight(1f))
            Text("${list.size + pending.size}/$maxPhotos", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (preparing || actions.busy) androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        if (list.isNotEmpty() || pending.isNotEmpty()) {
            Text("Tap ★ to choose the catalog photo; use arrows to reorder.", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                itemsIndexed(list, key = { _, img -> img.id }) { index, img ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(96.dp).clip(RoundedCornerShape(10.dp))
                                .border(if (img.primary) 3.dp else 1.dp, if (img.primary) PJColors.Gold else MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                                .clickable { nav.navigate(R.PhotoViewer(productId, index)) },
                        ) {
                            AsyncImage(c.absoluteUrl(img.thumbnailUrl), "Photo ${index + 1}", c.imageLoader, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Row {
                            IconButton(enabled = index > 0 && !actions.busy, onClick = {
                                val ids = list.map { it.id }.toMutableList().apply { add(index - 1, removeAt(index)) }
                                actions.run({ reorderImages(productId, ids) }) { images.replace(it); onChanged() }
                            }, modifier = Modifier.size(32.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Move left") }
                            IconButton(enabled = !img.primary && !actions.busy, onClick = {
                                actions.run({ setPrimaryImage(productId, img.id) }) { images.replace(it); onChanged(); c.toast("Catalog photo updated") }
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(if (img.primary) Icons.Filled.Star else Icons.Filled.StarBorder, if (img.primary) "Primary photo" else "Make primary", tint = PJColors.Gold)
                            }
                            IconButton(enabled = index < list.size - 1 && !actions.busy, onClick = {
                                val ids = list.map { it.id }.toMutableList().apply { add(index + 1, removeAt(index)) }
                                actions.run({ reorderImages(productId, ids) }) { images.replace(it); onChanged() }
                            }, modifier = Modifier.size(32.dp)) { Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, "Move right") }
                        }
                        IconButton(enabled = !actions.busy, onClick = { confirmDelete = img }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Filled.Delete, "Delete photo", tint = PJColors.Danger)
                        }
                    }
                }
                itemsIndexed(pending, key = { _, op -> op.id }) { _, op ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(96.dp).clip(RoundedCornerShape(10.dp)).border(1.dp, PJColors.Warning, RoundedCornerShape(10.dp))) {
                            AsyncImage(op.filePath?.let { File(it) }, "Pending photo", c.imageLoader, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            Icon(Icons.Filled.Sync, null, Modifier.align(Alignment.TopEnd).padding(4.dp).size(18.dp), tint = PJColors.Warning)
                        }
                        Spacer(Modifier.height(4.dp))
                        StatusChip(op.state, syncLabel(op.state))
                    }
                }
            }
        }
    }

    confirmDelete?.let { img ->
        ConfirmDialog(
            title = "Delete photo?",
            text = if (img.primary) "This is the catalog photo. The next photo becomes primary. This cannot be undone." else "This photo will be removed permanently.",
            confirmText = "Delete",
            destructive = true,
            onConfirm = {
                confirmDelete = null
                actions.run({ deleteImage(productId, img.id) }) { images.replace(it); onChanged(); c.toast("Photo deleted") }
            },
            onDismiss = { confirmDelete = null },
        )
    }
    ActionErrorDialog(actions)
}

@Composable
fun PhotoViewerScreen(productId: Long, startIndex: Int) {
    val c = container()
    val nav = LocalNav.current
    val images = loadVm("images:$productId") { images(productId) }
    val list = images.state.dataOrNull().orEmpty().sortedBy { it.displayOrder }
    var zoomed by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            images.state is Load.Failed -> ErrorState((images.state as Load.Failed).error, { images.reload() })
            list.isEmpty() -> LoadingState()
            else -> {
                val pager = rememberPagerState(initialPage = startIndex.coerceIn(0, list.size - 1)) { list.size }
                HorizontalPager(state = pager, userScrollEnabled = !zoomed, modifier = Modifier.fillMaxSize()) { page ->
                    ZoomableImage(c.absoluteUrl(list[page].url), "Photo ${page + 1} of ${list.size}", c.imageLoader) { zoomed = it }
                }
                Row(
                    Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                    Spacer(Modifier.weight(1f))
                    Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha = 0.15f)) {
                        Text("${pager.currentPage + 1} of ${list.size}", Modifier.padding(horizontal = 12.dp, vertical = 6.dp), color = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                }
            }
        }
    }
}

/** Pinch to zoom and pan; single-finger swipes pass through to the pager unless zoomed in. Double-tap toggles zoom. */
@Composable
private fun ZoomableImage(url: String, description: String, loader: coil.ImageLoader, onZoomChanged: (Boolean) -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    Box(
        Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    if (scale > 1f) {
                        scale = 1f; offset = Offset.Zero
                    } else scale = 2.5f
                    onZoomChanged(scale > 1f)
                })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val multiTouch = event.changes.count { it.pressed } > 1
                        if (multiTouch || scale > 1f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            offset = if (scale > 1f) {
                                val maxX = (size.width * (scale - 1f)) / 2f
                                val maxY = (size.height * (scale - 1f)) / 2f
                                Offset((offset.x + pan.x).coerceIn(-maxX, maxX), (offset.y + pan.y).coerceIn(-maxY, maxY))
                            } else Offset.Zero
                            onZoomChanged(scale > 1f)
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            },
    ) {
        AsyncImage(
            model = url,
            contentDescription = description,
            imageLoader = loader,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y
            },
        )
    }
}

private fun androidx.compose.ui.input.pointer.PointerInputChange.positionChanged(): Boolean = position != previousPosition
