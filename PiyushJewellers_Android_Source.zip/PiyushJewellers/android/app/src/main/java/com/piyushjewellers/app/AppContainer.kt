package com.piyushjewellers.app

import android.content.Context
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.piyushjewellers.app.data.ConnectivityMonitor
import com.piyushjewellers.app.data.Repository
import com.piyushjewellers.app.data.SessionStore
import com.piyushjewellers.app.data.local.AppDatabase
import com.piyushjewellers.app.data.remote.NetworkFactory
import com.piyushjewellers.app.data.remote.PjApi
import com.piyushjewellers.app.reminders.ReminderScheduler
import com.piyushjewellers.app.sync.Outbox
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import okhttp3.OkHttpClient

/** Manual dependency container; one instance per process. */
class AppContainer(val context: Context) {
    val session = SessionStore(context)
    val db: AppDatabase = AppDatabase.create(context)

    val okHttp: OkHttpClient = NetworkFactory.client(session) { session.baseUrl }

    @Volatile private var apiCache: Pair<String, PjApi>? = null

    /** Retrofit is rebuilt when the owner changes the server address in Settings. */
    val api: PjApi
        get() {
            val url = session.baseUrl.ifBlank { "http://invalid.local/" }
            apiCache?.let { (u, a) -> if (u == url) return a }
            return NetworkFactory.api(okHttp, url).also { apiCache = url to it }
        }

    val imageLoader: ImageLoader = ImageLoader.Builder(context)
        .okHttpClient(okHttp)
        .memoryCache { MemoryCache.Builder(context).maxSizePercent(0.20).build() }
        .diskCache { DiskCache.Builder().directory(context.cacheDir.resolve("images")).maxSizeBytes(150L * 1024 * 1024).build() }
        .crossfade(true)
        .respectCacheHeaders(false)
        .build()

    val outbox = Outbox(context, db, { okHttp }, session)
    val reminderScheduler = ReminderScheduler(context)
    val connectivity = ConnectivityMonitor(context) { outbox.scheduleSync() }
    val repo = Repository(this)

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()
    fun toast(message: String) {
        _messages.tryEmit(message)
    }

    fun absoluteUrl(path: String): String =
        if (path.startsWith("http")) path else session.baseUrl.trimEnd('/') + "/" + path.trimStart('/')
}
