package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import com.piyushjewellers.app.core.Carat
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.MetalCalc
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.remote.*
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.appViewModel
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors
import java.math.BigDecimal
import java.time.LocalDate

data class DealerBillQuery(val q: String = "", val metal: String? = null, val status: String? = null)

@Composable
fun DealersScreen() {
    val nav = LocalNav.current
    var tab by rememberSaveable { mutableStateOf(0) }
    var addDealer by rememberSaveable { mutableStateOf(false) }
    val dealers = pagedVm<String, DealerDto>("dealers", "") { q, p -> dealers(q, p) }
    val bills = pagedVm<DealerBillQuery, DealerBillDto>("dealer-bills", DealerBillQuery()) { q, p -> dealerBills(null, null, q.metal, q.status, q.q, p) }
    PJScaffold(
        title = "Dealer & Shop Management",
        topLevel = true,
        fab = {
            if (tab == 0) ExtendedFloatingActionButton(onClick = { addDealer = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add dealer") })
            else ExtendedFloatingActionButton(onClick = { nav.navigate(R.DealerBillEditor()) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Dealer bill") })
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Dealers") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Dealer bills") })
            }
            if (tab == 0) {
                OutlinedTextField(
                    value = dealers.query, onValueChange = { dealers.update(it) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Search dealer name or phone") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
                LoadContent(dealers.state, onRetry = dealers::refresh, refreshing = dealers.refreshing, onRefresh = dealers::refresh) { list ->
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(list, key = { it.id }) { d ->
                            ListRow(d.name, listOfNotNull(d.phone, "${d.shopCount} shop(s)", d.address?.take(40)).joinToString(" · "), onClick = { nav.navigate(R.DealerDetail(d.id)) })
                        }
                        if (list.isEmpty()) item { EmptyState("No dealers", "Add dealers to record gold and silver dealings.", Icons.Filled.Store) }
                        loadMoreItem(dealers.hasMore, dealers.loadingMore, dealers::loadMore)
                    }
                }
            } else {
                OutlinedTextField(
                    value = bills.query.q, onValueChange = { bills.update(bills.query.copy(q = it)) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Search bill number or dealer") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
                ChoiceChips(listOf(null) + Options.dealerMetals, bills.query.metal, { it?.let(Fmt::humanize) ?: "Gold & Silver" }, { bills.update(bills.query.copy(metal = it), false) }, Modifier.padding(horizontal = 16.dp))
                ChoiceChips(listOf(null, "OPEN", "PARTIALLY_SETTLED", "SETTLED", "REVERSED"), bills.query.status, { it?.let(Fmt::humanize) ?: "Any status" }, { bills.update(bills.query.copy(status = it), false) }, Modifier.padding(horizontal = 16.dp))
                LoadContent(bills.state, onRetry = bills::refresh, refreshing = bills.refreshing, onRefresh = bills::refresh) { list ->
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(list, key = { it.id }) { b -> DealerBillRow(b) { nav.navigate(R.DealerBillDetail(b.id)) } }
                        if (list.isEmpty()) item { EmptyState("No dealer bills", "Record purchases from or sales to dealers.") }
                        loadMoreItem(bills.hasMore, bills.loadingMore, bills::loadMore)
                    }
                }
            }
        }
    }
    if (addDealer) DealerFormDialog(null, onDismiss = { addDealer = false }) { d -> addDealer = false; dealers.refresh(); nav.navigate(R.DealerDetail(d.id)) }
}

@Composable
fun DealerBillRow(b: DealerBillDto, onClick: () -> Unit) {
    ListRow(
        title = "${b.billNumber} · ${b.dealerName.orEmpty()}",
        subtitle = "${Fmt.humanize(b.type)} · ${Fmt.humanize(b.metal)} · ${b.shopName.orEmpty()} · ${Fmt.date(b.dealDate)} · Final ${Fmt.grams(b.totalFinalWeight)}",
        trailingTop = b.amount?.let(Fmt::rupees) ?: Fmt.grams(b.totalFinalWeight),
        trailingBottom = { StatusChip(b.status) },
        onClick = onClick,
    )
}

@Composable
fun DealerFormDialog(existing: DealerDto?, onDismiss: () -> Unit, onSaved: (DealerDto) -> Unit) {
    val actions = actionVm("dealer-form:${existing?.id}")
    var name by rememberSaveable { mutableStateOf(existing?.name.orEmpty()) }
    var phone by rememberSaveable { mutableStateOf(existing?.phone.orEmpty()) }
    var address by rememberSaveable { mutableStateOf(existing?.address.orEmpty()) }
    var notes by rememberSaveable { mutableStateOf(existing?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add dealer" else "Edit dealer") },
        text = {
            Column(Modifier.dialogScroll(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Dealer name *", name, { name = it; error = null }, error = error)
                TextInput("Phone", phone, { phone = it }, keyboardType = KeyboardType.Phone)
                TextInput("Address", address, { address = it }, singleLine = false)
                TextInput("Notes", notes, { notes = it }, singleLine = false)
                if (existing == null) Text("A \"Main shop\" is created automatically; add more shops later.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(enabled = !actions.busy, onClick = {
                if (name.isBlank()) { error = "Enter a name"; return@Button }
                val req = DealerRequest(name.trim(), phone.ifBlank { null }, address.ifBlank { null }, notes.ifBlank { null }, existing?.version)
                actions.run({ if (existing == null) createDealer(req) else updateDealer(existing.id, req) }) { onSaved(it) }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    ActionErrorDialog(actions)
}

@Composable
private fun ShopDialog(dealerId: Long, existing: ShopDto?, onDismiss: () -> Unit, onSaved: () -> Unit) {
    val actions = actionVm("shop:$dealerId:${existing?.id}")
    var name by rememberSaveable { mutableStateOf(existing?.name.orEmpty()) }
    var location by rememberSaveable { mutableStateOf(existing?.location.orEmpty()) }
    var phone by rememberSaveable { mutableStateOf(existing?.phone.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add shop" else "Edit shop") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Shop name *", name, { name = it; error = null }, error = error)
                TextInput("Location", location, { location = it })
                TextInput("Phone", phone, { phone = it }, keyboardType = KeyboardType.Phone)
            }
        },
        confirmButton = {
            Button(enabled = !actions.busy, onClick = {
                if (name.isBlank()) { error = "Enter a shop name"; return@Button }
                val req = ShopRequest(name.trim(), location.ifBlank { null }, phone.ifBlank { null })
                actions.run({ if (existing == null) addShop(dealerId, req) else updateShop(dealerId, existing.id, req) }) { onSaved() }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    ActionErrorDialog(actions)
}

@Composable
fun DealerDetailScreen(id: Long) {
    val nav = LocalNav.current
    val dealer = loadVm("dealer:$id") { dealer(id) }
    val shops = loadVm("shops:$id") { shops(id) }
    var shopFilter by rememberSaveable { mutableStateOf<Long?>(null) }
    val ledger = loadVm("ledger:$id:$shopFilter") { ledger(id, shopFilter) }
    var edit by rememberSaveable { mutableStateOf(false) }
    var shopDialog by remember { mutableStateOf<Pair<Boolean, ShopDto?>?>(null) }
    val d = dealer.state.dataOrNull()
    PJScaffold(
        title = d?.name ?: "Dealer",
        subtitle = d?.phone,
        actions = { if (d != null) IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, "Edit dealer") } },
        fab = { ExtendedFloatingActionButton(onClick = { nav.navigate(R.DealerBillEditor(dealerId = id, shopId = shopFilter)) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Dealer bill") }) },
    ) { pad ->
        LoadContent(dealer.state, onRetry = { dealer.reload(); shops.reload(); ledger.reload() }, modifier = Modifier.padding(pad),
            refreshing = dealer.refreshing, onRefresh = { dealer.reload(); shops.reload(); ledger.reload() }) { dd ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    SectionCard("Dealer") {
                        InfoRow("Phone", dd.phone)
                        InfoRow("Address", dd.address)
                        if (!dd.notes.isNullOrBlank()) InfoRow("Notes", dd.notes)
                    }
                }
                item {
                    SectionCard("Shops", trailing = { TextButton(onClick = { shopDialog = true to null }) { Text("Add shop") } }) {
                        val list = shops.state.dataOrNull().orEmpty()
                        ChoiceChips(listOf<ShopDto?>(null) + list, list.firstOrNull { it.id == shopFilter }, { it?.name ?: "All shops" }, { shopFilter = it?.id })
                        list.forEach { s ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(s.name, fontWeight = FontWeight.Medium)
                                    Text(listOfNotNull(s.location, s.phone).joinToString(" · ").ifBlank { "—" }, style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton(onClick = { shopDialog = true to s }) { Icon(Icons.Filled.Edit, "Edit shop") }
                            }
                        }
                    }
                }
                when (val l = ledger.state) {
                    is Load.Ready -> {
                        item {
                            SectionCard("Balances" + (shopFilter?.let { sid -> shops.state.dataOrNull()?.firstOrNull { it.id == sid }?.name?.let { " · $it" } } ?: "")) {
                                l.data.balances.forEach { b ->
                                    Text(Fmt.humanize(b.metal), color = PJColors.GoldDeep, fontWeight = FontWeight.SemiBold)
                                    InfoRow("Dealer owes us", "${Fmt.grams(b.receivableWeight)} · ${Fmt.rupees(b.receivableAmount)}", valueColor = PJColors.Success)
                                    InfoRow("We owe dealer", "${Fmt.grams(b.payableWeight)} · ${Fmt.rupees(b.payableAmount)}", valueColor = PJColors.Danger)
                                }
                                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                                InfoRow("Total receivable", Fmt.rupees(l.data.totalReceivableAmount), emphasize = true)
                                InfoRow("Total payable", Fmt.rupees(l.data.totalPayableAmount), emphasize = true)
                            }
                        }
                        item { SectionHeader("Ledger", Modifier.padding(0.dp)) }
                        if (l.data.entries.isEmpty()) item { Text("No entries yet", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        items(l.data.entries.size, key = { "le$it" }) { i ->
                            val e = l.data.entries[i]
                            ListRow(
                                title = "${Fmt.humanize(e.kind)} · ${e.reference.orEmpty()}",
                                subtitle = listOfNotNull(Fmt.date(e.date), e.shopName, e.metal?.let(Fmt::humanize), e.description).joinToString(" · "),
                                trailingTop = e.weight?.let(Fmt::grams),
                                trailingBottom = { e.amount?.let { Text(Fmt.rupees(it), style = MaterialTheme.typography.labelMedium) } },
                                trailingColor = if (e.direction == "RECEIVABLE" || e.direction == "IN") PJColors.Success else PJColors.Danger,
                                onClick = e.billId?.let { bid -> { nav.navigate(R.DealerBillDetail(bid)) } },
                            )
                        }
                    }
                    is Load.Failed -> item { ErrorState(l.error, { ledger.reload() }) }
                    Load.Loading -> item { LoadingState(Modifier.padding(24.dp)) }
                }
            }
        }
    }
    if (edit && d != null) DealerFormDialog(d, onDismiss = { edit = false }) { dealer.replace(it); edit = false }
    shopDialog?.let { (_, s) -> ShopDialog(id, s, onDismiss = { shopDialog = null }) { shopDialog = null; shops.reload(); dealer.reload(silent = true) } }
}

// ---------------------------------------------------------------- Dealer bill editor

class DealerLineState {
    var description by mutableStateOf("")
    var gross by mutableStateOf("")
    var less by mutableStateOf("")
    var pieces by mutableStateOf("")
    var carat by mutableStateOf<Carat?>(Carat.K22)
    var labour by mutableStateOf("")
    val net: BigDecimal get() = MetalCalc.net(Num.parse(gross), Num.parse(less))
    fun finalWeight(metal: String): BigDecimal? = Num.parse(labour)?.let { MetalCalc.finalWeight(metal, net, carat, it) }
}

class DealerBillEditorVm : ViewModel() {
    var dealer by mutableStateOf<DealerDto?>(null)
    var shop by mutableStateOf<ShopDto?>(null)
    var billNumber by mutableStateOf("")
    var date by mutableStateOf<LocalDate>(Fmt.today())
    var type by mutableStateOf("PURCHASE")
    var metal by mutableStateOf("GOLD")
    var rate by mutableStateOf("")
    var description by mutableStateOf("")
    val lines = mutableStateListOf(DealerLineState())
}

@Composable
fun DealerBillEditorScreen(dealerId: Long?, shopId: Long?) {
    val nav = LocalNav.current
    val c = container()
    val vm = appViewModel("dealer-bill-editor:$dealerId:$shopId") { DealerBillEditorVm() }
    val actions = actionVm("dealer-bill-editor")
    val dealers = loadVm("dealers-all") { dealers(null, 0) }
    val shops = vm.dealer?.let { d -> loadVm("shops:${d.id}") { shops(d.id) } }
    var error by remember { mutableStateOf<String?>(null) }

    val dealerList = dealers.state.dataOrNull()?.content.orEmpty()
    LaunchedEffect(dealerList) { if (vm.dealer == null && dealerId != null) vm.dealer = dealerList.firstOrNull { it.id == dealerId } }
    val shopList = shops?.state?.dataOrNull().orEmpty()
    LaunchedEffect(shopList) {
        if (shopList.isNotEmpty() && (vm.shop == null || shopList.none { it.id == vm.shop?.id })) {
            vm.shop = shopList.firstOrNull { it.id == shopId } ?: shopList.first()
        }
    }

    val finals = vm.lines.map { it.finalWeight(vm.metal) }
    val totalNet = vm.lines.fold(BigDecimal.ZERO) { a, l -> a + l.net }
    val totalFinal = finals.fold(BigDecimal.ZERO) { a, f -> a + (f ?: BigDecimal.ZERO) }
    val rate = Num.parse(vm.rate)
    val amount = MetalCalc.amount(totalFinal, rate)

    PJScaffold(title = "New dealer bill", busy = actions.busy) { pad ->
        FormColumn(pad) {
            DropdownField("Dealer *", dealerList, vm.dealer, { it.name }, { vm.dealer = it; vm.shop = null })
            if (vm.dealer != null) DropdownField("Shop *", shopList, vm.shop, { it.name }, { vm.shop = it })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextInput("Bill number *", vm.billNumber, { vm.billNumber = it }, Modifier.weight(1f))
                DateInput("Deal date", vm.date, { it?.let { d -> vm.date = d } }, Modifier.weight(1f))
            }
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(vm.type == "PURCHASE", { vm.type = "PURCHASE" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Purchase (we owe)") }
                SegmentedButton(vm.type == "SALES", { vm.type = "SALES" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Sales (they owe)") }
            }
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(vm.metal == "GOLD", { vm.metal = "GOLD" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Gold") }
                SegmentedButton(vm.metal == "SILVER", { vm.metal = "SILVER" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Silver") }
            }
            Text(
                if (vm.metal == "GOLD") "Final weight = net × (carat % + labour %) ÷ 100" else "Final weight = net × (100 + labour %) ÷ 100",
                style = MaterialTheme.typography.bodySmall, color = PJColors.GoldDeep,
            )
            DecimalInput("Rate per gram (optional)", vm.rate, { vm.rate = it }, prefix = "₹", supporting = "Amount = final weight × rate")
            TextInput("Description", vm.description, { vm.description = it })

            vm.lines.forEachIndexed { i, l ->
                SectionCard("Line ${i + 1}", trailing = { if (vm.lines.size > 1) IconButton(onClick = { vm.lines.remove(l) }) { Icon(Icons.Filled.Delete, "Remove line") } }) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextInput("Item description", l.description, { l.description = it })
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DecimalInput("Gross wt *", l.gross, { l.gross = it }, Modifier.weight(1f), scale = 4, suffix = "g")
                            DecimalInput("Less wt", l.less, { l.less = it }, Modifier.weight(1f), scale = 4, suffix = "g")
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (vm.metal == "GOLD") DropdownField("Carat", Carat.entries.toList(), l.carat, { "${it.label} (${it.percent}%)" }, { l.carat = it }, Modifier.weight(1f))
                            DecimalInput("Labour %", l.labour, { l.labour = it }, Modifier.weight(1f), scale = 4, suffix = "%")
                        }
                        IntInput("Pieces", l.pieces, { l.pieces = it })
                        Row {
                            Text("Net ${Fmt.grams(l.net)}", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("Final ${l.finalWeight(vm.metal)?.let(Fmt::grams) ?: "—"}", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            OutlinedButton(onClick = { vm.lines.add(DealerLineState().also { n -> n.carat = vm.lines.lastOrNull()?.carat ?: Carat.K22 }) }, Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, null); Text(" Add line")
            }
            SectionCard("Totals") {
                InfoRow("Total net", Fmt.grams(totalNet))
                InfoRow("Total final weight", Fmt.grams(totalFinal), emphasize = true)
                InfoRow("Amount", amount?.let(Fmt::rupees) ?: "Enter a rate to value this bill")
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            PrimaryButton(if (actions.busy) "Saving…" else "Save dealer bill", {
                val d = vm.dealer; val s = vm.shop
                error = when {
                    d == null -> "Select a dealer"
                    s == null -> "Select a shop"
                    vm.billNumber.isBlank() -> "Enter the dealer's bill number"
                    vm.lines.any { Num.parse(it.gross) == null } -> "Enter gross weight on every line"
                    vm.lines.any { Num.parse(it.labour) == null } -> "Enter labour % on every line (0 if none)"
                    vm.metal == "GOLD" && vm.lines.any { it.carat == null } -> "Select the carat on every line"
                    vm.lines.any { (Num.parse(it.less) ?: BigDecimal.ZERO) > (Num.parse(it.gross) ?: BigDecimal.ZERO) } -> "Less weight can't exceed gross weight"
                    else -> null
                }
                if (error != null || d == null || s == null) return@PrimaryButton
                val req = DealerBillRequest(
                    d.id, s.id, vm.billNumber.trim(), vm.date.toString(), vm.type, vm.metal, vm.description.ifBlank { null }, rate,
                    vm.lines.map { l ->
                        DealerLineRequest(l.description.ifBlank { null }, Num.parse(l.gross)!!, Num.parse(l.less), l.pieces.toIntOrNull(),
                            if (vm.metal == "GOLD") l.carat?.name else null, Num.parse(l.labour)!!)
                    },
                )
                actions.run({ createDealerBill(req) }) { b -> c.toast("Dealer bill ${b.billNumber} saved"); nav.popBackStack(); nav.navigate(R.DealerBillDetail(b.id)) }
            }, enabled = !actions.busy)
            Spacer(Modifier.padding(12.dp))
        }
    }
    ActionErrorDialog(actions)
}

// ---------------------------------------------------------------- Dealer bill detail

@Composable
fun DealerBillDetailScreen(id: Long) {
    val nav = LocalNav.current
    val c = container()
    val vm = loadVm("dbill:$id") { dealerBill(id) }
    val actions = actionVm("dbill:$id")
    var reverseBill by rememberSaveable { mutableStateOf(false) }
    var reverseSettlement by remember { mutableStateOf<SettlementDto?>(null) }
    val b = vm.state.dataOrNull()
    PJScaffold(title = b?.let { "Dealer bill ${it.billNumber}" } ?: "Dealer bill", subtitle = b?.dealerName, busy = actions.busy) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { bill ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    SectionCard("${Fmt.humanize(bill.type)} · ${Fmt.humanize(bill.metal)}", trailing = { StatusChip(bill.status) }) {
                        InfoRow("Dealer / shop", "${bill.dealerName.orEmpty()} / ${bill.shopName.orEmpty()}")
                        InfoRow("Deal date", Fmt.date(bill.dealDate))
                        InfoRow("Entered", Fmt.dateTime(bill.enteredAt))
                        InfoRow("Rate", bill.rate?.let { Fmt.rupees(it) + "/g" })
                        if (!bill.description.isNullOrBlank()) InfoRow("Description", bill.description)
                        if (bill.status == "REVERSED") InfoRow("Reversal reason", bill.reversalReason, valueColor = PJColors.Danger)
                    }
                }
                items(bill.lines, key = { "dl${it.lineNo}" }) { l ->
                    SectionCard {
                        Row {
                            Text("${l.lineNo}. ${l.description ?: "Item"}", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                            Text(Fmt.grams(l.finalWeight), color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            listOfNotNull("Gross ${Fmt.grams(l.grossWeight)}", "Less ${Fmt.grams(l.lessWeight)}", "Net ${Fmt.grams(l.netWeight)}",
                                l.carat?.let { "${Fmt.carat(it)} ${l.caratPercent}%" }, "Labour ${Fmt.percent(l.labourPercent)}", "${l.pieces} pc".takeIf { l.pieces > 0 }).joinToString(" · "),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                item {
                    SectionCard("Totals") {
                        InfoRow("Total net", Fmt.grams(bill.totalNetWeight))
                        InfoRow("Total final weight", Fmt.grams(bill.totalFinalWeight), emphasize = true)
                        InfoRow("Amount", bill.amount?.let(Fmt::rupees))
                        InfoRow("Settled", "${Fmt.grams(bill.settledWeight)} · ${Fmt.rupees(bill.settledValue)}", valueColor = PJColors.Success)
                        InfoRow("Outstanding", "${Fmt.grams(bill.outstandingWeight)}" + (bill.outstandingAmount?.let { " · ${Fmt.rupees(it)}" } ?: ""),
                            valueColor = if (bill.outstandingWeight.signum() > 0) PJColors.Warning else PJColors.Success, emphasize = true)
                    }
                }
                item { SectionHeader("Settlements", Modifier.padding(0.dp)) }
                if (bill.settlements.isEmpty()) item { Text("Not settled yet", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(bill.settlements, key = { "s${it.id}" }) { s ->
                    SectionCard("Settlement · ${Fmt.date(s.settlementDate)}", trailing = { StatusChip(s.status) }) {
                        s.allocations.forEach { a ->
                            if (a.kind == "BAR") InfoRow("${a.barLabel ?: "MR Biscuit"} ${a.barLotCode.orEmpty()}", "${Fmt.grams(a.weight)} @ ${Fmt.rupees(a.rate)} = ${Fmt.rupees(a.value)}")
                            else InfoRow("${Fmt.method(a.method)}${a.reference?.let { " · $it" } ?: ""}", "${Fmt.rupees(a.value)} ≈ ${Fmt.grams(a.weightEquivalent)}")
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                        InfoRow("Total", "${Fmt.rupees(s.totalValue)} · ${Fmt.grams(s.totalWeightEquivalent)}", emphasize = true)
                        if (s.status == "REVERSED") InfoRow("Reversal reason", s.reversalReason, valueColor = PJColors.Danger)
                        if (s.status == "ACTIVE" && bill.status != "REVERSED") TextButton(onClick = { reverseSettlement = s }) { Text("Reverse settlement", color = PJColors.Danger) }
                    }
                }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (bill.status == "OPEN" || bill.status == "PARTIALLY_SETTLED") PrimaryButton("Settle with MR Biscuit / money", { nav.navigate(R.Settlement(id)) })
                        if (bill.status != "REVERSED") SecondaryButton("Reverse bill", { reverseBill = true })
                    }
                }
            }
        }
    }
    if (reverseBill) ReasonDialog("Reverse dealer bill?", "The bill stays on record as Reversed. Active settlements must be reversed first if the server requires it.",
        onConfirm = { r -> actions.run({ reverseDealerBill(id, r) }) { vm.replace(it); reverseBill = false; c.toast("Bill reversed") } }, onDismiss = { reverseBill = false })
    reverseSettlement?.let { s ->
        ReasonDialog("Reverse settlement?", "MR Biscuit movements and money entries of this settlement are reversed with opposite entries.",
            onConfirm = { r -> actions.run({ reverseSettlement(id, s.id, r) }) { vm.replace(it); reverseSettlement = null; c.toast("Settlement reversed") } },
            onDismiss = { reverseSettlement = null })
    }
    ActionErrorDialog(actions)
}

// ---------------------------------------------------------------- Settlement

class BarAllocState(metal: String) {
    var lot by mutableStateOf<BarLotDto?>(null)
    var newLotCode by mutableStateOf("")
    var purity by mutableStateOf("")
    var metal by mutableStateOf(metal)
    var weight by mutableStateOf("")
    var rate by mutableStateOf("")
}

class MoneyAllocState {
    var method by mutableStateOf("CASH")
    var amount by mutableStateOf("")
    var reference by mutableStateOf("")
    var rate by mutableStateOf("")
}

class SettlementVm : ViewModel() {
    val bars = mutableStateListOf<BarAllocState>()
    val money = mutableStateListOf<MoneyAllocState>()
    var date by mutableStateOf<LocalDate>(Fmt.today())
    var notes by mutableStateOf("")
    var crossMetal by mutableStateOf(false)
}

@Composable
fun SettlementScreen(billId: Long) {
    val nav = LocalNav.current
    val c = container()
    val billVm = loadVm("dbill:$billId") { dealerBill(billId) }
    val settings = loadVm("settings") { settings() }
    val vm = appViewModel("settlement:$billId") { SettlementVm() }
    val actions = actionVm("settlement:$billId")
    var error by remember { mutableStateOf<String?>(null) }
    val bill = billVm.state.dataOrNull()
    val crossAllowed = settings.state.dataOrNull()?.crossMetalSettlementAllowed == true
    val lotsVm = if (bill?.type == "PURCHASE") loadVm("bars-avail:${if (vm.crossMetal) null else bill.metal}") { barLots(if (vm.crossMetal) null else bill.metal, true) } else null

    PJScaffold(title = "Settle ${bill?.billNumber.orEmpty()}", busy = actions.busy) { pad ->
        LoadContent(billVm.state, onRetry = { billVm.reload() }, modifier = Modifier.padding(pad)) { b ->
            val billRate = b.rate
            val barValues = vm.bars.map { a ->
                val w = Num.parse(a.weight); val r = Num.parse(a.rate) ?: billRate
                if (w != null && r != null) MetalCalc.barValue(w, r) else null
            }
            val barWeq = vm.bars.fold(BigDecimal.ZERO) { acc, a -> acc + (Num.parse(a.weight) ?: BigDecimal.ZERO) }
            val moneyWeq = vm.money.fold(BigDecimal.ZERO) { acc, m ->
                val amt = Num.parse(m.amount); val r = Num.parse(m.rate) ?: billRate
                acc + (if (amt != null && r != null) MetalCalc.weightEquivalent(amt, r) ?: BigDecimal.ZERO else BigDecimal.ZERO)
            }
            val totalValue = barValues.fold(BigDecimal.ZERO) { a, v -> a + (v ?: BigDecimal.ZERO) } + vm.money.fold(BigDecimal.ZERO) { a, m -> a + (Num.parse(m.amount) ?: BigDecimal.ZERO) }
            val totalWeq = Num.weight(barWeq + moneyWeq)
            val remaining = Num.weight(b.outstandingWeight - totalWeq)
            FormColumn(PaddingValues(0.dp)) {
                SectionCard("Outstanding") {
                    InfoRow("Weight", Fmt.grams(b.outstandingWeight), emphasize = true)
                    InfoRow("Amount", b.outstandingAmount?.let(Fmt::rupees))
                    InfoRow("Bill rate", billRate?.let { Fmt.rupees(it) + "/g" } ?: "Not set — enter a rate per allocation")
                    Text(
                        if (b.type == "PURCHASE") "We pay the dealer: MR Biscuit is issued from our stock and money goes out."
                        else "Dealer pays us: MR Biscuit received is added as a new lot and money comes in.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                DateInput("Settlement date", vm.date, { it?.let { d -> vm.date = d } })
                if (crossAllowed) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(vm.crossMetal, { vm.crossMetal = it })
                        Text("Authorize cross-metal settlement for this bill")
                    }
                }
                SectionHeader("MR Biscuit", Modifier.padding(0.dp))
                vm.bars.forEachIndexed { i, a ->
                    SectionCard("Biscuit ${i + 1}", trailing = { IconButton(onClick = { vm.bars.remove(a) }) { Icon(Icons.Filled.Delete, "Remove") } }) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (b.type == "PURCHASE") {
                                val lots = lotsVm?.state?.dataOrNull().orEmpty()
                                DropdownField("Lot to issue", lots, a.lot, { "${it.label} ${it.lotCode} · ${Fmt.grams(it.remainingWeight)} left" }, { a.lot = it })
                            } else {
                                if (vm.crossMetal) DropdownField("Biscuit metal", Options.dealerMetals, a.metal, { if (it == "GOLD") "MR Biscuit (Gold)" else "MR Biscuit (Silver)" }, { a.metal = it })
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextInput("New lot code", a.newLotCode, { a.newLotCode = it }, Modifier.weight(1f), supporting = "Blank = automatic")
                                    TextInput("Purity", a.purity, { a.purity = it }, Modifier.weight(1f))
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DecimalInput("Weight", a.weight, { a.weight = it }, Modifier.weight(1f), scale = 4, suffix = "g")
                                DecimalInput("Rate /g", a.rate, { a.rate = it }, Modifier.weight(1f), prefix = "₹", placeholder = billRate?.let(Fmt::plain))
                            }
                            Text("Value ${barValues[i]?.let(Fmt::rupees) ?: "—"}", color = MaterialTheme.colorScheme.tertiary)
                        }
                    }
                }
                OutlinedButton(onClick = { vm.bars.add(BarAllocState(b.metal)) }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.Add, null); Text(" Add MR Biscuit") }
                SectionHeader("Money", Modifier.padding(0.dp))
                vm.money.forEachIndexed { i, m ->
                    SectionCard("Payment ${i + 1}", trailing = { IconButton(onClick = { vm.money.remove(m) }) { Icon(Icons.Filled.Delete, "Remove") } }) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            MethodField(m.method, { m.method = it })
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                DecimalInput("Amount", m.amount, { m.amount = it }, Modifier.weight(1f), prefix = "₹")
                                DecimalInput("Rate /g", m.rate, { m.rate = it }, Modifier.weight(1f), prefix = "₹", placeholder = billRate?.let(Fmt::plain))
                            }
                            TextInput(if (m.method == "CHEQUE") "Cheque number" else "Reference", m.reference, { m.reference = it })
                            val amt = Num.parse(m.amount); val r = Num.parse(m.rate) ?: billRate
                            Text("≈ ${if (amt != null && r != null) Fmt.grams(MetalCalc.weightEquivalent(amt, r)) else "—"}", color = MaterialTheme.colorScheme.tertiary)
                        }
                    }
                }
                OutlinedButton(onClick = { vm.money.add(MoneyAllocState()) }, Modifier.fillMaxWidth()) { Icon(Icons.Filled.Add, null); Text(" Add money") }
                SectionCard("Preview") {
                    InfoRow("Total value", Fmt.rupees(totalValue))
                    InfoRow("Weight equivalent", Fmt.grams(totalWeq), emphasize = true)
                    InfoRow("Remaining after", Fmt.grams(remaining), valueColor = when {
                        remaining.signum() < 0 -> PJColors.Danger
                        remaining.signum() == 0 -> PJColors.Success
                        else -> PJColors.Warning
                    })
                    if (remaining.signum() < 0) Text("This is more than the outstanding weight.", color = PJColors.Danger, style = MaterialTheme.typography.bodySmall)
                }
                TextInput("Notes", vm.notes, { vm.notes = it }, singleLine = false)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                PrimaryButton(if (actions.busy) "Saving…" else "Save settlement", {
                    error = when {
                        vm.bars.isEmpty() && vm.money.isEmpty() -> "Add an MR Biscuit or money allocation"
                        vm.bars.any { Num.parse(it.weight)?.signum() != 1 } -> "Enter the weight for each MR Biscuit"
                        b.type == "PURCHASE" && vm.bars.any { it.lot == null } -> "Select the lot to issue for each MR Biscuit"
                        vm.money.any { Num.parse(it.amount)?.signum() != 1 } -> "Enter the amount for each payment"
                        vm.money.any { (Num.parse(it.rate) ?: billRate) == null } -> "Enter a rate to convert money into weight"
                        remaining.signum() < 0 -> "Settlement exceeds the outstanding weight"
                        else -> null
                    }
                    if (error != null) return@PrimaryButton
                    val req = SettlementRequest(
                        vm.date.toString(), vm.notes.ifBlank { null },
                        vm.bars.map { a ->
                            BarAllocationRequest(a.lot?.id, Num.parse(a.weight)!!, Num.parse(a.rate), a.newLotCode.ifBlank { null }, a.purity.ifBlank { null },
                                if (b.type == "SALES") a.metal else null)
                        },
                        vm.money.map { m -> MoneyAllocationRequest(m.method, Num.parse(m.amount)!!, m.reference.ifBlank { null }, Num.parse(m.rate)) },
                        vm.crossMetal,
                    )
                    actions.run({ settle(billId, req) }) { updated ->
                        billVm.replace(updated)
                        c.toast(if (updated.status == "SETTLED") "Bill fully settled" else "Settlement saved")
                        nav.popBackStack()
                    }
                }, enabled = !actions.busy)
                Spacer(Modifier.padding(12.dp))
            }
        }
    }
    ActionErrorDialog(actions)
}
