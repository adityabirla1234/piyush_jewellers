package com.piyushjewellers.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.material3.ripple
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.sp
import com.piyushjewellers.app.ui.theme.Cinzel
import com.piyushjewellers.app.ui.theme.PJBrush
import kotlinx.coroutines.delay
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.local.OutboxOp
import com.piyushjewellers.app.data.local.SyncState
import com.piyushjewellers.app.data.remote.AppException
import com.piyushjewellers.app.ui.ActionVm
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.theme.PJColors
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneOffset

val LocalDrawerOpener = staticCompositionLocalOf<() -> Unit> { {} }
val LocalNav = staticCompositionLocalOf<NavHostController> { error("No navigation") }
val LocalSnackbar = staticCompositionLocalOf { SnackbarHostState() }

// ---------------------------------------------------------------- Scaffold

@Composable
fun PJScaffold(
    title: String,
    subtitle: String? = null,
    topLevel: Boolean = false,
    actions: @Composable RowScope.() -> Unit = {},
    fab: @Composable () -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    busy: Boolean = false,
    titleContent: (@Composable () -> Unit)? = null,
    content: @Composable (PaddingValues) -> Unit,
) {
    val nav = LocalNav.current
    val openDrawer = LocalDrawerOpener.current
    val online by container().connectivity.online.collectAsState()
    Scaffold(
        topBar = {
            Column(Modifier.background(PJBrush.OnyxBar)) {
                TopAppBar(
                    title = {
                        if (titleContent != null) titleContent()
                        else Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.labelMedium, color = PJColors.GoldSoft.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    },
                    navigationIcon = {
                        if (topLevel) {
                            IconButton(onClick = openDrawer) { Icon(Icons.Filled.Menu, contentDescription = "Open menu") }
                        } else {
                            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
                        }
                    },
                    actions = actions,
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        titleContentColor = PJColors.Ivory,
                        navigationIconContentColor = PJColors.GoldBright,
                        actionIconContentColor = PJColors.GoldBright,
                    ),
                )
                GoldHairline()
                AnimatedVisibility(!online) {
                    Row(
                        Modifier.fillMaxWidth().background(PJColors.GoldSoft).padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.CloudOff, null, Modifier.size(16.dp), tint = PJColors.GoldDeep)
                        Spacer(Modifier.width(8.dp))
                        Text("Offline — showing saved data. Supported entries will sync later.", style = MaterialTheme.typography.labelMedium, color = Color(0xFF4A3500))
                    }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = PJColors.Gold)
            }
        },
        floatingActionButton = fab,
        bottomBar = bottomBar,
        snackbarHost = { SnackbarHost(LocalSnackbar.current) },
        containerColor = MaterialTheme.colorScheme.background,
        content = content,
    )
}

// ---------------------------------------------------------------- Load states

@Composable
fun <T> LoadContent(
    state: Load<T>,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
    refreshing: Boolean = false,
    onRefresh: (() -> Unit)? = null,
    content: @Composable (T) -> Unit,
) {
    when (state) {
        Load.Loading -> LoadingState(modifier)
        is Load.Failed -> ErrorState(state.error, onRetry, modifier)
        is Load.Ready -> {
            Column(modifier.fillMaxSize()) {
                if (state.fromCache) CachedBanner(state.savedAt)
                if (onRefresh != null) {
                    PullToRefreshBox(isRefreshing = refreshing, onRefresh = onRefresh, modifier = Modifier.fillMaxSize()) { content(state.data) }
                } else {
                    Box(Modifier.fillMaxSize()) { content(state.data) }
                }
            }
        }
    }
}

@Composable
fun CachedBanner(savedAt: Long?) {
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.History, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(8.dp))
        Text(
            "Saved data" + (savedAt?.let { " from ${Fmt.epoch(it)}" } ?: "") + " · may be out of date",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun LoadingState(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = PJColors.Gold) }
}

@Composable
fun ErrorState(error: AppException, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(if (error.isOffline) Icons.Filled.CloudOff else Icons.Filled.ErrorOutline, null, Modifier.size(48.dp), tint = PJColors.GoldDeep)
        Spacer(Modifier.height(12.dp))
        Text(
            if (error.isOffline) "No saved data yet" else "Couldn't load",
            style = MaterialTheme.typography.titleMedium,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            if (error.isOffline) "Connect to the internet once to load this screen; it will then be available offline." else error.message,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onRetry) { Text("Try again") }
    }
}

@Composable
fun EmptyState(title: String, message: String, icon: ImageVector = Icons.Filled.Inbox, action: (@Composable () -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 48.dp, horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, Modifier.size(48.dp), tint = PJColors.Gold)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            action()
        }
    }
}

/** Shows an action failure (validation, conflict, offline) in a dialog. */
@Composable
fun ActionErrorDialog(actions: ActionVm) {
    val e = actions.error ?: return
    AlertDialog(
        onDismissRequest = actions::clearError,
        confirmButton = { TextButton(onClick = actions::clearError) { Text("OK") } },
        title = { Text(if (e.isOffline) "You're offline" else if (e.kind == AppException.Kind.CONFLICT) "Can't complete" else "Please check") },
        text = {
            Column {
                Text(if (e.isOffline) "This action needs a connection to the server so totals stay correct. Try again when online." else e.message)
                e.fieldErrors.forEach { (f, m) -> Text("• ${Fmt.humanize(f.substringAfterLast('.'))}: $m", style = MaterialTheme.typography.bodySmall) }
            }
        },
    )
}

// ---------------------------------------------------------------- Cards & rows

@Composable
fun SectionCard(title: String? = null, modifier: Modifier = Modifier, trailing: (@Composable () -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(Modifier.padding(16.dp)) {
            if (title != null || trailing != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (title != null) {
                        Column(Modifier.weight(1f)) {
                            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
                            Spacer(Modifier.height(4.dp))
                            Box(Modifier.width(28.dp).height(2.dp).background(PJBrush.GoldFoil, RoundedCornerShape(1.dp)))
                        }
                    }
                    trailing?.invoke()
                }
                Spacer(Modifier.height(10.dp))
            }
            content()
        }
    }
}

@Composable
fun GoldHairline(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(PJBrush.GoldHairline))
}

/** Fades and lifts content in once; the saved flag stops it replaying when a list item scrolls back into view. */
@Composable
fun Modifier.reveal(index: Int = 0): Modifier {
    var shown by rememberSaveable { mutableStateOf(false) }
    val progress = remember { Animatable(if (shown) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (!shown) {
            delay(index.coerceAtMost(8) * 45L)
            progress.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
            shown = true
        }
    }
    return graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 20.dp.toPx()
    }
}

/** Clickable with a ripple and a slight press-in scale. */
@Composable
fun Modifier.pressable(onClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, spring(stiffness = Spring.StiffnessMediumLow), label = "press")
    return graphicsLayer { scaleX = scale; scaleY = scale }.clickable(interactionSource = source, indication = ripple(), onClick = onClick)
}

@Composable
fun InfoRow(label: String, value: String?, emphasize: Boolean = false, valueColor: Color = Color.Unspecified) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.weight(0.45f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Text(
            value ?: "—",
            Modifier.weight(0.55f),
            textAlign = TextAlign.End,
            style = if (emphasize) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
            fontWeight = if (emphasize) FontWeight.SemiBold else FontWeight.Normal,
            color = valueColor,
        )
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier, hint: String? = null, accent: Color = MaterialTheme.colorScheme.onSurface, onClick: (() -> Unit)? = null) {
    Card(
        modifier.then(if (onClick != null) Modifier.pressable(onClick) else Modifier),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (hint != null) Text(hint, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

fun statusColor(status: String?): Color = when (status) {
    "ACTIVE", "OPEN", "PENDING", "PENDING_SYNC", "QUEUED", "RUNNING", "SYNCING", "AWAITING_JEWELLERY_RETURN", "PARTIALLY_SETTLED", "PARTIAL", "UNPAID", "LOW_STOCK" -> PJColors.Warning
    "FINALIZED", "SETTLED", "PAID", "CLEARED", "COMPLETED", "SYNCED", "AVAILABLE", "IN_STOCK", "RECEIVABLE", "IN" -> PJColors.Success
    "REVERSED", "BOUNCED", "FAILED", "CONFLICT", "EXPIRED", "OUT_OF_STOCK", "EXHAUSTED", "OVERDUE" -> PJColors.Danger
    "DRAFT", "PAYABLE", "OUT" -> PJColors.Info
    else -> PJColors.GoldDeep
}

@Composable
fun StatusChip(status: String?, label: String = Fmt.humanize(status)) {
    val color = statusColor(status)
    Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50)) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 3.dp), color = color, style = MaterialTheme.typography.labelMedium, maxLines = 1)
    }
}

@Composable
fun ListRow(
    title: String,
    subtitle: String? = null,
    trailingTop: String? = null,
    trailingBottom: (@Composable () -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    trailingColor: Color = Color.Unspecified,
) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            leading()
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (trailingTop != null || trailingBottom != null) {
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                if (trailingTop != null) Text(trailingTop, style = MaterialTheme.typography.titleSmall, color = trailingColor, fontWeight = FontWeight.SemiBold)
                trailingBottom?.invoke()
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
}

fun LazyListScope.loadMoreItem(hasMore: Boolean, loading: Boolean, onLoadMore: () -> Unit) {
    if (!hasMore) return
    item(key = "load-more") {
        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
            if (loading) CircularProgressIndicator(Modifier.size(28.dp)) else OutlinedButton(onClick = onLoadMore) { Text("Load more") }
        }
    }
}

/** Unsynced offline entries for a module, shown above the server list. */
fun LazyListScope.pendingOpsSection(ops: List<OutboxOp>, onOpen: () -> Unit) {
    if (ops.isEmpty()) return
    item(key = "pending-header") {
        Row(
            Modifier.fillMaxWidth().background(PJColors.GoldSoft.copy(alpha = 0.5f)).clickable(onClick = onOpen).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Sync, null, Modifier.size(16.dp), tint = PJColors.GoldDeep)
            Spacer(Modifier.width(8.dp))
            Text("${ops.size} not yet synced · tap to manage", style = MaterialTheme.typography.labelLarge, color = Color(0xFF4A3500))
        }
    }
    items(ops.size, key = { "pending-${ops[it].id}" }) { i ->
        val op = ops[i]
        ListRow(
            title = op.summary,
            subtitle = (op.lastError ?: "Saved on this device") + " · " + Fmt.epoch(op.createdAt),
            trailingBottom = { StatusChip(op.state, syncLabel(op.state)) },
            onClick = onOpen,
        )
    }
}

fun syncLabel(state: String): String = when (state) {
    SyncState.DRAFT -> "On hold"
    SyncState.PENDING_SYNC -> "Pending sync"
    SyncState.SYNCING -> "Syncing"
    SyncState.SYNCED -> "Synced"
    SyncState.CONFLICT -> "Conflict"
    SyncState.FAILED -> "Failed"
    else -> Fmt.humanize(state)
}

// ---------------------------------------------------------------- Inputs

@Composable
fun TextInput(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    error: String? = null,
    supporting: String? = null,
    singleLine: Boolean = true,
    keyboardType: KeyboardType = KeyboardType.Text,
    enabled: Boolean = true,
    minLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        isError = error != null,
        supportingText = (error ?: supporting)?.let { { Text(it) } },
        singleLine = singleLine,
        minLines = minLines,
        enabled = enabled,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
    )
}

/** Decimal input that keeps exactly what the user typed (no float conversion). */
@Composable
fun DecimalInput(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    scale: Int = 2,
    prefix: String? = null,
    suffix: String? = null,
    error: String? = null,
    supporting: String? = null,
    enabled: Boolean = true,
    placeholder: String? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { t ->
            val clean = t.replace(",", "").trim()
            if (Num.isValidDecimalInput(clean, scale)) onChange(clean)
        },
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        prefix = prefix?.let { { Text(it) } },
        suffix = suffix?.let { { Text(it) } },
        placeholder = placeholder?.let { { Text(it) } },
        isError = error != null,
        supportingText = (error ?: supporting)?.let { { Text(it) } },
        singleLine = true,
        enabled = enabled,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
    )
}

@Composable
fun IntInput(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, error: String? = null) {
    OutlinedTextField(
        value = value,
        onValueChange = { t -> if (t.isEmpty() || (t.length <= 6 && t.all(Char::isDigit))) onChange(t) },
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        isError = error != null,
        supportingText = error?.let { { Text(it) } },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
    )
}

@Composable
fun <T> DropdownField(
    label: String,
    options: List<T>,
    selected: T?,
    display: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    error: String? = null,
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { if (enabled) expanded = it }, modifier = modifier) {
        OutlinedTextField(
            value = selected?.let(display) ?: "",
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            label = { Text(label) },
            isError = error != null,
            supportingText = error?.let { { Text(it) } },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable, enabled).fillMaxWidth(),
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { o ->
                DropdownMenuItem(text = { Text(display(o)) }, onClick = {
                    onSelect(o)
                    expanded = false
                })
            }
        }
    }
}

@Composable
fun <T> ChoiceChips(options: List<T>, selected: T?, label: (T) -> String, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    FlowRow(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o -> FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) }) }
    }
}

@Composable
private fun pressOpens(onOpen: () -> Unit): MutableInteractionSource {
    val source = remember { MutableInteractionSource() }
    LaunchedEffect(source) {
        source.interactions.collect { if (it is PressInteraction.Release) onOpen() }
    }
    return source
}

@Composable
fun DateInput(
    label: String,
    value: LocalDate?,
    onChange: (LocalDate?) -> Unit,
    modifier: Modifier = Modifier,
    clearable: Boolean = false,
    error: String? = null,
    supporting: String? = null,
) {
    var open by rememberSaveable { mutableStateOf(false) }
    OutlinedTextField(
        value = value?.let(Fmt::date) ?: "",
        onValueChange = {},
        readOnly = true,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        isError = error != null,
        supportingText = (error ?: supporting)?.let { { Text(it) } },
        trailingIcon = {
            if (clearable && value != null) TextButton(onClick = { onChange(null) }) { Text("Clear") }
            else Icon(Icons.Filled.Event, null)
        },
        interactionSource = pressOpens { open = true },
        singleLine = true,
    )
    if (open) {
        val state = rememberDatePickerState(initialSelectedDateMillis = (value ?: Fmt.today()).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                    open = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Cancel") } },
        ) { DatePicker(state = state) }
    }
}

@Composable
fun TimeInput(label: String, value: LocalTime, onChange: (LocalTime) -> Unit, modifier: Modifier = Modifier) {
    var open by rememberSaveable { mutableStateOf(false) }
    OutlinedTextField(
        value = value.format(java.time.format.DateTimeFormatter.ofPattern("hh:mm a", java.util.Locale.ENGLISH)),
        onValueChange = {},
        readOnly = true,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        trailingIcon = { Icon(Icons.Filled.Schedule, null) },
        interactionSource = pressOpens { open = true },
        singleLine = true,
    )
    if (open) {
        val state = rememberTimePickerState(initialHour = value.hour, initialMinute = value.minute, is24Hour = false)
        AlertDialog(
            onDismissRequest = { open = false },
            confirmButton = {
                TextButton(onClick = {
                    onChange(LocalTime.of(state.hour, state.minute))
                    open = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Cancel") } },
            text = { TimePicker(state = state) },
        )
    }
}

@Composable
fun DateTimeInput(label: String, value: LocalDateTime, onChange: (LocalDateTime) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DateInput(label, value.toLocalDate(), { d -> d?.let { onChange(LocalDateTime.of(it, value.toLocalTime())) } }, Modifier.weight(1f))
        TimeInput("Time", value.toLocalTime(), { t -> onChange(LocalDateTime.of(value.toLocalDate(), t)) }, Modifier.weight(0.8f))
    }
}

// ---------------------------------------------------------------- Dialogs

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    destructive: Boolean = false,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = if (destructive) ButtonDefaults.buttonColors(containerColor = PJColors.Danger) else ButtonDefaults.buttonColors(),
            ) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

/** Reversals always require a reason; the original record is kept and a reversing entry is posted. */
@Composable
fun ReasonDialog(title: String, explanation: String, confirmText: String = "Reverse", onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var reason by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(explanation)
                Spacer(Modifier.height(12.dp))
                TextInput("Reason", reason, { reason = it; error = null }, error = error, singleLine = false, minLines = 2)
            }
        },
        confirmButton = {
            Button(
                onClick = { if (reason.isBlank()) error = "Enter a reason" else onConfirm(reason.trim()) },
                colors = ButtonDefaults.buttonColors(containerColor = PJColors.Danger),
            ) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Small helpers

@Composable
fun MoneyText(v: BigDecimal?, modifier: Modifier = Modifier, color: Color = Color.Unspecified, showSign: Boolean = false) {
    Text(Fmt.rupees(v, showSign), modifier, color = color, fontWeight = FontWeight.SemiBold)
}

/** Counts up to the amount once; the final frame always shows the exact value. */
@Composable
fun AnimatedRupees(value: BigDecimal?, style: androidx.compose.ui.text.TextStyle, modifier: Modifier = Modifier) {
    val progress = remember(value) { Animatable(0f) }
    LaunchedEffect(value) { progress.animateTo(1f, tween(900, easing = FastOutSlowInEasing)) }
    val shown = when {
        value == null || progress.value >= 1f -> value
        else -> value.multiply(BigDecimal(progress.value.toDouble())).setScale(2, java.math.RoundingMode.HALF_UP)
    }
    Text(Fmt.rupees(shown), modifier, style = style, maxLines = 1)
}

@Composable
fun FormColumn(padding: PaddingValues, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content,
    )
}

/** Scrolling for dialog bodies that may not fit on small screens. */
@Composable
fun Modifier.dialogScroll(): Modifier = this.verticalScroll(rememberScrollState())

@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = PJColors.Onyx, disabledContainerColor = Color.Transparent),
    ) {
        Box(
            Modifier.fillMaxSize().background(
                if (enabled) PJBrush.GoldFoil else androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)),
                RoundedCornerShape(14.dp),
            ),
            contentAlignment = Alignment.Center,
        ) { Text(text, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp) }
    }
}

@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(12.dp)) { Text(text) }
}

@Composable
fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp),
        style = MaterialTheme.typography.labelLarge.copy(fontFamily = Cinzel, letterSpacing = 1.6.sp),
        color = MaterialTheme.colorScheme.secondary,
    )
}
