package com.piyushjewellers.app.reports

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.piyushjewellers.app.AppContainer
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.Repository
import com.piyushjewellers.app.data.remote.*
import com.piyushjewellers.app.ui.container
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Saves PDFs through the system document picker (CreateDocument) and shares them via FileProvider. */
class PdfExporter(private val startSave: (File) -> Unit, private val context: Context) {
    fun save(file: File) = startSave(file)

    fun share(file: File) {
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, "Share PDF").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

@Composable
fun rememberPdfExporter(): PdfExporter {
    val context = LocalContext.current
    val c = container()
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<File?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val file = pending
        pending = null
        if (uri != null && file != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } } != null
                    }.getOrDefault(false)
                }
                c.toast(if (ok) "PDF saved" else "Couldn't save the PDF to that location")
            }
        }
    }
    return remember(launcher) {
        PdfExporter({ f ->
            pending = f
            launcher.launch(f.name)
        }, context)
    }
}

/**
 * Builds an on-device PDF from data cached during the last sync. Every page is stamped PROVISIONAL because
 * it may not include entries made on other devices or still waiting to sync.
 */
object ProvisionalPdf {
    data class Section(val heading: String, val columns: List<String>, val rows: List<List<String>>, val weights: List<Float>? = null)
    data class Content(val title: String, val filterSummary: String, val dataAsOf: Long?, val sections: List<Section>)

    private const val W = 595
    private const val H = 842
    private const val M = 36f

    fun write(context: Context, content: Content): File {
        val doc = PdfDocument()
        val title = Paint().apply { color = Color.rgb(0x1F, 0x19, 0x15); textSize = 18f; typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD) }
        val h2 = Paint().apply { color = Color.rgb(0x8C, 0x6D, 0x1F); textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
        val body = Paint().apply { color = Color.rgb(0x2A, 0x1A, 0x1F); textSize = 9f }
        val bold = Paint(body).apply { typeface = Typeface.DEFAULT_BOLD }
        val stamp = Paint().apply { color = Color.argb(40, 0xB3, 0x26, 0x1E); textSize = 64f; typeface = Typeface.DEFAULT_BOLD }
        val warn = Paint().apply { color = Color.rgb(0xB3, 0x26, 0x1E); textSize = 9f; typeface = Typeface.DEFAULT_BOLD }
        val rule = Paint().apply { color = Color.rgb(0xE2, 0xD4, 0xBF); strokeWidth = 0.7f }

        var pageNo = 0
        var page: PdfDocument.Page? = null
        var y = 0f

        fun finishPage() {
            page?.let { p ->
                p.canvas.drawText("Page $pageNo", W - M - 40f, H - 20f, body)
                doc.finishPage(p)
            }
        }

        fun newPage() {
            finishPage()
            pageNo += 1
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            val cv = page!!.canvas
            cv.save()
            cv.rotate(-35f, W / 2f, H / 2f)
            cv.drawText("PROVISIONAL", 90f, H / 2f, stamp)
            cv.restore()
            y = M + 10f
            cv.drawText("Piyush Jewellers — ${content.title}", M, y, title)
            y += 16f
            cv.drawText("PROVISIONAL · generated offline on ${Fmt.epoch(System.currentTimeMillis())}" +
                (content.dataAsOf?.let { " · data as of ${Fmt.epoch(it)}" } ?: ""), M, y, warn)
            y += 12f
            cv.drawText("May not include entries pending sync or made on other devices. Generate online for the final report.", M, y, body)
            y += 12f
            if (content.filterSummary.isNotBlank()) {
                cv.drawText("Filters: ${content.filterSummary}", M, y, body)
                y += 12f
            }
            y += 6f
        }

        fun ensure(space: Float) {
            if (page == null || y + space > H - 40f) newPage()
        }

        fun fit(text: String, width: Float, paint: Paint): String {
            if (paint.measureText(text) <= width) return text
            var t = text
            while (t.isNotEmpty() && paint.measureText("$t…") > width) t = t.dropLast(1)
            return "$t…"
        }

        newPage()
        for (s in content.sections) {
            ensure(40f)
            page!!.canvas.drawText(s.heading, M, y, h2)
            y += 14f
            val weights = s.weights ?: List(s.columns.size) { 1f }
            val total = weights.sum()
            val usable = W - 2 * M
            val widths = weights.map { usable * it / total }
            fun drawRow(cells: List<String>, paint: Paint) {
                ensure(14f)
                var x = M
                cells.forEachIndexed { i, cell ->
                    val w = widths.getOrElse(i) { 60f }
                    page!!.canvas.drawText(fit(cell, w - 4f, paint), x, y, paint)
                    x += w
                }
                y += 4f
                page!!.canvas.drawLine(M, y, W - M, y, rule)
                y += 10f
            }
            drawRow(s.columns, bold)
            if (s.rows.isEmpty()) drawRow(listOf("No records in saved data"), body)
            s.rows.forEach { drawRow(it, body) }
            y += 8f
        }
        finishPage()

        val dir = File(context.filesDir, "reports").apply { mkdirs() }
        val file = File(dir, "Provisional-${content.title.replace(Regex("[^A-Za-z0-9]+"), "-")}-${System.currentTimeMillis()}.pdf")
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
        return file
    }

    /** Assembles report content for [type] from the offline cache. Returns null when nothing is cached yet. */
    suspend fun fromCache(c: AppContainer, type: String): Content? {
        val r: Repository = c.repo
        return when (type) {
            "FINANCIAL" -> {
                val d = r.cachedOnly("dashboard", DashboardDto.serializer()) ?: return null
                val tx = r.cachedOnly("tx:null:null:null:null:null:null:", Page.serializer(TransactionDto.serializer()))
                val s = d.data.allTime
                Content(
                    "Financial Report", "All dates (saved data)", d.savedAt,
                    listOf(
                        Section("Balances", listOf("Measure", "Amount"), listOf(
                            listOf("Combined balance", Fmt.rupees(s.combinedBalance)),
                            listOf("Available balance", Fmt.rupees(s.availableBalance)),
                            listOf("Pending cheques in", Fmt.rupees(s.pendingChequesIn)),
                            listOf("Pending cheques out", Fmt.rupees(s.pendingChequesOut)),
                            listOf("Money in", Fmt.rupees(s.moneyIn)),
                            listOf("Money out", Fmt.rupees(s.moneyOut)),
                        ), listOf(2f, 1f)),
                        Section("By payment method", listOf("Method", "In", "Out", "Net"), s.byMethod.map {
                            listOf(Fmt.method(it.method), Fmt.rupees(it.moneyIn), Fmt.rupees(it.moneyOut), Fmt.rupees(it.net))
                        }),
                        Section("Recent transactions", listOf("Date", "Description", "Method", "In/Out", "Amount"),
                            (tx?.data?.content ?: d.data.recentTransactions).map {
                                listOf(Fmt.date(it.businessDate), it.description ?: it.category ?: Fmt.humanize(it.sourceType), Fmt.method(it.method), it.direction, Fmt.rupees(it.amount))
                            }, listOf(1.2f, 3f, 1f, 0.8f, 1.4f)),
                    ),
                )
            }
            "INVENTORY" -> {
                val p = r.cachedOnly("products::null:null:null", Page.serializer(ProductDto.serializer()))
                val list = p?.data?.content ?: c.db.cache().search("product", "").mapNotNull { runCatching { AppJson.decodeFromString(ProductDto.serializer(), it.json) }.getOrNull() }
                if (list.isEmpty()) return null
                Content("Inventory Report", "All products (saved data)", p?.savedAt, listOf(
                    Section("Stock", listOf("Code", "Name", "Metal", "Purity", "Net wt", "Pcs", "Status"), list.map {
                        listOf(it.code, it.name, Fmt.humanize(it.metal), it.purity.orEmpty(), Fmt.grams(it.netWeight), it.pieces.toString(), Fmt.humanize(it.availability))
                    }, listOf(1f, 2.4f, 0.9f, 0.8f, 1.1f, 0.5f, 1.1f)),
                ))
            }
            "CUSTOMER_BILLING" -> {
                val b = r.cachedOnly("bills:null:null:null:null:null:", Page.serializer(BillDto.serializer())) ?: return null
                Content("Customer Billing Report", "Recent bills (saved data)", b.savedAt, listOf(
                    Section("Bills", listOf("Date", "Bill", "Type", "Customer", "Total", "Paid", "Due", "Status"), b.data.content.map {
                        listOf(Fmt.date(it.billDate), it.billNumber, Fmt.humanize(it.type), it.personName ?: it.customerName.orEmpty(), Fmt.rupees(it.grandTotal), Fmt.rupees(it.paidAmount), Fmt.rupees(it.outstandingAmount), Fmt.humanize(it.status))
                    }, listOf(1f, 1f, 0.8f, 1.8f, 1.2f, 1.2f, 1.2f, 1f)),
                ))
            }
            "DEALER" -> {
                val b = r.cachedOnly("dbills:null:null:null:null:", Page.serializer(DealerBillDto.serializer())) ?: return null
                Content("Dealer Report", "Recent dealer bills (saved data)", b.savedAt, listOf(
                    Section("Dealer bills", listOf("Date", "Bill", "Dealer / shop", "Metal", "Final wt", "Amount", "Outstanding"), b.data.content.map {
                        listOf(Fmt.date(it.dealDate), it.billNumber, "${it.dealerName.orEmpty()} / ${it.shopName.orEmpty()}", Fmt.humanize(it.metal), Fmt.grams(it.totalFinalWeight), Fmt.rupees(it.amount), it.outstandingAmount?.let(Fmt::rupees) ?: Fmt.grams(it.outstandingWeight))
                    }, listOf(1f, 0.9f, 2f, 0.8f, 1.1f, 1.2f, 1.2f)),
                ))
            }
            "MORTGAGE" -> {
                val m = r.cachedOnly("mortgages:null:null:null:null:", Page.serializer(MortgageDto.serializer())) ?: return null
                Content("Mortgage & Interest Report", "Recent mortgages (saved data)", m.savedAt, listOf(
                    Section("Mortgages", listOf("Serial", "Customer", "Kind", "Issued", "Principal", "Rate/m", "Last calc due", "Status"), m.data.content.map {
                        listOf(it.serial, it.personName.orEmpty(), Fmt.humanize(it.kind), Fmt.date(it.issueDate), Fmt.rupees(it.principal), Fmt.percent(it.monthlyRate), it.lastCalculation?.let { lc -> Fmt.rupees(lc.totalDue) } ?: "Not calculated", Fmt.humanize(it.status))
                    }, listOf(1.1f, 1.6f, 0.9f, 1f, 1.1f, 0.7f, 1.2f, 0.8f)),
                ))
            }
            "DUES" -> {
                val d = r.cachedOnly("dues::null:null:ACTIVE", DueOverview.serializer()) ?: return null
                Content("Due Management Report", "Active dues (saved data)", d.savedAt, listOf(
                    Section("Totals", listOf("Measure", "Amount"), listOf(
                        listOf("Total receivable", Fmt.rupees(d.data.totalReceivable)),
                        listOf("Total payable", Fmt.rupees(d.data.totalPayable)),
                        listOf("Net", Fmt.rupees(d.data.net)),
                    ), listOf(2f, 1f)),
                    Section("By person", listOf("Name", "Phone", "Receivable", "Payable", "Net", "Next date"), d.data.persons.content.map {
                        listOf(it.name, it.phone.orEmpty(), Fmt.rupees(it.receivable), Fmt.rupees(it.payable), Fmt.rupees(it.net), Fmt.date(it.nextExpectedDate))
                    }, listOf(1.8f, 1.2f, 1.2f, 1.2f, 1.2f, 1f)),
                ))
            }
            "LENDING" -> {
                val l = r.cachedOnly("loans:null:null:null:", Page.serializer(LoanDto.serializer())) ?: return null
                Content("Lending & Borrowing Report", "Recent loans (saved data)", l.savedAt, listOf(
                    Section("Loans", listOf("Date", "Person", "Kind", "Principal", "Repaid", "Outstanding", "Expected", "Status"), l.data.content.map {
                        listOf(Fmt.date(it.loanDate), it.personName.orEmpty(), Fmt.humanize(it.kind), Fmt.rupees(it.principal), Fmt.rupees(it.repaidAmount), Fmt.rupees(it.outstanding), Fmt.date(it.expectedReturnDate), Fmt.humanize(it.status))
                    }, listOf(1f, 1.6f, 0.8f, 1.1f, 1.1f, 1.1f, 1f, 0.8f)),
                ))
            }
            "EXCHANGE" -> {
                val e = r.cachedOnly("exchanges:null:null:", Page.serializer(ExchangeDto.serializer())) ?: return null
                Content("Jewellery Exchange Report", "Recent exchanges (saved data)", e.savedAt, listOf(
                    Section("Exchanges", listOf("Date", "No.", "Party", "Received", "Issued", "Difference", "Status"), e.data.content.map {
                        listOf(Fmt.date(it.exchangeDate), it.exchangeNumber, it.personName ?: it.partyName.orEmpty(), Fmt.rupees(it.receivedValue), Fmt.rupees(it.issuedValue), Fmt.rupees(it.cashDifference), Fmt.humanize(it.status))
                    }, listOf(1f, 1f, 1.8f, 1.2f, 1.2f, 1.2f, 0.9f)),
                ))
            }
            else -> null
        }
    }
}
