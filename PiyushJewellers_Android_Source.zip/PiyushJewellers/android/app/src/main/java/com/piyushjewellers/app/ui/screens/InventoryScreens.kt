package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import com.piyushjewellers.app.R as Res
import com.piyushjewellers.app.ui.theme.PJBrush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.MetalCalc
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.remote.BarLotDto
import com.piyushjewellers.app.data.remote.BarLotRequest
import com.piyushjewellers.app.data.remote.MovementDto
import com.piyushjewellers.app.data.remote.ProductDto
import com.piyushjewellers.app.data.remote.ProductRequest
import com.piyushjewellers.app.data.remote.StockOperationRequest
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors
import java.math.BigDecimal

data class ProductQuery(val q: String = "", val metal: String? = null, val category: String? = null, val availability: String? = null)

@Composable
fun InventoryScreen() {
    val nav = LocalNav.current
    var tab by rememberSaveable { mutableStateOf(0) }
    val vm = pagedVm<ProductQuery, ProductDto>("products", ProductQuery()) { q, p -> products(q.q, q.category, q.metal, q.availability, p) }
    var addLot by rememberSaveable { mutableStateOf(false) }
    PJScaffold(
        title = "Inventory & Purchasing",
        topLevel = true,
        fab = {
            if (tab == 2) ExtendedFloatingActionButton(onClick = { addLot = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add MR Biscuit") })
            else ExtendedFloatingActionButton(onClick = { nav.navigate(R.ProductForm()) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add product") })
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                listOf("Catalog", "Stock", "MR Biscuit").forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            if (tab == 2) {
                BarLotsTab()
            } else {
                OutlinedTextField(
                    value = vm.query.q, onValueChange = { vm.update(vm.query.copy(q = it)) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Search code, name or purity") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
                )
                ChoiceChips(listOf(null) + Options.metals, vm.query.metal, { it?.let(Fmt::humanize) ?: "All metals" }, { vm.update(vm.query.copy(metal = it), false) }, Modifier.padding(horizontal = 16.dp))
                ChoiceChips(listOf(null) + Options.categories, vm.query.category, { it?.let(Fmt::humanize) ?: "All types" }, { vm.update(vm.query.copy(category = it), false) }, Modifier.padding(horizontal = 16.dp))
                LoadContent(vm.state, onRetry = vm::refresh, refreshing = vm.refreshing, onRefresh = vm::refresh) { list ->
                    if (tab == 0) CatalogGrid(list, vm.hasMore, vm.loadingMore, vm::loadMore) { nav.navigate(R.ProductDetail(it.id)) }
                    else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(list, key = { it.id }) { p ->
                            ListRow(
                                "${p.code} · ${p.name}",
                                "${Fmt.humanize(p.category)} · ${Fmt.humanize(p.metal)} ${p.purity.orEmpty()} · Gross ${Fmt.grams(p.grossWeight)} · Less ${Fmt.grams(p.lessWeight)}",
                                trailingTop = Fmt.grams(p.netWeight),
                                trailingBottom = { Text("${p.pieces} pc", style = MaterialTheme.typography.labelSmall) },
                                onClick = { nav.navigate(R.ProductDetail(p.id)) },
                            )
                        }
                        if (list.isEmpty()) item { EmptyState("No products", "Add products to track stock and photos.", Icons.Filled.Diamond) }
                        loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                    }
                }
            }
        }
    }
    if (addLot) BarLotDialog(onDismiss = { addLot = false })
}

@Composable
private fun CatalogGrid(list: List<ProductDto>, hasMore: Boolean, loadingMore: Boolean, onMore: () -> Unit, onOpen: (ProductDto) -> Unit) {
    val c = container()
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 96.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(list, key = { _, p -> p.id }) { i, p ->
            Card(
                Modifier.fillMaxWidth().reveal(i % 6).pressable { onOpen(p) },
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            ) {
                Box(Modifier.fillMaxWidth().aspectRatio(0.8f).background(Brush.verticalGradient(listOf(PJColors.Champagne, PJColors.GoldSoft)))) {
                    if (p.primaryImage != null) {
                        AsyncImage(
                            model = c.absoluteUrl(p.primaryImage.thumbnailUrl),
                            contentDescription = p.name,
                            imageLoader = c.imageLoader,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    } else {
                        Image(
                            painterResource(Res.drawable.pj_monogram), null,
                            Modifier.size(72.dp).align(Alignment.Center).graphicsLayer { alpha = 0.45f },
                        )
                    }
                    Box(Modifier.fillMaxWidth().height(64.dp).align(Alignment.BottomCenter).background(PJBrush.Scrim))
                    Surface(Modifier.align(Alignment.TopStart).padding(8.dp), shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.92f)) {
                        StatusChip(p.availability)
                    }
                    if (p.imageCount > 1) {
                        Surface(Modifier.align(Alignment.TopEnd).padding(8.dp), shape = RoundedCornerShape(50), color = PJColors.Onyx.copy(alpha = 0.7f)) {
                            Row(Modifier.padding(horizontal = 7.dp, vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.PhotoLibrary, null, Modifier.size(12.dp), tint = PJColors.GoldBright)
                                Text(" ${p.imageCount}", color = PJColors.Ivory, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                    Text(
                        Fmt.grams(p.netWeight),
                        Modifier.align(Alignment.BottomStart).padding(start = 10.dp, bottom = 8.dp),
                        style = MaterialTheme.typography.titleMedium.copy(brush = PJBrush.GoldFoil),
                    )
                }
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${p.code} · ${p.purity ?: Fmt.humanize(p.metal)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                }
            }
        }
        if (list.isEmpty()) item(span = { GridItemSpan(2) }) { EmptyState("No products", "Add products to build the photo catalog.", Icons.Filled.Diamond) }
        if (hasMore) item(span = { GridItemSpan(2) }) {
            Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                if (loadingMore) CircularProgressIndicator(Modifier.size(28.dp)) else OutlinedButton(onClick = onMore) { Text("Load more") }
            }
        }
    }
}

@Composable
private fun BarLotsTab() {
    val nav = LocalNav.current
    var metal by rememberSaveable { mutableStateOf<String?>(null) }
    var availableOnly by rememberSaveable { mutableStateOf(true) }
    val vm = loadVm("bars:$metal:$availableOnly") { barLots(metal, availableOnly) }
    Column {
        ChoiceChips(listOf(null, "GOLD", "SILVER"), metal, { it?.let(Fmt::humanize) ?: "All" }, { metal = it }, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        ChoiceChips(listOf(true, false), availableOnly, { if (it) "Available" else "All lots" }, { availableOnly = it }, Modifier.padding(horizontal = 16.dp))
        LoadContent(vm.state, onRetry = { vm.reload() }, refreshing = vm.refreshing, onRefresh = { vm.reload() }) { lots ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                item {
                    val gold = lots.filter { it.metal == "GOLD" }.fold(BigDecimal.ZERO) { a, l -> a + l.remainingWeight }
                    val silver = lots.filter { it.metal == "SILVER" }.fold(BigDecimal.ZERO) { a, l -> a + l.remainingWeight }
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard("MR Biscuit (Gold)", Fmt.grams(gold), Modifier.weight(1f), accent = PJColors.GoldDeep)
                        StatCard("MR Biscuit (Silver)", Fmt.grams(silver), Modifier.weight(1f), accent = PJColors.Info)
                    }
                }
                items(lots, key = { it.id }) { l ->
                    ListRow(
                        "${l.label} · ${l.lotCode}",
                        listOfNotNull(l.purity, l.rate?.let { "Rate ${Fmt.rupees(it)}/g" }, l.source, Fmt.date(l.receivedDate)).joinToString(" · "),
                        trailingTop = Fmt.grams(l.remainingWeight),
                        trailingBottom = { StatusChip(l.status) },
                        onClick = { nav.navigate(R.BarLotDetail(l.id)) },
                    )
                }
                if (lots.isEmpty()) item { EmptyState("No MR Biscuit lots", "Record biscuits received from dealers or purchased.") }
            }
        }
    }
}

@Composable
fun BarLotDialog(onDismiss: () -> Unit) {
    val actions = actionVm("barlot-new")
    val c = container()
    var metal by rememberSaveable { mutableStateOf("GOLD") }
    var code by rememberSaveable { mutableStateOf("") }
    var weight by rememberSaveable { mutableStateOf("") }
    var purity by rememberSaveable { mutableStateOf("") }
    var rate by rememberSaveable { mutableStateOf("") }
    var source by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add MR Biscuit lot") },
        text = {
            Column(Modifier.dialogScroll(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ChoiceChips(listOf("GOLD", "SILVER"), metal, { if (it == "GOLD") "MR Biscuit (Gold)" else "MR Biscuit (Silver)" }, { metal = it })
                DecimalInput("Weight", weight, { weight = it; error = null }, scale = 4, suffix = "g", error = error)
                TextInput("Lot code (optional)", code, { code = it }, supporting = "Generated automatically when blank")
                TextInput("Purity", purity, { purity = it })
                DecimalInput("Rate per gram", rate, { rate = it }, prefix = "₹")
                DateInput("Received date", date, { it?.let { d -> date = d } })
                TextInput("Source", source, { source = it })
                TextInput("Notes", notes, { notes = it }, singleLine = false)
            }
        },
        confirmButton = {
            Button(enabled = !actions.busy, onClick = {
                val w = Num.parse(weight)
                if (w == null || w.signum() <= 0) { error = "Enter the weight"; return@Button }
                actions.run({
                    createBarLot(BarLotRequest(metal, code.ifBlank { null }, w, purity.ifBlank { null }, Num.parse(rate), date.toString(), source.ifBlank { null }, notes.ifBlank { null }))
                }) { c.toast("Added ${it.label} ${it.lotCode}"); onDismiss() }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
    ActionErrorDialog(actions)
}

@Composable
fun BarLotDetailScreen(id: Long) {
    val lots = loadVm("bars-all") { barLots(null, false) }
    val moves = loadVm("barmov:$id") { barMovements(id) }
    val actions = actionVm("bar-adjust:$id")
    val c = container()
    var adjust by rememberSaveable { mutableStateOf(false) }
    val lot: BarLotDto? = lots.state.dataOrNull()?.firstOrNull { it.id == id }
    PJScaffold(
        title = lot?.let { "${it.label} · ${it.lotCode}" } ?: "MR Biscuit",
        actions = { if (lot != null) TextButton(onClick = { adjust = true }) { Text("Adjust", color = PJColors.Ivory) } },
        busy = actions.busy,
    ) { pad ->
        LoadContent(moves.state, onRetry = { lots.reload(); moves.reload() }, modifier = Modifier.padding(pad)) { list ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (lot != null) item {
                    SectionCard("Lot") {
                        InfoRow("Remaining", Fmt.grams(lot.remainingWeight), emphasize = true)
                        InfoRow("Received", Fmt.grams(lot.receivedWeight))
                        InfoRow("Purity", lot.purity)
                        InfoRow("Rate", lot.rate?.let { Fmt.rupees(it) + "/g" })
                        InfoRow("Received on", Fmt.date(lot.receivedDate))
                        InfoRow("Source", lot.source)
                        InfoRow("Status", Fmt.humanize(lot.status))
                    }
                }
                item { SectionHeader("Movements") }
                items(list, key = { it.id }) { m ->
                    ListRow(
                        Fmt.humanize(m.type),
                        listOfNotNull(Fmt.date(m.businessDate), m.reason, m.sourceType?.let(Fmt::humanize), m.createdBy).joinToString(" · "),
                        trailingTop = (if (m.weightDelta.signum() > 0) "+" else "") + Fmt.grams(m.weightDelta),
                        trailingColor = if (m.weightDelta.signum() >= 0) PJColors.Success else PJColors.Danger,
                        trailingBottom = { Text("Left ${Fmt.grams(m.remainingAfter)}", style = MaterialTheme.typography.labelSmall) },
                    )
                }
            }
        }
    }
    if (adjust && lot != null) {
        WeightAdjustDialog(
            title = "Adjust ${lot.lotCode}",
            onDismiss = { adjust = false },
            onConfirm = { delta, reason ->
                actions.run({ adjustBarLot(id, delta, reason) }) { adjust = false; c.toast("Adjusted"); lots.reload(); moves.reload() }
            },
        )
    }
    ActionErrorDialog(actions)
}

@Composable
private fun WeightAdjustDialog(title: String, onDismiss: () -> Unit, onConfirm: (BigDecimal, String) -> Unit) {
    var increase by rememberSaveable { mutableStateOf(true) }
    var weight by rememberSaveable { mutableStateOf("") }
    var reason by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(increase, { increase = true }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Increase") }
                    SegmentedButton(!increase, { increase = false }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Decrease") }
                }
                DecimalInput("Weight", weight, { weight = it; error = null }, scale = 4, suffix = "g")
                TextInput("Reason (required)", reason, { reason = it; error = null }, singleLine = false)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val w = Num.parse(weight)
                when {
                    w == null || w.signum() <= 0 -> error = "Enter the weight"
                    reason.isBlank() -> error = "Enter a reason"
                    else -> onConfirm(if (increase) w else w.negate(), reason.trim())
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun ProductFormScreen(id: Long?) {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("product-form:$id")
    val existing = if (id != null) loadVm("product-edit:$id") { product(id) } else null
    val loaded = existing?.state?.dataOrNull()
    var code by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("FINISHED_JEWELLERY") }
    var metal by rememberSaveable { mutableStateOf("GOLD") }
    var purity by rememberSaveable { mutableStateOf("") }
    var gross by rememberSaveable { mutableStateOf("") }
    var less by rememberSaveable { mutableStateOf("") }
    var pieces by rememberSaveable { mutableStateOf("") }
    var initialised by rememberSaveable { mutableStateOf(id == null) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var lessError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(loaded) {
        if (!initialised && loaded != null) {
            code = loaded.code; name = loaded.name; description = loaded.description.orEmpty(); category = loaded.category
            metal = loaded.metal; purity = loaded.purity.orEmpty(); initialised = true
        }
    }
    val net = MetalCalc.net(Num.parse(gross), Num.parse(less))

    PJScaffold(title = if (id == null) "Add product" else "Edit product", busy = actions.busy) { pad ->
        if (existing != null && existing.state !is Load.Ready) {
            LoadContent(existing.state, onRetry = { existing.reload() }, modifier = Modifier.padding(pad)) {}
            return@PJScaffold
        }
        FormColumn(pad) {
            TextInput("Product name *", name, { name = it; nameError = null }, error = nameError)
            TextInput("Code", code, { code = it }, supporting = if (id == null) "Leave blank to generate automatically" else null)
            DropdownField("Type", Options.categories, category, Fmt::humanize, { category = it })
            DropdownField("Metal", Options.metals, metal, Fmt::humanize, { metal = it })
            TextInput("Purity (e.g. 22K, 916, 92.5)", purity, { purity = it })
            TextInput("Description", description, { description = it }, singleLine = false, minLines = 2)
            if (id == null) {
                SectionHeader("Opening stock")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DecimalInput("Gross wt", gross, { gross = it; lessError = null }, Modifier.weight(1f), scale = 4, suffix = "g")
                    DecimalInput("Less wt", less, { less = it; lessError = null }, Modifier.weight(1f), scale = 4, suffix = "g", error = lessError)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DecimalInput("Net wt (auto)", Fmt.plain(net), {}, Modifier.weight(1f), scale = 4, suffix = "g", enabled = false)
                    IntInput("Pieces", pieces, { pieces = it }, Modifier.weight(1f))
                }
            } else {
                Text("Stock changes are recorded as movements from the product screen so history is kept.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            PrimaryButton(if (actions.busy) "Saving…" else "Save", {
                if (name.isBlank()) { nameError = "Enter a name"; return@PrimaryButton }
                val g = Num.parse(gross); val l = Num.parse(less)
                if (g != null && l != null && l > g) { lessError = "Less weight can't exceed gross weight"; return@PrimaryButton }
                val req = ProductRequest(
                    code.trim().ifBlank { null }, name.trim(), description.trim().ifBlank { null }, category, metal, purity.trim().ifBlank { null },
                    if (id == null) g else null, if (id == null) l else null, if (id == null && g != null) net else null,
                    if (id == null) pieces.toIntOrNull() else null, loaded?.version,
                )
                if (id == null) actions.run({ createProduct(req) }) { p -> c.toast("Product saved — add photos now"); nav.popBackStack(); nav.navigate(R.ProductDetail(p.id)) }
                else actions.run({ updateProduct(id, req) }) { c.toast("Saved changes"); nav.popBackStack() }
            }, enabled = !actions.busy)
        }
    }
    ActionErrorDialog(actions)
}

@Composable
fun ProductDetailScreen(id: Long) {
    val nav = LocalNav.current
    val c = container()
    val product = loadVm("product:$id") { product(id) }
    val movements = loadVm("movements:$id") { movements(id, 0) }
    val actions = actionVm("stock:$id")
    var operation by rememberSaveable { mutableStateOf<String?>(null) }
    val p = product.state.dataOrNull()
    PJScaffold(
        title = p?.name ?: "Product",
        subtitle = p?.code,
        actions = { if (p != null) IconButton(onClick = { nav.navigate(R.ProductForm(id)) }) { Icon(Icons.Filled.Edit, "Edit") } },
        busy = actions.busy,
    ) { pad ->
        LoadContent(product.state, onRetry = { product.reload() }, modifier = Modifier.padding(pad), refreshing = product.refreshing,
            onRefresh = { product.reload(); movements.reload() }) { pd ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 32.dp)) {
                item { ProductGallery(productId = id, onChanged = { product.reload(silent = true) }) }
                item {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionCard("Stock", trailing = { StatusChip(pd.availability) }) {
                            InfoRow("Gross weight", Fmt.grams(pd.grossWeight))
                            InfoRow("Less weight", Fmt.grams(pd.lessWeight))
                            InfoRow("Net weight", Fmt.grams(pd.netWeight), emphasize = true)
                            InfoRow("Pieces", pd.pieces.toString())
                            InfoRow("Type", Fmt.humanize(pd.category))
                            InfoRow("Metal / purity", "${Fmt.humanize(pd.metal)} ${pd.purity.orEmpty()}")
                            if (!pd.description.isNullOrBlank()) InfoRow("Description", pd.description)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { operation = "ADDITION" }, Modifier.weight(1f)) { Text("Add stock") }
                            OutlinedButton(onClick = { operation = "DEDUCTION" }, Modifier.weight(1f)) { Text("Deduct") }
                            OutlinedButton(onClick = { operation = "ADJUSTMENT" }, Modifier.weight(1f)) { Text("Adjust") }
                        }
                    }
                }
                item { SectionHeader("Stock history") }
                when (val m = movements.state) {
                    is Load.Ready -> {
                        if (m.data.content.isEmpty()) item { Text("No movements yet", Modifier.padding(16.dp)) }
                        items(m.data.content, key = { it.id }) { mv -> MovementRow(mv) }
                    }
                    is Load.Failed -> item { Text(m.error.message, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) }
                    Load.Loading -> item { LoadingState(Modifier.height(80.dp)) }
                }
            }
        }
    }
    operation?.let { op ->
        StockOperationDialog(op, onDismiss = { operation = null }) { req ->
            actions.run({ stockOperation(id, req) }) {
                operation = null
                c.toast("Stock updated")
                product.reload(silent = true); movements.reload(silent = true)
            }
        }
    }
    ActionErrorDialog(actions)
}

@Composable
private fun MovementRow(m: MovementDto) {
    ListRow(
        Fmt.humanize(m.type),
        listOfNotNull(Fmt.date(m.businessDate), m.reason, m.sourceType?.takeIf { it != "MANUAL" }?.let(Fmt::humanize), m.createdBy).joinToString(" · "),
        trailingTop = (if (m.netDelta.signum() > 0) "+" else "") + Fmt.grams(m.netDelta),
        trailingColor = if (m.netDelta.signum() >= 0) PJColors.Success else PJColors.Danger,
        trailingBottom = { Text("Now ${Fmt.grams(m.netAfter)} · ${m.piecesAfter} pc", style = MaterialTheme.typography.labelSmall) },
    )
}

@Composable
private fun StockOperationDialog(type: String, onDismiss: () -> Unit, onConfirm: (StockOperationRequest) -> Unit) {
    var increase by rememberSaveable { mutableStateOf(true) }
    var gross by rememberSaveable { mutableStateOf("") }
    var less by rememberSaveable { mutableStateOf("") }
    var pieces by rememberSaveable { mutableStateOf("") }
    var reason by rememberSaveable { mutableStateOf("") }
    var date by remember { mutableStateOf(Fmt.today()) }
    var error by remember { mutableStateOf<String?>(null) }
    val net = MetalCalc.net(Num.parse(gross), Num.parse(less))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(when (type) { "ADDITION" -> "Add stock"; "DEDUCTION" -> "Deduct stock"; else -> "Adjust stock" }) },
        text = {
            Column(Modifier.dialogScroll(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (type == "ADJUSTMENT") {
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        SegmentedButton(increase, { increase = true }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Increase") }
                        SegmentedButton(!increase, { increase = false }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Decrease") }
                    }
                }
                DecimalInput("Gross weight", gross, { gross = it; error = null }, scale = 4, suffix = "g")
                DecimalInput("Less weight", less, { less = it; error = null }, scale = 4, suffix = "g")
                Text("Net: ${Fmt.grams(net)}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.tertiary)
                IntInput("Pieces", pieces, { pieces = it })
                DateInput("Date", date, { it?.let { d -> date = d } })
                TextInput("Reason (required)", reason, { reason = it; error = null }, singleLine = false)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val g = Num.parse(gross); val l = Num.parse(less); val pc = pieces.toIntOrNull()
                when {
                    (g == null || g.signum() == 0) && (pc == null || pc == 0) -> error = "Enter a weight or number of pieces"
                    g != null && l != null && l > g -> error = "Less weight can't exceed gross weight"
                    reason.isBlank() -> error = "Enter a reason"
                    else -> {
                        val sign = if (type == "ADJUSTMENT" && !increase) BigDecimal.ONE.negate() else BigDecimal.ONE
                        onConfirm(StockOperationRequest(
                            type, g?.multiply(sign), l?.multiply(sign), net.multiply(sign),
                            pc?.let { if (sign.signum() < 0) -it else it }, reason.trim(), date.toString(),
                        ))
                    }
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}