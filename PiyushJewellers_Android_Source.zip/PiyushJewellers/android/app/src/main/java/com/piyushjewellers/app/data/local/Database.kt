package com.piyushjewellers.app.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/** Last good server response for a screen or record, used to show data while offline. */
@Entity(tableName = "cached_records")
data class CachedRecord(
    @PrimaryKey val key: String,
    val type: String,
    val json: String,
    val searchText: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
)

object SyncState {
    const val DRAFT = "DRAFT"
    const val PENDING_SYNC = "PENDING_SYNC"
    const val SYNCING = "SYNCING"
    const val SYNCED = "SYNCED"
    const val CONFLICT = "CONFLICT"
    const val FAILED = "FAILED"
}

/**
 * Durable outbox. [id] is a UUID used as the server Idempotency-Key, so a replay after a lost response never
 * creates a duplicate. [localId] is a negative placeholder id handed to the UI for records created offline.
 */
@Entity(tableName = "outbox", indices = [Index("state"), Index("createdAt")])
data class OutboxOp(
    @PrimaryKey val id: String,
    val entityType: String,
    val summary: String,
    val method: String,
    val path: String,
    val body: String? = null,
    val filePath: String? = null,
    val localId: Long? = null,
    val state: String = SyncState.PENDING_SYNC,
    val attempts: Int = 0,
    val lastError: String? = null,
    val serverId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "id_mappings")
data class IdMapping(@PrimaryKey val localId: Long, val serverId: Long, val entityType: String)

@Entity(tableName = "reminders", indices = [Index("remindAt")])
data class LocalReminder(
    @PrimaryKey val key: String,
    val sourceType: String,
    val sourceId: Long? = null,
    val personId: Long? = null,
    val title: String,
    val notes: String? = null,
    val remindAt: Long,
    val enabled: Boolean = true,
    val firedAt: Long? = null,
    val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "report_history")
data class ReportHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportType: String,
    val title: String,
    val filterSummary: String,
    val provisional: Boolean,
    val filePath: String?,
    val serverJobId: Long? = null,
    val dataAsOf: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Dao
interface CacheDao {
    @Upsert suspend fun put(r: CachedRecord)
    @Upsert suspend fun putAll(r: List<CachedRecord>)
    @Query("SELECT * FROM cached_records WHERE `key` = :key") suspend fun get(key: String): CachedRecord?
    @Query("SELECT * FROM cached_records WHERE type = :type AND searchText LIKE '%' || :q || '%' ORDER BY updatedAt DESC LIMIT :limit")
    suspend fun search(type: String, q: String, limit: Int = 200): List<CachedRecord>
    @Query("DELETE FROM cached_records") suspend fun clear()
}

@Dao
interface OutboxDao {
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(op: OutboxOp)
    @Upsert suspend fun upsert(op: OutboxOp)
    @Query("SELECT * FROM outbox WHERE id = :id") suspend fun get(id: String): OutboxOp?
    @Query("SELECT * FROM outbox WHERE state = 'PENDING_SYNC' ORDER BY createdAt ASC") suspend fun pending(): List<OutboxOp>
    @Query("SELECT * FROM outbox WHERE localId = :localId LIMIT 1") suspend fun byLocalId(localId: Long): OutboxOp?
    @Query("SELECT * FROM outbox ORDER BY createdAt DESC LIMIT 200") fun observeAll(): Flow<List<OutboxOp>>
    @Query("SELECT * FROM outbox WHERE entityType = :type AND state NOT IN ('SYNCED') ORDER BY createdAt DESC") fun observeUnsynced(type: String): Flow<List<OutboxOp>>
    @Query("SELECT * FROM outbox WHERE entityType = :type AND state NOT IN ('SYNCED') ORDER BY createdAt DESC") suspend fun unsynced(type: String): List<OutboxOp>
    @Query("SELECT COUNT(*) FROM outbox WHERE state NOT IN ('SYNCED')") fun observeUnsyncedCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM outbox WHERE state IN ('CONFLICT','FAILED')") fun observeProblemCount(): Flow<Int>
    @Query("UPDATE outbox SET state = 'PENDING_SYNC', updatedAt = :now WHERE state = 'SYNCING'") suspend fun resetStuck(now: Long = System.currentTimeMillis())
    @Query("DELETE FROM outbox WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM outbox WHERE state = 'SYNCED' AND updatedAt < :before") suspend fun purgeSynced(before: Long)
}

@Dao
interface IdMappingDao {
    @Upsert suspend fun put(m: IdMapping)
    @Query("SELECT * FROM id_mappings WHERE localId = :localId") suspend fun get(localId: Long): IdMapping?
}

@Dao
interface ReminderDao {
    @Upsert suspend fun upsert(r: LocalReminder)
    @Upsert suspend fun upsertAll(r: List<LocalReminder>)
    @Query("SELECT * FROM reminders WHERE `key` = :key") suspend fun get(key: String): LocalReminder?
    @Query("SELECT * FROM reminders ORDER BY remindAt ASC") fun observeAll(): Flow<List<LocalReminder>>
    @Query("SELECT * FROM reminders WHERE enabled = 1 AND remindAt > :now") suspend fun upcoming(now: Long): List<LocalReminder>
    @Query("SELECT * FROM reminders") suspend fun all(): List<LocalReminder>
    @Query("DELETE FROM reminders WHERE `key` = :key") suspend fun delete(key: String)
}

@Dao
interface ReportHistoryDao {
    @Insert suspend fun insert(r: ReportHistory): Long
    @Query("SELECT * FROM report_history ORDER BY createdAt DESC LIMIT 100") fun observeAll(): Flow<List<ReportHistory>>
    @Query("DELETE FROM report_history WHERE id = :id") suspend fun delete(id: Long)
}

@Database(
    entities = [CachedRecord::class, OutboxOp::class, IdMapping::class, LocalReminder::class, ReportHistory::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cache(): CacheDao
    abstract fun outbox(): OutboxDao
    abstract fun idMappings(): IdMappingDao
    abstract fun reminders(): ReminderDao
    abstract fun reports(): ReportHistoryDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "piyush_jewellers.db").build()
    }
}
