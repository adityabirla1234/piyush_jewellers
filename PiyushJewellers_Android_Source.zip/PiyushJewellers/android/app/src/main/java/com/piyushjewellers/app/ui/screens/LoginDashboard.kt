package com.piyushjewellers.app.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SouthWest
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.piyushjewellers.app.R as Res
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.SessionStore
import com.piyushjewellers.app.data.remote.AppException
import com.piyushjewellers.app.data.remote.DashboardDto
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.nav.openTopLevel
import com.piyushjewellers.app.ui.theme.BrandStyle
import com.piyushjewellers.app.ui.theme.PJBrush
import com.piyushjewellers.app.ui.theme.PJColors
import com.piyushjewellers.app.ui.theme.PJTheme
import java.time.LocalTime

@Composable
fun LoginScreen() {
    val c = container()
    val actions = actionVm("login")
    val expired by c.session.expired.collectAsState()
    var server by rememberSaveable { mutableStateOf(c.session.baseUrl) }
    var username by rememberSaveable { mutableStateOf(c.session.user?.username ?: "") }
    var password by rememberSaveable { mutableStateOf("") }
    var showPassword by rememberSaveable { mutableStateOf(false) }
    var showServer by rememberSaveable { mutableStateOf(c.session.baseUrl.isBlank()) }
    var serverError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }

    fun submit() {
        serverError = SessionStore.validate(server)
        if (serverError != null) {
            showServer = true
            return
        }
        if (username.isBlank() || password.isEmpty()) {
            formError = "Enter your username and password"
            return
        }
        formError = null
        actions.run(
            block = { login(server, username, password) },
            onError = { e ->
                formError = when {
                    e.kind == AppException.Kind.UNAUTHORIZED -> "Incorrect username or password"
                    e.isOffline -> "Can't reach the server. Check the internet connection and the server address."
                    else -> e.message
                }
                true
            },
        )
    }

    val intro = remember { Animatable(0f) }
    LaunchedEffect(Unit) { intro.animateTo(1f, tween(1100, easing = FastOutSlowInEasing)) }
    val glow by rememberInfiniteTransition(label = "glow").animateFloat(
        0.10f, 0.22f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "glow",
    )

    PJTheme(dark = true) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF241B14), PJColors.Onyx), radius = 1400f))) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).imePadding().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Spacer(Modifier.height(32.dp))
                Box(contentAlignment = Alignment.Center) {
                    Box(Modifier.size(260.dp).background(Brush.radialGradient(listOf(PJColors.Gold.copy(alpha = glow), Color.Transparent))))
                    Image(
                        painterResource(Res.drawable.pj_logo),
                        contentDescription = "Piyush Jewellers",
                        modifier = Modifier.width(200.dp).graphicsLayer {
                            val p = (intro.value / 0.6f).coerceIn(0f, 1f)
                            alpha = p
                            scaleX = 0.9f + 0.1f * p
                            scaleY = 0.9f + 0.1f * p
                        },
                    )
                }
                Text(
                    "Shop management",
                    style = BrandStyle.copy(fontSize = 11.sp, letterSpacing = 4.sp),
                    color = PJColors.GoldSoft.copy(alpha = 0.7f),
                    modifier = Modifier.graphicsLayer { alpha = ((intro.value - 0.3f) / 0.5f).coerceIn(0f, 1f) },
                )
                Spacer(Modifier.height(28.dp))
                Card(
                    Modifier.fillMaxWidth().graphicsLayer {
                        val p = ((intro.value - 0.35f) / 0.65f).coerceIn(0f, 1f)
                        alpha = p
                        translationY = (1f - p) * 40.dp.toPx()
                    },
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = PJColors.OnyxRaised.copy(alpha = 0.92f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PJColors.Gold.copy(alpha = 0.35f)),
                ) {
                    Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Welcome back", style = MaterialTheme.typography.headlineSmall, color = PJColors.Ivory)
                        Text("Sign in to continue", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (expired) {
                            Text("Your session ended. Sign in again — unsynced work is kept on this device.", color = Color(0xFFFFB74D), style = MaterialTheme.typography.bodyMedium)
                        }
                        OutlinedTextField(
                            value = username, onValueChange = { username = it; formError = null },
                            label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                        OutlinedTextField(
                            value = password, onValueChange = { password = it; formError = null },
                            label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            trailingIcon = {
                                IconButton(onClick = { showPassword = !showPassword }) {
                                    Icon(if (showPassword) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, if (showPassword) "Hide password" else "Show password")
                                }
                            },
                        )
                        if (showServer) {
                            TextInput(
                                "Server address", server, { server = it; serverError = null },
                                error = serverError, supporting = "For example https://piyush-jewellers.onrender.com", keyboardType = KeyboardType.Uri,
                            )
                        } else {
                            TextButton(onClick = { showServer = true }) { Text("Server: ${server.ifBlank { "not set" }}", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        }
                        formError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Spacer(Modifier.height(2.dp))
                        PrimaryButton(if (actions.busy) "Signing in…" else "Sign in", ::submit, enabled = !actions.busy)
                    }
                }
                Spacer(Modifier.height(40.dp))
            }
        }
    }
}

@Composable
private fun BrandTitle() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(Res.drawable.pj_monogram), null, Modifier.height(34.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text("Piyush", style = BrandStyle.copy(fontSize = 19.sp, brush = PJBrush.GoldFoil), maxLines = 1)
            Text("Jewellers", style = BrandStyle.copy(fontSize = 9.sp, letterSpacing = 4.sp), color = PJColors.GoldSoft.copy(alpha = 0.8f), maxLines = 1)
        }
    }
}

private fun greeting(): String = when (LocalTime.now().hour) {
    in 0..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    else -> "Good evening"
}

@Composable
private fun HeroCard(d: DashboardDto, name: String?, onOpen: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier.fillMaxWidth().pressable(onOpen).clip(shape).background(PJBrush.OnyxHero).border(1.dp, PJColors.Gold.copy(alpha = 0.35f), shape),
    ) {
        Image(
            painterResource(Res.drawable.pj_monogram), null,
            Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 6.dp).size(124.dp).graphicsLayer { alpha = 0.10f },
        )
        Column(Modifier.padding(20.dp)) {
            Text(greeting() + (name?.let { ", $it" } ?: ""), color = PJColors.GoldSoft, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(Fmt.date(Fmt.today()), color = PJColors.Ivory.copy(alpha = 0.6f), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(18.dp))
            Text("COMBINED BALANCE", color = PJColors.Ivory.copy(alpha = 0.65f), style = MaterialTheme.typography.labelSmall, letterSpacing = 1.6.sp)
            AnimatedRupees(d.allTime.combinedBalance, MaterialTheme.typography.headlineMedium.copy(brush = PJBrush.GoldFoil))
            Text("Includes pending cheques", color = PJColors.Ivory.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(16.dp))
            GoldHairline()
            Spacer(Modifier.height(14.dp))
            Row {
                HeroFigure("Available", Fmt.rupees(d.allTime.availableBalance), Color(0xFFA5D6A7), Modifier.weight(1f))
                HeroDivider()
                HeroFigure("Today in", Fmt.rupees(d.today.moneyIn), Color(0xFFA5D6A7), Modifier.weight(1f))
                HeroDivider()
                HeroFigure("Today out", Fmt.rupees(d.today.moneyOut), Color(0xFFF2B8B5), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun HeroFigure(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.padding(horizontal = 4.dp)) {
        Text(label.uppercase(), color = PJColors.Ivory.copy(alpha = 0.55f), style = MaterialTheme.typography.labelSmall, letterSpacing = 0.8.sp, maxLines = 1)
        Spacer(Modifier.height(2.dp))
        Text(value, color = color, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun HeroDivider() {
    Box(Modifier.padding(horizontal = 6.dp).width(1.dp).height(34.dp).background(PJColors.Gold.copy(alpha = 0.3f)))
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.width(64.dp).pressable(onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerLowest).border(1.dp, PJBrush.GoldFoil, CircleShape),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.secondary) }
        Spacer(Modifier.height(6.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun DashboardScreen() {
    val vm = loadVm<DashboardDto>("dashboard") { dashboard() }
    val nav = LocalNav.current
    val user = container().session.user
    PJScaffold(
        title = "Dashboard",
        topLevel = true,
        titleContent = { BrandTitle() },
        actions = { IconButton(onClick = { vm.reload() }) { Icon(Icons.Filled.Refresh, "Refresh") } },
    ) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { d ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item(key = "hero") {
                    HeroCard(d, user?.fullName ?: user?.username, onOpen = { nav.openTopLevel(R.Transactions) }, modifier = Modifier.reveal(0))
                }
                item(key = "actions") {
                    Row(Modifier.fillMaxWidth().reveal(1), horizontalArrangement = Arrangement.SpaceBetween) {
                        QuickAction(Icons.AutoMirrored.Filled.ReceiptLong, "New sale") { nav.navigate(R.BillEditor(type = "SALES")) }
                        QuickAction(Icons.Filled.SouthWest, "Money in") { nav.navigate(R.TransactionEntry(direction = "IN")) }
                        QuickAction(Icons.Filled.NorthEast, "Money out") { nav.navigate(R.TransactionEntry(direction = "OUT")) }
                        QuickAction(Icons.Filled.Store, "Dealer bill") { nav.navigate(R.DealerBillEditor()) }
                        QuickAction(Icons.Filled.CurrencyExchange, "Exchange") { nav.navigate(R.ExchangeEditor()) }
                    }
                }
                item(key = "cheques") {
                    Row(Modifier.reveal(2), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard("Pending cheques in", Fmt.rupees(d.allTime.pendingChequesIn), Modifier.weight(1f), accent = PJColors.Warning, onClick = { nav.navigate(R.Cheques) })
                        StatCard("Pending cheques out", Fmt.rupees(d.allTime.pendingChequesOut), Modifier.weight(1f), accent = PJColors.Warning, onClick = { nav.navigate(R.Cheques) })
                    }
                }
                item(key = "dues") {
                    Row(Modifier.reveal(3), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard("To receive", Fmt.rupees(d.totalReceivable), Modifier.weight(1f), accent = PJColors.Success, onClick = { nav.openTopLevel(R.Dues) })
                        StatCard("To pay", Fmt.rupees(d.totalPayable), Modifier.weight(1f), accent = PJColors.Danger, onClick = { nav.openTopLevel(R.Dues) })
                    }
                }
                item(key = "lending") {
                    Row(Modifier.reveal(4), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard("Active mortgages", "${d.activeMortgages.count}", Modifier.weight(1f), hint = Fmt.rupees(d.activeMortgages.amount) + " principal", onClick = { nav.openTopLevel(R.Mortgages) })
                        StatCard("Lent / Borrowed", "${d.activeLent.count} / ${d.activeBorrowed.count}", Modifier.weight(1f), hint = "${Fmt.rupees(d.activeLent.amount)} / ${Fmt.rupees(d.activeBorrowed.amount)}", onClick = { nav.openTopLevel(R.Loans) })
                    }
                }
                item(key = "inventory") {
                    SectionCard("Inventory", Modifier.reveal(5), trailing = { TextButton(onClick = { nav.openTopLevel(R.Inventory) }) { Text("Open") } }) {
                        InfoRow("Products", "${d.inventory.productCount} (${d.inventory.outOfStockCount} out of stock)")
                        InfoRow("Gold in stock (net)", Fmt.grams(d.inventory.goldNetWeight))
                        InfoRow("Silver in stock (net)", Fmt.grams(d.inventory.silverNetWeight))
                        InfoRow("MR Biscuit (Gold)", Fmt.grams(d.inventory.goldBarWeight))
                        InfoRow("MR Biscuit (Silver)", Fmt.grams(d.inventory.silverBarWeight))
                    }
                }
                if (d.allTime.byMethod.isNotEmpty()) {
                    item(key = "methods") {
                        SectionCard("Balance by method", Modifier.reveal(6)) {
                            d.allTime.byMethod.forEach { m -> InfoRow(Fmt.method(m.method), Fmt.rupees(m.net), valueColor = if (m.net.signum() < 0) PJColors.Danger else Color.Unspecified) }
                        }
                    }
                }
                item(key = "recent") {
                    SectionCard("Recent transactions", Modifier.reveal(7), trailing = { TextButton(onClick = { nav.openTopLevel(R.Transactions) }) { Text("All") } }) {
                        if (d.recentTransactions.isEmpty()) Text("No transactions yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                itemsIndexed(d.recentTransactions, key = { _, t -> t.id }) { i, t ->
                    Box(Modifier.reveal(8 + i)) { TransactionRow(t) { nav.navigate(R.TransactionDetail(t.id)) } }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}
