package com.piyushjewellers.app.reminders

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.piyushjewellers.app.MainActivity
import com.piyushjewellers.app.PiyushApp
import com.piyushjewellers.app.R
import com.piyushjewellers.app.data.local.LocalReminder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Reminders are delivered as local notifications only (no push, no messaging services).
 * Alarms are re-registered after reboot, app update and clock changes.
 */
class ReminderScheduler(private val context: Context) {

    private val alarms = context.getSystemService(AlarmManager::class.java)

    fun ensureChannel() {
        val nm = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL_ID, context.getString(R.string.reminder_channel_name), NotificationManager.IMPORTANCE_HIGH)
        channel.description = context.getString(R.string.reminder_channel_desc)
        nm.createNotificationChannel(channel)
    }

    fun canNotify(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun schedule(r: LocalReminder) {
        cancel(r.key)
        if (!r.enabled || r.remindAt <= System.currentTimeMillis()) return
        val pi = pendingIntent(r.key, create = true) ?: return
        val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarms.canScheduleExactAlarms()
        if (exactAllowed) {
            alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.remindAt, pi)
        } else {
            alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.remindAt, pi)
        }
    }

    fun cancel(key: String) {
        pendingIntent(key, create = false)?.let {
            alarms.cancel(it)
            it.cancel()
        }
    }

    private fun pendingIntent(key: String, create: Boolean): PendingIntent? {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = ACTION_FIRE
            putExtra(EXTRA_KEY, key)
            data = android.net.Uri.parse("pj-reminder://$key")
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE
        return PendingIntent.getBroadcast(context, key.hashCode(), intent, flags)
    }

    fun notify(r: LocalReminder) {
        if (!canNotify()) return
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_OPEN, "reminders")
        }
        val contentIntent = PendingIntent.getActivity(context, r.key.hashCode(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_reminder)
            .setContentTitle(r.title)
            .setContentText(r.notes ?: "Reminder")
            .setStyle(NotificationCompat.BigTextStyle().bigText(r.notes ?: r.title))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(r.key.hashCode(), n)
        } catch (e: SecurityException) {
            // Permission revoked between the check and the post; nothing else to do.
        }
    }

    companion object {
        const val CHANNEL_ID = "pj_reminders"
        const val ACTION_FIRE = "com.piyushjewellers.app.REMINDER_FIRE"
        const val EXTRA_KEY = "key"
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val key = intent.getStringExtra(ReminderScheduler.EXTRA_KEY) ?: return
        val container = (context.applicationContext as PiyushApp).container
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val r = container.db.reminders().get(key)
                if (r != null && r.enabled) {
                    container.reminderScheduler.notify(r)
                    container.db.reminders().upsert(r.copy(firedAt = System.currentTimeMillis()))
                }
            } finally {
                pending.finish()
            }
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val container = (context.applicationContext as PiyushApp).container
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                container.db.reminders().upcoming(System.currentTimeMillis()).forEach { container.reminderScheduler.schedule(it) }
            } finally {
                pending.finish()
            }
        }
    }
}
