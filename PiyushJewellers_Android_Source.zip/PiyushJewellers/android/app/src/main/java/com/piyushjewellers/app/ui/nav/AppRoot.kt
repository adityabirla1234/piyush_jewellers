package com.piyushjewellers.app.ui.nav

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.sp
import com.piyushjewellers.app.R as Res
import com.piyushjewellers.app.ui.components.GoldHairline
import com.piyushjewellers.app.ui.theme.BrandStyle
import com.piyushjewellers.app.ui.theme.PJBrush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PendingActions
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.piyushjewellers.app.ui.components.ConfirmDialog
import com.piyushjewellers.app.ui.components.LocalDrawerOpener
import com.piyushjewellers.app.ui.components.LocalNav
import com.piyushjewellers.app.ui.components.LocalSnackbar
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.screens.*
import com.piyushjewellers.app.ui.theme.PJColors
import kotlinx.coroutines.launch
import kotlin.reflect.KClass

private data class DrawerEntry(val label: String, val icon: ImageVector, val route: Any, val cls: KClass<*>)

private val drawerEntries = listOf(
    DrawerEntry("Dashboard", Icons.Filled.Dashboard, R.Dashboard, R.Dashboard::class),
    DrawerEntry("Customers & Suppliers", Icons.Filled.People, R.People, R.People::class),
    DrawerEntry("Inventory & Purchasing", Icons.Filled.Inventory2, R.Inventory, R.Inventory::class),
    DrawerEntry("Customer Billing (Sales/Purchase)", Icons.AutoMirrored.Filled.ReceiptLong, R.Bills, R.Bills::class),
    DrawerEntry("Dealer & Shop Management", Icons.Filled.Store, R.Dealers, R.Dealers::class),
    DrawerEntry("Daily Transactions", Icons.Filled.Payments, R.Transactions, R.Transactions::class),
    DrawerEntry("Lending & Borrowing", Icons.Filled.Handshake, R.Loans, R.Loans::class),
    DrawerEntry("Mortgages (Jewellery/Cash)", Icons.Filled.AccountBalance, R.Mortgages, R.Mortgages::class),
    DrawerEntry("Jewellery Exchange", Icons.Filled.CurrencyExchange, R.Exchanges, R.Exchanges::class),
    DrawerEntry("Due Management", Icons.Filled.PendingActions, R.Dues, R.Dues::class),
    DrawerEntry("Reminders", Icons.Filled.NotificationsActive, R.Reminders, R.Reminders::class),
    DrawerEntry("Reports & PDF", Icons.Filled.PictureAsPdf, R.Reports, R.Reports::class),
    DrawerEntry("Settings", Icons.Filled.Settings, R.Settings, R.Settings::class),
)

@Composable
fun AppRoot(openTarget: String?, onTargetHandled: () -> Unit) {
    val c = container()
    val loggedIn by c.session.loggedIn.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { c.messages.collect { snackbar.showSnackbar(it) } }
    CompositionLocalProvider(LocalSnackbar provides snackbar) {
        if (!loggedIn) LoginScreen() else MainShell(openTarget, onTargetHandled)
    }
}

fun NavHostController.openTopLevel(route: Any) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
private fun MainShell(openTarget: String?, onTargetHandled: () -> Unit) {
    val c = container()
    val nav = rememberNavController()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStack by nav.currentBackStackEntryAsState()
    val unsynced by c.db.outbox().observeUnsyncedCount().collectAsState(initial = 0)
    val problems by c.db.outbox().observeProblemCount().collectAsState(initial = 0)
    var confirmLogout by rememberSaveable { mutableStateOf(false) }
    val user = c.session.user

    LaunchedEffect(openTarget) {
        if (openTarget == "reminders") {
            nav.openTopLevel(R.Reminders)
            onTargetHandled()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.surface) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Column(Modifier.fillMaxWidth().background(PJBrush.OnyxHero).padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(painterResource(Res.drawable.pj_monogram), null, Modifier.height(44.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Piyush", style = BrandStyle.copy(fontSize = 22.sp, brush = PJBrush.GoldFoil))
                                Text("Jewellers", style = BrandStyle.copy(fontSize = 10.sp, letterSpacing = 4.sp), color = PJColors.GoldSoft.copy(alpha = 0.8f))
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(
                            (user?.fullName ?: user?.username ?: "") + (user?.role?.let { " · ${it.lowercase().replaceFirstChar(Char::titlecase)}" } ?: ""),
                            color = PJColors.GoldSoft, style = MaterialTheme.typography.bodyMedium,
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.clickable {
                                scope.launch { drawer.close() }
                                nav.navigate(R.Sync)
                            },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.Sync, null, tint = PJColors.GoldBright, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                when {
                                    problems > 0 -> "$problems need attention · $unsynced unsynced"
                                    unsynced > 0 -> "$unsynced waiting to sync"
                                    else -> "All changes synced"
                                },
                                color = PJColors.Ivory, style = MaterialTheme.typography.labelMedium,
                            )
                        }
                    }
                    GoldHairline()
                    Spacer(Modifier.height(8.dp))
                    drawerEntries.forEach { e ->
                        val selected = backStack?.destination?.hasRoute(e.cls) == true
                        NavigationDrawerItem(
                            label = { Text(e.label) },
                            icon = { Icon(e.icon, null) },
                            selected = selected,
                            onClick = {
                                scope.launch { drawer.close() }
                                nav.openTopLevel(e.route)
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.secondary,
                                unselectedIconColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.75f),
                            ),
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                        )
                    }
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    NavigationDrawerItem(
                        label = { Text("Logout") },
                        icon = { Icon(Icons.AutoMirrored.Filled.Logout, null) },
                        selected = false,
                        onClick = {
                            scope.launch { drawer.close() }
                            confirmLogout = true
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    )
                    Spacer(Modifier.height(16.dp))
                }
            }
        },
    ) {
        CompositionLocalProvider(LocalNav provides nav, LocalDrawerOpener provides { scope.launch { drawer.open() } }) {
            AppNavHost(nav)
        }
    }

    if (confirmLogout) {
        ConfirmDialog(
            title = "Log out?",
            text = if (unsynced > 0) "$unsynced change(s) have not synced yet. They stay on this device and sync after you sign in again." else "You will need your password to sign in again.",
            confirmText = "Log out",
            onConfirm = {
                confirmLogout = false
                scope.launch { c.repo.logout() }
            },
            onDismiss = { confirmLogout = false },
        )
    }
}

@Composable
private fun AppNavHost(nav: NavHostController) {
    NavHost(
        navController = nav,
        startDestination = R.Dashboard,
        enterTransition = { fadeIn(tween(280)) + slideInHorizontally(tween(280)) { it / 10 } },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(280)) + slideInHorizontally(tween(280)) { -it / 10 } },
        popExitTransition = { fadeOut(tween(200)) + slideOutHorizontally(tween(240)) { it / 10 } },
    ) {
        composable<R.Dashboard> { DashboardScreen() }
        composable<R.People> { PeopleScreen() }
        composable<R.PersonDetail> { PersonDetailScreen(it.toRoute<R.PersonDetail>().id) }
        composable<R.PersonForm> { PersonFormScreen(it.toRoute<R.PersonForm>().id) }

        composable<R.Inventory> { InventoryScreen() }
        composable<R.ProductDetail> { ProductDetailScreen(it.toRoute<R.ProductDetail>().id) }
        composable<R.ProductForm> { ProductFormScreen(it.toRoute<R.ProductForm>().id) }
        composable<R.PhotoViewer> { val r = it.toRoute<R.PhotoViewer>(); PhotoViewerScreen(r.productId, r.index) }
        composable<R.BarLotDetail> { BarLotDetailScreen(it.toRoute<R.BarLotDetail>().id) }

        composable<R.Bills> { BillsScreen() }
        composable<R.BillDetail> { BillDetailScreen(it.toRoute<R.BillDetail>().id) }
        composable<R.BillEditor> { val r = it.toRoute<R.BillEditor>(); BillEditorScreen(r.id, r.type, r.personId) }

        composable<R.Dealers> { DealersScreen() }
        composable<R.DealerDetail> { DealerDetailScreen(it.toRoute<R.DealerDetail>().id) }
        composable<R.DealerBillDetail> { DealerBillDetailScreen(it.toRoute<R.DealerBillDetail>().id) }
        composable<R.DealerBillEditor> { val r = it.toRoute<R.DealerBillEditor>(); DealerBillEditorScreen(r.dealerId, r.shopId) }
        composable<R.Settlement> { SettlementScreen(it.toRoute<R.Settlement>().billId) }

        composable<R.Transactions> { TransactionsScreen() }
        composable<R.TransactionDetail> { TransactionDetailScreen(it.toRoute<R.TransactionDetail>().id) }
        composable<R.TransactionEntry> { val r = it.toRoute<R.TransactionEntry>(); TransactionEntryScreen(r.personId, r.direction) }
        composable<R.Transfer> { TransferScreen() }
        composable<R.Cheques> { ChequesScreen() }

        composable<R.Loans> { LoansScreen() }
        composable<R.LoanDetail> { LoanDetailScreen(it.toRoute<R.LoanDetail>().id) }
        composable<R.LoanForm> { val r = it.toRoute<R.LoanForm>(); LoanFormScreen(r.kind, r.personId) }

        composable<R.Mortgages> { MortgagesScreen() }
        composable<R.MortgageAccountDetail> { MortgageAccountScreen(it.toRoute<R.MortgageAccountDetail>().id) }
        composable<R.MortgageDetail> { MortgageDetailScreen(it.toRoute<R.MortgageDetail>().id) }
        composable<R.MortgageForm> { MortgageFormScreen(it.toRoute<R.MortgageForm>().accountId) }

        composable<R.Exchanges> { ExchangesScreen() }
        composable<R.ExchangeDetail> { ExchangeDetailScreen(it.toRoute<R.ExchangeDetail>().id) }
        composable<R.ExchangeEditor> { val r = it.toRoute<R.ExchangeEditor>(); ExchangeEditorScreen(r.id, r.personId) }

        composable<R.Dues> { DuesScreen() }
        composable<R.DueAccount> { DueAccountScreen(it.toRoute<R.DueAccount>().personId) }

        composable<R.Reminders> { RemindersScreen() }
        composable<R.ReminderEditor> { ReminderEditorScreen(it.toRoute<R.ReminderEditor>()) }

        composable<R.Reports> { ReportsScreen() }
        composable<R.Settings> { SettingsScreen() }
        composable<R.Sync> { SyncScreen() }
        composable<R.Audit> { AuditScreen() }
    }
}
