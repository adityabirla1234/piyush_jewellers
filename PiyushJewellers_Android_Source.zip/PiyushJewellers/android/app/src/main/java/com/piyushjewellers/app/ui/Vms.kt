package com.piyushjewellers.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.piyushjewellers.app.AppContainer
import com.piyushjewellers.app.PiyushApp
import com.piyushjewellers.app.data.Fetched
import com.piyushjewellers.app.data.Repository
import com.piyushjewellers.app.data.remote.AppException
import com.piyushjewellers.app.data.remote.Page
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface Load<out T> {
    data object Loading : Load<Nothing>
    data class Ready<T>(val data: T, val fromCache: Boolean = false, val savedAt: Long? = null) : Load<T>
    data class Failed(val error: AppException) : Load<Nothing>
}

fun <T> Load<T>.dataOrNull(): T? = (this as? Load.Ready<T>)?.data

fun Throwable.asApp(): AppException = this as? AppException
    ?: AppException(AppException.Kind.UNKNOWN, message ?: "Something went wrong")

@Composable
fun container(): AppContainer = (LocalContext.current.applicationContext as PiyushApp).container

/** Creates a ViewModel with access to the container. [key] separates instances for different records. */
@Composable
inline fun <reified VM : ViewModel> appViewModel(key: String? = null, crossinline create: (AppContainer) -> VM): VM {
    val c = container()
    return viewModel(key = key, factory = viewModelFactory { initializer { create(c) } })
}

/** Loads one resource; supports refresh and replacing the data after a successful action. */
class LoadVm<T>(private val loader: suspend () -> Fetched<T>) : ViewModel() {
    var state by mutableStateOf<Load<T>>(Load.Loading)
        private set
    var refreshing by mutableStateOf(false)
        private set
    private var job: Job? = null

    init {
        reload()
    }

    fun reload(silent: Boolean = false) {
        job?.cancel()
        if (!silent && state !is Load.Ready) state = Load.Loading
        refreshing = state is Load.Ready
        job = viewModelScope.launch {
            state = try {
                val f = loader()
                Load.Ready(f.data, f.fromCache, f.savedAt)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                val current = state
                if (current is Load.Ready && silent) current else Load.Failed(e.asApp())
            }
            refreshing = false
        }
    }

    fun replace(data: T) {
        state = Load.Ready(data)
    }
}

/** Paged list with a query object; query changes are debounced and reload from page 0. */
class PagedVm<Q, T>(initial: Q, private val loader: suspend (Q, Int) -> Fetched<Page<T>>) : ViewModel() {
    var query by mutableStateOf(initial)
        private set
    var state by mutableStateOf<Load<List<T>>>(Load.Loading)
        private set
    var total by mutableStateOf(0L)
        private set
    var hasMore by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var refreshing by mutableStateOf(false)
        private set
    private var page = 0
    private var job: Job? = null

    init {
        load(0, debounce = false)
    }

    fun update(q: Q, debounce: Boolean = true) {
        if (q == query) return
        query = q
        load(0, debounce)
    }

    fun refresh() {
        refreshing = state is Load.Ready
        load(0, debounce = false)
    }

    fun loadMore() {
        if (!hasMore || loadingMore) return
        loadingMore = true
        viewModelScope.launch {
            try {
                val f = loader(query, page + 1)
                val current = (state as? Load.Ready)?.data.orEmpty()
                page += 1
                hasMore = !f.data.last
                state = Load.Ready(current + f.data.content, f.fromCache, f.savedAt)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
            } finally {
                loadingMore = false
            }
        }
    }

    private fun load(p: Int, debounce: Boolean) {
        job?.cancel()
        if (state !is Load.Ready) state = Load.Loading
        job = viewModelScope.launch {
            if (debounce) delay(300)
            try {
                val f = loader(query, p)
                page = p
                hasMore = !f.data.last
                total = f.data.totalElements
                state = Load.Ready(f.data.content, f.fromCache, f.savedAt)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                state = Load.Failed(e.asApp())
            } finally {
                refreshing = false
            }
        }
    }
}

/** Runs user actions with a busy flag and a surfaced error; success callbacks run on the main thread. */
class ActionVm(val c: AppContainer) : ViewModel() {
    val repo: Repository get() = c.repo
    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<AppException?>(null)

    fun <T> run(block: suspend Repository.() -> T, onError: (AppException) -> Boolean = { false }, onSuccess: (T) -> Unit = {}) {
        if (busy) return
        busy = true
        error = null
        viewModelScope.launch {
            try {
                val v = repo.block()
                onSuccess(v)
            } catch (e: Exception) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                val app = e.asApp()
                if (!onError(app)) error = app
            } finally {
                busy = false
            }
        }
    }

    fun clearError() {
        error = null
    }
}

@Composable
fun actionVm(key: String? = null): ActionVm = appViewModel(key = "action:$key") { ActionVm(it) }

@Composable
fun <T> loadVm(key: String, loader: suspend Repository.() -> Fetched<T>): LoadVm<T> =
    appViewModel(key = key) { c -> LoadVm { c.repo.loader() } }

@Composable
fun <Q, T> pagedVm(key: String, initial: Q, loader: suspend Repository.(Q, Int) -> Fetched<Page<T>>): PagedVm<Q, T> =
    appViewModel(key = key) { c -> PagedVm(initial) { q, p -> c.repo.loader(q, p) } }
