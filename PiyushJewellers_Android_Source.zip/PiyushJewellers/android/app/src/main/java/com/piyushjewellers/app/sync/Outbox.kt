package com.piyushjewellers.app.sync

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.piyushjewellers.app.PiyushApp
import com.piyushjewellers.app.data.SessionStore
import com.piyushjewellers.app.data.local.AppDatabase
import com.piyushjewellers.app.data.local.IdMapping
import com.piyushjewellers.app.data.local.OutboxOp
import com.piyushjewellers.app.data.local.SyncState
import com.piyushjewellers.app.data.remote.AppException
import com.piyushjewellers.app.data.remote.AppJson
import com.piyushjewellers.app.data.remote.JSON_MEDIA
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.KSerializer
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** Result of a write that may have been queued for later sync. */
sealed interface Submit<out T> {
    data class Done<T>(val value: T) : Submit<T>
    data class Queued(val op: OutboxOp) : Submit<Nothing>
}

object EntityTypes {
    const val PERSON = "PERSON"
    const val TRANSACTION = "TRANSACTION"
    const val LOAN = "LOAN"
    const val REPAYMENT = "REPAYMENT"
    const val BILL_DRAFT = "BILL_DRAFT"
    const val EXCHANGE_DRAFT = "EXCHANGE_DRAFT"
    const val REMINDER = "REMINDER"
    const val PHOTO = "PHOTO"
}

class Outbox(
    private val context: Context,
    private val db: AppDatabase,
    private val client: () -> OkHttpClient,
    private val session: SessionStore,
) {
    private val mutex = Mutex()

    private data class Raw(val code: Int, val body: String?)

    private sealed interface Resolution {
        data class Ready(val path: String, val body: String?) : Resolution
        data object Waiting : Resolution
        data class Broken(val reason: String) : Resolution
    }

    fun newLocalId(): Long = -(Random.nextLong(1, Long.MAX_VALUE / 2))

    /**
     * Sends a queueable write now. If the device is offline or the server is temporarily unavailable, the
     * operation is stored durably and replayed later with the same Idempotency-Key.
     * Validation and conflict errors are returned immediately so the user can correct them.
     */
    suspend fun <T> submit(
        entityType: String,
        summary: String,
        method: String,
        path: String,
        body: String?,
        serializer: KSerializer<T>?,
        createsRecord: Boolean = false,
    ): Submit<T?> {
        val op = OutboxOp(
            id = UUID.randomUUID().toString(),
            entityType = entityType,
            summary = summary,
            method = method,
            path = path,
            body = body,
            localId = if (createsRecord) newLocalId() else null,
        )
        when (val res = resolve(op)) {
            is Resolution.Broken -> throw AppException(AppException.Kind.VALIDATION, res.reason)
            Resolution.Waiting -> {
                db.outbox().insert(op)
                scheduleSync()
                return Submit.Queued(op)
            }
            is Resolution.Ready -> {
                val raw = try {
                    execute(op, res.path, res.body)
                } catch (e: IOException) {
                    db.outbox().insert(op)
                    scheduleSync()
                    return Submit.Queued(op)
                }
                if (raw.code in 200..299) {
                    return Submit.Done(if (serializer == null || raw.body.isNullOrBlank()) null else AppJson.decodeFromString(serializer, raw.body))
                }
                if (raw.code >= 500 || raw.code == 408 || raw.code == 429) {
                    db.outbox().insert(op.copy(attempts = 1, lastError = "Server unavailable (${raw.code})"))
                    scheduleSync()
                    return Submit.Queued(op)
                }
                throw AppException.fromHttp(raw.code, raw.body)
            }
        }
    }

    /** Photo uploads always go through the outbox so a captured photo is never lost. */
    suspend fun enqueuePhoto(productId: Long, file: File, summary: String): OutboxOp {
        val op = OutboxOp(
            id = UUID.randomUUID().toString(),
            entityType = EntityTypes.PHOTO,
            summary = summary,
            method = "MULTIPART",
            path = "api/v1/products/$productId/images",
            filePath = file.absolutePath,
        )
        db.outbox().insert(op)
        scheduleSync()
        return op
    }

    /** Queues a write that must reach the server eventually (for example reminder upserts). */
    suspend fun enqueue(entityType: String, summary: String, method: String, path: String, body: String?) {
        db.outbox().insert(
            OutboxOp(id = UUID.randomUUID().toString(), entityType = entityType, summary = summary, method = method, path = path, body = body),
        )
        scheduleSync()
    }

    suspend fun retry(id: String) {
        db.outbox().get(id)?.let { db.outbox().upsert(it.copy(state = SyncState.PENDING_SYNC, lastError = null, updatedAt = now())) }
        scheduleSync()
    }

    suspend fun pause(id: String) {
        db.outbox().get(id)?.takeIf { it.state == SyncState.PENDING_SYNC || it.state == SyncState.FAILED || it.state == SyncState.CONFLICT }
            ?.let { db.outbox().upsert(it.copy(state = SyncState.DRAFT, updatedAt = now())) }
    }

    suspend fun discard(id: String) {
        db.outbox().get(id)?.let { op ->
            op.filePath?.let { runCatching { File(it).delete() } }
            db.outbox().delete(op.id)
        }
    }

    suspend fun serverIdFor(localId: Long): Long? = db.idMappings().get(localId)?.serverId

    fun scheduleSync() {
        val request = OneTimeWorkRequestBuilder<SyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE_WORK, ExistingWorkPolicy.APPEND_OR_REPLACE, request)
    }

    fun schedulePeriodic() {
        val request = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(PERIODIC_WORK, ExistingPeriodicWorkPolicy.KEEP, request)
    }

    /** Replays pending operations in creation order. Returns true when a retry with backoff is needed. */
    suspend fun runSync(): Boolean = mutex.withLock {
        if (session.accessToken == null && session.refreshToken == null) return false
        db.outbox().resetStuck()
        db.outbox().purgeSynced(now() - TimeUnit.DAYS.toMillis(7))
        var needsRetry = false
        var progressed = true
        while (progressed) {
            progressed = false
            for (op in db.outbox().pending()) {
                when (val res = resolve(op)) {
                    Resolution.Waiting -> continue
                    is Resolution.Broken -> {
                        db.outbox().upsert(op.copy(state = SyncState.FAILED, lastError = res.reason, updatedAt = now()))
                    }
                    is Resolution.Ready -> {
                        db.outbox().upsert(op.copy(state = SyncState.SYNCING, updatedAt = now()))
                        val raw = try {
                            execute(op, res.path, res.body)
                        } catch (e: IOException) {
                            db.outbox().upsert(op.copy(state = SyncState.PENDING_SYNC, attempts = op.attempts + 1, lastError = "No connection", updatedAt = now()))
                            return@withLock true
                        }
                        when {
                            raw.code in 200..299 -> {
                                val serverId = raw.body?.let { b -> runCatching { AppJson.parseToJsonElement(b).jsonObject["id"]?.jsonPrimitive?.longOrNull }.getOrNull() }
                                if (op.localId != null && serverId != null) {
                                    db.idMappings().put(IdMapping(op.localId, serverId, op.entityType))
                                }
                                op.filePath?.let { runCatching { File(it).delete() } }
                                db.outbox().upsert(op.copy(state = SyncState.SYNCED, serverId = serverId, lastError = null, updatedAt = now()))
                                progressed = true
                            }
                            raw.code == 401 -> {
                                db.outbox().upsert(op.copy(state = SyncState.PENDING_SYNC, lastError = "Sign in again to continue syncing", updatedAt = now()))
                                return@withLock false
                            }
                            raw.code >= 500 || raw.code == 408 || raw.code == 429 -> {
                                db.outbox().upsert(op.copy(state = SyncState.PENDING_SYNC, attempts = op.attempts + 1, lastError = "Server unavailable (${raw.code})", updatedAt = now()))
                                needsRetry = true
                            }
                            else -> {
                                val err = AppException.fromHttp(raw.code, raw.body)
                                val state = if (raw.code == 409) SyncState.CONFLICT else SyncState.FAILED
                                db.outbox().upsert(op.copy(state = state, attempts = op.attempts + 1, lastError = err.message, updatedAt = now()))
                            }
                        }
                    }
                }
            }
        }
        if (!needsRetry) session.lastSyncAt = now()
        needsRetry
    }

    private suspend fun resolve(op: OutboxOp): Resolution {
        val segments = op.path.split('/')
        val mappedSegments = ArrayList<String>(segments.size)
        for (s in segments) {
            val n = s.toLongOrNull()
            if (n != null && n < 0) {
                when (val r = mapId(n)) {
                    is IdResult.Mapped -> mappedSegments.add(r.id.toString())
                    IdResult.Waiting -> return Resolution.Waiting
                    is IdResult.Broken -> return Resolution.Broken(r.reason)
                }
            } else mappedSegments.add(s)
        }
        val path = mappedSegments.joinToString("/")
        val body = op.body ?: return Resolution.Ready(path, null)
        val element = AppJson.parseToJsonElement(body)
        var waiting = false
        var broken: String? = null
        suspend fun walk(e: JsonElement, key: String?): JsonElement = when (e) {
            is JsonObject -> JsonObject(e.mapValues { (k, v) -> walk(v, k) })
            is JsonArray -> JsonArray(e.map { walk(it, key) })
            is JsonPrimitive -> {
                val n = if (!e.isString) e.longOrNull else null
                if (key != null && key.endsWith("Id") && n != null && n < 0) {
                    when (val r = mapId(n)) {
                        is IdResult.Mapped -> JsonPrimitive(r.id)
                        IdResult.Waiting -> { waiting = true; e }
                        is IdResult.Broken -> { broken = r.reason; e }
                    }
                } else e
            }
            else -> e
        }
        val resolved = walk(element, null)
        broken?.let { return Resolution.Broken(it) }
        if (waiting) return Resolution.Waiting
        return Resolution.Ready(path, resolved.toString())
    }

    private sealed interface IdResult {
        data class Mapped(val id: Long) : IdResult
        data object Waiting : IdResult
        data class Broken(val reason: String) : IdResult
    }

    private suspend fun mapId(localId: Long): IdResult {
        db.idMappings().get(localId)?.let { return IdResult.Mapped(it.serverId) }
        val creator = db.outbox().byLocalId(localId)
            ?: return IdResult.Broken("Linked record created offline was discarded")
        return when (creator.state) {
            SyncState.CONFLICT, SyncState.FAILED -> IdResult.Broken("Waiting on \"${creator.summary}\", which failed to sync")
            else -> IdResult.Waiting
        }
    }

    private suspend fun execute(op: OutboxOp, path: String, body: String?): Raw = withContext(Dispatchers.IO) {
        val base = session.baseUrl.trimEnd('/')
        if (base.isEmpty()) throw IOException("No server configured")
        val url = "$base/${path.trimStart('/')}"
        val builder = Request.Builder().url(url).header("Idempotency-Key", op.id)
        val request = when (op.method) {
            "MULTIPART" -> {
                val file = File(op.filePath ?: throw IOException("Missing photo"))
                if (!file.exists()) return@withContext Raw(410, """{"message":"The photo file is no longer on this device"}""")
                val part = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("file", file.name, file.asRequestBody("image/jpeg".toMediaType()))
                    .build()
                builder.post(part).build()
            }
            "DELETE" -> builder.delete().build()
            "PUT" -> builder.put((body ?: "{}").toRequestBody(JSON_MEDIA)).build()
            else -> builder.post((body ?: "{}").toRequestBody(JSON_MEDIA)).build()
        }
        client().newCall(request).execute().use { r -> Raw(r.code, r.body?.string()) }
    }

    private fun now() = System.currentTimeMillis()

    companion object {
        const val UNIQUE_WORK = "pj-sync"
        const val PERIODIC_WORK = "pj-sync-periodic"
    }
}

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val container = (applicationContext as PiyushApp).container
        return try {
            if (container.outbox.runSync()) Result.retry() else Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 10) Result.retry() else Result.failure()
        }
    }
}
