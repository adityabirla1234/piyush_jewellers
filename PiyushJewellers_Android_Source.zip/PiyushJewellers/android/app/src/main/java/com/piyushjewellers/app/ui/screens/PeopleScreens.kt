package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.data.remote.PersonDto
import com.piyushjewellers.app.data.remote.PersonDueAccount
import com.piyushjewellers.app.data.remote.PersonRequest
import com.piyushjewellers.app.data.remote.TimelineEntry
import com.piyushjewellers.app.sync.EntityTypes
import com.piyushjewellers.app.sync.Submit
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors

data class PeopleQuery(val q: String = "", val type: String? = null)

@Composable
fun PeopleScreen() {
    val nav = LocalNav.current
    val c = container()
    val vm = pagedVm<PeopleQuery, PersonDto>("people", PeopleQuery()) { q, p -> people(q.q, q.type, p) }
    val pending by c.repo.observeUnsynced(EntityTypes.PERSON).collectAsState(initial = emptyList())
    PJScaffold(
        title = "Customers & Suppliers",
        topLevel = true,
        fab = { ExtendedFloatingActionButton(onClick = { nav.navigate(R.PersonForm()) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add person") }) },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = vm.query.q, onValueChange = { vm.update(vm.query.copy(q = it)) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search name, phone or ID") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
            )
            ChoiceChips(
                listOf(null, "CUSTOMER", "SUPPLIER", "DEALER"), vm.query.type,
                { when (it) { null -> "All"; "CUSTOMER" -> "Customers"; "SUPPLIER" -> "Suppliers"; else -> "Dealers" } },
                { vm.update(vm.query.copy(type = it), debounce = false) },
                Modifier.padding(horizontal = 16.dp),
            )
            LoadContent(vm.state, onRetry = vm::refresh, refreshing = vm.refreshing, onRefresh = vm::refresh) { list ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                    pendingOpsSection(pending) { nav.navigate(R.Sync) }
                    items(list, key = { it.id }) { p ->
                        ListRow(
                            title = p.name,
                            subtitle = listOfNotNull(p.phone, roles(p), p.address?.take(40)).joinToString(" · "),
                            onClick = { nav.navigate(R.PersonDetail(p.id)) },
                        )
                    }
                    if (list.isEmpty() && pending.isEmpty()) {
                        item { EmptyState("No people found", if (vm.query.q.isBlank()) "Add customers and suppliers to start billing." else "Try a different name or phone.", Icons.Filled.People) }
                    }
                    loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                }
            }
        }
    }
}

@Composable
fun PersonFormScreen(id: Long?) {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("person-form:$id")
    val existing = if (id != null) loadVm("person-edit:$id") { person(id) } else null
    val loaded = existing?.state?.dataOrNull()

    var name by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var altPhone by rememberSaveable { mutableStateOf("") }
    var address by rememberSaveable { mutableStateOf("") }
    var idRef by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var customer by rememberSaveable { mutableStateOf(true) }
    var supplier by rememberSaveable { mutableStateOf(false) }
    var initialised by rememberSaveable { mutableStateOf(id == null) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var duplicate by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(loaded) {
        if (!initialised && loaded != null) {
            name = loaded.name; phone = loaded.phone.orEmpty(); altPhone = loaded.alternatePhone.orEmpty()
            address = loaded.address.orEmpty(); idRef = loaded.idReference.orEmpty(); notes = loaded.notes.orEmpty()
            customer = loaded.customer; supplier = loaded.supplier
            initialised = true
        }
    }

    fun save(allowDuplicate: Boolean) {
        if (name.isBlank()) { nameError = "Enter a name"; return }
        if (!customer && !supplier && loaded?.dealer != true) { nameError = "Mark as customer, supplier or both"; return }
        val req = PersonRequest(
            name.trim(), phone.trim().ifBlank { null }, altPhone.trim().ifBlank { null }, address.trim().ifBlank { null },
            idRef.trim().ifBlank { null }, notes.trim().ifBlank { null }, customer, supplier, loaded?.version, allowDuplicate,
        )
        val dupHandler: (com.piyushjewellers.app.data.remote.AppException) -> Boolean = { e ->
            if (e.code == "DUPLICATE_CONTACT") { duplicate = e.message; true } else false
        }
        if (id == null) {
            actions.run({ createPerson(req) }, dupHandler) { res ->
                when (res) {
                    is Submit.Done -> { c.toast("Saved ${req.name}"); nav.popBackStack(); res.value?.let { nav.navigate(R.PersonDetail(it.id)) } }
                    is Submit.Queued -> { c.toast("Saved offline — ${req.name} will sync when online"); nav.popBackStack() }
                }
            }
        } else {
            actions.run({ updatePerson(id, req) }, dupHandler) { c.toast("Saved changes"); nav.popBackStack() }
        }
    }

    PJScaffold(title = if (id == null) "Add person" else "Edit person", busy = actions.busy) { pad ->
        if (id != null && existing != null && existing.state !is Load.Ready) {
            LoadContent(existing.state, onRetry = { existing.reload() }, modifier = Modifier.padding(pad)) {}
            return@PJScaffold
        }
        FormColumn(pad) {
            TextInput("Full name *", name, { name = it; nameError = null }, error = nameError)
            TextInput("Phone", phone, { phone = it }, keyboardType = KeyboardType.Phone, supporting = "Used to detect duplicates; people are never merged automatically")
            TextInput("Alternate phone", altPhone, { altPhone = it }, keyboardType = KeyboardType.Phone)
            TextInput("Address", address, { address = it }, singleLine = false, minLines = 2)
            TextInput("ID reference (Aadhaar/PAN last digits, etc.)", idRef, { idRef = it })
            TextInput("Notes", notes, { notes = it }, singleLine = false, minLines = 2)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(customer, { customer = it }); Text("Customer")
                Spacer(Modifier.padding(8.dp))
                Checkbox(supplier, { supplier = it }); Text("Supplier")
            }
            PrimaryButton(if (actions.busy) "Saving…" else "Save", { save(false) }, enabled = !actions.busy)
        }
    }
    duplicate?.let { msg ->
        ConfirmDialog(
            "Possible duplicate", "$msg\n\nCreate or keep a separate record with this phone anyway?", "Save anyway",
            onConfirm = { duplicate = null; save(true) }, onDismiss = { duplicate = null },
        )
    }
    ActionErrorDialog(actions)
}

@Composable
fun PersonDetailScreen(id: Long) {
    val nav = LocalNav.current
    if (id < 0) {
        PJScaffold(title = "Pending person") { pad ->
            Column(Modifier.padding(pad)) {
                EmptyState("Waiting to sync", "This person was added offline. Full details appear after it syncs with the server.", action = {
                    PrimaryButton("Open sync status", { nav.navigate(R.Sync) })
                })
            }
        }
        return
    }
    val person = loadVm("person:$id") { person(id) }
    val account = loadVm("dueacct:$id") { dueAccount(id) }
    val p = person.state.dataOrNull()
    PJScaffold(
        title = p?.name ?: "Person",
        subtitle = p?.phone,
        actions = { if (p != null) IconButton(onClick = { nav.navigate(R.PersonForm(id)) }) { Icon(Icons.Filled.Edit, "Edit") } },
    ) { pad ->
        LoadContent(person.state, onRetry = { person.reload(); account.reload() }, modifier = Modifier.padding(pad), refreshing = person.refreshing,
            onRefresh = { person.reload(); account.reload() }) { pd ->
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    SectionCard("Details") {
                        InfoRow("Phone", pd.phone)
                        if (pd.alternatePhone != null) InfoRow("Alternate phone", pd.alternatePhone)
                        InfoRow("Address", pd.address)
                        InfoRow("ID reference", pd.idReference)
                        InfoRow("Roles", roles(pd))
                        if (!pd.notes.isNullOrBlank()) InfoRow("Notes", pd.notes)
                    }
                }
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { nav.navigate(R.BillEditor(type = "SALES", personId = id)) }, label = { Text("Sales bill") })
                        AssistChip(onClick = { nav.navigate(R.BillEditor(type = "PURCHASE", personId = id)) }, label = { Text("Purchase bill") })
                        AssistChip(onClick = { nav.navigate(R.TransactionEntry(personId = id, direction = "IN")) }, label = { Text("Money in") })
                        AssistChip(onClick = { nav.navigate(R.TransactionEntry(personId = id, direction = "OUT")) }, label = { Text("Money out") })
                        AssistChip(onClick = { nav.navigate(R.LoanForm("LENT", id)) }, label = { Text("Lend") })
                        AssistChip(onClick = { nav.navigate(R.LoanForm("BORROWED", id)) }, label = { Text("Borrow") })
                        AssistChip(onClick = { nav.navigate(R.ExchangeEditor(personId = id)) }, label = { Text("Exchange") })
                        AssistChip(onClick = { nav.navigate(R.ReminderEditor(title = "Follow up: ${pd.name}", sourceType = "PERSON", sourceId = id, personId = id)) }, label = { Text("Reminder") })
                    }
                }
                when (val a = account.state) {
                    is Load.Ready -> personAccountItems(a.data, onOpen = { src, sid -> openSource(nav, src, sid) })
                    is Load.Failed -> item { Text("Dues unavailable: ${a.error.message}", color = MaterialTheme.colorScheme.error) }
                    Load.Loading -> item { LoadingState(Modifier.height(80.dp)) }
                }
            }
        }
    }
}

/** Shared by person detail and the due account screen. */
fun androidx.compose.foundation.lazy.LazyListScope.personAccountItems(a: PersonDueAccount, onOpen: (String?, Long?) -> Unit) {
    item {
        SectionCard("Account summary") {
            InfoRow("Receivable", Fmt.rupees(a.receivable), valueColor = PJColors.Success)
            InfoRow("Payable", Fmt.rupees(a.payable), valueColor = PJColors.Danger)
            InfoRow("Net", Fmt.rupees(a.net), emphasize = true)
            if (a.mortgageSerial != null) InfoRow("Mortgage account", a.mortgageSerial)
        }
    }
    if (a.items.isNotEmpty()) {
        item { SectionHeader("Open items") }
        items(a.items, key = { "due-${it.source}-${it.sourceId}" }) { d ->
            ListRow(
                title = d.title ?: Fmt.humanize(d.source),
                subtitle = listOfNotNull(d.reference, Fmt.humanize(d.source), d.expectedDate?.let { "Expected ${Fmt.date(it)}" }, d.state?.let(Fmt::humanize)).joinToString(" · "),
                trailingTop = d.outstandingAmount?.let(Fmt::rupees) ?: d.outstandingWeight?.let(Fmt::grams),
                trailingColor = if (d.direction == "RECEIVABLE") PJColors.Success else PJColors.Danger,
                trailingBottom = { Text(if (d.direction == "RECEIVABLE") "To receive" else "To pay", style = MaterialTheme.typography.labelSmall) },
                onClick = { onOpen(d.source, d.sourceId) },
            )
        }
    }
    item { SectionHeader("Timeline") }
    if (a.timeline.isEmpty()) item { Text("No activity yet", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
    items(a.timeline.size, key = { "tl-$it" }) { i -> TimelineRow(a.timeline[i], onOpen) }
}

@Composable
fun TimelineRow(t: TimelineEntry, onOpen: (String?, Long?) -> Unit) {
    ListRow(
        title = t.title ?: Fmt.humanize(t.kind),
        subtitle = listOfNotNull(Fmt.date(t.date), t.reference, t.status?.let(Fmt::humanize)).joinToString(" · "),
        trailingTop = t.amount?.let { Fmt.rupees(it) },
        trailingColor = when (t.direction) { "IN", "RECEIVABLE" -> PJColors.Success; "OUT", "PAYABLE" -> PJColors.Danger; else -> Color.Unspecified },
        onClick = if (t.sourceId != null) ({ onOpen(if (t.kind == "TRANSACTION") "TRANSACTION" else t.sourceType, t.sourceId) }) else null,
    )
}

/** Opens the screen that owns a record referenced from dues or timelines. */
fun openSource(nav: androidx.navigation.NavHostController, source: String?, id: Long?) {
    if (id == null) return
    when (source) {
        "CUSTOMER_BILL" -> nav.navigate(R.BillDetail(id))
        "DEALER_BILL", "DEALER_SETTLEMENT" -> nav.navigate(R.DealerBillDetail(id))
        "LOAN", "LOAN_REPAYMENT" -> nav.navigate(R.LoanDetail(id))
        "JEWELLERY_MORTGAGE", "CASH_MORTGAGE", "MORTGAGE", "MORTGAGE_ISSUE", "MORTGAGE_PAYMENT" -> nav.navigate(R.MortgageDetail(id))
        "EXCHANGE" -> nav.navigate(R.ExchangeDetail(id))
        "MANUAL", "TRANSFER", "TRANSACTION", "CHEQUE_BOUNCE", "REVERSAL" -> nav.navigate(R.TransactionDetail(id))
    }
}
