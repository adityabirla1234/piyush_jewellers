package com.piyushjewellers.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.piyushjewellers.app.core.Fmt
import com.piyushjewellers.app.core.Num
import com.piyushjewellers.app.data.remote.ChequeDto
import com.piyushjewellers.app.data.remote.PersonDto
import com.piyushjewellers.app.data.remote.TransactionDto
import com.piyushjewellers.app.data.remote.TransactionRequest
import com.piyushjewellers.app.data.remote.TransferRequest
import com.piyushjewellers.app.sync.EntityTypes
import com.piyushjewellers.app.sync.Submit
import com.piyushjewellers.app.ui.Load
import com.piyushjewellers.app.ui.actionVm
import com.piyushjewellers.app.ui.components.*
import com.piyushjewellers.app.ui.container
import com.piyushjewellers.app.ui.dataOrNull
import com.piyushjewellers.app.ui.loadVm
import com.piyushjewellers.app.ui.nav.R
import com.piyushjewellers.app.ui.pagedVm
import com.piyushjewellers.app.ui.theme.PJColors
import java.time.LocalDate

data class TxQuery(
    val q: String = "",
    val from: LocalDate? = null,
    val to: LocalDate? = null,
    val direction: String? = null,
    val method: String? = null,
)

@Composable
fun TransactionRow(t: TransactionDto, onClick: () -> Unit) {
    val incoming = t.direction == "IN"
    ListRow(
        title = t.description?.takeIf { it.isNotBlank() } ?: t.category ?: Fmt.humanize(t.sourceType),
        subtitle = listOfNotNull(
            Fmt.dateTime(t.businessDate),
            Fmt.method(t.method),
            t.personName,
            t.cheque?.let { "Cheque ${Fmt.humanize(it.status)}" },
        ).joinToString(" · "),
        trailingTop = (if (incoming) "+" else "−") + Fmt.rupees(t.amount),
        trailingColor = if (t.status == "REVERSED") PJColors.Info else if (incoming) PJColors.Success else PJColors.Danger,
        trailingBottom = if (t.status != "ACTIVE") ({ StatusChip(t.status) }) else null,
        onClick = onClick,
    )
}

@Composable
fun TransactionsScreen() {
    val nav = LocalNav.current
    val c = container()
    val vm = pagedVm<TxQuery, TransactionDto>("transactions", TxQuery()) { q, p ->
        transactions(q.from?.toString(), q.to?.toString(), q.direction, q.method, null, null, q.q, p)
    }
    val summary = loadVm("summary:${vm.query.from}:${vm.query.to}") { summary(vm.query.from?.toString(), vm.query.to?.toString()) }
    val pending by c.repo.observeUnsynced(EntityTypes.TRANSACTION).collectAsState(initial = emptyList())
    var filters by rememberSaveable { mutableStateOf(false) }
    PJScaffold(
        title = "Daily Transactions",
        topLevel = true,
        actions = { IconButton(onClick = { filters = !filters }) { Icon(Icons.Filled.FilterList, "Filters") } },
        fab = { ExtendedFloatingActionButton(onClick = { nav.navigate(R.TransactionEntry()) }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("New entry") }) },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = vm.query.q, onValueChange = { vm.update(vm.query.copy(q = it)) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                placeholder = { Text("Search description, person, reference") }, leadingIcon = { Icon(Icons.Filled.Search, null) }, singleLine = true,
            )
            if (filters) {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        DateInput("From", vm.query.from, { vm.update(vm.query.copy(from = it), false) }, Modifier.weight(1f), clearable = true)
                        DateInput("To", vm.query.to, { vm.update(vm.query.copy(to = it), false) }, Modifier.weight(1f), clearable = true)
                    }
                    ChoiceChips(listOf(null, "IN", "OUT"), vm.query.direction, { when (it) { "IN" -> "Money in"; "OUT" -> "Money out"; else -> "Both" } }, { vm.update(vm.query.copy(direction = it), false) })
                    ChoiceChips(listOf(null) + Options.methods, vm.query.method, { it?.let(Fmt::method) ?: "All methods" }, { vm.update(vm.query.copy(method = it), false) })
                }
            }
            LoadContent(vm.state, onRetry = { vm.refresh(); summary.reload() }, refreshing = vm.refreshing, onRefresh = { vm.refresh(); summary.reload() }) { list ->
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 88.dp)) {
                    item {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            when (val s = summary.state) {
                                is Load.Ready -> {
                                    val d = s.data
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        StatCard("Combined balance", Fmt.rupees(d.combinedBalance), Modifier.weight(1f), hint = "Includes pending cheques")
                                        StatCard("Available funds", Fmt.rupees(d.availableBalance), Modifier.weight(1f), hint = "Excludes pending cheques", accent = PJColors.Success)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        StatCard(if (vm.query.from != null || vm.query.to != null) "In (period)" else "Total in", Fmt.rupees(d.moneyIn), Modifier.weight(1f), accent = PJColors.Success)
                                        StatCard(if (vm.query.from != null || vm.query.to != null) "Out (period)" else "Total out", Fmt.rupees(d.moneyOut), Modifier.weight(1f), accent = PJColors.Danger)
                                    }
                                    if (d.pendingChequesIn.signum() != 0 || d.pendingChequesOut.signum() != 0) {
                                        Text("Pending cheques: in ${Fmt.rupees(d.pendingChequesIn)} · out ${Fmt.rupees(d.pendingChequesOut)}", style = MaterialTheme.typography.bodySmall, color = PJColors.Warning)
                                    }
                                    if (d.byMethod.isNotEmpty()) {
                                        SectionCard("By method") {
                                            d.byMethod.forEach { m -> InfoRow(Fmt.method(m.method), "${Fmt.rupees(m.moneyIn)} in · ${Fmt.rupees(m.moneyOut)} out · net ${Fmt.rupees(m.net)}") }
                                        }
                                    }
                                }
                                is Load.Failed -> Text("Summary unavailable: ${s.error.message}", color = MaterialTheme.colorScheme.error)
                                Load.Loading -> Unit
                            }
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AssistChip(onClick = { nav.navigate(R.TransactionEntry(direction = "IN")) }, label = { Text("Money in") })
                                AssistChip(onClick = { nav.navigate(R.TransactionEntry(direction = "OUT")) }, label = { Text("Money out") })
                                AssistChip(onClick = { nav.navigate(R.Transfer) }, label = { Text("Transfer") })
                                AssistChip(onClick = { nav.navigate(R.Cheques) }, label = { Text("Cheques") })
                            }
                        }
                    }
                    pendingOpsSection(pending) { nav.navigate(R.Sync) }
                    items(list, key = { it.id }) { t -> TransactionRow(t) { nav.navigate(R.TransactionDetail(t.id)) } }
                    if (list.isEmpty()) item { EmptyState("No transactions", "Money in and out appears here, including bill payments and settlements.") }
                    loadMoreItem(vm.hasMore, vm.loadingMore, vm::loadMore)
                }
            }
        }
    }
}

@Composable
fun TransactionDetailScreen(id: Long) {
    val nav = LocalNav.current
    val c = container()
    val vm = loadVm("tx:$id") { transaction(id) }
    val actions = actionVm("tx:$id")
    var reverse by rememberSaveable { mutableStateOf(false) }
    PJScaffold(title = "Transaction", busy = actions.busy) { pad ->
        LoadContent(vm.state, onRetry = { vm.reload() }, modifier = Modifier.padding(pad), refreshing = vm.refreshing, onRefresh = { vm.reload() }) { t ->
            FormColumn(PaddingValues(0.dp)) {
                SectionCard(if (t.direction == "IN") "Money in" else "Money out", trailing = { StatusChip(t.status) }) {
                    Text(Fmt.rupees(t.amount), style = MaterialTheme.typography.headlineSmall, color = if (t.direction == "IN") PJColors.Success else PJColors.Danger, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.padding(4.dp))
                    InfoRow("Date", Fmt.dateTime(t.businessDate))
                    InfoRow("Method", Fmt.method(t.method))
                    InfoRow("Category", t.category)
                    InfoRow("Description", t.description)
                    InfoRow("Person", t.personName)
                    InfoRow("Reference", t.reference)
                    if (t.approxReturnDate != null) InfoRow("Approx. return", Fmt.date(t.approxReturnDate))
                    if (!t.notes.isNullOrBlank()) InfoRow("Notes", t.notes)
                    InfoRow("Source", Fmt.humanize(t.sourceType))
                    InfoRow("Entered", "${Fmt.dateTime(t.createdAt)}${t.createdBy?.let { " by $it" } ?: ""}")
                    if (t.status == "REVERSED") InfoRow("Reversal reason", t.reversalReason, valueColor = PJColors.Danger)
                    if (t.reversalOfId != null) InfoRow("Reverses", "#${t.reversalOfId}")
                }
                t.cheque?.let { ch ->
                    SectionCard("Cheque", trailing = { StatusChip(ch.status) }) {
                        InfoRow("Number", ch.chequeNumber)
                        InfoRow("Bank", ch.bankName)
                        InfoRow("Cheque date", Fmt.date(ch.chequeDate))
                        if (ch.clearedDate != null) InfoRow("Cleared", Fmt.date(ch.clearedDate))
                        if (ch.bouncedDate != null) InfoRow("Bounced", "${Fmt.date(ch.bouncedDate)} · ${ch.bounceReason.orEmpty()}")
                        if (ch.status == "PENDING") TextButton(onClick = { nav.navigate(R.Cheques) }) { Text("Clear or mark bounced") }
                    }
                }
                if (t.sourceType != "MANUAL" && t.sourceId != null && t.sourceType != "TRANSFER") {
                    SecondaryButton("Open ${Fmt.humanize(t.sourceType)}", { openSource(nav, t.sourceType, t.sourceId) })
                }
                if (t.reversalOfId != null) SecondaryButton("Open original entry", { nav.navigate(R.TransactionDetail(t.reversalOfId)) })
                if (t.personId != null) SecondaryButton("Open ${t.personName ?: "person"}", { nav.navigate(R.PersonDetail(t.personId)) })
                if (t.status == "ACTIVE" && t.sourceType == "MANUAL" && t.reversalOfId == null) {
                    PrimaryButton("Reverse entry", { reverse = true })
                    Text("Entries are never deleted. Reversing posts an opposite entry and keeps both on record.", style = MaterialTheme.typography.bodySmall)
                } else if (t.status == "ACTIVE" && t.sourceType != "MANUAL") {
                    Text("This entry belongs to another record. Reverse it from that record so both stay consistent.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
    if (reverse) ReasonDialog("Reverse this entry?", "An opposite entry is posted and balances are restored.",
        onConfirm = { r -> actions.run({ reverseTransaction(id, r) }) { reverse = false; vm.reload(); c.toast("Entry reversed") } },
        onDismiss = { reverse = false })
    ActionErrorDialog(actions)
}

@Composable
fun TransactionEntryScreen(personId: Long?, direction: String) {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("tx-entry")
    val preset = personId?.let { pid -> loadVm("person:$pid") { person(pid) } }
    var dir by rememberSaveable { mutableStateOf(direction) }
    var amount by rememberSaveable { mutableStateOf("") }
    var method by rememberSaveable { mutableStateOf("CASH") }
    var date by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var category by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var reference by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var approxReturn by rememberSaveable { mutableStateOf<String?>(null) }
    var chequeNo by rememberSaveable { mutableStateOf("") }
    var chequeBank by rememberSaveable { mutableStateOf("") }
    var chequeDate by rememberSaveable { mutableStateOf<String?>(null) }
    var person by remember { mutableStateOf<PersonDto?>(null) }
    var errors by remember { mutableStateOf(mapOf<String, String>()) }
    val presetPerson = preset?.state?.dataOrNull()
    LaunchedEffect(presetPerson) { if (person == null && presetPerson != null) person = presetPerson }

    PJScaffold(title = if (dir == "IN") "Money in" else "Money out", busy = actions.busy) { pad ->
        FormColumn(pad) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(dir == "IN", { dir = "IN" }, SegmentedButtonDefaults.itemShape(0, 2)) { Text("Money in") }
                SegmentedButton(dir == "OUT", { dir = "OUT" }, SegmentedButtonDefaults.itemShape(1, 2)) { Text("Money out") }
            }
            DecimalInput("Amount *", amount, { amount = it; errors = errors - "amount" }, prefix = "₹", error = errors["amount"])
            MethodField(method, { method = it })
            DateInput("Date", Fmt.parseDate(date), { it?.let { d -> date = d.toString() } })
            PersonPickerField("Person (optional)", person, { person = it })
            TextInput("Category", category, { category = it }, supporting = "For example: Rent, Salary, Electricity")
            TextInput("Description", description, { description = it })
            if (method == "CHEQUE") {
                SectionCard("Cheque details") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextInput("Cheque number *", chequeNo, { chequeNo = it; errors = errors - "cheque" }, error = errors["cheque"])
                        TextInput("Bank", chequeBank, { chequeBank = it })
                        DateInput("Cheque date", Fmt.parseDate(chequeDate), { chequeDate = it?.toString() }, clearable = true)
                        Text("Pending cheques count in the combined balance but not in available funds until cleared.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                TextInput("Reference", reference, { reference = it })
            }
            DateInput("Approx. return date (optional)", Fmt.parseDate(approxReturn), { approxReturn = it?.toString() }, clearable = true,
                supporting = "Used for money that is expected back; adds a due-date hint")
            TextInput("Notes", notes, { notes = it }, singleLine = false)
            PrimaryButton(if (actions.busy) "Saving…" else "Save entry", {
                val amt = Num.parse(amount)
                val e = mutableMapOf<String, String>()
                if (amt == null || amt.signum() <= 0) e["amount"] = "Enter an amount greater than zero"
                if (method == "CHEQUE" && chequeNo.isBlank()) e["cheque"] = "Enter the cheque number"
                errors = e
                if (e.isNotEmpty() || amt == null) return@PrimaryButton
                val req = TransactionRequest(
                    businessDate = LocalDate.parse(date).atTime(Fmt.now().toLocalTime()).toString(),
                    direction = dir, amount = Num.money(amt), category = category.ifBlank { null }, description = description.ifBlank { null },
                    method = method, personId = person?.id, reference = reference.ifBlank { null }.takeIf { method != "CHEQUE" },
                    notes = notes.ifBlank { null }, approxReturnDate = approxReturn,
                    chequeNumber = chequeNo.ifBlank { null }.takeIf { method == "CHEQUE" }, chequeBank = chequeBank.ifBlank { null }.takeIf { method == "CHEQUE" },
                    chequeDate = chequeDate.takeIf { method == "CHEQUE" },
                )
                actions.run({ createTransaction(req) }) { res ->
                    when (res) {
                        is Submit.Done -> { c.toast("Entry saved"); nav.popBackStack() }
                        is Submit.Queued -> { c.toast("Saved offline — will sync when online"); nav.popBackStack() }
                    }
                }
            }, enabled = !actions.busy)
        }
    }
    ActionErrorDialog(actions)
}

@Composable
fun TransferScreen() {
    val nav = LocalNav.current
    val c = container()
    val actions = actionVm("transfer")
    var from by rememberSaveable { mutableStateOf("CASH") }
    var to by rememberSaveable { mutableStateOf("BANK") }
    var amount by rememberSaveable { mutableStateOf("") }
    var date by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var notes by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    PJScaffold(title = "Transfer between methods", busy = actions.busy) { pad ->
        FormColumn(pad) {
            Text("Moves money between cash, bank and UPI. The combined balance stays the same.", style = MaterialTheme.typography.bodyMedium)
            MethodField(from, { from = it }, allowCheque = false, label = "From")
            MethodField(to, { to = it }, allowCheque = false, label = "To")
            DecimalInput("Amount *", amount, { amount = it }, prefix = "₹")
            DateInput("Date", Fmt.parseDate(date), { it?.let { d -> date = d.toString() } })
            TextInput("Notes", notes, { notes = it })
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            PrimaryButton(if (actions.busy) "Saving…" else "Save transfer", {
                val amt = Num.parse(amount)
                error = when {
                    from == to -> "Choose two different methods"
                    amt == null || amt.signum() <= 0 -> "Enter an amount greater than zero"
                    else -> null
                }
                if (error != null || amt == null) return@PrimaryButton
                actions.run({ transfer(TransferRequest(from, to, Num.money(amt), LocalDate.parse(date).atTime(Fmt.now().toLocalTime()).toString(), notes.ifBlank { null })) }) {
                    c.toast("Transfer saved"); nav.popBackStack()
                }
            }, enabled = !actions.busy)
        }
    }
    ActionErrorDialog(actions)
}

@Composable
fun ChequesScreen() {
    val c = container()
    var status by rememberSaveable { mutableStateOf<String?>("PENDING") }
    val vm = loadVm("cheques:$status") { cheques(status) }
    val actions = actionVm("cheques")
    var clearing by remember { mutableStateOf<ChequeDto?>(null) }
    var bouncing by remember { mutableStateOf<ChequeDto?>(null) }
    PJScaffold(title = "Cheques", busy = actions.busy) { pad ->
        Column(Modifier.padding(pad)) {
            ChoiceChips(listOf("PENDING", "CLEARED", "BOUNCED", null), status, { it?.let(Fmt::humanize) ?: "All" }, { status = it }, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            LoadContent(vm.state, onRetry = { vm.reload() }, refreshing = vm.refreshing, onRefresh = { vm.reload() }) { list ->
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.id }) { ch ->
                        Column {
                            ListRow(
                                title = "${if (ch.direction == "IN") "Received" else "Issued"} · ${ch.chequeNumber.orEmpty()} · ${ch.bankName.orEmpty()}",
                                subtitle = listOfNotNull(ch.personName, ch.chequeDate?.let { "Dated ${Fmt.date(it)}" }, ch.bounceReason).joinToString(" · "),
                                trailingTop = Fmt.rupees(ch.amount),
                                trailingColor = if (ch.direction == "IN") PJColors.Success else PJColors.Danger,
                                trailingBottom = { StatusChip(ch.status) },
                            )
                            if (ch.status == "PENDING") {
                                Row(Modifier.padding(horizontal = 8.dp)) {
                                    TextButton(onClick = { clearing = ch }) { Text("Mark cleared") }
                                    TextButton(onClick = { bouncing = ch }) { Text("Mark bounced", color = PJColors.Danger) }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                    if (list.isEmpty()) item { EmptyState("No cheques", "Cheque payments recorded anywhere in the app appear here.") }
                }
            }
        }
    }
    clearing?.let { ch ->
        ChequeActionDialog("Mark cheque cleared", "The amount becomes part of available funds.", false, onDismiss = { clearing = null }) { d, _ ->
            actions.run({ clearCheque(ch.id, d) }) { clearing = null; vm.reload(); c.toast("Cheque cleared") }
        }
    }
    bouncing?.let { ch ->
        ChequeActionDialog("Mark cheque bounced", "A reversing entry is posted and the amount is restored as due.", true, onDismiss = { bouncing = null }) { d, r ->
            actions.run({ bounceCheque(ch.id, d, r) }) { bouncing = null; vm.reload(); c.toast("Cheque marked bounced") }
        }
    }
    ActionErrorDialog(actions)
}

@Composable
private fun ChequeActionDialog(title: String, text: String, needsReason: Boolean, onDismiss: () -> Unit, onConfirm: (String, String?) -> Unit) {
    var date by rememberSaveable { mutableStateOf(Fmt.today().toString()) }
    var reason by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(text)
                DateInput("Date", Fmt.parseDate(date), { it?.let { d -> date = d.toString() } })
                if (needsReason) TextInput("Reason", reason, { reason = it; error = null }, error = error)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (needsReason && reason.isBlank()) { error = "Enter a reason"; return@Button }
                onConfirm(date, reason.ifBlank { null })
            }) { Text("Confirm") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
