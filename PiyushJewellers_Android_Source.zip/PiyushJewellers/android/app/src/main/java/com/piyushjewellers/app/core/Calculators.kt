package com.piyushjewellers.app.core

import java.math.BigDecimal
import java.math.RoundingMode

/** Gold purity table shared with the backend: 18K 78%, 20K 84%, 22K 92%, 23K 97%, 24K 99%. */
enum class Carat(val percent: Int, val label: String) {
    K18(78, "18K"), K20(84, "20K"), K22(92, "22K"), K23(97, "23K"), K24(99, "24K");

    companion object {
        fun of(name: String?): Carat? = entries.firstOrNull { it.name == name }
    }
}

/**
 * Live previews of the dealer formulas. The server recalculates and is authoritative; these exist so the
 * owner sees the same numbers while typing.
 *  Gold:   final = net × (carat% + labour%) / 100
 *  Silver: final = net × (100 + labour%) / 100
 *  Amount = final weight × rate
 */
object MetalCalc {
    private val CALC_SCALE = 10

    fun net(gross: BigDecimal?, less: BigDecimal?): BigDecimal =
        Num.weight(Num.nz(gross).subtract(Num.nz(less)).max(BigDecimal.ZERO))

    fun goldFinal(net: BigDecimal, carat: Carat, labourPercent: BigDecimal): BigDecimal {
        val factor = BigDecimal(carat.percent).add(labourPercent)
        return Num.weight(net.multiply(factor).divide(Num.HUNDRED, CALC_SCALE, RoundingMode.HALF_UP))
    }

    fun silverFinal(net: BigDecimal, labourPercent: BigDecimal): BigDecimal {
        val factor = Num.HUNDRED.add(labourPercent)
        return Num.weight(net.multiply(factor).divide(Num.HUNDRED, CALC_SCALE, RoundingMode.HALF_UP))
    }

    fun finalWeight(metal: String, net: BigDecimal, carat: Carat?, labourPercent: BigDecimal): BigDecimal? = when (metal) {
        "GOLD" -> carat?.let { goldFinal(net, it, labourPercent) }
        "SILVER" -> silverFinal(net, labourPercent)
        else -> null
    }

    fun amount(finalWeight: BigDecimal, rate: BigDecimal?): BigDecimal? =
        rate?.let { Num.money(finalWeight.multiply(it)) }

    /** Value of a bar allocation and its weight equivalent at the bill rate. */
    fun barValue(weight: BigDecimal, rate: BigDecimal): BigDecimal = Num.money(weight.multiply(rate))

    fun weightEquivalent(value: BigDecimal, billRate: BigDecimal?): BigDecimal? {
        if (billRate == null || billRate.signum() <= 0) return null
        return Num.weight(value.divide(billRate, CALC_SCALE, RoundingMode.HALF_UP))
    }
}

/** Customer bill line preview: line total = net × rate + making charges. Blank making charges stay blank. */
object BillCalc {
    data class Line(val net: BigDecimal, val rate: BigDecimal?, val making: BigDecimal?)

    fun metalValue(net: BigDecimal, rate: BigDecimal?): BigDecimal = Num.money(net.multiply(Num.nz(rate)))

    fun lineTotal(l: Line): BigDecimal = Num.money(metalValue(l.net, l.rate).add(Num.nz(l.making)))

    fun subtotal(lines: List<Line>): BigDecimal = lines.fold(BigDecimal.ZERO) { a, l -> a.add(metalValue(l.net, l.rate)) }.let(Num::money)

    fun makingTotal(lines: List<Line>): BigDecimal = lines.fold(BigDecimal.ZERO) { a, l -> a.add(Num.nz(l.making)) }.let(Num::money)

    fun grandTotal(lines: List<Line>): BigDecimal = Num.money(subtotal(lines).add(makingTotal(lines)))

    fun hasBlankMaking(lines: List<Line>): Boolean = lines.any { it.making == null }
}

/** Exchange preview: value = net × rate per line; difference = issued − received. */
object ExchangeCalc {
    fun value(net: BigDecimal, rate: BigDecimal?): BigDecimal = Num.money(net.multiply(Num.nz(rate)))
}
