package com.piyushjewellers.app

import android.app.Application
import androidx.work.Configuration

class PiyushApp : Application(), Configuration.Provider {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.reminderScheduler.ensureChannel()
        container.outbox.schedulePeriodic()
        container.outbox.scheduleSync()
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder().setMinimumLoggingLevel(android.util.Log.WARN).build()
}
