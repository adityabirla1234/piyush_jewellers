package com.piyushjewellers.dealers;

import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class DealerController {

    private final DealerService service;

    public record ReasonRequest(String reason) {
    }

    @GetMapping("/dealers")
    public PageResponse<DealerService.DealerDto> search(@RequestParam(required = false) String q,
                                                        @RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "30") int size) {
        return service.search(q, page, size);
    }

    @GetMapping("/dealers/{id}")
    public DealerService.DealerDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping("/dealers")
    @ResponseStatus(HttpStatus.CREATED)
    public DealerService.DealerDto create(@Valid @RequestBody DealerService.DealerRequest request) {
        return service.create(request);
    }

    @PutMapping("/dealers/{id}")
    public DealerService.DealerDto update(@PathVariable Long id, @Valid @RequestBody DealerService.DealerRequest request) {
        return service.update(id, request);
    }

    @GetMapping("/dealers/{id}/shops")
    public List<DealerService.ShopDto> shops(@PathVariable Long id) {
        return service.shops(id);
    }

    @PostMapping("/dealers/{id}/shops")
    @ResponseStatus(HttpStatus.CREATED)
    public DealerService.ShopDto addShop(@PathVariable Long id, @Valid @RequestBody DealerService.ShopRequest request) {
        return service.addShop(id, request);
    }

    @PutMapping("/dealers/{id}/shops/{shopId}")
    public DealerService.ShopDto updateShop(@PathVariable Long id, @PathVariable Long shopId,
                                            @Valid @RequestBody DealerService.ShopRequest request) {
        return service.updateShop(id, shopId, request);
    }

    @GetMapping("/dealers/{id}/ledger")
    public DealerService.DealerLedger ledger(@PathVariable Long id, @RequestParam(required = false) Long shopId) {
        return service.ledger(id, shopId);
    }

    @GetMapping("/dealer-bills")
    public PageResponse<DealerService.DealerBillDto> bills(@RequestParam(required = false) Long dealerId,
                                                           @RequestParam(required = false) Long shopId,
                                                           @RequestParam(required = false) Enums.Metal metal,
                                                           @RequestParam(required = false) DealerBill.Status status,
                                                           @RequestParam(required = false) String q,
                                                           @RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "30") int size) {
        return service.searchBills(dealerId, shopId, metal, status, q, page, size);
    }

    @GetMapping("/dealer-bills/{id}")
    public DealerService.DealerBillDto bill(@PathVariable Long id) {
        return service.getBill(id);
    }

    @PostMapping("/dealer-bills")
    @ResponseStatus(HttpStatus.CREATED)
    public DealerService.DealerBillDto createBill(@Valid @RequestBody DealerService.DealerBillRequest request) {
        return service.createBill(request);
    }

    @PostMapping("/dealer-bills/{id}/settlements")
    public DealerService.DealerBillDto settle(@PathVariable Long id, @Valid @RequestBody DealerService.SettlementRequest request) {
        return service.settle(id, request);
    }

    @PostMapping("/dealer-bills/{id}/settlements/{settlementId}/reverse")
    public DealerService.DealerBillDto reverseSettlement(@PathVariable Long id, @PathVariable Long settlementId,
                                                         @RequestBody ReasonRequest request) {
        return service.reverseSettlement(id, settlementId, request.reason());
    }

    @PostMapping("/dealer-bills/{id}/reverse")
    public DealerService.DealerBillDto reverse(@PathVariable Long id, @RequestBody ReasonRequest request) {
        return service.reverseBill(id, request.reason());
    }
}
