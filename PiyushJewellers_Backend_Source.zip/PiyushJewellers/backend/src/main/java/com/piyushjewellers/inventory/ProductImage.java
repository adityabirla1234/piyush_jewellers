package com.piyushjewellers.inventory;

import com.piyushjewellers.common.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/** Image metadata only. Binaries live in file/object storage, never as MySQL BLOBs. */
@Getter
@Setter
@Entity
@Table(name = "product_images", indexes = @Index(name = "idx_image_product", columnList = "productId,displayOrder"))
public class ProductImage extends BaseEntity {

    @Column(nullable = false)
    private Long productId;

    @Column(nullable = false, length = 300)
    private String storageKey;

    @Column(nullable = false, length = 300)
    private String thumbnailKey;

    @Column(nullable = false)
    private int displayOrder;

    @Column(nullable = false)
    private boolean primaryImage;

    @Column(nullable = false, length = 40)
    private String contentType;

    @Column(nullable = false)
    private long byteSize;

    private Integer width;

    private Integer height;

    @Column(length = 64)
    private String checksum;
}
