package com.piyushjewellers.reports;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.ColumnText;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Small OpenPDF wrapper producing branded documents: Piyush Jewellers identity, title, period/filters,
 * generation timestamp, detail tables with totals/units and page numbers.
 * Uses "Rs." because the built-in Helvetica font has no rupee glyph.
 */
public class PdfBuilder {

    static final Color BURGUNDY = new Color(0x6B, 0x1E, 0x2E);
    static final Color GOLD = new Color(0xB8, 0x8A, 0x2E);
    static final Color IVORY = new Color(0xFB, 0xF6, 0xEC);
    private static final DateTimeFormatter TS = DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a");

    private final ByteArrayOutputStream out = new ByteArrayOutputStream();
    private final Document document;
    private final Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16, BURGUNDY);
    private final Font brandFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, BURGUNDY);
    private final Font sectionFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11, BURGUNDY);
    private final Font normal = FontFactory.getFont(FontFactory.HELVETICA, 8.5f, Color.DARK_GRAY);
    private final Font bold = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, Color.BLACK);
    private final Font headerCell = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 8.5f, Color.WHITE);
    private final Font warnFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, new Color(0xB4, 0x23, 0x18));

    public PdfBuilder(String shopName, String title, boolean landscape) {
        document = new Document(landscape ? PageSize.A4.rotate() : PageSize.A4, 32, 32, 36, 40);
        PdfWriter writer = PdfWriter.getInstance(document, out);
        writer.setPageEvent(new PdfPageEventHelper() {
            @Override
            public void onEndPage(PdfWriter w, Document d) {
                Phrase footer = new Phrase(shopName + "  •  " + title + "  •  Page " + w.getPageNumber(),
                        FontFactory.getFont(FontFactory.HELVETICA, 7.5f, Color.GRAY));
                ColumnText.showTextAligned(w.getDirectContent(), Element.ALIGN_CENTER, footer,
                        (d.right() + d.left()) / 2, d.bottom() - 18, 0);
            }
        });
        document.open();
        Paragraph brand = new Paragraph(shopName.toUpperCase(), brandFont);
        brand.setAlignment(Element.ALIGN_CENTER);
        document.add(brand);
        Paragraph rule = new Paragraph(new Chunk(new com.lowagie.text.pdf.draw.LineSeparator(1.2f, 100, GOLD, Element.ALIGN_CENTER, -2)));
        document.add(rule);
        Paragraph t = new Paragraph(title, titleFont);
        t.setAlignment(Element.ALIGN_CENTER);
        t.setSpacingBefore(6);
        document.add(t);
    }

    public PdfBuilder meta(String label, String value) {
        Paragraph p = new Paragraph();
        p.add(new Chunk(label + ": ", bold));
        p.add(new Chunk(value == null ? "—" : value, normal));
        document.add(p);
        return this;
    }

    public PdfBuilder generatedNow() {
        return meta("Generated", LocalDateTime.now(ZoneId.of("Asia/Kolkata")).format(TS));
    }

    public PdfBuilder warning(String text) {
        Paragraph p = new Paragraph(text, warnFont);
        p.setSpacingBefore(4);
        document.add(p);
        return this;
    }

    public PdfBuilder section(String title) {
        Paragraph p = new Paragraph(title, sectionFont);
        p.setSpacingBefore(12);
        p.setSpacingAfter(4);
        document.add(p);
        return this;
    }

    public PdfBuilder text(String text) {
        document.add(new Paragraph(text, normal));
        return this;
    }

    /**
     * @param numeric indexes of right-aligned numeric columns
     * @param totals  optional totals row (same length as headers), may be null
     */
    public PdfBuilder table(List<String> headers, List<List<String>> rows, float[] widths, int[] numeric, List<String> totals) {
        PdfPTable table = new PdfPTable(headers.size());
        table.setWidthPercentage(100);
        if (widths != null) table.setWidths(widths);
        table.setHeaderRows(1);
        for (int i = 0; i < headers.size(); i++) {
            PdfPCell c = new PdfPCell(new Phrase(headers.get(i), headerCell));
            c.setBackgroundColor(BURGUNDY);
            c.setPadding(4);
            c.setHorizontalAlignment(isNumeric(numeric, i) ? Element.ALIGN_RIGHT : Element.ALIGN_LEFT);
            table.addCell(c);
        }
        int r = 0;
        for (List<String> row : rows) {
            for (int i = 0; i < headers.size(); i++) {
                String v = i < row.size() && row.get(i) != null ? row.get(i) : "";
                PdfPCell c = new PdfPCell(new Phrase(v, normal));
                c.setPadding(3.5f);
                c.setBorderColor(new Color(0xE5, 0xDC, 0xCC));
                if (r % 2 == 1) c.setBackgroundColor(IVORY);
                c.setHorizontalAlignment(isNumeric(numeric, i) ? Element.ALIGN_RIGHT : Element.ALIGN_LEFT);
                table.addCell(c);
            }
            r++;
        }
        if (rows.isEmpty()) {
            PdfPCell c = new PdfPCell(new Phrase("No records for the selected filters", normal));
            c.setColspan(headers.size());
            c.setPadding(6);
            c.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(c);
        }
        if (totals != null) {
            for (int i = 0; i < headers.size(); i++) {
                String v = i < totals.size() && totals.get(i) != null ? totals.get(i) : "";
                PdfPCell c = new PdfPCell(new Phrase(v, bold));
                c.setPadding(4);
                c.setBorder(Rectangle.TOP);
                c.setBorderWidthTop(1.2f);
                c.setBorderColorTop(GOLD);
                c.setHorizontalAlignment(isNumeric(numeric, i) ? Element.ALIGN_RIGHT : Element.ALIGN_LEFT);
                table.addCell(c);
            }
        }
        document.add(table);
        return this;
    }

    public PdfBuilder keyValues(List<String[]> pairs) {
        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(60);
        table.setHorizontalAlignment(Element.ALIGN_RIGHT);
        for (String[] kv : pairs) {
            PdfPCell k = new PdfPCell(new Phrase(kv[0], bold));
            k.setBorder(Rectangle.NO_BORDER);
            k.setPadding(3);
            PdfPCell v = new PdfPCell(new Phrase(kv[1], bold));
            v.setBorder(Rectangle.NO_BORDER);
            v.setHorizontalAlignment(Element.ALIGN_RIGHT);
            v.setPadding(3);
            table.addCell(k);
            table.addCell(v);
        }
        table.setSpacingBefore(8);
        document.add(table);
        return this;
    }

    public byte[] build() {
        document.close();
        return out.toByteArray();
    }

    private static boolean isNumeric(int[] numeric, int i) {
        if (numeric == null) return false;
        for (int n : numeric) if (n == i) return true;
        return false;
    }

    public static String rs(BigDecimal v) {
        if (v == null) return "—";
        return "Rs. " + String.format("%,.2f", v);
    }

    public static String g(BigDecimal v) {
        if (v == null) return "—";
        return v.setScale(4, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString() + " g";
    }

    public static String s(Object o) {
        return o == null ? "" : o.toString();
    }
}
