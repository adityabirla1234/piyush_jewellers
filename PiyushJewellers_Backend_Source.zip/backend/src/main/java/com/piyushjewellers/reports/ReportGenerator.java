package com.piyushjewellers.reports;

import com.piyushjewellers.billing.BillService;
import com.piyushjewellers.billing.CustomerBill;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.dealers.DealerBill;
import com.piyushjewellers.dealers.DealerService;
import com.piyushjewellers.dues.DueService;
import com.piyushjewellers.exchange.Exchange;
import com.piyushjewellers.exchange.ExchangeService;
import com.piyushjewellers.inventory.BarLotService;
import com.piyushjewellers.inventory.InventoryRepositories;
import com.piyushjewellers.inventory.InventoryService;
import com.piyushjewellers.inventory.StockMovement;
import com.piyushjewellers.loans.Loan;
import com.piyushjewellers.loans.LoanService;
import com.piyushjewellers.mortgages.InterestEngine;
import com.piyushjewellers.mortgages.Mortgage;
import com.piyushjewellers.mortgages.MortgageService;
import com.piyushjewellers.sellpurchase.SellPurchaseService;
import com.piyushjewellers.settings.SettingsModule;
import com.piyushjewellers.transactions.TransactionService;
import com.piyushjewellers.turnover.TurnoverService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntFunction;

import static com.piyushjewellers.reports.PdfBuilder.g;
import static com.piyushjewellers.reports.PdfBuilder.rs;
import static com.piyushjewellers.reports.PdfBuilder.s;

/** Generates report PDFs in the background so requests never block on large reports. */
@Slf4j
@Component
@RequiredArgsConstructor
public class ReportGenerator {

    private final ReportJobRepository jobRepo;
    private final com.piyushjewellers.inventory.FileStorage storage;
    private final SettingsModule.SettingsService settingsService;
    private final TransactionService transactionService;
    private final InventoryService inventoryService;
    private final InventoryRepositories.StockMovementRepository movementRepo;
    private final BarLotService barLotService;
    private final BillService billService;
    private final DealerService dealerService;
    private final MortgageService mortgageService;
    private final DueService dueService;
    private final LoanService loanService;
    private final ExchangeService exchangeService;
    private final SellPurchaseService sellPurchaseService;
    private final TurnoverService turnoverService;

    @Async
    public void generate(Long jobId) {
        ReportJob job = jobRepo.findById(jobId).orElse(null);
        if (job == null) return;
        job.setStatus(ReportJob.Status.RUNNING);
        jobRepo.save(job);
        try {
            byte[] pdf = build(job);
            String key = "reports/" + job.getId() + "-" + job.getType().name().toLowerCase() + ".pdf";
            storage.write(key, pdf);
            job = jobRepo.findById(jobId).orElseThrow();
            job.setFileKey(key);
            job.setFileSize((long) pdf.length);
            job.setStatus(ReportJob.Status.COMPLETED);
            job.setCompletedAt(Instant.now());
            jobRepo.save(job);
        } catch (Exception e) {
            log.error("Report {} failed", jobId, e);
            job = jobRepo.findById(jobId).orElseThrow();
            job.setStatus(ReportJob.Status.FAILED);
            job.setError("Report generation failed. Please retry.");
            job.setCompletedAt(Instant.now());
            jobRepo.save(job);
        }
    }

    @Transactional(readOnly = true)
    public byte[] build(ReportJob job) {
        var settings = settingsService.current();
        boolean landscape = job.getType() != ReportJob.Type.DUES;
        PdfBuilder pdf = new PdfBuilder(settings.getShopName(), job.getTitle(), landscape);
        pdf.meta("Period", period(job.getFromDate(), job.getToDate()))
                .meta("Filters", job.getFilterSummary() == null || job.getFilterSummary().isBlank() ? "None" : job.getFilterSummary())
                .generatedNow()
                .text("Complete report generated from synchronized server data.");
        LocalDate from = job.getFromDate();
        LocalDate to = job.getToDate();
        Enums.Metal metal = job.getMetal() == null ? null : Enums.Metal.valueOf(job.getMetal());
        switch (job.getType()) {
            case FINANCIAL -> financial(pdf, from, to, job.getPersonId());
            case INVENTORY -> inventory(pdf, from, to, metal);
            case CUSTOMER_BILLING -> billing(pdf, from, to, job.getPersonId(), job.getStatusFilter());
            case DEALER -> dealer(pdf, job.getDealerId(), job.getShopId(), metal, job.getStatusFilter(), from, to);
            case MORTGAGE -> mortgage(pdf, job.getPersonId(), job.getStatusFilter());
            case DUES -> dues(pdf, job.getStatusFilter());
            case LENDING -> lending(pdf, job.getPersonId(), job.getStatusFilter(), from, to);
            case EXCHANGE -> exchange(pdf, job.getPersonId(), from, to);
            case SELL_PURCHASE -> sellPurchase(pdf, metal, from, to);
            case TURNOVER -> turnover(pdf, from, to);
        }
        return pdf.build();
    }

    private void financial(PdfBuilder pdf, LocalDate from, LocalDate to, Long personId) {
        TransactionService.Summary sm = transactionService.summary(from, to);
        pdf.section("Summary").keyValues(List.of(
                new String[]{"Opening balance", rs(sm.openingBalance())},
                new String[]{"Money in", rs(sm.moneyIn())},
                new String[]{"Money out", rs(sm.moneyOut())},
                new String[]{"Combined ledger balance", rs(sm.combinedBalance())},
                new String[]{"Cleared / available funds", rs(sm.availableBalance())},
                new String[]{"Pending cheques in", rs(sm.pendingChequesIn())},
                new String[]{"Pending cheques out", rs(sm.pendingChequesOut())}));
        List<List<String>> methods = new ArrayList<>();
        for (TransactionService.MethodSummary m : sm.byMethod()) {
            methods.add(List.of(m.method().name(), rs(m.moneyIn()), rs(m.moneyOut()), rs(m.net())));
        }
        pdf.section("By payment method").table(List.of("Method", "In", "Out", "Net"), methods, new float[]{10, 12, 12, 12}, new int[]{1, 2, 3}, null);
        List<TransactionService.TransactionDto> rows = all(p -> transactionService.search(from, to, null, null, personId, null, null, p, 100));
        List<List<String>> table = new ArrayList<>();
        BigDecimal in = BigDecimal.ZERO;
        BigDecimal out = BigDecimal.ZERO;
        for (TransactionService.TransactionDto t : rows) {
            boolean isIn = t.direction() == Enums.Direction.IN;
            if (isIn) in = in.add(t.amount()); else out = out.add(t.amount());
            table.add(List.of(s(t.businessDate().toLocalDate()), s(t.category()), s(t.description()), s(t.personName()),
                    t.method().name() + (t.cheque() == null ? "" : " (" + t.cheque().status() + ")"), t.sourceType().name(),
                    isIn ? rs(t.amount()) : "", isIn ? "" : rs(t.amount()), t.status().name()));
        }
        pdf.section("Transactions").table(List.of("Date", "Category", "Description", "Person", "Method", "Source", "In", "Out", "Status"),
                table, new float[]{8, 10, 22, 12, 10, 10, 10, 10, 8}, new int[]{6, 7},
                List.of("Total", "", "", "", "", "", rs(in), rs(out), ""));
        List<LoanService.LoanDto> loans = all(p -> loanService.search(null, Loan.Status.ACTIVE, personId, null, p, 100));
        List<List<String>> lrows = new ArrayList<>();
        for (LoanService.LoanDto l : loans) {
            lrows.add(List.of(l.personName(), l.kind().name(), rs(l.principal()), rs(l.repaidAmount()), rs(l.outstanding()), s(l.expectedReturnDate())));
        }
        pdf.section("Active lending / borrowing").table(List.of("Person", "Type", "Principal", "Repaid", "Outstanding", "Expected"),
                lrows, new float[]{18, 8, 10, 10, 10, 10}, new int[]{2, 3, 4}, null);
    }

    private void inventory(PdfBuilder pdf, LocalDate from, LocalDate to, Enums.Metal metal) {
        List<InventoryService.ProductDto> products = all(p -> inventoryService.search(null, null, metal, null, null, p, 100));
        List<List<String>> rows = new ArrayList<>();
        BigDecimal net = BigDecimal.ZERO;
        int pcs = 0;
        for (InventoryService.ProductDto p : products) {
            net = net.add(p.netWeight());
            pcs += p.pieces();
            rows.add(List.of(p.code(), p.name(), p.category().name(), p.metal().name(), s(p.purity()), g(p.grossWeight()),
                    g(p.lessWeight()), g(p.netWeight()), String.valueOf(p.pieces()), p.availability()));
        }
        pdf.section("Stock").table(List.of("Code", "Name", "Category", "Metal", "Purity", "Gross", "Less", "Net", "Pcs", "Status"),
                rows, new float[]{8, 20, 12, 7, 7, 9, 8, 9, 5, 9}, new int[]{5, 6, 7, 8},
                List.of("Total", "", "", "", "", "", "", g(net), String.valueOf(pcs), ""));
        List<List<String>> lots = new ArrayList<>();
        for (BarLotService.BarLotDto b : barLotService.list(metal, false)) {
            lots.add(List.of(b.lotCode(), b.label(), s(b.purity()), g(b.receivedWeight()), g(b.remainingWeight()), rs(b.rate()),
                    s(b.receivedDate()), s(b.source()), b.status().name()));
        }
        pdf.section("MR Biscuit lots").table(List.of("Lot", "Type", "Purity", "Received", "Remaining", "Rate", "Date", "Source", "Status"),
                lots, new float[]{8, 12, 7, 9, 9, 9, 8, 18, 8}, new int[]{3, 4, 5}, null);
        LocalDate f = from == null ? LocalDate.of(2000, 1, 1) : from;
        LocalDate t = to == null ? LocalDate.of(2999, 12, 31) : to;
        List<List<String>> moves = new ArrayList<>();
        for (StockMovement m : movementRepo.findInRange(f, t)) {
            if (metal != null && m.getProduct().getMetal() != metal) continue;
            moves.add(List.of(s(m.getBusinessDate()), m.getProduct().getCode(), m.getProduct().getName(), m.getType().name(),
                    g(m.getNetDelta()), String.valueOf(m.getPiecesDelta()), g(m.getNetAfter()), s(m.getReason())));
        }
        pdf.section("Stock movements & adjustments").table(List.of("Date", "Code", "Product", "Type", "Net Δ", "Pcs Δ", "Net after", "Reason"),
                moves, new float[]{8, 8, 18, 10, 9, 6, 9, 22}, new int[]{4, 5, 6}, null);
    }

    private void billing(PdfBuilder pdf, LocalDate from, LocalDate to, Long personId, String status) {
        CustomerBill.Status st = parse(CustomerBill.Status.class, status);
        for (CustomerBill.Type type : CustomerBill.Type.values()) {
            List<BillService.BillDto> bills = all(p -> billService.search(type, st, personId, from, to, null, p, 100));
            List<List<String>> rows = new ArrayList<>();
            BigDecimal total = BigDecimal.ZERO, paid = BigDecimal.ZERO, outstanding = BigDecimal.ZERO, making = BigDecimal.ZERO, weight = BigDecimal.ZERO;
            for (BillService.BillDto b : bills) {
                BigDecimal w = b.lines().stream().map(BillService.LineDto::netWeight).reduce(BigDecimal.ZERO, BigDecimal::add);
                if (b.status() == CustomerBill.Status.FINALIZED) {
                    total = total.add(b.grandTotal());
                    paid = paid.add(b.paidAmount());
                    outstanding = outstanding.add(b.outstandingAmount());
                    making = making.add(b.makingChargesTotal());
                    weight = weight.add(w);
                }
                String rates = b.lines().stream().map(l -> l.rate().stripTrailingZeros().toPlainString()).distinct().reduce((a, c) -> a + ", " + c).orElse("");
                rows.add(List.of(b.billNumber(), s(b.billDate()), s(b.customerName()), g(w), rates, rs(b.makingChargesTotal()),
                        rs(b.grandTotal()), rs(b.paidAmount()), rs(b.outstandingAmount()), b.status().name()));
            }
            pdf.section(type == CustomerBill.Type.SALES ? "Sales bills" : "Purchase bills")
                    .table(List.of("Bill", "Date", "Customer", "Net wt", "Rate(s)/g", "Making", "Total", "Paid", "Outstanding", "Status"),
                            rows, new float[]{9, 8, 16, 8, 10, 9, 10, 10, 10, 9}, new int[]{3, 5, 6, 7, 8},
                            List.of("Finalized totals", "", "", g(weight), "", rs(making), rs(total), rs(paid), rs(outstanding), ""));
        }
    }

    private void dealer(PdfBuilder pdf, Long dealerId, Long shopId, Enums.Metal metal, String status, LocalDate from, LocalDate to) {
        DealerBill.Status st = parse(DealerBill.Status.class, status);
        List<DealerService.DealerBillDto> bills = all(p -> dealerService.searchBills(dealerId, shopId, metal, st, null, p, 100));
        List<List<String>> rows = new ArrayList<>();
        BigDecimal amount = BigDecimal.ZERO, outAmt = BigDecimal.ZERO, outWt = BigDecimal.ZERO, finalWt = BigDecimal.ZERO;
        List<List<String>> settlements = new ArrayList<>();
        for (DealerService.DealerBillDto b : bills) {
            if (from != null && b.dealDate().isBefore(from)) continue;
            if (to != null && b.dealDate().isAfter(to)) continue;
            if (b.status() != DealerBill.Status.REVERSED) {
                amount = amount.add(b.amount());
                outAmt = outAmt.add(b.outstandingAmount());
                outWt = outWt.add(b.outstandingWeight());
                finalWt = finalWt.add(b.totalFinalWeight());
            }
            rows.add(List.of(b.billNumber(), s(b.dealDate()), b.dealerName(), b.shopName(), b.type().name(), b.metal().name(),
                    g(b.totalNetWeight()), g(b.totalFinalWeight()), rs(b.rate()), rs(b.amount()), g(b.outstandingWeight()),
                    rs(b.outstandingAmount()), b.status().name()));
            for (DealerService.SettlementDto sd : b.settlements()) {
                for (DealerService.AllocationDto a : sd.allocations()) {
                    settlements.add(List.of(b.billNumber(), s(sd.settlementDate()),
                            a.kind().name().equals("BAR") ? a.barLabel() + " " + a.barLotCode() : s(a.method()),
                            a.weight() == null ? "" : g(a.weight()), rs(a.rate()), rs(a.value()), g(a.weightEquivalent()), sd.status().name()));
                }
            }
        }
        pdf.section("Dealer bills").table(List.of("Bill", "Date", "Dealer", "Shop", "Type", "Metal", "Net", "Final wt", "Rate", "Amount", "Out wt", "Out amt", "Status"),
                rows, new float[]{7, 7, 11, 9, 7, 6, 7, 8, 7, 9, 7, 9, 8}, new int[]{6, 7, 8, 9, 10, 11},
                List.of("Totals", "", "", "", "", "", "", g(finalWt), "", rs(amount), g(outWt), rs(outAmt), ""));
        pdf.section("Bar & cash settlements").table(List.of("Bill", "Date", "Allocation", "Weight", "Rate", "Value", "Weight eq.", "Status"),
                settlements, new float[]{8, 8, 18, 9, 9, 10, 9, 8}, new int[]{3, 4, 5, 6}, null);
    }

    private void mortgage(PdfBuilder pdf, Long personId, String status) {
        Mortgage.Status st = parse(Mortgage.Status.class, status);
        List<MortgageService.MortgageDto> list = all(p -> mortgageService.search(null, st, null, personId, null, p, 100));
        List<List<String>> rows = new ArrayList<>();
        BigDecimal principal = BigDecimal.ZERO, received = BigDecimal.ZERO;
        for (MortgageService.MortgageDto m : list) {
            principal = principal.add(m.principal());
            received = received.add(m.amountReceived());
            String item = m.kind() == Mortgage.Kind.JEWELLERY
                    ? s(m.jewelleryName()) + " " + g(m.netWeight()) + " / " + m.pieces() + " pcs " + s(m.metal()) : "Cash";
            rows.add(List.of(m.serial(), m.personName(), item, s(m.issueDate()), rs(m.principal()), m.monthlyRate().stripTrailingZeros().toPlainString() + "%",
                    rs(m.amountReceived()), m.lastCalculation() == null ? "Not calculated" : rs(m.lastCalculation().totalDue()) + " @ " + m.lastCalculation().effectiveThrough(),
                    s(m.approxReminderDate()), m.completionState()));
        }
        pdf.section("Mortgages").table(List.of("Serial", "Customer", "Item", "Issued", "Principal", "Rate/mo", "Received", "Last calculated due", "Reminder", "State"),
                rows, new float[]{9, 12, 18, 8, 9, 6, 9, 14, 8, 10}, new int[]{4, 6}, List.of("Totals", "", "", "", rs(principal), "", rs(received), "", "", ""));
        List<List<String>> breakdown = new ArrayList<>();
        for (MortgageService.MortgageDto m : list) {
            if (m.lastCalculation() == null) continue;
            for (InterestEngine.Period p : m.lastCalculation().periods()) {
                breakdown.add(List.of(m.serial(), "Year " + p.index(), s(p.from()) + " → " + s(p.to()), rs(p.openingPrincipal()),
                        p.prorationDetail(), rs(p.interest()), p.completedYear() ? rs(p.capitalizedAfter()) : "—"));
            }
        }
        pdf.section("Interest breakdowns (last calculation)").table(List.of("Serial", "Period", "Dates", "Opening principal", "Months/days", "Interest", "Capitalized to"),
                breakdown, new float[]{9, 6, 14, 10, 24, 9, 10}, new int[]{3, 5, 6}, null);
        pdf.text("Policy: " + String.join(" ", InterestEngine.POLICY_NOTES));
    }

    private void dues(PdfBuilder pdf, String state) {
        String st = state == null ? "ACTIVE" : state;
        List<DueService.PersonDueSummary> persons = all(p -> dueService.overview(null, null, null, st, null, null, null, p, 100).persons());
        DueService.DueOverview overview = dueService.overview(null, null, null, st, null, null, null, 0, 1);
        pdf.keyValues(List.of(new String[]{"Total to receive", rs(overview.totalReceivable())},
                new String[]{"Total to pay", rs(overview.totalPayable())}, new String[]{"Net position", rs(overview.net())}));
        List<List<String>> rows = new ArrayList<>();
        for (DueService.PersonDueSummary p : persons) {
            rows.add(List.of(p.name(), s(p.phone()) + (p.serial() == null ? "" : " / " + p.serial()), rs(p.receivable()), rs(p.payable()),
                    rs(p.net()), String.join(", ", p.sources()), s(p.nextExpectedDate())));
        }
        pdf.section("Person-wise receivables and payables").table(List.of("Person", "Contact / serial", "Receivable", "Payable", "Net", "Sources", "Next date"),
                rows, new float[]{14, 13, 10, 10, 10, 18, 9}, new int[]{2, 3, 4}, null);
    }

    private void lending(PdfBuilder pdf, Long personId, String status, LocalDate from, LocalDate to) {
        Loan.Status st = parse(Loan.Status.class, status);
        List<LoanService.LoanDto> loans = all(p -> loanService.search(null, st, personId, null, p, 100));
        List<List<String>> rows = new ArrayList<>();
        List<List<String>> reps = new ArrayList<>();
        BigDecimal lent = BigDecimal.ZERO, borrowed = BigDecimal.ZERO;
        for (LoanService.LoanDto l : loans) {
            if (from != null && l.loanDate().isBefore(from)) continue;
            if (to != null && l.loanDate().isAfter(to)) continue;
            if (l.kind() == Loan.Kind.LENT) lent = lent.add(l.outstanding()); else borrowed = borrowed.add(l.outstanding());
            rows.add(List.of("#" + l.id(), l.personName(), l.kind().name(), s(l.loanDate()), rs(l.principal()), rs(l.repaidAmount()),
                    rs(l.outstanding()), s(l.expectedReturnDate()), l.status().name()));
            for (LoanService.RepaymentDto r : l.repayments()) {
                reps.add(List.of("#" + l.id(), l.personName(), s(r.repaymentDate()), r.method().name(), rs(r.amount()), r.effective() ? "Effective" : "Reversed"));
            }
        }
        pdf.keyValues(List.of(new String[]{"Outstanding lent (to receive)", rs(lent)}, new String[]{"Outstanding borrowed (to pay)", rs(borrowed)}));
        pdf.section("Loans").table(List.of("Loan", "Person", "Type", "Date", "Principal", "Repaid", "Outstanding", "Expected", "Status"),
                rows, new float[]{6, 16, 9, 9, 10, 10, 10, 9, 8}, new int[]{4, 5, 6}, null);
        pdf.section("Repayments").table(List.of("Loan", "Person", "Date", "Method", "Amount", "State"), reps, new float[]{6, 16, 9, 9, 10, 9}, new int[]{4}, null);
    }

    private void exchange(PdfBuilder pdf, Long personId, LocalDate from, LocalDate to) {
        List<ExchangeService.ExchangeDto> list = all(p -> exchangeService.search(null, personId, null, p, 100));
        List<List<String>> rows = new ArrayList<>();
        List<List<String>> lines = new ArrayList<>();
        for (ExchangeService.ExchangeDto e : list) {
            if (from != null && e.exchangeDate().isBefore(from)) continue;
            if (to != null && e.exchangeDate().isAfter(to)) continue;
            rows.add(List.of(e.exchangeNumber(), s(e.exchangeDate()), s(e.partyName()), rs(e.receivedValue()), rs(e.issuedValue()),
                    rs(e.cashDifference()), e.cashDirection().replace('_', ' '), e.status().name()));
            for (ExchangeService.LineDto l : e.lines()) {
                lines.add(List.of(e.exchangeNumber(), l.side().name(), l.description(), l.metal().name(), s(l.purity()), g(l.netWeight()),
                        rs(l.rate()), rs(l.value())));
            }
        }
        pdf.section("Exchanges").table(List.of("No.", "Date", "Party", "Received value", "Issued value", "Difference", "Who pays", "Status"),
                rows, new float[]{8, 8, 16, 11, 11, 10, 11, 9}, new int[]{3, 4, 5}, null);
        pdf.section("Exchange items").table(List.of("No.", "Side", "Description", "Metal", "Purity", "Net wt", "Rate", "Value"),
                lines, new float[]{8, 8, 22, 7, 7, 9, 9, 10}, new int[]{5, 6, 7}, null);
        if (list.stream().anyMatch(e -> e.status() == Exchange.Status.DRAFT)) {
            pdf.text("Draft exchanges are listed for reference and have no stock or cash effect yet.");
        }
    }

    private static final LocalDate EPOCH = LocalDate.of(2000, 1, 1);

    private static String bucketLine(SellPurchaseService.Bucket b) {
        return b.count() + " bills · " + rs(b.amount()) + " · " + g(b.netWeight());
    }

    private void sellPurchase(PdfBuilder pdf, Enums.Metal metal, LocalDate from, LocalDate to) {
        SellPurchaseService.Result r = sellPurchaseService.query(metal, from == null ? EPOCH : from, to == null ? LocalDate.now() : to, null, null);
        pdf.section("Summary").keyValues(List.of(
                new String[]{"Metal", metal == null ? "Gold & Silver (all)" : metal.name()},
                new String[]{"Sales", bucketLine(r.sales())},
                new String[]{"Purchases", bucketLine(r.purchase())},
                new String[]{"Total billed (sales + purchase)", rs(r.totalAmount())},
                new String[]{"Net (sales − purchase)", rs(r.net())}));
        List<List<String>> metals = new ArrayList<>();
        for (SellPurchaseService.MetalTotals m : r.byMetal()) {
            metals.add(List.of(m.metal().name(), String.valueOf(m.sales().count()), rs(m.sales().amount()), g(m.sales().netWeight()),
                    String.valueOf(m.purchase().count()), rs(m.purchase().amount()), g(m.purchase().netWeight())));
        }
        pdf.section("By metal").table(List.of("Metal", "Sales bills", "Sales amount", "Sales weight", "Purchase bills",
                "Purchase amount", "Purchase weight"), metals, new float[]{8, 8, 12, 10, 8, 12, 10}, new int[]{1, 2, 3, 4, 5, 6}, null);
        List<List<String>> rows = new ArrayList<>();
        for (SellPurchaseService.Row x : r.rows()) {
            rows.add(List.of(s(x.date()), x.kind() == SellPurchaseService.Kind.SALES ? "Sell" : "Purchase",
                    x.source() == SellPurchaseService.Source.CUSTOMER ? "Customer" : "Dealer", s(x.billNumber()),
                    s(x.partyName()), s(x.metal()), g(x.netWeight()), x.fineWeight() == null ? "" : g(x.fineWeight()),
                    rs(x.amount()), x.outstanding() == null ? "" : rs(x.outstanding()), s(x.status())));
        }
        pdf.section("Bills").table(List.of("Date", "Type", "Source", "Bill no.", "Party", "Metal", "Net wt", "Fine wt",
                        "Amount", "Outstanding", "Status"), rows, new float[]{8, 7, 7, 9, 17, 6, 8, 8, 10, 10, 9},
                new int[]{6, 7, 8, 9}, List.of("Total", "", "", "", "", "", "", "", rs(r.totalAmount()), "", ""));
        pdf.text("Customer bills: finalized only. Dealer bills: all except reversed. Fine weight applies to dealer bills.");
    }

    private void turnover(PdfBuilder pdf, LocalDate from, LocalDate to) {
        TurnoverService.Result t = turnoverService.compute(from == null ? EPOCH : from, to == null ? LocalDate.now() : to);
        pdf.section("Turnover").keyValues(List.of(
                new String[]{"Sales turnover", rs(t.salesTurnover()) + " (" + t.sales().count() + " bills)"},
                new String[]{"Purchase turnover", rs(t.purchaseTurnover()) + " (" + t.purchase().count() + " bills)"},
                new String[]{"Gross turnover", rs(t.grossTurnover())}));
        pdf.section("Money movement").keyValues(List.of(
                new String[]{"Opening balance", rs(t.openingBalance())},
                new String[]{"Total money in", rs(t.moneyIn())},
                new String[]{"Total money out", rs(t.moneyOut())},
                new String[]{"Net cash flow", rs(t.net())},
                new String[]{"Closing balance (combined)", rs(t.closingBalance())},
                new String[]{"Available balance (cleared)", rs(t.availableBalance())},
                new String[]{"Pending cheques in / out", rs(t.pendingChequesIn()) + " / " + rs(t.pendingChequesOut())},
                new String[]{"Moved between own accounts (excluded)", rs(t.transfersMoved())}));
        List<List<String>> comps = new ArrayList<>();
        for (TurnoverService.Component c : t.components()) {
            comps.add(List.of(c.label(), "", rs(c.moneyIn()), rs(c.moneyOut()), rs(c.net()), String.valueOf(c.count())));
            for (TurnoverService.Line l : c.lines()) {
                comps.add(List.of("", l.category(), rs(l.moneyIn()), rs(l.moneyOut()), rs(l.moneyIn().subtract(l.moneyOut())), String.valueOf(l.count())));
            }
        }
        pdf.section("Money in & out by component").table(List.of("Component", "Category", "In", "Out", "Net", "Entries"),
                comps, new float[]{16, 18, 12, 12, 12, 7}, new int[]{2, 3, 4, 5},
                List.of("Total", "", rs(t.moneyIn()), rs(t.moneyOut()), rs(t.net()), ""));
        List<List<String>> methods = new ArrayList<>();
        for (TransactionService.MethodSummary m : t.byMethod()) {
            methods.add(List.of(m.method().name(), rs(m.moneyIn()), rs(m.moneyOut()), rs(m.net())));
        }
        pdf.section("By payment method (includes transfers)").table(List.of("Method", "In", "Out", "Net"), methods,
                new float[]{10, 12, 12, 12}, new int[]{1, 2, 3}, null);
        List<List<String>> metals = new ArrayList<>();
        for (SellPurchaseService.MetalTotals m : t.byMetal()) {
            metals.add(List.of(m.metal().name(), rs(m.sales().amount()), g(m.sales().netWeight()),
                    rs(m.purchase().amount()), g(m.purchase().netWeight())));
        }
        pdf.section("Turnover by metal").table(List.of("Metal", "Sales", "Sales weight", "Purchases", "Purchase weight"),
                metals, new float[]{8, 12, 10, 12, 10}, new int[]{1, 2, 3, 4}, null);
        pdf.text("Money figures come from the canonical ledger (reversals appear as separate correcting entries). "
                + "Turnover figures come from finalized customer bills and non-reversed dealer bills.");
    }

    private static <T> List<T> all(IntFunction<PageResponse<T>> fetch) {
        List<T> out = new ArrayList<>();
        int page = 0;
        while (true) {
            PageResponse<T> r = fetch.apply(page);
            out.addAll(r.content());
            if (r.last() || r.content().isEmpty() || out.size() > 20000) break;
            page++;
        }
        return out;
    }

    private static <E extends Enum<E>> E parse(Class<E> type, String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return Enum.valueOf(type, value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    static String period(LocalDate from, LocalDate to) {
        if (from == null && to == null) return "All dates";
        return (from == null ? "Beginning" : from.toString()) + " to " + (to == null ? "Today" : to.toString());
    }
}
