package com.piyushjewellers.reports;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.inventory.FileStorage;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/** On-demand reports only: no scheduled delivery, no Telegram, no automatic distribution. */
@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportJobRepository repo;
    private final ReportGenerator generator;
    private final FileStorage storage;
    private final AuditService auditService;

    @Value("${pj.reports.retention-days:7}")
    private int retentionDays;

    public record ReportRequest(@NotNull ReportJob.Type type, LocalDate from, LocalDate to, Long personId,
                                Long dealerId, Long shopId, String metal, String status, String filterLabel) {
    }

    public record ReportJobDto(Long id, ReportJob.Type type, String title, ReportJob.Status status, LocalDate from,
                               LocalDate to, String filterSummary, Long fileSize, boolean available, String error,
                               Instant createdAt, Instant completedAt) {
        static ReportJobDto from(ReportJob j) {
            return new ReportJobDto(j.getId(), j.getReportType(), j.getTitle(), j.getStatus(), j.getFromDate(), j.getToDate(),
                    j.getFilterSummary(), j.getFileSize(), j.getStatus() == ReportJob.Status.COMPLETED, j.getError(),
                    j.getCreatedAt(), j.getCompletedAt());
        }
    }

    @PostMapping
    @ResponseStatus(HttpStatus.ACCEPTED)
    @Transactional
    public ReportJobDto create(@Valid @RequestBody ReportRequest r) {
        if (r.from() != null && r.to() != null && r.to().isBefore(r.from())) {
            throw ApiException.validation("End date is before start date");
        }
        ReportJob job = new ReportJob();
        job.setReportType(r.type());
        job.setTitle(title(r.type()));
        job.setFromDate(r.from());
        job.setToDate(r.to());
        job.setPersonId(r.personId());
        job.setDealerId(r.dealerId());
        job.setShopId(r.shopId());
        job.setMetal(r.metal() == null || r.metal().isBlank() ? null : r.metal().toUpperCase());
        job.setStatusFilter(r.status());
        List<String> parts = new ArrayList<>();
        if (r.filterLabel() != null && !r.filterLabel().isBlank()) parts.add(r.filterLabel().trim());
        if (job.getMetal() != null) parts.add("Metal: " + job.getMetal());
        if (r.status() != null && !r.status().isBlank()) parts.add("Status: " + r.status());
        job.setFilterSummary(String.join("; ", parts));
        repo.save(job);
        auditService.record("REPORT_REQUESTED", "ReportJob", job.getId(), null, job.getTitle());
        Long id = job.getId();
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                generator.generate(id);
            }
        });
        return ReportJobDto.from(job);
    }

    @GetMapping
    @Transactional(readOnly = true)
    public PageResponse<ReportJobDto> history(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "30") int size) {
        return PageResponse.of(repo.findAllByOrderByIdDesc(PageResponse.pageable(page, size, org.springframework.data.domain.Sort.unsorted())),
                ReportJobDto::from);
    }

    @GetMapping("/{id}")
    @Transactional(readOnly = true)
    public ReportJobDto get(@PathVariable Long id) {
        return ReportJobDto.from(repo.findById(id).orElseThrow(() -> ApiException.notFound("Report", id)));
    }

    @PostMapping("/{id}/retry")
    @Transactional
    public ReportJobDto retry(@PathVariable Long id) {
        ReportJob job = repo.findById(id).orElseThrow(() -> ApiException.notFound("Report", id));
        if (job.getStatus() != ReportJob.Status.FAILED && job.getStatus() != ReportJob.Status.EXPIRED) {
            throw ApiException.state("Only failed or expired reports can be regenerated");
        }
        job.setStatus(ReportJob.Status.QUEUED);
        job.setError(null);
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                generator.generate(id);
            }
        });
        return ReportJobDto.from(job);
    }

    @GetMapping("/{id}/download")
    @Transactional(readOnly = true)
    public ResponseEntity<InputStreamResource> download(@PathVariable Long id) throws IOException {
        ReportJob job = repo.findById(id).orElseThrow(() -> ApiException.notFound("Report", id));
        if (job.getStatus() != ReportJob.Status.COMPLETED || job.getFileKey() == null || !storage.exists(job.getFileKey())) {
            throw ApiException.state("This report file is not available. Generate it again.");
        }
        String filename = "PiyushJewellers-" + job.getReportType().name().toLowerCase() + "-" + job.getId() + ".pdf";
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(MediaType.APPLICATION_PDF)
                .contentLength(storage.size(job.getFileKey()))
                .body(new InputStreamResource(storage.open(job.getFileKey())));
    }

    /** Temporary backend storage: files expire after the configured retention period. */
    @Scheduled(cron = "0 15 2 * * *")
    @Transactional
    public void expireOldReports() {
        for (ReportJob job : repo.findByStatusAndCompletedAtBefore(ReportJob.Status.COMPLETED,
                Instant.now().minus(retentionDays, ChronoUnit.DAYS))) {
            if (job.getFileKey() != null) storage.deleteQuietly(job.getFileKey());
            job.setStatus(ReportJob.Status.EXPIRED);
            job.setFileKey(null);
        }
    }

    static String title(ReportJob.Type type) {
        return switch (type) {
            case FINANCIAL -> "Financial Report";
            case INVENTORY -> "Inventory Report";
            case CUSTOMER_BILLING -> "Customer Billing Report";
            case DEALER -> "Dealer Report";
            case MORTGAGE -> "Mortgage & Interest Report";
            case DUES -> "Due Management Report";
            case LENDING -> "Lending & Borrowing Report";
            case EXCHANGE -> "Jewellery Exchange Report";
        };
    }
}
