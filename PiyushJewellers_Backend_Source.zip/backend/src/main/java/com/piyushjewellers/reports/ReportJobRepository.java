package com.piyushjewellers.reports;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.Instant;
import java.util.List;

public interface ReportJobRepository extends JpaRepository<ReportJob, Long> {
    Page<ReportJob> findAllByOrderByIdDesc(Pageable pageable);

    List<ReportJob> findByStatusAndCompletedAtBefore(ReportJob.Status status, Instant before);
}
