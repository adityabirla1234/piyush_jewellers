package com.piyushjewellers.reports;

import com.piyushjewellers.common.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@Table(name = "report_jobs")
public class ReportJob extends BaseEntity {

    public enum Type { FINANCIAL, INVENTORY, CUSTOMER_BILLING, DEALER, MORTGAGE, DUES, LENDING, EXCHANGE }

    public enum Status { QUEUED, RUNNING, COMPLETED, FAILED, EXPIRED }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Type reportType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private Status status = Status.QUEUED;

    @Column(nullable = false, length = 200)
    private String title;

    private LocalDate fromDate;

    private LocalDate toDate;

    private Long personId;

    private Long dealerId;

    private Long shopId;

    @Column(length = 10)
    private String metal;

    @Column(length = 30)
    private String statusFilter;

    @Column(length = 500)
    private String filterSummary;

    @Column(length = 300)
    private String fileKey;

    private Long fileSize;

    @Column(length = 500)
    private String error;

    private Instant completedAt;
}
