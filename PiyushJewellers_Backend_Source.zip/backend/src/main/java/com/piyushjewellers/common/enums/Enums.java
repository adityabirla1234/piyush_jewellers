package com.piyushjewellers.common.enums;

/**
 * Shared business enumerations used across modules.
 */
public final class Enums {

    private Enums() {
    }

    public enum Metal { GOLD, SILVER, OTHER }

    public enum PaymentMethod { CASH, BANK, UPI, CHEQUE, OTHER }

    public enum Direction { IN, OUT }

    public enum DueDirection { RECEIVABLE, PAYABLE }

    /** Configured gold purity table: 18K 78%, 20K 84%, 22K 92%, 23K 97%, 24K 99%. */
    public enum Carat {
        K18(78), K20(84), K22(92), K23(97), K24(99);

        private final int percent;

        Carat(int percent) {
            this.percent = percent;
        }

        public int percent() {
            return percent;
        }
    }

    /** Origin of a canonical money movement, used to prevent double counting. */
    public enum SourceType {
        MANUAL, TRANSFER, CUSTOMER_BILL, DEALER_SETTLEMENT, LOAN, LOAN_REPAYMENT,
        MORTGAGE_ISSUE, MORTGAGE_PAYMENT, EXCHANGE, CHEQUE_BOUNCE, REVERSAL
    }
}
