package com.piyushjewellers.common.idempotency;

import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Optional;

@Service
public class IdempotencyStore {

    public interface Repo extends JpaRepository<IdempotencyRecord, Long> {
        Optional<IdempotencyRecord> findByKey(String key);

        @Modifying
        @Query("delete from IdempotencyRecord r where r.createdAt < :before")
        int deleteOlderThan(Instant before);
    }

    private final Repo repo;
    private final TransactionTemplate tx;

    public IdempotencyStore(Repo repo, PlatformTransactionManager txManager) {
        this.repo = repo;
        this.tx = new TransactionTemplate(txManager);
        this.tx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    }

    public Optional<IdempotencyRecord> find(String key) {
        return tx.execute(s -> repo.findByKey(key));
    }

    /** @return true when this request now owns the key. */
    public boolean tryClaim(String key, String username, String method, String path) {
        try {
            return Boolean.TRUE.equals(tx.execute(s -> {
                IdempotencyRecord r = new IdempotencyRecord();
                r.setKey(key);
                r.setUsername(username);
                r.setMethod(method);
                r.setPath(path);
                r.setState(IdempotencyRecord.State.IN_PROGRESS);
                r.setCreatedAt(Instant.now());
                repo.saveAndFlush(r);
                return true;
            }));
        } catch (DataIntegrityViolationException e) {
            return false;
        }
    }

    public void complete(String key, int status, String body) {
        tx.executeWithoutResult(s -> repo.findByKey(key).ifPresent(r -> {
            r.setState(IdempotencyRecord.State.COMPLETED);
            r.setResponseStatus(status);
            r.setResponseBody(body);
        }));
    }

    public void release(String key) {
        tx.executeWithoutResult(s -> repo.findByKey(key).ifPresent(repo::delete));
    }

    @Scheduled(cron = "0 30 3 * * *")
    public void purgeOld() {
        tx.executeWithoutResult(s -> repo.deleteOlderThan(Instant.now().minus(60, ChronoUnit.DAYS)));
    }
}
