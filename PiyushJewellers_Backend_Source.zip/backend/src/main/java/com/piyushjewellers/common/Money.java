package com.piyushjewellers.common;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Precision policy. Money is stored as DECIMAL(19,2) and rounded HALF_UP at persistence boundaries.
 * Weights are stored as DECIMAL(19,4) grams. Intermediate calculations use scale 10.
 * Exact currency scale / rounding mode is listed as an owner decision before production.
 */
public final class Money {

    public static final int MONEY_SCALE = 2;
    public static final int WEIGHT_SCALE = 4;
    public static final int CALC_SCALE = 10;
    public static final RoundingMode ROUNDING = RoundingMode.HALF_UP;

    private Money() {
    }

    public static BigDecimal money(BigDecimal value) {
        return nz(value).setScale(MONEY_SCALE, ROUNDING);
    }

    public static BigDecimal weight(BigDecimal value) {
        return nz(value).setScale(WEIGHT_SCALE, ROUNDING);
    }

    public static BigDecimal nz(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }

    public static boolean isPositive(BigDecimal value) {
        return value != null && value.signum() > 0;
    }
}
