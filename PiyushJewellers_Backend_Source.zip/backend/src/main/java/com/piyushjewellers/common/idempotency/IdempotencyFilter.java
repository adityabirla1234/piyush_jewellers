package com.piyushjewellers.common.idempotency;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.piyushjewellers.common.ApiError;
import com.piyushjewellers.security.CurrentUser;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Optional;
import java.util.Set;

/**
 * Makes financial writes safe to retry. A client sends a stable {@code Idempotency-Key} (the Android outbox
 * operation UUID). The first successful (2xx) response is stored and replayed for any retry with the same key,
 * so offline replays never duplicate bills, payments, settlements, stock movements or image records.
 * Non-2xx results release the key so the user can correct and resubmit.
 * Runs after the Spring Security chain so the authenticated user is known.
 */
@Component
@Order(Ordered.LOWEST_PRECEDENCE - 10)
@RequiredArgsConstructor
public class IdempotencyFilter extends OncePerRequestFilter {

    public static final String HEADER = "Idempotency-Key";
    private static final Set<String> WRITE_METHODS = Set.of("POST", "PUT", "PATCH", "DELETE");

    private final IdempotencyStore store;
    private final ObjectMapper objectMapper;

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String key = request.getHeader(HEADER);
        return key == null || key.isBlank() || !WRITE_METHODS.contains(request.getMethod())
                || request.getRequestURI().startsWith("/api/v1/auth/");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String username = CurrentUser.username();
        if ("system".equals(username)) {
            chain.doFilter(request, response);
            return;
        }
        String key = username + ":" + request.getHeader(HEADER).trim();
        if (key.length() > 100) {
            writeError(response, 400, "INVALID_IDEMPOTENCY_KEY", "Idempotency key is too long", false);
            return;
        }
        String path = request.getRequestURI();

        Optional<IdempotencyRecord> existing = store.find(key);
        if (existing.isEmpty() && store.tryClaim(key, username, request.getMethod(), path)) {
            ContentCachingResponseWrapper wrapper = new ContentCachingResponseWrapper(response);
            boolean completed = false;
            try {
                chain.doFilter(request, wrapper);
                int status = wrapper.getStatus();
                if (status >= 200 && status < 300) {
                    String body = new String(wrapper.getContentAsByteArray(), StandardCharsets.UTF_8);
                    store.complete(key, status, body);
                    completed = true;
                }
            } finally {
                if (!completed) {
                    store.release(key);
                }
                wrapper.copyBodyToResponse();
            }
            return;
        }

        IdempotencyRecord record = existing.orElseGet(() -> store.find(key).orElse(null));
        if (record == null || record.getState() == IdempotencyRecord.State.IN_PROGRESS) {
            writeError(response, 409, "IDEMPOTENCY_IN_PROGRESS", "The same operation is still being processed", true);
            return;
        }
        if (!record.getPath().equals(path) || !record.getMethod().equals(request.getMethod())) {
            writeError(response, 422, "IDEMPOTENCY_KEY_REUSED", "Idempotency key was already used for another request", false);
            return;
        }
        response.setStatus(record.getResponseStatus());
        response.setHeader("Idempotent-Replay", "true");
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        if (record.getResponseBody() != null) {
            response.getOutputStream().write(record.getResponseBody().getBytes(StandardCharsets.UTF_8));
        }
    }

    private void writeError(HttpServletResponse response, int status, String code, String message, boolean retryable)
            throws IOException {
        response.setStatus(status);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getOutputStream(),
                new ApiError(status, code, message, retryable, null, null, Instant.now()));
    }
}
