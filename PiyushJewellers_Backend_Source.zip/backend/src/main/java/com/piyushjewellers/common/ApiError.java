package com.piyushjewellers.common;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * Consistent error envelope. {@code retryable} tells clients whether an automatic retry is safe.
 */
public record ApiError(
        int status,
        String code,
        String message,
        boolean retryable,
        List<FieldViolation> fieldErrors,
        Map<String, Object> details,
        Instant timestamp
) {
    public record FieldViolation(String field, String message) {
    }
}
