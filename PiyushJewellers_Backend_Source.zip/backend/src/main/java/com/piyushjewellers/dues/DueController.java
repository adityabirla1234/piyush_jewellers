package com.piyushjewellers.dues;

import com.piyushjewellers.common.enums.Enums;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class DueController {

    private final DueService service;

    @GetMapping("/dues")
    public DueService.DueOverview overview(@RequestParam(required = false) String q,
                                           @RequestParam(required = false) Enums.DueDirection direction,
                                           @RequestParam(required = false) DueService.Source source,
                                           @RequestParam(defaultValue = "ACTIVE") String state,
                                           @RequestParam(required = false) BigDecimal minAmount,
                                           @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate expectedFrom,
                                           @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate expectedTo,
                                           @RequestParam(defaultValue = "0") int page,
                                           @RequestParam(defaultValue = "30") int size) {
        return service.overview(q, direction, source, state, minAmount, expectedFrom, expectedTo, page, size);
    }

    @GetMapping("/dues/persons/{personId}")
    public DueService.PersonDueAccount account(@PathVariable Long personId) {
        return service.account(personId);
    }

    @GetMapping("/people/{personId}/timeline")
    public List<DueService.TimelineEntry> timeline(@PathVariable Long personId) {
        return service.timeline(personId);
    }
}
