package com.piyushjewellers.dues;

import com.piyushjewellers.billing.BillRepository;
import com.piyushjewellers.billing.BillService;
import com.piyushjewellers.billing.CustomerBill;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.dealers.DealerBill;
import com.piyushjewellers.dealers.DealerRepositories;
import com.piyushjewellers.exchange.ExchangeService;
import com.piyushjewellers.loans.Loan;
import com.piyushjewellers.loans.LoanService;
import com.piyushjewellers.mortgages.Mortgage;
import com.piyushjewellers.mortgages.MortgageService;
import com.piyushjewellers.people.Person;
import com.piyushjewellers.people.PersonService;
import com.piyushjewellers.transactions.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Due Management is a consolidated read model over the canonical records (bills, dealer bills, loans,
 * mortgages). It never creates financial records itself, so nothing is duplicated.
 * People are never netted against each other; net position is per person.
 */
@Service
@RequiredArgsConstructor
public class DueService {

    public enum Source { CUSTOMER_BILL, DEALER_BILL, LOAN, JEWELLERY_MORTGAGE, CASH_MORTGAGE }

    private final BillRepository billRepo;
    private final BillService billService;
    private final DealerRepositories.DealerBillRepository dealerBillRepo;
    private final LoanService.LoanRepository loanRepo;
    private final LoanService loanService;
    private final MortgageService.MortgageRepository mortgageRepo;
    private final MortgageService mortgageService;
    private final ExchangeService.ExchangeRepository exchangeRepo;
    private final ExchangeService exchangeService;
    private final TransactionService transactionService;
    private final PersonService personService;

    public record DueItem(Source source, Long sourceId, String reference, String title, Long personId,
                          Enums.DueDirection direction, BigDecimal originalAmount, BigDecimal outstandingAmount,
                          BigDecimal outstandingWeight, Enums.Metal metal, LocalDate date, LocalDate expectedDate,
                          String state, BigDecimal lastCalculatedDue) {
    }

    public record PersonDueSummary(Long personId, String name, String phone, String serial, BigDecimal receivable,
                                   BigDecimal payable, BigDecimal net, BigDecimal receivableWeight,
                                   BigDecimal payableWeight, int activeItems, LocalDate nextExpectedDate,
                                   List<String> sources) {
    }

    public record DueOverview(BigDecimal totalReceivable, BigDecimal totalPayable, BigDecimal net,
                              PageResponse<PersonDueSummary> persons) {
    }

    public record TimelineEntry(LocalDate date, String kind, String title, String reference, BigDecimal amount,
                                String direction, String sourceType, Long sourceId, String status) {
    }

    public record PersonDueAccount(PersonService.PersonDto person, String mortgageSerial, BigDecimal receivable,
                                   BigDecimal payable, BigDecimal net, List<DueItem> items,
                                   List<TimelineEntry> timeline) {
    }

    @Transactional(readOnly = true)
    public DueOverview overview(String q, Enums.DueDirection direction, Source source, String state,
                                BigDecimal minAmount, LocalDate expectedFrom, LocalDate expectedTo, int page, int size) {
        boolean includeSettled = "SETTLED".equalsIgnoreCase(state) || "ALL".equalsIgnoreCase(state);
        boolean onlySettled = "SETTLED".equalsIgnoreCase(state);
        List<DueItem> items = collect(null, includeSettled);
        Map<Long, List<DueItem>> byPerson = new LinkedHashMap<>();
        for (DueItem item : items) {
            if (item.personId() == null) continue;
            if (onlySettled && !"SETTLED".equals(item.state())) continue;
            if (!onlySettled && !includeSettled && !"ACTIVE".equals(item.state())) continue;
            if (direction != null && item.direction() != direction) continue;
            if (source != null && item.source() != source) continue;
            if (expectedFrom != null && (item.expectedDate() == null || item.expectedDate().isBefore(expectedFrom))) continue;
            if (expectedTo != null && (item.expectedDate() == null || item.expectedDate().isAfter(expectedTo))) continue;
            byPerson.computeIfAbsent(item.personId(), k -> new ArrayList<>()).add(item);
        }
        String query = q == null || q.isBlank() ? null : q.trim().toLowerCase();
        String phoneQuery = query == null ? null : PersonService.normalizePhone(query);
        List<PersonDueSummary> summaries = new ArrayList<>();
        BigDecimal totalReceivable = BigDecimal.ZERO;
        BigDecimal totalPayable = BigDecimal.ZERO;
        for (Map.Entry<Long, List<DueItem>> e : byPerson.entrySet()) {
            Person p = personService.require(e.getKey());
            String serial = e.getValue().stream().filter(i -> i.source() == Source.JEWELLERY_MORTGAGE || i.source() == Source.CASH_MORTGAGE)
                    .map(i -> i.reference().contains("-") ? i.reference().substring(0, i.reference().lastIndexOf('-')) : i.reference())
                    .findFirst().orElse(null);
            if (query != null) {
                boolean match = p.getName().toLowerCase().contains(query)
                        || (serial != null && serial.toLowerCase().contains(query))
                        || (phoneQuery != null && p.getNormalizedPhone() != null && p.getNormalizedPhone().contains(phoneQuery))
                        || e.getValue().stream().anyMatch(i -> i.reference() != null && i.reference().toLowerCase().contains(query));
                if (!match) continue;
            }
            BigDecimal rec = sum(e.getValue(), Enums.DueDirection.RECEIVABLE, false);
            BigDecimal pay = sum(e.getValue(), Enums.DueDirection.PAYABLE, false);
            if (minAmount != null && rec.max(pay).compareTo(minAmount) < 0) continue;
            LocalDate next = e.getValue().stream().filter(i -> "ACTIVE".equals(i.state())).map(DueItem::expectedDate)
                    .filter(Objects::nonNull).min(Comparator.naturalOrder()).orElse(null);
            int active = (int) e.getValue().stream().filter(i -> "ACTIVE".equals(i.state())).count();
            List<String> sources = e.getValue().stream().map(i -> i.source().name()).distinct().toList();
            summaries.add(new PersonDueSummary(p.getId(), p.getName(), p.getPhone(), serial, rec, pay, Money.money(rec.subtract(pay)),
                    sum(e.getValue(), Enums.DueDirection.RECEIVABLE, true), sum(e.getValue(), Enums.DueDirection.PAYABLE, true),
                    active, next, sources));
            totalReceivable = totalReceivable.add(rec);
            totalPayable = totalPayable.add(pay);
        }
        summaries.sort(Comparator.comparing((PersonDueSummary s) -> s.receivable().add(s.payable())).reversed());
        return new DueOverview(Money.money(totalReceivable), Money.money(totalPayable),
                Money.money(totalReceivable.subtract(totalPayable)), PageResponse.ofList(summaries, page, size));
    }

    @Transactional(readOnly = true)
    public PersonDueAccount account(Long personId) {
        Person p = personService.require(personId);
        List<DueItem> items = collect(personId, true);
        items.sort(Comparator.comparing((DueItem i) -> "ACTIVE".equals(i.state()) ? 0 : 1)
                .thenComparing(DueItem::date, Comparator.nullsLast(Comparator.reverseOrder())));
        BigDecimal rec = sum(items, Enums.DueDirection.RECEIVABLE, false);
        BigDecimal pay = sum(items, Enums.DueDirection.PAYABLE, false);
        String serial = items.stream().filter(i -> i.source() == Source.JEWELLERY_MORTGAGE || i.source() == Source.CASH_MORTGAGE)
                .map(i -> i.reference().substring(0, i.reference().lastIndexOf('-'))).findFirst().orElse(null);
        return new PersonDueAccount(PersonService.PersonDto.from(p), serial, rec, pay, Money.money(rec.subtract(pay)), items, timeline(personId));
    }

    @Transactional(readOnly = true)
    public List<TimelineEntry> timeline(Long personId) {
        List<TimelineEntry> out = new ArrayList<>();
        for (TransactionService.TransactionDto t : transactionService.forPerson(personId)) {
            out.add(new TimelineEntry(t.businessDate().toLocalDate(), "TRANSACTION",
                    t.description() == null ? t.category() : t.description(), t.method().name(), t.amount(),
                    t.direction().name(), t.sourceType().name(), t.id(), t.status().name()));
        }
        for (CustomerBill b : billRepo.findByPersonIdOrderByBillDateDesc(personId)) {
            out.add(new TimelineEntry(b.getBillDate(), b.getBillType() == CustomerBill.Type.SALES ? "SALES_BILL" : "PURCHASE_BILL",
                    (b.getBillType() == CustomerBill.Type.SALES ? "Sales bill " : "Purchase bill ") + b.getBillNumber(),
                    b.getBillNumber(), b.getGrandTotal(), null, "CUSTOMER_BILL", b.getId(), b.getStatus().name()));
        }
        for (Loan l : loanRepo.findByPersonIdOrderByLoanDateDesc(personId)) {
            out.add(new TimelineEntry(l.getLoanDate(), l.getKind() == Loan.Kind.LENT ? "LOAN_LENT" : "LOAN_BORROWED",
                    (l.getKind() == Loan.Kind.LENT ? "Money lent" : "Money borrowed") + " #" + l.getId(), "Loan #" + l.getId(),
                    l.getPrincipal(), l.getKind() == Loan.Kind.LENT ? "OUT" : "IN", "LOAN", l.getId(), l.getStatus().name()));
        }
        for (MortgageService.MortgageDto m : mortgageService.search(null, null, null, personId, null, 0, 100).content()) {
            out.add(new TimelineEntry(m.issueDate(), m.kind() == Mortgage.Kind.JEWELLERY ? "JEWELLERY_MORTGAGE" : "CASH_MORTGAGE",
                    (m.kind() == Mortgage.Kind.JEWELLERY ? "Jewellery pledge " + m.jewelleryName() : "Cash mortgage") + " " + m.serial(),
                    m.serial(), m.principal(), "OUT", "MORTGAGE", m.id(), m.status().name()));
        }
        dealerBillRepo.findByDealerPersonIdAndStatusIn(personId, List.of(DealerBill.Status.values())).forEach(b ->
                out.add(new TimelineEntry(b.getDealDate(), "DEALER_BILL", "Dealer " + b.getBillType().name().toLowerCase() + " bill "
                        + b.getBillNumber() + " (" + b.getMetal() + ")", b.getBillNumber(), b.getAmount(), null, "DEALER_BILL",
                        b.getId(), b.getStatus().name())));
        exchangeRepo.findByPersonIdOrderByExchangeDateDesc(personId).forEach(e -> {
            ExchangeService.ExchangeDto dto = exchangeService.toDto(e);
            out.add(new TimelineEntry(e.getExchangeDate(), "EXCHANGE", "Exchange " + e.getExchangeNumber(), e.getExchangeNumber(),
                    dto.cashDifference(), null, "EXCHANGE", e.getId(), e.getStatus().name()));
        });
        out.sort(Comparator.comparing(TimelineEntry::date).reversed());
        return out;
    }

    /** Builds due items from canonical records. personId null = all people. */
    public List<DueItem> collect(Long personId, boolean includeSettled) {
        List<DueItem> items = new ArrayList<>();
        List<CustomerBill> bills = personId == null ? billRepo.findByStatus(CustomerBill.Status.FINALIZED)
                : billRepo.findByPersonIdAndStatus(personId, CustomerBill.Status.FINALIZED);
        for (CustomerBill b : bills) {
            if (b.getPerson() == null) continue;
            BigDecimal outstanding = billService.outstanding(b);
            boolean active = outstanding.signum() > 0;
            if (!active && !includeSettled) continue;
            items.add(new DueItem(Source.CUSTOMER_BILL, b.getId(), b.getBillNumber(),
                    (b.getBillType() == CustomerBill.Type.SALES ? "Sales bill " : "Purchase bill ") + b.getBillNumber(),
                    b.getPerson().getId(),
                    b.getBillType() == CustomerBill.Type.SALES ? Enums.DueDirection.RECEIVABLE : Enums.DueDirection.PAYABLE,
                    b.getGrandTotal(), outstanding.max(BigDecimal.ZERO), null, null, b.getBillDate(), null,
                    active ? "ACTIVE" : "SETTLED", null));
        }
        List<DealerBill.Status> dealerStatuses = includeSettled
                ? List.of(DealerBill.Status.OPEN, DealerBill.Status.PARTIALLY_SETTLED, DealerBill.Status.SETTLED)
                : List.of(DealerBill.Status.OPEN, DealerBill.Status.PARTIALLY_SETTLED);
        List<DealerBill> dealerBills = personId == null ? dealerBillRepo.findByStatusIn(dealerStatuses)
                : dealerBillRepo.findByDealerPersonIdAndStatusIn(personId, dealerStatuses);
        for (DealerBill b : dealerBills) {
            boolean active = b.getStatus() != DealerBill.Status.SETTLED;
            items.add(new DueItem(Source.DEALER_BILL, b.getId(), b.getBillNumber(),
                    "Dealer " + b.getBillType().name().toLowerCase() + " bill " + b.getBillNumber() + " — " + b.getShop().getName(),
                    b.getDealer().getPerson().getId(),
                    b.getBillType() == DealerBill.Type.SALES ? Enums.DueDirection.RECEIVABLE : Enums.DueDirection.PAYABLE,
                    b.getAmount(), Money.money(b.getAmount().subtract(b.getSettledValue()).max(BigDecimal.ZERO)),
                    Money.weight(b.getTotalFinalWeight().subtract(b.getSettledWeight()).max(BigDecimal.ZERO)), b.getMetal(),
                    b.getDealDate(), null, active ? "ACTIVE" : "SETTLED", null));
        }
        List<Loan> loans = personId == null
                ? (includeSettled ? loanRepo.findAll() : loanRepo.findByStatus(Loan.Status.ACTIVE))
                : loanRepo.findByPersonIdOrderByLoanDateDesc(personId);
        for (Loan l : loans) {
            if (l.getStatus() == Loan.Status.REVERSED) continue;
            boolean active = l.getStatus() == Loan.Status.ACTIVE;
            if (!active && !includeSettled) continue;
            items.add(new DueItem(Source.LOAN, l.getId(), "Loan #" + l.getId(),
                    (l.getKind() == Loan.Kind.LENT ? "Money lent" : "Money borrowed") + " on " + l.getLoanDate(),
                    l.getPerson().getId(),
                    l.getKind() == Loan.Kind.LENT ? Enums.DueDirection.RECEIVABLE : Enums.DueDirection.PAYABLE,
                    l.getPrincipal(), loanService.outstanding(l), null, null, l.getLoanDate(), l.getExpectedReturnDate(),
                    active ? "ACTIVE" : "SETTLED", null));
        }
        List<Mortgage> mortgages = personId == null
                ? (includeSettled ? mortgageRepo.findAll() : mortgageRepo.findByStatus(Mortgage.Status.ACTIVE))
                : mortgageService.search(null, null, null, personId, null, 0, 100).content().stream()
                .map(dto -> mortgageService.require(dto.id())).toList();
        for (Mortgage m : mortgages) {
            boolean active = m.getStatus() == Mortgage.Status.ACTIVE;
            if (!active && !includeSettled) continue;
            BigDecimal received = mortgageService.received(m);
            BigDecimal principalOutstanding = active ? Money.money(m.getPrincipal().subtract(received).max(BigDecimal.ZERO)) : BigDecimal.ZERO.setScale(2);
            BigDecimal lastDue = m.getCalculations().isEmpty() ? null : m.getCalculations().get(0).getRemainingBalance();
            items.add(new DueItem(m.getKind() == Mortgage.Kind.JEWELLERY ? Source.JEWELLERY_MORTGAGE : Source.CASH_MORTGAGE,
                    m.getId(), m.getSerial(),
                    m.getKind() == Mortgage.Kind.JEWELLERY ? "Jewellery pledge: " + m.getJewelleryName() : "Cash mortgage",
                    m.getAccount().getPerson().getId(), Enums.DueDirection.RECEIVABLE, m.getPrincipal(), principalOutstanding,
                    m.getKind() == Mortgage.Kind.JEWELLERY ? m.getNetWeight() : null, m.getMetal(), m.getIssueDate(),
                    m.getApproxReminderDate(), active ? "ACTIVE" : "SETTLED", active ? lastDue : null));
        }
        return items;
    }

    private static BigDecimal sum(List<DueItem> items, Enums.DueDirection d, boolean weight) {
        BigDecimal total = BigDecimal.ZERO;
        for (DueItem i : items) {
            if (i.direction() != d || !"ACTIVE".equals(i.state())) continue;
            BigDecimal v = weight ? i.outstandingWeight() : i.outstandingAmount();
            if (v != null) total = total.add(v);
        }
        return weight ? Money.weight(total) : Money.money(total);
    }
}
