package com.piyushjewellers.loans;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.common.enums.Enums.Direction;
import com.piyushjewellers.common.enums.Enums.SourceType;
import com.piyushjewellers.people.Person;
import com.piyushjewellers.people.PersonService;
import com.piyushjewellers.transactions.DailyTransaction;
import com.piyushjewellers.transactions.TransactionService;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class LoanService {

    public interface LoanRepository extends JpaRepository<Loan, Long> {
        @Query("""
                select l from Loan l join l.person p
                where (:kind is null or l.kind = :kind)
                  and (:status is null or l.status = :status)
                  and (:personId is null or p.id = :personId)
                  and (:q is null or lower(p.name) like lower(concat('%', :q, '%')) or p.normalizedPhone like concat('%', :q, '%'))
                """)
        Page<Loan> search(Loan.Kind kind, Loan.Status status, Long personId, String q, Pageable pageable);

        List<Loan> findByStatus(Loan.Status status);

        List<Loan> findByPersonIdOrderByLoanDateDesc(Long personId);
    }

    private final LoanRepository repo;
    private final jakarta.persistence.EntityManager entityManager;
    private final PersonService personService;
    private final TransactionService transactionService;
    private final AuditService auditService;

    public record LoanRequest(@NotNull Long personId, @NotNull Loan.Kind kind,
                              @NotNull @DecimalMin("0.01") BigDecimal principal, @NotNull LocalDate loanDate,
                              @NotNull Enums.PaymentMethod method, @Size(max = 120) String reference,
                              @Size(max = 1000) String notes, LocalDate expectedReturnDate) {
    }

    public record RepaymentRequest(@NotNull @DecimalMin("0.01") BigDecimal amount, @NotNull LocalDate repaymentDate,
                                   @NotNull Enums.PaymentMethod method, @Size(max = 120) String reference,
                                   @Size(max = 500) String notes) {
    }

    public record ExpectedDateRequest(LocalDate expectedReturnDate) {
    }

    public record RepaymentDto(Long id, BigDecimal amount, LocalDate repaymentDate, Enums.PaymentMethod method,
                               String reference, String notes, Long transactionId, boolean effective, Instant createdAt) {
    }

    public record LoanDto(Long id, Long personId, String personName, String personPhone, Loan.Kind kind,
                          BigDecimal principal, BigDecimal repaidAmount, BigDecimal outstanding, LocalDate loanDate,
                          LocalDate expectedReturnDate, Enums.PaymentMethod method, String reference, String notes,
                          Loan.Status status, Long transactionId, List<RepaymentDto> repayments, Long version) {
    }

    @Transactional(readOnly = true)
    public PageResponse<LoanDto> search(Loan.Kind kind, Loan.Status status, Long personId, String q, int page, int size) {
        return PageResponse.of(repo.search(kind, status, personId, (q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "loanDate", "id"))), this::toDto);
    }

    @Transactional(readOnly = true)
    public LoanDto get(Long id) {
        return toDto(require(id));
    }

    /** Lending creates a receivable and an OUT movement; borrowing creates a payable and an IN movement. */
    @Transactional
    public LoanDto create(LoanRequest r) {
        Person person = personService.require(r.personId());
        Loan loan = new Loan();
        loan.setPerson(person);
        loan.setKind(r.kind());
        loan.setPrincipal(Money.money(r.principal()));
        loan.setLoanDate(r.loanDate());
        loan.setExpectedReturnDate(r.expectedReturnDate());
        loan.setMethod(r.method());
        loan.setReference(r.reference());
        loan.setNotes(r.notes());
        repo.save(loan);
        boolean lent = r.kind() == Loan.Kind.LENT;
        DailyTransaction t = transactionService.postLinked(new TransactionService.LinkedPayment(
                lent ? Direction.OUT : Direction.IN, loan.getPrincipal(), r.method(), r.reference(),
                r.loanDate().atTime(LocalTime.now()), person, lent ? "Money lent" : "Money borrowed",
                (lent ? "Lent to " : "Borrowed from ") + person.getName(), SourceType.LOAN, loan.getId(),
                r.method() == Enums.PaymentMethod.CHEQUE ? r.reference() : null, null, r.expectedReturnDate()));
        loan.setTransactionId(t.getId());
        auditService.record("LOAN_CREATED", "Loan", loan.getId(), null, r.kind() + " " + loan.getPrincipal());
        return toDto(loan);
    }

    @Transactional
    public LoanDto repay(Long id, RepaymentRequest r) {
        Loan loan = require(id);
        if (loan.getStatus() != Loan.Status.ACTIVE) throw ApiException.state("This loan is " + loan.getStatus());
        BigDecimal outstanding = outstanding(loan);
        if (r.amount().compareTo(outstanding) > 0) {
            throw ApiException.validation("Repayment exceeds the outstanding balance of " + outstanding);
        }
        LoanRepayment rep = new LoanRepayment();
        rep.setLoan(loan);
        rep.setAmount(Money.money(r.amount()));
        rep.setRepaymentDate(r.repaymentDate());
        rep.setMethod(r.method());
        rep.setReference(r.reference());
        rep.setNotes(r.notes());
        loan.getRepayments().add(rep);
        entityManager.persist(rep);
        boolean lent = loan.getKind() == Loan.Kind.LENT;
        DailyTransaction t = transactionService.postLinked(new TransactionService.LinkedPayment(
                lent ? Direction.IN : Direction.OUT, rep.getAmount(), r.method(), r.reference(),
                r.repaymentDate().atTime(LocalTime.now()), loan.getPerson(), lent ? "Loan collection" : "Loan repayment",
                (lent ? "Collection from " : "Repayment to ") + loan.getPerson().getName() + " (loan #" + loan.getId() + ")",
                SourceType.LOAN_REPAYMENT, loan.getId(), r.method() == Enums.PaymentMethod.CHEQUE ? r.reference() : null,
                null, null));
        rep.setTransactionId(t.getId());
        if (outstanding(loan).signum() <= 0) loan.setStatus(Loan.Status.SETTLED);
        auditService.record("LOAN_REPAYMENT", "Loan", loan.getId(), null, rep.getAmount().toPlainString());
        return toDto(loan);
    }

    @Transactional
    public LoanDto updateExpectedDate(Long id, LocalDate date) {
        Loan loan = require(id);
        loan.setExpectedReturnDate(date);
        auditService.record("LOAN_EXPECTED_DATE", "Loan", loan.getId(), null, String.valueOf(date));
        return toDto(loan);
    }

    @Transactional
    public LoanDto reverse(Long id, String reason) {
        if (reason == null || reason.isBlank()) throw ApiException.validation("A reason is required");
        Loan loan = require(id);
        if (loan.getStatus() == Loan.Status.REVERSED) throw ApiException.state("Already reversed");
        for (LoanRepayment rep : loan.getRepayments()) {
            if (transactionService.isEffective(rep.getTransactionId())) {
                transactionService.reverse(transactionService.require(rep.getTransactionId()), "Loan reversed: " + reason);
            }
        }
        if (transactionService.isEffective(loan.getTransactionId())) {
            transactionService.reverse(transactionService.require(loan.getTransactionId()), "Loan reversed: " + reason);
        }
        loan.setStatus(Loan.Status.REVERSED);
        auditService.record("LOAN_REVERSED", "Loan", loan.getId(), reason, null);
        return toDto(loan);
    }

    public Loan require(Long id) {
        return repo.findById(id).orElseThrow(() -> ApiException.notFound("Loan", id));
    }

    public BigDecimal repaid(Loan loan) {
        return loan.getRepayments().stream().filter(r -> transactionService.isEffective(r.getTransactionId()))
                .map(LoanRepayment::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /** A bounced/reversed principal cheque means nothing is owed; a bounced repayment restores the balance. */
    public BigDecimal outstanding(Loan loan) {
        if (loan.getStatus() == Loan.Status.REVERSED || !transactionService.isEffective(loan.getTransactionId())) {
            return BigDecimal.ZERO;
        }
        return Money.money(loan.getPrincipal().subtract(repaid(loan)));
    }

    public LoanDto toDto(Loan l) {
        List<RepaymentDto> reps = l.getRepayments().stream().map(r -> new RepaymentDto(r.getId(), r.getAmount(),
                r.getRepaymentDate(), r.getMethod(), r.getReference(), r.getNotes(), r.getTransactionId(),
                transactionService.isEffective(r.getTransactionId()), r.getCreatedAt())).toList();
        return new LoanDto(l.getId(), l.getPerson().getId(), l.getPerson().getName(), l.getPerson().getPhone(), l.getKind(),
                l.getPrincipal(), Money.money(repaid(l)), outstanding(l), l.getLoanDate(), l.getExpectedReturnDate(),
                l.getMethod(), l.getReference(), l.getNotes(), l.getStatus(), l.getTransactionId(), reps, l.getVersion());
    }
}
