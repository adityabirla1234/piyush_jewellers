package com.piyushjewellers.loans;

import com.piyushjewellers.common.PageResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/loans")
@RequiredArgsConstructor
public class LoanController {

    private final LoanService service;

    public record ReasonRequest(String reason) {
    }

    @GetMapping
    public PageResponse<LoanService.LoanDto> search(@RequestParam(required = false) Loan.Kind kind,
                                                    @RequestParam(required = false) Loan.Status status,
                                                    @RequestParam(required = false) Long personId,
                                                    @RequestParam(required = false) String q,
                                                    @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "30") int size) {
        return service.search(kind, status, personId, q, page, size);
    }

    @GetMapping("/{id}")
    public LoanService.LoanDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public LoanService.LoanDto create(@Valid @RequestBody LoanService.LoanRequest request) {
        return service.create(request);
    }

    @PostMapping("/{id}/repayments")
    public LoanService.LoanDto repay(@PathVariable Long id, @Valid @RequestBody LoanService.RepaymentRequest request) {
        return service.repay(id, request);
    }

    @PutMapping("/{id}/expected-date")
    public LoanService.LoanDto expectedDate(@PathVariable Long id, @RequestBody LoanService.ExpectedDateRequest request) {
        return service.updateExpectedDate(id, request.expectedReturnDate());
    }

    @PostMapping("/{id}/reverse")
    public LoanService.LoanDto reverse(@PathVariable Long id, @RequestBody ReasonRequest request) {
        return service.reverse(id, request.reason());
    }
}
