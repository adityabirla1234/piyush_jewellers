package com.piyushjewellers.loans;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.people.Person;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** Money lent to (receivable) or borrowed from (payable) a person. */
@Getter
@Setter
@Entity
@Table(name = "loans", indexes = @Index(name = "idx_loan_person", columnList = "person_id,status"))
public class Loan extends BaseEntity {

    public enum Kind { LENT, BORROWED }

    public enum Status { ACTIVE, SETTLED, REVERSED }

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "person_id")
    private Person person;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Kind kind;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal principal;

    @Column(nullable = false)
    private LocalDate loanDate;

    private LocalDate expectedReturnDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.PaymentMethod method;

    @Column(length = 120)
    private String reference;

    @Column(length = 1000)
    private String notes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Status status = Status.ACTIVE;

    private Long transactionId;

    @OneToMany(mappedBy = "loan", cascade = CascadeType.ALL)
    @OrderBy("repaymentDate ASC, id ASC")
    private List<LoanRepayment> repayments = new ArrayList<>();
}
