package com.piyushjewellers.inventory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.UUID;

/**
 * Uploads product photos to ImageKit when configured. Keys and URLs come from environment variables only.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class ImageKitClient {

    private final ObjectMapper objectMapper;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(45)).build();

    @Value("${pj.imagekit.private-key:}")
    private String privateKey;

    @Value("${pj.imagekit.url-endpoint:}")
    private String urlEndpoint;

    public boolean enabled() {
        return privateKey != null && !privateKey.isBlank() && urlEndpoint != null && !urlEndpoint.isBlank();
    }

    public record Uploaded(String fileId, String url, String thumbnailUrl) {
    }

    public Uploaded upload(byte[] bytes, String fileName, String folder, String contentType) throws IOException {
        String boundary = "----PJ" + UUID.randomUUID();
        byte[] body = multipart(boundary, bytes, fileName, folder, contentType);
        HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create("https://upload.imagekit.io/api/v1/files/upload"))
                .header("Authorization", basicAuth())
                .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                .POST(HttpRequest.BodyPublishers.ofByteArray(body))
                .timeout(Duration.ofMinutes(2))
                .build();
        try {
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() >= 300) {
                throw new IOException("ImageKit upload failed (HTTP " + res.statusCode() + ")");
            }
            JsonNode n = objectMapper.readTree(res.body());
            String fileId = n.path("fileId").asText(null);
            String url = n.path("url").asText(null);
            if (fileId == null || url == null) {
                throw new IOException("ImageKit response missing fileId or url");
            }
            String thumb = n.hasNonNull("thumbnailUrl") ? n.get("thumbnailUrl").asText() : "";
            if (thumb.isBlank()) {
                thumb = url + (url.contains("?") ? "&" : "?") + "tr=w-360,c-at_max";
            }
            return new Uploaded(fileId, url, thumb);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException(e);
        }
    }

    public void delete(String fileId) {
        if (!enabled() || fileId == null || fileId.isBlank()) {
            return;
        }
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.imagekit.io/v1/files/" + URLEncoder.encode(fileId, StandardCharsets.UTF_8)))
                    .header("Authorization", basicAuth())
                    .DELETE()
                    .timeout(Duration.ofSeconds(30))
                    .build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() >= 300 && res.statusCode() != 404) {
                log.warn("ImageKit delete {}: HTTP {}", fileId, res.statusCode());
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (IOException e) {
            log.warn("ImageKit delete failed for {}", fileId);
        }
    }

    private String basicAuth() {
        return "Basic " + Base64.getEncoder().encodeToString((privateKey + ":").getBytes(StandardCharsets.UTF_8));
    }

    private static byte[] multipart(String boundary, byte[] fileBytes, String fileName, String folder, String contentType) throws IOException {
        var out = new ByteArrayOutputStream();
        String nl = "\r\n";
        out.write(("--" + boundary + nl).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"" + nl).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Type: " + contentType + nl + nl).getBytes(StandardCharsets.UTF_8));
        out.write(fileBytes);
        out.write(nl.getBytes(StandardCharsets.UTF_8));
        out.write(("--" + boundary + nl).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"fileName\"" + nl + nl + fileName + nl).getBytes(StandardCharsets.UTF_8));
        out.write(("--" + boundary + nl).getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"folder\"" + nl + nl + folder + nl).getBytes(StandardCharsets.UTF_8));
        out.write(("--" + boundary + "--" + nl).getBytes(StandardCharsets.UTF_8));
        return out.toByteArray();
    }
}
