package com.piyushjewellers.inventory;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.enums.Enums;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class BarLotService {

    private final InventoryRepositories.BarLotRepository lotRepo;
    private final InventoryRepositories.BarMovementRepository movementRepo;
    private final AuditService auditService;

    public record BarLotDto(Long id, String lotCode, Enums.Metal metal, String label, BigDecimal receivedWeight,
                            BigDecimal remainingWeight, String purity, BigDecimal rate, LocalDate receivedDate,
                            String source, String notes, BarLot.Status status, Long version) {
        static BarLotDto from(BarLot b) {
            return new BarLotDto(b.getId(), b.getLotCode(), b.getMetal(), BarLot.label(b.getMetal()), b.getReceivedWeight(),
                    b.getRemainingWeight(), b.getPurity(), b.getRate(), b.getReceivedDate(), b.getSource(), b.getNotes(),
                    b.getStatus(), b.getVersion());
        }
    }

    public record BarLotRequest(@NotNull Enums.Metal metal, @Size(max = 40) String lotCode,
                                @NotNull @DecimalMin("0.0001") BigDecimal weight, @Size(max = 20) String purity,
                                @DecimalMin("0") BigDecimal rate, LocalDate receivedDate, @Size(max = 200) String source,
                                @Size(max = 500) String notes) {
    }

    public record BarMovementDto(Long id, Long barLotId, String lotCode, BarMovement.Type type, BigDecimal weightDelta,
                                 BigDecimal remainingAfter, BigDecimal rate, String sourceType, Long sourceId,
                                 String reason, LocalDate businessDate, Instant createdAt, String createdBy) {
        static BarMovementDto from(BarMovement m) {
            return new BarMovementDto(m.getId(), m.getBarLot().getId(), m.getBarLot().getLotCode(), m.getType(),
                    m.getWeightDelta(), m.getRemainingAfter(), m.getRate(), m.getSourceType(), m.getSourceId(),
                    m.getReason(), m.getBusinessDate(), m.getCreatedAt(), m.getCreatedBy());
        }
    }

    @Transactional(readOnly = true)
    public List<BarLotDto> list(Enums.Metal metal, boolean availableOnly) {
        List<BarLot> lots = metal == null ? lotRepo.findAllByOrderByReceivedDateDesc() : lotRepo.findByMetalOrderByReceivedDateDesc(metal);
        return lots.stream().filter(l -> !availableOnly || l.getStatus() == BarLot.Status.AVAILABLE).map(BarLotDto::from).toList();
    }

    @Transactional(readOnly = true)
    public List<BarMovementDto> movements(Long lotId) {
        return movementRepo.findByBarLotIdOrderByIdDesc(lotId).stream().map(BarMovementDto::from).toList();
    }

    @Transactional
    public BarLotDto create(BarLotRequest r) {
        BarLot lot = receive(r.metal(), r.lotCode(), r.weight(), r.purity(), r.rate(),
                r.receivedDate() == null ? LocalDate.now() : r.receivedDate(), r.source(), "MANUAL", null);
        lot.setNotes(r.notes());
        return BarLotDto.from(lot);
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public BarLot receive(Enums.Metal metal, String lotCode, BigDecimal weight, String purity, BigDecimal rate,
                          LocalDate date, String source, String sourceType, Long sourceId) {
        if (metal == Enums.Metal.OTHER) throw ApiException.validation("MR Biscuit lots must be Gold or Silver");
        if (!Money.isPositive(weight)) throw ApiException.validation("Bar weight must be greater than zero");
        String code = (lotCode == null || lotCode.isBlank()) ? nextCode(metal) : lotCode.trim();
        if (lotRepo.existsByLotCode(code)) {
            throw ApiException.conflict("DUPLICATE_LOT", "Lot code " + code + " already exists", null);
        }
        BarLot lot = new BarLot();
        lot.setLotCode(code);
        lot.setMetal(metal);
        lot.setReceivedWeight(Money.weight(weight));
        lot.setRemainingWeight(Money.weight(weight));
        lot.setPurity(purity);
        lot.setRate(rate == null ? null : Money.money(rate));
        lot.setReceivedDate(date);
        lot.setSource(source);
        lotRepo.save(lot);
        movement(lot, BarMovement.Type.RECEIPT, lot.getReceivedWeight(), rate, sourceType, sourceId, "Lot received", date);
        auditService.record("BAR_LOT_RECEIVED", "BarLot", lot.getId(), null, code + " " + weight + " g");
        return lot;
    }

    /** Issues weight from one lot (e.g. dealer settlement). Lot remaining weight can never go negative. */
    @Transactional(propagation = Propagation.MANDATORY)
    public BarLot issue(Long lotId, BigDecimal weight, BigDecimal rate, String sourceType, Long sourceId, String reason, LocalDate date) {
        BarLot lot = lotRepo.findById(lotId).orElseThrow(() -> ApiException.notFound("Bar lot", lotId));
        if (!Money.isPositive(weight)) throw ApiException.validation("Issued weight must be greater than zero");
        if (lot.getRemainingWeight().compareTo(weight) < 0) {
            throw ApiException.conflict("INSUFFICIENT_BAR_WEIGHT", lot.getLotCode() + " has only "
                    + lot.getRemainingWeight().stripTrailingZeros().toPlainString() + " g remaining",
                    Map.of("barLotId", lotId, "remaining", lot.getRemainingWeight()));
        }
        lot.setRemainingWeight(Money.weight(lot.getRemainingWeight().subtract(weight)));
        if (lot.getRemainingWeight().signum() == 0) lot.setStatus(BarLot.Status.EXHAUSTED);
        movement(lot, BarMovement.Type.ISSUE, weight.negate(), rate, sourceType, sourceId, reason, date);
        return lot;
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void reverseFor(String sourceType, Long sourceId, String reason) {
        for (BarMovement m : movementRepo.findBySourceTypeAndSourceId(sourceType, sourceId)) {
            if (m.getType() == BarMovement.Type.REVERSAL) continue;
            BarLot lot = m.getBarLot();
            BigDecimal opposite = m.getWeightDelta().negate();
            BigDecimal next = lot.getRemainingWeight().add(opposite);
            if (next.signum() < 0) {
                throw ApiException.conflict("INSUFFICIENT_BAR_WEIGHT",
                        "Cannot reverse: " + lot.getLotCode() + " was already used elsewhere", null);
            }
            lot.setRemainingWeight(Money.weight(next));
            lot.setStatus(lot.getRemainingWeight().signum() == 0 ? BarLot.Status.EXHAUSTED : BarLot.Status.AVAILABLE);
            movement(lot, BarMovement.Type.REVERSAL, opposite, m.getRate(), sourceType, sourceId, "Reversal: " + reason, LocalDate.now());
        }
    }

    @Transactional
    public BarLotDto adjust(Long lotId, BigDecimal delta, String reason) {
        if (reason == null || reason.isBlank()) throw ApiException.validation("A reason is required for an adjustment");
        BarLot lot = lotRepo.findById(lotId).orElseThrow(() -> ApiException.notFound("Bar lot", lotId));
        BigDecimal next = lot.getRemainingWeight().add(Money.nz(delta));
        if (next.signum() < 0) throw ApiException.validation("Adjustment would make the remaining weight negative");
        lot.setRemainingWeight(Money.weight(next));
        lot.setStatus(next.signum() == 0 ? BarLot.Status.EXHAUSTED : BarLot.Status.AVAILABLE);
        movement(lot, BarMovement.Type.ADJUSTMENT, delta, null, "MANUAL", null, reason, LocalDate.now());
        auditService.record("BAR_LOT_ADJUSTED", "BarLot", lot.getId(), reason, "delta " + delta);
        return BarLotDto.from(lot);
    }

    private void movement(BarLot lot, BarMovement.Type type, BigDecimal delta, BigDecimal rate, String sourceType,
                          Long sourceId, String reason, LocalDate date) {
        BarMovement m = new BarMovement();
        m.setBarLot(lot);
        m.setType(type);
        m.setWeightDelta(Money.weight(delta));
        m.setRemainingAfter(lot.getRemainingWeight());
        m.setRate(rate == null ? null : Money.money(rate));
        m.setSourceType(sourceType);
        m.setSourceId(sourceId);
        m.setReason(reason);
        m.setBusinessDate(date == null ? LocalDate.now() : date);
        movementRepo.save(m);
    }

    private String nextCode(Enums.Metal metal) {
        String prefix = metal == Enums.Metal.GOLD ? "MRG-" : "MRS-";
        long n = lotRepo.count() + 1;
        String code;
        do {
            code = prefix + String.format("%04d", n++);
        } while (lotRepo.existsByLotCode(code));
        return code;
    }
}
