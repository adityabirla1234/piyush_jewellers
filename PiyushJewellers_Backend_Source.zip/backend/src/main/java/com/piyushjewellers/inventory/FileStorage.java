package com.piyushjewellers.inventory;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * File storage for image binaries and generated PDFs. Keys are server-generated (never client file names).
 * Swap this component for an object-storage implementation (S3/R2) in production; Render's disk is ephemeral
 * unless a persistent disk is attached.
 */
@Slf4j
@Component
public class FileStorage {

    private final Path root;

    public FileStorage(@Value("${pj.storage.root:./pj-storage}") String root) throws IOException {
        this.root = Path.of(root).toAbsolutePath().normalize();
        Files.createDirectories(this.root);
    }

    public void write(String key, byte[] bytes) throws IOException {
        Path target = resolve(key);
        Files.createDirectories(target.getParent());
        Path tmp = target.resolveSibling(target.getFileName() + ".tmp");
        Files.write(tmp, bytes);
        Files.move(tmp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
    }

    public InputStream open(String key) throws IOException {
        return Files.newInputStream(resolve(key));
    }

    public boolean exists(String key) {
        return Files.exists(resolve(key));
    }

    public long size(String key) throws IOException {
        return Files.size(resolve(key));
    }

    public void deleteQuietly(String key) {
        try {
            Files.deleteIfExists(resolve(key));
        } catch (IOException e) {
            log.warn("Could not delete stored file {}", key);
        }
    }

    private Path resolve(String key) {
        Path p = root.resolve(key).normalize();
        if (!p.startsWith(root)) {
            throw new IllegalArgumentException("Invalid storage key");
        }
        return p;
    }
}
