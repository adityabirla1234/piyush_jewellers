package com.piyushjewellers.inventory;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/** An individual MR Biscuit (Gold) / MR Biscuit (Silver) lot. Remaining weight only changes through BarMovement. */
@Getter
@Setter
@Entity
@Table(name = "bar_lots", indexes = @Index(name = "idx_barlot_metal", columnList = "metal,status"))
public class BarLot extends BaseEntity {

    public enum Status { AVAILABLE, EXHAUSTED }

    @Column(nullable = false, unique = true, length = 40)
    private String lotCode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.Metal metal;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal receivedWeight;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal remainingWeight;

    @Column(length = 20)
    private String purity;

    @Column(precision = 19, scale = 2)
    private BigDecimal rate;

    @Column(nullable = false)
    private LocalDate receivedDate;

    @Column(length = 200)
    private String source;

    @Column(length = 500)
    private String notes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private Status status = Status.AVAILABLE;

    public static String label(Enums.Metal metal) {
        return metal == Enums.Metal.SILVER ? "MR Biscuit (Silver)" : "MR Biscuit (Gold)";
    }
}
