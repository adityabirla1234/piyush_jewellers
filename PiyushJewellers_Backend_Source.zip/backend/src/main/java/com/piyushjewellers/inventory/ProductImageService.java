package com.piyushjewellers.inventory;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;

/**
 * Product photo gallery. Photo operations never touch stock quantities, weights, valuation or ledgers.
 */
@Service
@RequiredArgsConstructor
public class ProductImageService {

    private final InventoryRepositories.ProductImageRepository imageRepo;
    private final InventoryService inventoryService;
    private final FileStorage storage;
    private final ImageKitClient imageKit;
    private final AuditService auditService;

    @Value("${pj.photos.max-per-product:12}")
    private int maxPerProduct;
    @Value("${pj.photos.max-bytes:10485760}")
    private long maxBytes;
    @Value("${pj.photos.thumbnail-size:360}")
    private int thumbSize;

    public record ImageDto(Long id, Long productId, String url, String thumbnailUrl, int displayOrder, boolean primary,
                           String contentType, long byteSize, Integer width, Integer height, Instant createdAt) {
        static ImageDto from(ProductImage i) {
            if (isHttp(i.getStorageKey())) {
                return new ImageDto(i.getId(), i.getProductId(), i.getStorageKey(), thumbPublicUrl(i),
                        i.getDisplayOrder(), i.isPrimaryImage(), i.getContentType(), i.getByteSize(), i.getWidth(),
                        i.getHeight(), i.getCreatedAt());
            }
            return new ImageDto(i.getId(), i.getProductId(), contentUrl(i.getId(), "full"), contentUrl(i.getId(), "thumb"),
                    i.getDisplayOrder(), i.isPrimaryImage(), i.getContentType(), i.getByteSize(), i.getWidth(),
                    i.getHeight(), i.getCreatedAt());
        }
    }

    public record StoredContent(String key, String contentType, String redirectUrl) {
        public StoredContent(String key, String contentType) {
            this(key, contentType, null);
        }
    }

    public static String contentUrl(Long imageId, String variant) {
        return "/api/v1/images/" + imageId + "/content?variant=" + variant;
    }

    @Transactional(readOnly = true)
    public List<ImageDto> list(Long productId) {
        inventoryService.require(productId);
        return imageRepo.findByProductIdOrderByDisplayOrderAscIdAsc(productId).stream().map(ImageDto::from).toList();
    }

    @Transactional
    public ImageDto upload(Long productId, MultipartFile file) throws IOException {
        inventoryService.require(productId);
        if (file == null || file.isEmpty()) throw ApiException.validation("Choose an image to upload");
        if (file.getSize() > maxBytes) {
            throw new ApiException(HttpStatus.PAYLOAD_TOO_LARGE, "FILE_TOO_LARGE",
                    "Image exceeds the " + (maxBytes / (1024 * 1024)) + " MB limit", null);
        }
        long existing = imageRepo.countByProductId(productId);
        if (existing >= maxPerProduct) {
            throw ApiException.validation("A product can have at most " + maxPerProduct + " photos");
        }
        byte[] bytes = file.getBytes();
        String type = sniffType(bytes);
        if (type == null) {
            throw new ApiException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "UNSUPPORTED_IMAGE",
                    "Only JPEG, PNG or WEBP images are accepted", null);
        }
        Integer width = null;
        Integer height = null;
        byte[] thumb = bytes;
        if (!type.equals("image/webp")) {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
            if (img == null) {
                throw new ApiException(HttpStatus.UNSUPPORTED_MEDIA_TYPE, "MALFORMED_IMAGE", "The image file is damaged or unreadable", null);
            }
            width = img.getWidth();
            height = img.getHeight();
            thumb = thumbnail(img);
        }
        String base = "products/" + productId + "/" + UUID.randomUUID();
        String ext = switch (type) {
            case "image/png" -> ".png";
            case "image/webp" -> ".webp";
            default -> ".jpg";
        };
        String key;
        String thumbKey;
        String cloudId = null;
        String cloudThumbId = null;
        if (imageKit.enabled()) {
            String folder = "/piyush/products/" + productId;
            String name = UUID.randomUUID() + ext;
            ImageKitClient.Uploaded full = imageKit.upload(bytes, name, folder, type);
            String thumbType = type.equals("image/webp") ? "image/webp" : "image/jpeg";
            ImageKitClient.Uploaded th = imageKit.upload(thumb, "thumb-" + name, folder, thumbType);
            key = full.url();
            thumbKey = th.thumbnailUrl();
            cloudId = full.fileId();
            cloudThumbId = th.fileId();
        } else {
            key = base + ext;
            thumbKey = base + "_thumb" + (type.equals("image/webp") ? ".webp" : ".jpg");
            storage.write(key, bytes);
            storage.write(thumbKey, thumb);
            cleanupOnRollback(key, thumbKey);
        }

        ProductImage image = new ProductImage();
        image.setProductId(productId);
        image.setStorageKey(key);
        image.setThumbnailKey(thumbKey);
        image.setCloudFileId(cloudId);
        image.setCloudThumbFileId(cloudThumbId);
        image.setDisplayOrder((int) existing);
        image.setPrimaryImage(existing == 0);
        image.setContentType(type);
        image.setByteSize(bytes.length);
        image.setWidth(width);
        image.setHeight(height);
        image.setChecksum(sha256(bytes));
        imageRepo.save(image);
        auditService.record("PRODUCT_IMAGE_ADDED", "Product", productId, null, "image #" + image.getId());
        return ImageDto.from(image);
    }

    @Transactional
    public List<ImageDto> reorder(Long productId, List<Long> imageIds) {
        List<ProductImage> images = imageRepo.findByProductIdOrderByDisplayOrderAscIdAsc(productId);
        if (imageIds == null || imageIds.size() != images.size()
                || !images.stream().map(ProductImage::getId).allMatch(imageIds::contains)) {
            throw ApiException.validation("The new order must include every photo of this product exactly once");
        }
        for (ProductImage image : images) {
            image.setDisplayOrder(imageIds.indexOf(image.getId()));
        }
        auditService.record("PRODUCT_IMAGES_REORDERED", "Product", productId, null, imageIds.toString());
        return list(productId);
    }

    @Transactional
    public List<ImageDto> setPrimary(Long productId, Long imageId) {
        List<ProductImage> images = imageRepo.findByProductIdOrderByDisplayOrderAscIdAsc(productId);
        if (images.stream().noneMatch(i -> i.getId().equals(imageId))) {
            throw ApiException.notFound("Image", imageId);
        }
        images.forEach(i -> i.setPrimaryImage(i.getId().equals(imageId)));
        auditService.record("PRODUCT_IMAGE_PRIMARY", "Product", productId, null, "image #" + imageId);
        return list(productId);
    }

    @Transactional
    public List<ImageDto> delete(Long productId, Long imageId) {
        ProductImage image = imageRepo.findById(imageId)
                .filter(i -> i.getProductId().equals(productId))
                .orElseThrow(() -> ApiException.notFound("Image", imageId));
        boolean wasPrimary = image.isPrimaryImage();
        imageRepo.delete(image);
        imageRepo.flush();
        List<ProductImage> rest = new ArrayList<>(imageRepo.findByProductIdOrderByDisplayOrderAscIdAsc(productId));
        for (int i = 0; i < rest.size(); i++) {
            rest.get(i).setDisplayOrder(i);
        }
        if (wasPrimary && !rest.isEmpty()) {
            rest.get(0).setPrimaryImage(true);
        }
        String key = image.getStorageKey();
        String thumbKey = image.getThumbnailKey();
        String cloud = image.getCloudFileId();
        String cloudThumb = image.getCloudThumbFileId();
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                if (cloud != null) {
                    imageKit.delete(cloud);
                    imageKit.delete(cloudThumb);
                } else {
                    storage.deleteQuietly(key);
                    storage.deleteQuietly(thumbKey);
                }
            }
        });
        auditService.record("PRODUCT_IMAGE_REMOVED", "Product", productId, null, "image #" + imageId);
        return list(productId);
    }

    @Transactional(readOnly = true)
    public StoredContent content(Long imageId, String variant) {
        ProductImage image = imageRepo.findById(imageId).orElseThrow(() -> ApiException.notFound("Image", imageId));
        boolean thumb = "thumb".equalsIgnoreCase(variant);
        if (isHttp(image.getStorageKey())) {
            String url = thumb ? thumbPublicUrl(image) : image.getStorageKey();
            String type = thumb && !image.getContentType().equals("image/webp") ? "image/jpeg" : image.getContentType();
            return new StoredContent(null, type, url);
        }
        String key = thumb ? image.getThumbnailKey() : image.getStorageKey();
        String type = thumb && !image.getContentType().equals("image/webp") ? "image/jpeg" : image.getContentType();
        return new StoredContent(key, type);
    }

    private static boolean isHttp(String key) {
        return key != null && (key.startsWith("https://") || key.startsWith("http://"));
    }

    private static String thumbPublicUrl(ProductImage i) {
        if (isHttp(i.getThumbnailKey())) {
            return i.getThumbnailKey();
        }
        if (isHttp(i.getStorageKey())) {
            String url = i.getStorageKey();
            return url + (url.contains("?") ? "&" : "?") + "tr=w-360,c-at_max";
        }
        return contentUrl(i.getId(), "thumb");
    }

    private void cleanupOnRollback(String... keys) {
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCompletion(int status) {
                if (status != STATUS_COMMITTED) {
                    for (String k : keys) storage.deleteQuietly(k);
                }
            }
        });
    }

    private byte[] thumbnail(BufferedImage img) throws IOException {
        double scale = Math.min(1.0, thumbSize / (double) Math.max(img.getWidth(), img.getHeight()));
        int w = Math.max(1, (int) Math.round(img.getWidth() * scale));
        int h = Math.max(1, (int) Math.round(img.getHeight() * scale));
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setColor(java.awt.Color.WHITE);
        g.fillRect(0, 0, w, h);
        g.drawImage(img, 0, 0, w, h, null);
        g.dispose();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ImageIO.write(out, "jpg", bos);
        return bos.toByteArray();
    }

    /** Content sniffing by magic bytes: client file names and MIME types are not trusted. */
    static String sniffType(byte[] b) {
        if (b.length < 12) return null;
        if ((b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8 && (b[2] & 0xFF) == 0xFF) return "image/jpeg";
        if ((b[0] & 0xFF) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G') return "image/png";
        if (b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') {
            return "image/webp";
        }
        return null;
    }

    private static String sha256(byte[] bytes) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        } catch (Exception e) {
            return null;
        }
    }
}
