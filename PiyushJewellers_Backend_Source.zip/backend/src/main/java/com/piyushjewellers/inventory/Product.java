package com.piyushjewellers.inventory;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Inventory master. Current gross/less/net weight and pieces are a materialized balance that only changes
 * together with an immutable {@link StockMovement} row in the same database transaction.
 */
@Getter
@Setter
@Entity
@Table(name = "products", indexes = {
        @Index(name = "idx_product_name", columnList = "name"),
        @Index(name = "idx_product_category", columnList = "category,metal")
})
public class Product extends BaseEntity {

    public enum Category { FINISHED_JEWELLERY, GOLD, SILVER, RAW_METAL }

    @Column(nullable = false, unique = true, length = 40)
    private String code;

    @Column(nullable = false, length = 150)
    private String name;

    @Column(length = 1000)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private Category category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.Metal metal;

    @Column(length = 20)
    private String purity;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal grossWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal lessWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal netWeight = BigDecimal.ZERO;

    @Column(nullable = false)
    private int pieces;

    @Column(nullable = false)
    private boolean active = true;
}
