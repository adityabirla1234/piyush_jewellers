package com.piyushjewellers.inventory;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryRepositories.ProductRepository productRepo;
    private final InventoryRepositories.StockMovementRepository movementRepo;
    private final InventoryRepositories.ProductImageRepository imageRepo;
    private final AuditService auditService;

    public record ImageRef(Long id, String url, String thumbnailUrl) {
    }

    public record ProductDto(Long id, String code, String name, String description, Product.Category category,
                             Enums.Metal metal, String purity, BigDecimal grossWeight, BigDecimal lessWeight,
                             BigDecimal netWeight, int pieces, String availability, ImageRef primaryImage,
                             long imageCount, Long version, Instant updatedAt) {
    }

    public record ProductRequest(@Size(max = 40) String code, @NotBlank @Size(max = 150) String name,
                                 @Size(max = 1000) String description, @NotNull Product.Category category,
                                 @NotNull Enums.Metal metal, @Size(max = 20) String purity,
                                 @DecimalMin("0") BigDecimal openingGrossWeight, @DecimalMin("0") BigDecimal openingLessWeight,
                                 @DecimalMin("0") BigDecimal openingNetWeight, @Min(0) Integer openingPieces,
                                 Long version) {
    }

    public record StockOperationRequest(@NotNull StockMovement.Type type, BigDecimal grossWeight, BigDecimal lessWeight,
                                        BigDecimal netWeight, Integer pieces, @NotBlank @Size(max = 300) String reason,
                                        LocalDate businessDate) {
    }

    public record MovementDto(Long id, Long productId, String productName, StockMovement.Type type,
                              BigDecimal grossDelta, BigDecimal lessDelta, BigDecimal netDelta, int piecesDelta,
                              BigDecimal netAfter, int piecesAfter, String sourceType, Long sourceId, String reason,
                              LocalDate businessDate, Instant createdAt, String createdBy) {
        static MovementDto from(StockMovement m) {
            return new MovementDto(m.getId(), m.getProduct().getId(), m.getProduct().getName(), m.getType(),
                    m.getGrossDelta(), m.getLessDelta(), m.getNetDelta(), m.getPiecesDelta(), m.getNetAfter(),
                    m.getPiecesAfter(), m.getSourceType(), m.getSourceId(), m.getReason(), m.getBusinessDate(),
                    m.getCreatedAt(), m.getCreatedBy());
        }
    }

    /** Signed stock change applied atomically with its ledger row. */
    public record StockDelta(BigDecimal gross, BigDecimal less, BigDecimal net, int pieces) {
        public StockDelta negate() {
            return new StockDelta(Money.nz(gross).negate(), Money.nz(less).negate(), Money.nz(net).negate(), -pieces);
        }
    }

    @Transactional(readOnly = true)
    public PageResponse<ProductDto> search(String q, Product.Category category, Enums.Metal metal, String purity,
                                           String availability, int page, int size) {
        Page<Product> result = productRepo.search(blank(q), category, metal, blank(purity), blank(availability),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "updatedAt")));
        List<Long> ids = result.getContent().stream().map(Product::getId).toList();
        Map<Long, ProductImage> primaries = ids.isEmpty() ? Map.of()
                : imageRepo.findByProductIdInAndPrimaryImageTrue(ids).stream()
                .collect(Collectors.toMap(ProductImage::getProductId, Function.identity(), (a, b) -> a));
        Map<Long, Long> counts = ids.isEmpty() ? Map.of()
                : imageRepo.countByProductIds(ids).stream()
                .collect(Collectors.toMap(r -> (Long) r[0], r -> (Long) r[1]));
        return PageResponse.of(result, p -> toDto(p, primaries.get(p.getId()), counts.getOrDefault(p.getId(), 0L)));
    }

    @Transactional(readOnly = true)
    public ProductDto get(Long id) {
        Product p = require(id);
        List<ProductImage> images = imageRepo.findByProductIdOrderByDisplayOrderAscIdAsc(id);
        ProductImage primary = images.stream().filter(ProductImage::isPrimaryImage).findFirst()
                .orElse(images.isEmpty() ? null : images.get(0));
        return toDto(p, primary, images.size());
    }

    public Product require(Long id) {
        return productRepo.findById(id).orElseThrow(() -> ApiException.notFound("Product", id));
    }

    @Transactional
    public ProductDto create(ProductRequest r) {
        Product p = new Product();
        String code = blank(r.code());
        if (code == null) {
            code = nextCode();
        } else if (productRepo.existsByCode(code)) {
            throw ApiException.conflict("DUPLICATE_CODE", "Stock code " + code + " is already used", null);
        }
        p.setCode(code);
        applyMaster(p, r);
        productRepo.save(p);
        StockDelta opening = new StockDelta(Money.nz(r.openingGrossWeight()), Money.nz(r.openingLessWeight()),
                resolveNet(r.openingGrossWeight(), r.openingLessWeight(), r.openingNetWeight()),
                r.openingPieces() == null ? 0 : r.openingPieces());
        if (opening.net().signum() != 0 || opening.pieces() != 0 || opening.gross().signum() != 0) {
            applyMovement(p, StockMovement.Type.OPENING, opening, "PRODUCT", p.getId(), "Opening stock", LocalDate.now());
        }
        auditService.record("PRODUCT_CREATED", "Product", p.getId(), null, p.getCode());
        return get(p.getId());
    }

    /** Updates descriptive master data only; quantities and weights change exclusively through stock movements. */
    @Transactional
    public ProductDto update(Long id, ProductRequest r) {
        Product p = require(id);
        if (r.version() != null && !r.version().equals(p.getVersion())) {
            throw ApiException.conflict("VERSION_CONFLICT", "This product was changed elsewhere. Reload and retry.", null);
        }
        String code = blank(r.code());
        if (code != null && !code.equals(p.getCode())) {
            if (productRepo.existsByCode(code)) {
                throw ApiException.conflict("DUPLICATE_CODE", "Stock code " + code + " is already used", null);
            }
            p.setCode(code);
        }
        applyMaster(p, r);
        productRepo.saveAndFlush(p);
        auditService.record("PRODUCT_UPDATED", "Product", p.getId(), null, p.getCode());
        return get(id);
    }

    @Transactional
    public MovementDto manualOperation(Long productId, StockOperationRequest r) {
        Product p = require(productId);
        BigDecimal gross = Money.nz(r.grossWeight());
        BigDecimal less = Money.nz(r.lessWeight());
        BigDecimal net = resolveNet(r.grossWeight(), r.lessWeight(), r.netWeight());
        int pieces = r.pieces() == null ? 0 : r.pieces();
        StockDelta delta = switch (r.type()) {
            case ADDITION, RETURN, PURCHASE -> new StockDelta(gross.abs(), less.abs(), net.abs(), Math.abs(pieces));
            case DEDUCTION, SALE -> new StockDelta(gross.abs(), less.abs(), net.abs(), Math.abs(pieces)).negate();
            case ADJUSTMENT -> new StockDelta(gross, less, net, pieces);
            default -> throw ApiException.validation("Use the originating module for " + r.type() + " movements");
        };
        StockMovement m = applyMovement(p, r.type(), delta, "MANUAL", null, r.reason(),
                r.businessDate() == null ? LocalDate.now() : r.businessDate());
        auditService.record("STOCK_" + r.type(), "Product", p.getId(), r.reason(), "net " + delta.net() + ", pcs " + delta.pieces());
        return MovementDto.from(m);
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public StockMovement applyMovement(Product p, StockMovement.Type type, StockDelta d, String sourceType,
                                       Long sourceId, String reason, LocalDate businessDate) {
        BigDecimal newGross = p.getGrossWeight().add(Money.nz(d.gross()));
        BigDecimal newLess = p.getLessWeight().add(Money.nz(d.less()));
        BigDecimal newNet = p.getNetWeight().add(Money.nz(d.net()));
        int newPieces = p.getPieces() + d.pieces();
        if (newNet.signum() < 0 || newPieces < 0 || newGross.signum() < 0) {
            throw ApiException.conflict("INSUFFICIENT_STOCK",
                    "Not enough stock for " + p.getName() + " (" + p.getCode() + "). Available: "
                            + p.getNetWeight().stripTrailingZeros().toPlainString() + " g, " + p.getPieces() + " pcs",
                    Map.of("productId", p.getId(), "availableNet", p.getNetWeight(), "availablePieces", p.getPieces()));
        }
        p.setGrossWeight(Money.weight(newGross));
        p.setLessWeight(Money.weight(newLess.max(BigDecimal.ZERO)));
        p.setNetWeight(Money.weight(newNet));
        p.setPieces(newPieces);
        StockMovement m = new StockMovement();
        m.setProduct(p);
        m.setType(type);
        m.setGrossDelta(Money.weight(d.gross()));
        m.setLessDelta(Money.weight(d.less()));
        m.setNetDelta(Money.weight(d.net()));
        m.setPiecesDelta(d.pieces());
        m.setNetAfter(p.getNetWeight());
        m.setPiecesAfter(p.getPieces());
        m.setSourceType(sourceType);
        m.setSourceId(sourceId);
        m.setReason(reason);
        m.setBusinessDate(businessDate == null ? LocalDate.now() : businessDate);
        productRepo.save(p);
        return movementRepo.save(m);
    }

    /** Reverses every movement written for a source document (bill, exchange) with opposite ledger rows. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void reverseMovementsFor(String sourceType, Long sourceId, String reason) {
        for (StockMovement m : movementRepo.findBySourceTypeAndSourceId(sourceType, sourceId)) {
            if (m.getType() == StockMovement.Type.REVERSAL) continue;
            StockDelta opposite = new StockDelta(m.getGrossDelta(), m.getLessDelta(), m.getNetDelta(), m.getPiecesDelta()).negate();
            applyMovement(m.getProduct(), StockMovement.Type.REVERSAL, opposite, sourceType, sourceId,
                    "Reversal: " + reason, LocalDate.now());
        }
    }

    @Transactional(readOnly = true)
    public PageResponse<MovementDto> movements(Long productId, int page, int size) {
        require(productId);
        return PageResponse.of(movementRepo.findByProductIdOrderByIdDesc(productId,
                PageResponse.pageable(page, size, Sort.unsorted())), MovementDto::from);
    }

    @Transactional(readOnly = true)
    public List<MovementDto> movementsForSource(String sourceType, Long sourceId) {
        return movementRepo.findBySourceTypeAndSourceId(sourceType, sourceId).stream().map(MovementDto::from).toList();
    }

    @Transactional
    public Product createFromDocument(String name, Product.Category category, Enums.Metal metal, String purity, String description) {
        Product p = new Product();
        p.setCode(nextCode());
        p.setName(name.trim());
        p.setCategory(category);
        p.setMetal(metal);
        p.setPurity(blank(purity));
        p.setDescription(blank(description));
        productRepo.save(p);
        auditService.record("PRODUCT_CREATED", "Product", p.getId(), null, p.getCode());
        return p;
    }

    private String nextCode() {
        long n = productRepo.count() + 1;
        String code;
        do {
            code = String.format("PJ-%05d", n++);
        } while (productRepo.existsByCode(code));
        return code;
    }

    private void applyMaster(Product p, ProductRequest r) {
        p.setName(r.name().trim());
        p.setDescription(blank(r.description()));
        p.setCategory(r.category());
        p.setMetal(r.metal());
        p.setPurity(blank(r.purity()));
    }

    static BigDecimal resolveNet(BigDecimal gross, BigDecimal less, BigDecimal net) {
        if (net != null) return net;
        return Money.nz(gross).subtract(Money.nz(less));
    }

    ProductDto toDto(Product p, ProductImage primary, long imageCount) {
        ImageRef ref = primary == null ? null : new ImageRef(primary.getId(),
                ProductImageService.contentUrl(primary.getId(), "full"),
                ProductImageService.contentUrl(primary.getId(), "thumb"));
        boolean inStock = p.getPieces() > 0 || p.getNetWeight().signum() > 0;
        return new ProductDto(p.getId(), p.getCode(), p.getName(), p.getDescription(), p.getCategory(), p.getMetal(),
                p.getPurity(), p.getGrossWeight(), p.getLessWeight(), p.getNetWeight(), p.getPieces(),
                inStock ? "IN_STOCK" : "OUT_OF_STOCK", ref, imageCount, p.getVersion(), p.getUpdatedAt());
    }

    private static String blank(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }
}
