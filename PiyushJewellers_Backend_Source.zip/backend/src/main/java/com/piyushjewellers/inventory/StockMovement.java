package com.piyushjewellers.inventory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

/** Immutable stock ledger row. Deltas are signed (+ adds stock, − removes stock). */
@Getter
@Setter
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "stock_movements", indexes = {
        @Index(name = "idx_movement_product", columnList = "product_id,businessDate"),
        @Index(name = "idx_movement_source", columnList = "sourceType,sourceId")
})
public class StockMovement {

    public enum Type { OPENING, ADDITION, DEDUCTION, PURCHASE, SALE, RETURN, EXCHANGE_IN, EXCHANGE_OUT, ADJUSTMENT, REVERSAL }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id")
    private Product product;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Type type;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal grossDelta;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal lessDelta;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal netDelta;

    @Column(nullable = false)
    private int piecesDelta;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal netAfter;

    @Column(nullable = false)
    private int piecesAfter;

    @Column(length = 30)
    private String sourceType;

    private Long sourceId;

    @Column(length = 300)
    private String reason;

    @Column(nullable = false)
    private LocalDate businessDate;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @CreatedBy
    @Column(length = 80, updatable = false)
    private String createdBy;
}
