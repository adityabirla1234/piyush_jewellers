package com.piyushjewellers.inventory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

@Getter
@Setter
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "bar_movements", indexes = @Index(name = "idx_barmove_lot", columnList = "bar_lot_id"))
public class BarMovement {

    public enum Type { RECEIPT, ISSUE, ADJUSTMENT, REVERSAL }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bar_lot_id")
    private BarLot barLot;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private Type type;

    /** Signed: receipt positive, issue negative. */
    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal weightDelta;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal remainingAfter;

    @Column(precision = 19, scale = 2)
    private BigDecimal rate;

    @Column(length = 30)
    private String sourceType;

    private Long sourceId;

    @Column(length = 300)
    private String reason;

    @Column(nullable = false)
    private LocalDate businessDate;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @CreatedBy
    @Column(length = 80, updatable = false)
    private String createdBy;
}
