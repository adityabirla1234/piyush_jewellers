package com.piyushjewellers.inventory;

import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URI;
import java.util.List;
import java.util.concurrent.TimeUnit;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class InventoryController {

    private final InventoryService inventoryService;
    private final ProductImageService imageService;
    private final BarLotService barLotService;
    private final FileStorage storage;

    public record ReorderRequest(List<Long> imageIds) {
    }

    public record BarAdjustRequest(BigDecimal weightDelta, String reason) {
    }

    @GetMapping("/products")
    public PageResponse<InventoryService.ProductDto> search(@RequestParam(required = false) String q,
                                                            @RequestParam(required = false) Product.Category category,
                                                            @RequestParam(required = false) Enums.Metal metal,
                                                            @RequestParam(required = false) String purity,
                                                            @RequestParam(required = false) String availability,
                                                            @RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "30") int size) {
        return inventoryService.search(q, category, metal, purity, availability, page, size);
    }

    @GetMapping("/products/{id}")
    public InventoryService.ProductDto get(@PathVariable Long id) {
        return inventoryService.get(id);
    }

    @PostMapping("/products")
    @ResponseStatus(HttpStatus.CREATED)
    public InventoryService.ProductDto create(@Valid @RequestBody InventoryService.ProductRequest request) {
        return inventoryService.create(request);
    }

    @PutMapping("/products/{id}")
    public InventoryService.ProductDto update(@PathVariable Long id, @Valid @RequestBody InventoryService.ProductRequest request) {
        return inventoryService.update(id, request);
    }

    @GetMapping("/products/{id}/movements")
    public PageResponse<InventoryService.MovementDto> movements(@PathVariable Long id,
                                                                @RequestParam(defaultValue = "0") int page,
                                                                @RequestParam(defaultValue = "30") int size) {
        return inventoryService.movements(id, page, size);
    }

    @PostMapping("/products/{id}/movements")
    @ResponseStatus(HttpStatus.CREATED)
    public InventoryService.MovementDto stockOperation(@PathVariable Long id,
                                                       @Valid @RequestBody InventoryService.StockOperationRequest request) {
        return inventoryService.manualOperation(id, request);
    }

    // ---- Photos ----

    @GetMapping("/products/{id}/images")
    public List<ProductImageService.ImageDto> images(@PathVariable Long id) {
        return imageService.list(id);
    }

    @PostMapping(value = "/products/{id}/images", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public ProductImageService.ImageDto upload(@PathVariable Long id, @RequestPart("file") MultipartFile file) throws IOException {
        return imageService.upload(id, file);
    }

    @PutMapping("/products/{id}/images/order")
    public List<ProductImageService.ImageDto> reorder(@PathVariable Long id, @RequestBody ReorderRequest request) {
        return imageService.reorder(id, request.imageIds());
    }

    @PutMapping("/products/{id}/images/{imageId}/primary")
    public List<ProductImageService.ImageDto> primary(@PathVariable Long id, @PathVariable Long imageId) {
        return imageService.setPrimary(id, imageId);
    }

    @DeleteMapping("/products/{id}/images/{imageId}")
    public List<ProductImageService.ImageDto> delete(@PathVariable Long id, @PathVariable Long imageId) {
        return imageService.delete(id, imageId);
    }

    @GetMapping("/images/{imageId}/content")
    public ResponseEntity<InputStreamResource> content(@PathVariable Long imageId,
                                                       @RequestParam(defaultValue = "full") String variant) throws IOException {
        ProductImageService.StoredContent content = imageService.content(imageId, variant);
        if (content.redirectUrl() != null) {
            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(URI.create(content.redirectUrl()))
                    .cacheControl(CacheControl.maxAge(30, TimeUnit.DAYS).cachePrivate())
                    .build();
        }
        if (content.key() == null || !storage.exists(content.key())) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok()
                .cacheControl(CacheControl.maxAge(30, TimeUnit.DAYS).cachePrivate())
                .contentType(MediaType.parseMediaType(content.contentType()))
                .contentLength(storage.size(content.key()))
                .body(new InputStreamResource(storage.open(content.key())));
    }

    // ---- MR Biscuit bar lots ----

    @GetMapping("/bar-lots")
    public List<BarLotService.BarLotDto> barLots(@RequestParam(required = false) Enums.Metal metal,
                                                 @RequestParam(defaultValue = "false") boolean availableOnly) {
        return barLotService.list(metal, availableOnly);
    }

    @PostMapping("/bar-lots")
    @ResponseStatus(HttpStatus.CREATED)
    public BarLotService.BarLotDto createLot(@Valid @RequestBody BarLotService.BarLotRequest request) {
        return barLotService.create(request);
    }

    @GetMapping("/bar-lots/{id}/movements")
    public List<BarLotService.BarMovementDto> lotMovements(@PathVariable Long id) {
        return barLotService.movements(id);
    }

    @PostMapping("/bar-lots/{id}/adjust")
    public BarLotService.BarLotDto adjustLot(@PathVariable Long id, @RequestBody BarAdjustRequest request) {
        return barLotService.adjust(id, request.weightDelta(), request.reason());
    }
}
