package com.piyushjewellers.people;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.PageResponse;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class PersonService {

    private final PersonRepository repository;
    private final AuditService auditService;

    public record PersonDto(Long id, String name, String phone, String alternatePhone, String address,
                            String idReference, String notes, boolean customer, boolean supplier, boolean dealer,
                            Long version, Instant createdAt, Instant updatedAt) {
        public static PersonDto from(Person p) {
            return new PersonDto(p.getId(), p.getName(), p.getPhone(), p.getAlternatePhone(), p.getAddress(),
                    p.getIdReference(), p.getNotes(), p.isCustomer(), p.isSupplier(), p.isDealer(),
                    p.getVersion(), p.getCreatedAt(), p.getUpdatedAt());
        }
    }

    public record PersonRequest(@NotBlank @Size(max = 150) String name, @Size(max = 30) String phone,
                                @Size(max = 30) String alternatePhone, @Size(max = 400) String address,
                                @Size(max = 120) String idReference, @Size(max = 1000) String notes,
                                boolean customer, boolean supplier, Long version, boolean allowDuplicatePhone) {
    }

    /** Keeps the last 10 digits so "+91 98765-43210" and "09876543210" match. Never merges on name alone. */
    public static String normalizePhone(String phone) {
        if (phone == null) return null;
        String digits = phone.replaceAll("\\D", "");
        if (digits.isEmpty()) return null;
        return digits.length() > 10 ? digits.substring(digits.length() - 10) : digits;
    }

    @Transactional(readOnly = true)
    public PageResponse<PersonDto> search(String q, String type, int page, int size) {
        String query = (q == null || q.isBlank()) ? null : q.trim();
        if (query != null && query.replaceAll("\\D", "").length() >= 4 && query.matches("[\\d+\\-\\s()]+")) {
            query = normalizePhone(query);
        }
        return PageResponse.of(repository.search(query, type, PageResponse.pageable(page, size, Sort.by("name"))),
                PersonDto::from);
    }

    @Transactional(readOnly = true)
    public PersonDto get(Long id) {
        return PersonDto.from(require(id));
    }

    @Transactional(readOnly = true)
    public Person require(Long id) {
        return repository.findById(id).orElseThrow(() -> ApiException.notFound("Person", id));
    }

    @Transactional
    public PersonDto create(PersonRequest request) {
        Person person = new Person();
        apply(person, request);
        checkDuplicate(person, request.allowDuplicatePhone());
        repository.save(person);
        auditService.record("PERSON_CREATED", "Person", person.getId(), null, person.getName());
        return PersonDto.from(person);
    }

    @Transactional
    public PersonDto update(Long id, PersonRequest request) {
        Person person = require(id);
        if (request.version() != null && !request.version().equals(person.getVersion())) {
            throw ApiException.conflict("VERSION_CONFLICT", "This person was changed elsewhere. Reload and retry.", null);
        }
        String oldPhone = person.getNormalizedPhone();
        apply(person, request);
        if (person.getNormalizedPhone() != null && !person.getNormalizedPhone().equals(oldPhone)) {
            checkDuplicate(person, request.allowDuplicatePhone());
        }
        repository.saveAndFlush(person);
        auditService.record("PERSON_UPDATED", "Person", person.getId(), null, person.getName());
        return PersonDto.from(person);
    }

    /** Used by dealer / mortgage modules to create a linked identity in the same transaction. */
    @Transactional
    public Person createInternal(String name, String phone, String address, String idReference, boolean dealer) {
        String normalized = normalizePhone(phone);
        if (normalized != null) {
            List<Person> matches = repository.findByNormalizedPhone(normalized);
            for (Person match : matches) {
                if (match.getName().equalsIgnoreCase(name.trim())) {
                    if (dealer) match.setDealer(true);
                    return match;
                }
            }
        }
        Person p = new Person();
        p.setName(name.trim());
        p.setPhone(phone);
        p.setNormalizedPhone(normalized);
        p.setAddress(address);
        p.setIdReference(idReference);
        p.setDealer(dealer);
        p.setCustomer(!dealer);
        repository.save(p);
        auditService.record("PERSON_CREATED", "Person", p.getId(), null, p.getName());
        return p;
    }

    private void checkDuplicate(Person person, boolean allowDuplicate) {
        if (allowDuplicate || person.getNormalizedPhone() == null) return;
        repository.findByNormalizedPhone(person.getNormalizedPhone()).stream()
                .filter(p -> !p.getId().equals(person.getId()))
                .findFirst()
                .ifPresent(existing -> {
                    throw ApiException.conflict("DUPLICATE_CONTACT",
                            "Another person already uses this phone number: " + existing.getName(),
                            Map.of("existingPersonId", existing.getId(), "existingPersonName", existing.getName()));
                });
    }

    private void apply(Person person, PersonRequest r) {
        person.setName(r.name().trim());
        person.setPhone(blankToNull(r.phone()));
        person.setNormalizedPhone(normalizePhone(r.phone()));
        person.setAlternatePhone(blankToNull(r.alternatePhone()));
        person.setAddress(blankToNull(r.address()));
        person.setIdReference(blankToNull(r.idReference()));
        person.setNotes(blankToNull(r.notes()));
        person.setCustomer(r.customer() || (!r.supplier() && !person.isDealer()));
        person.setSupplier(r.supplier());
    }

    private static String blankToNull(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }
}
