package com.piyushjewellers.people;

import com.piyushjewellers.common.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * Shared person identity for customers, suppliers, dealers, borrowers/lenders and mortgage customers,
 * so every activity of one person appears in a single Due Management account.
 */
@Getter
@Setter
@Entity
@Table(name = "persons", indexes = {
        @Index(name = "idx_person_name", columnList = "name"),
        @Index(name = "idx_person_phone", columnList = "normalizedPhone")
})
public class Person extends BaseEntity {

    @Column(nullable = false, length = 150)
    private String name;

    @Column(length = 30)
    private String phone;

    @Column(length = 15)
    private String normalizedPhone;

    @Column(length = 30)
    private String alternatePhone;

    @Column(length = 400)
    private String address;

    @Column(length = 120)
    private String idReference;

    @Column(length = 1000)
    private String notes;

    @Column(nullable = false)
    private boolean customer;

    @Column(nullable = false)
    private boolean supplier;

    @Column(nullable = false)
    private boolean dealer;

    @Column(nullable = false)
    private boolean active = true;
}
