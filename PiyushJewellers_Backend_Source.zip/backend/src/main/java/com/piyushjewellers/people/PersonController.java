package com.piyushjewellers.people;

import com.piyushjewellers.common.PageResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/people")
@RequiredArgsConstructor
public class PersonController {

    private final PersonService service;

    @GetMapping
    public PageResponse<PersonService.PersonDto> search(@RequestParam(required = false) String q,
                                                        @RequestParam(required = false) String type,
                                                        @RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "30") int size) {
        return service.search(q, type, page, size);
    }

    @GetMapping("/{id}")
    public PersonService.PersonDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PersonService.PersonDto create(@Valid @RequestBody PersonService.PersonRequest request) {
        return service.create(request);
    }

    @PutMapping("/{id}")
    public PersonService.PersonDto update(@PathVariable Long id, @Valid @RequestBody PersonService.PersonRequest request) {
        return service.update(id, request);
    }
}
