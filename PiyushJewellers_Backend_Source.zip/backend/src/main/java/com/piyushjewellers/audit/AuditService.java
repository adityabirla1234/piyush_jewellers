package com.piyushjewellers.audit;

import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.security.CurrentUser;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditEventRepository repository;

    /** Joins the caller's transaction so the audit row commits atomically with the business change. */
    @Transactional(propagation = Propagation.MANDATORY)
    public void record(String action, String entityType, Long entityId, String reason, String details) {
        AuditEvent event = new AuditEvent();
        event.setActor(CurrentUser.username());
        event.setAction(action);
        event.setEntityType(entityType);
        event.setEntityId(entityId);
        event.setReason(truncate(reason, 500));
        event.setDetails(truncate(details, 2000));
        event.setOccurredAt(Instant.now());
        repository.save(event);
    }

    @Transactional(readOnly = true)
    public PageResponse<AuditEventDto> list(String entityType, Long entityId, int page, int size) {
        Pageable pageable = PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "occurredAt"));
        Page<AuditEvent> result = (entityType != null && entityId != null)
                ? repository.findByEntityTypeAndEntityId(entityType, entityId, pageable)
                : repository.findAll(pageable);
        return PageResponse.of(result, AuditEventDto::from);
    }

    private static String truncate(String value, int max) {
        if (value == null) return null;
        return value.length() <= max ? value : value.substring(0, max);
    }

    public record AuditEventDto(Long id, String actor, String action, String entityType, Long entityId,
                                String reason, String details, Instant occurredAt) {
        static AuditEventDto from(AuditEvent e) {
            return new AuditEventDto(e.getId(), e.getActor(), e.getAction(), e.getEntityType(), e.getEntityId(),
                    e.getReason(), e.getDetails(), e.getOccurredAt());
        }
    }
}
