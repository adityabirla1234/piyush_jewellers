package com.piyushjewellers.security;

import java.security.Principal;

public record AuthPrincipal(String username, String fullName) implements Principal {

    @Override
    public String getName() {
        return username;
    }

    public String auditorName() {
        if (fullName != null && !fullName.isBlank()) {
            return fullName.trim();
        }
        return username;
    }
}
