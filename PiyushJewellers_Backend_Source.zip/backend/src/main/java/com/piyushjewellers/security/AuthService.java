package com.piyushjewellers.security;

import com.piyushjewellers.common.ApiException;
import lombok.RequiredArgsConstructor;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.HexFormat;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepositories.AppUserRepository userRepository;
    private final UserRepositories.RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final SecurityProperties properties;
    private final SecureRandom random = new SecureRandom();

    public record UserDto(Long id, String username, String fullName, String role) {
        static UserDto from(AppUser u) {
            return new UserDto(u.getId(), u.getUsername(), u.getFullName(), u.getRole().name());
        }
    }

    public record TokenResponse(String accessToken, String refreshToken, long expiresInSeconds, UserDto user) {
    }

    @Transactional
    public TokenResponse login(String username, String password) {
        AppUser user = userRepository.findByUsernameIgnoreCase(username.trim())
                .filter(AppUser::isActive)
                .orElseThrow(() -> new BadCredentialsException("invalid"));
        if (!passwordEncoder.matches(password, user.getPasswordHash())) {
            throw new BadCredentialsException("invalid");
        }
        return issue(user);
    }

    @Transactional
    public TokenResponse refresh(String rawRefreshToken) {
        RefreshToken token = refreshTokenRepository.findByTokenHash(hash(rawRefreshToken))
                .filter(t -> !t.isRevoked() && t.getExpiresAt().isAfter(Instant.now()))
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "UNAUTHENTICATED",
                        "Session expired. Please sign in again.", null));
        token.setRevoked(true);
        AppUser user = token.getUser();
        if (!user.isActive()) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "UNAUTHENTICATED", "Account disabled", null);
        }
        return issue(user);
    }

    @Transactional
    public void logout(String rawRefreshToken) {
        if (rawRefreshToken == null || rawRefreshToken.isBlank()) return;
        refreshTokenRepository.findByTokenHash(hash(rawRefreshToken)).ifPresent(t -> t.setRevoked(true));
    }

    @Transactional(readOnly = true)
    public UserDto me(String username) {
        return userRepository.findByUsernameIgnoreCase(username).map(UserDto::from)
                .orElseThrow(() -> ApiException.notFound("User", username));
    }

    public record ProfileRequest(@NotBlank @Size(max = 120) String fullName) {
    }

    public record ProfileUpdateResponse(UserDto user, String accessToken) {
    }

    @Transactional
    public ProfileUpdateResponse updateProfile(String username, ProfileRequest request) {
        AppUser user = userRepository.findByUsernameIgnoreCase(username)
                .orElseThrow(() -> ApiException.notFound("User", username));
        String name = request.fullName().trim();
        if (name.isEmpty()) {
            throw ApiException.validation("Enter your display name");
        }
        user.setFullName(name);
        return new ProfileUpdateResponse(UserDto.from(user), jwtService.issueAccessToken(user));
    }

    private TokenResponse issue(AppUser user) {
        byte[] bytes = new byte[48];
        random.nextBytes(bytes);
        String raw = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        RefreshToken token = new RefreshToken();
        token.setUser(user);
        token.setTokenHash(hash(raw));
        token.setCreatedAt(Instant.now());
        token.setExpiresAt(Instant.now().plus(properties.refreshTokenDays(), ChronoUnit.DAYS));
        refreshTokenRepository.save(token);
        return new TokenResponse(jwtService.issueAccessToken(user), raw, jwtService.accessTokenSeconds(), UserDto.from(user));
    }

    static String hash(String raw) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest(raw.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
