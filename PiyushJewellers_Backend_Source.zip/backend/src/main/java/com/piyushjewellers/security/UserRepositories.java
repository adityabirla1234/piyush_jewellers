package com.piyushjewellers.security;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepositories {

    interface AppUserRepository extends JpaRepository<AppUser, Long> {
        Optional<AppUser> findByUsernameIgnoreCase(String username);
    }

    interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {
        Optional<RefreshToken> findByTokenHash(String tokenHash);
    }
}
