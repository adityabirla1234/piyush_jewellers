package com.piyushjewellers.security;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Creates the initial owner account from environment variables when no user exists.
 * This is application code, not an SQL initialization script; credentials are never hardcoded.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class AdminBootstrap implements ApplicationRunner {

    private final UserRepositories.AppUserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${pj.bootstrap.admin-username:}")
    private String username;
    @Value("${pj.bootstrap.admin-password:}")
    private String password;
    @Value("${pj.bootstrap.admin-full-name:Shop Owner}")
    private String fullName;

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (userRepository.count() > 0) {
            return;
        }
        if (username == null || username.isBlank() || password == null || password.length() < 8) {
            log.warn("No users exist. Set PJ_ADMIN_USERNAME and PJ_ADMIN_PASSWORD (min 8 chars) to create the owner account.");
            return;
        }
        AppUser user = new AppUser();
        user.setUsername(username.trim());
        user.setPasswordHash(passwordEncoder.encode(password));
        user.setFullName(fullName);
        user.setRole(AppUser.Role.OWNER);
        userRepository.save(user);
        log.info("Owner account created for configured username.");
    }
}
