package com.piyushjewellers.security;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "pj.security")
public record SecurityProperties(String jwtSecret, long accessTokenMinutes, long refreshTokenDays) {
}
