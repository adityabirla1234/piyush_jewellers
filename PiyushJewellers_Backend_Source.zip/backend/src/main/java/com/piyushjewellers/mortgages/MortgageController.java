package com.piyushjewellers.mortgages;

import com.piyushjewellers.common.PageResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class MortgageController {

    private final MortgageService service;

    @GetMapping("/mortgage-accounts")
    public PageResponse<MortgageService.AccountDto> accounts(@RequestParam(required = false) String q,
                                                             @RequestParam(defaultValue = "0") int page,
                                                             @RequestParam(defaultValue = "30") int size) {
        return service.searchAccounts(q, page, size);
    }

    @GetMapping("/mortgage-accounts/{id}")
    public MortgageService.AccountDto account(@PathVariable Long id) {
        return service.getAccount(id);
    }

    @PostMapping("/mortgage-accounts")
    @ResponseStatus(HttpStatus.CREATED)
    public MortgageService.AccountDto createAccount(@Valid @RequestBody MortgageService.AccountRequest request) {
        return service.createAccount(request);
    }

    @GetMapping("/mortgages")
    public PageResponse<MortgageService.MortgageDto> search(@RequestParam(required = false) Mortgage.Kind kind,
                                                            @RequestParam(required = false) Mortgage.Status status,
                                                            @RequestParam(required = false) Long accountId,
                                                            @RequestParam(required = false) Long personId,
                                                            @RequestParam(required = false) String q,
                                                            @RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "30") int size) {
        return service.search(kind, status, accountId, personId, q, page, size);
    }

    @GetMapping("/mortgages/{id}")
    public MortgageService.MortgageDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping("/mortgages")
    @ResponseStatus(HttpStatus.CREATED)
    public MortgageService.MortgageDto create(@Valid @RequestBody MortgageService.MortgageRequest request) {
        return service.create(request);
    }

    @PostMapping("/mortgages/{id}/calculate-interest")
    public MortgageService.CalculationDto calculate(@PathVariable Long id,
                                                    @RequestBody(required = false) MortgageService.CalculateRequest request) {
        return service.calculateInterest(id, request == null ? null : request.effectiveThrough());
    }

    @PostMapping("/mortgages/{id}/payments")
    public MortgageService.MortgageDto pay(@PathVariable Long id, @Valid @RequestBody MortgageService.PaymentRequest request) {
        return service.addPayment(id, request);
    }

    @PostMapping("/mortgages/{id}/full-final")
    public MortgageService.FullFinalResult fullFinal(@PathVariable Long id,
                                                     @Valid @RequestBody MortgageService.FullFinalRequest request) {
        return service.fullAndFinal(id, request);
    }

    @PostMapping("/mortgages/{id}/jewellery-return")
    public MortgageService.MortgageDto jewelleryReturn(@PathVariable Long id,
                                                       @Valid @RequestBody MortgageService.JewelleryReturnRequest request) {
        return service.recordJewelleryReturn(id, request);
    }

    @PutMapping("/mortgages/{id}/reminder-date")
    public MortgageService.MortgageDto reminderDate(@PathVariable Long id, @RequestBody MortgageService.ReminderDateRequest request) {
        return service.updateReminderDate(id, request.approxReminderDate());
    }
}
