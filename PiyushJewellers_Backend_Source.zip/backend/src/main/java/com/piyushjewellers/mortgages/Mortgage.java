package com.piyushjewellers.mortgages;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/** One independently tracked jewellery pledge or cash mortgage. */
@Getter
@Setter
@Entity
@Table(name = "mortgages", indexes = {
        @Index(name = "idx_mortgage_account", columnList = "account_id,status"),
        @Index(name = "idx_mortgage_reminder", columnList = "approxReminderDate")
})
public class Mortgage extends BaseEntity {

    public enum Kind { JEWELLERY, CASH }

    public enum Status { ACTIVE, PAID }

    @Column(nullable = false, unique = true, length = 30)
    private String serial;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "account_id")
    private MortgageAccount account;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Kind kind;

    @Column(nullable = false)
    private LocalDate issueDate;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal principal;

    /** Monthly interest rate in percent, e.g. 2.00 = 2% per month. */
    @Column(nullable = false, precision = 7, scale = 4)
    private BigDecimal monthlyRate;

    /** Follow-up reminder only; not a legal due date nor proof of payment. */
    private LocalDate approxReminderDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Status status = Status.ACTIVE;

    @Column(length = 200)
    private String jewelleryName;

    @Column(precision = 19, scale = 4)
    private BigDecimal netWeight;

    private Integer pieces;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private Enums.Metal metal;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.PaymentMethod issueMethod;

    @Column(length = 1000)
    private String notes;

    private Long issueTransactionId;

    @Column(nullable = false)
    private boolean fullPaymentConfirmed;

    private LocalDate settledDate;

    @Column(nullable = false)
    private boolean jewelleryReturned;

    private LocalDate jewelleryReturnDate;

    @Column(length = 150)
    private String jewelleryReturnedTo;

    @Column(length = 500)
    private String jewelleryReturnNotes;

    @OneToMany(mappedBy = "mortgage", cascade = CascadeType.ALL)
    @OrderBy("paymentDate ASC, id ASC")
    private List<MortgagePayment> payments = new ArrayList<>();

    @OneToMany(mappedBy = "mortgage", cascade = CascadeType.ALL)
    @OrderBy("id DESC")
    private List<InterestCalculation> calculations = new ArrayList<>();
}
