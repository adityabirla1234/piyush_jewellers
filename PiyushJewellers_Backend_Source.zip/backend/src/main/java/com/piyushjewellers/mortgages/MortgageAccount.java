package com.piyushjewellers.mortgages;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.people.Person;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/** Mortgage customer account with a unique auto-generated serial; holds many independent pledges. */
@Getter
@Setter
@Entity
@Table(name = "mortgage_accounts")
public class MortgageAccount extends BaseEntity {

    @Column(nullable = false, unique = true, length = 20)
    private String serial;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "person_id", unique = true)
    private Person person;

    @Column(length = 300)
    private String reference;
}
