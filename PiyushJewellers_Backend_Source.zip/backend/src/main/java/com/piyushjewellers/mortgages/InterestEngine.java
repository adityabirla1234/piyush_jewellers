package com.piyushjewellers.mortgages;

import com.piyushjewellers.common.Money;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * Mortgage interest engine (binding rules):
 * - Rate is monthly. Simple interest within each year.
 * - After every complete unpaid year, accrued interest is capitalized into the interest-bearing principal.
 * - Incomplete months are prorated by actual elapsed days over the actual number of days in each calendar month.
 * <p>
 * Deterministic boundary policy used here (surfaced as policy notes for owner confirmation):
 * - Interest accrues from the issue date; the issue day itself is not charged (elapsed days = effectiveThrough − issueDate).
 * - Years and months are counted on issue-date anniversaries (e.g. 31 Jan + 1 month = 28/29 Feb).
 * - The remaining partial month is split by calendar month, each part ÷ that month's length (leap years included).
 * - Each period's interest is rounded HALF_UP to 2 decimals; capitalization uses the rounded value.
 * - Dates are business dates in Asia/Kolkata; no time-of-day component.
 * Pure function: recomputed from the issue date every time, so a period can never be capitalized twice.
 */
public final class InterestEngine {

    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);

    public static final List<String> POLICY_NOTES = List.of(
            "Interest starts accruing from the issue date; the issue day itself is not charged.",
            "Years and months are counted on issue-date anniversaries.",
            "Incomplete months are prorated by actual days over the actual length of each calendar month.",
            "Unpaid interest is capitalized at each completed year; later interest is on principal plus capitalized interest.",
            "Each period is rounded half-up to 2 decimals.",
            "Payments received are subtracted from the total due; interest/principal allocation of payments is not applied (owner to confirm policy)."
    );

    private InterestEngine() {
    }

    public record Period(int index, LocalDate from, LocalDate to, BigDecimal openingPrincipal, int fullMonths,
                         long extraDays, String prorationDetail, BigDecimal interest, boolean completedYear,
                         BigDecimal capitalizedAfter) {
    }

    public record Result(BigDecimal originalPrincipal, BigDecimal monthlyRate, LocalDate issueDate,
                         LocalDate effectiveThrough, long elapsedDays, BigDecimal totalInterest,
                         BigDecimal capitalizedPrincipal, BigDecimal currentPeriodInterest, BigDecimal totalDue,
                         List<Period> periods) {
    }

    public static Result calculate(BigDecimal principal, BigDecimal monthlyRatePercent, LocalDate issueDate, LocalDate effectiveThrough) {
        if (principal == null || principal.signum() <= 0) throw new IllegalArgumentException("Principal must be positive");
        if (monthlyRatePercent == null || monthlyRatePercent.signum() < 0) throw new IllegalArgumentException("Rate must be zero or positive");
        if (effectiveThrough.isBefore(issueDate)) throw new IllegalArgumentException("Effective date is before the issue date");

        BigDecimal monthlyFactor = monthlyRatePercent.divide(HUNDRED, Money.CALC_SCALE, Money.ROUNDING);
        BigDecimal p = Money.money(principal);
        BigDecimal totalInterest = BigDecimal.ZERO;
        BigDecimal currentPeriodInterest = BigDecimal.ZERO;
        List<Period> periods = new ArrayList<>();

        int year = 0;
        while (true) {
            LocalDate yearStart = issueDate.plusYears(year);
            LocalDate yearEnd = issueDate.plusYears(year + 1L);
            if (!yearEnd.isAfter(effectiveThrough)) {
                BigDecimal interest = Money.money(p.multiply(monthlyFactor).multiply(BigDecimal.valueOf(12)));
                totalInterest = totalInterest.add(interest);
                BigDecimal capitalized = Money.money(p.add(interest));
                periods.add(new Period(year + 1, yearStart, yearEnd, p, 12, 0, "Full year (12 months)", interest, true, capitalized));
                p = capitalized;
                year++;
                continue;
            }
            // Final, incomplete year.
            int months = 0;
            while (!issueDate.plusYears(year).plusMonths(months + 1L).isAfter(effectiveThrough)) {
                months++;
            }
            LocalDate partialStart = issueDate.plusYears(year).plusMonths(months);
            BigDecimal monthFraction = BigDecimal.ZERO;
            StringBuilder detail = new StringBuilder(months + " full month(s)");
            long extraDays = ChronoUnit.DAYS.between(partialStart, effectiveThrough);
            LocalDate cursor = partialStart;
            while (cursor.isBefore(effectiveThrough)) {
                YearMonth ym = YearMonth.from(cursor);
                LocalDate monthEndExclusive = ym.atEndOfMonth().plusDays(1);
                LocalDate segmentEnd = monthEndExclusive.isBefore(effectiveThrough) ? monthEndExclusive : effectiveThrough;
                long days = ChronoUnit.DAYS.between(cursor, segmentEnd);
                int len = ym.lengthOfMonth();
                monthFraction = monthFraction.add(BigDecimal.valueOf(days).divide(BigDecimal.valueOf(len), Money.CALC_SCALE, Money.ROUNDING));
                detail.append(" + ").append(days).append("/").append(len).append(" (").append(ym).append(")");
                cursor = segmentEnd;
            }
            BigDecimal factor = BigDecimal.valueOf(months).add(monthFraction);
            BigDecimal interest = Money.money(p.multiply(monthlyFactor).multiply(factor));
            if (months > 0 || extraDays > 0) {
                periods.add(new Period(year + 1, issueDate.plusYears(year), effectiveThrough, p, months, extraDays,
                        detail.toString(), interest, false, null));
            }
            totalInterest = totalInterest.add(interest);
            currentPeriodInterest = interest;
            break;
        }
        BigDecimal totalDue = Money.money(p.add(currentPeriodInterest));
        return new Result(Money.money(principal), monthlyRatePercent, issueDate, effectiveThrough,
                ChronoUnit.DAYS.between(issueDate, effectiveThrough), Money.money(totalInterest), p,
                Money.money(currentPeriodInterest), totalDue, periods);
    }
}
