package com.piyushjewellers.mortgages;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

/** Stored, auditable interest calculation: inputs, breakdown (JSON), effective-through date and result. */
@Getter
@Setter
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "interest_calculations")
public class InterestCalculation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "mortgage_id")
    private Mortgage mortgage;

    @Column(nullable = false)
    private LocalDate effectiveThrough;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal principal;

    @Column(nullable = false, precision = 7, scale = 4)
    private BigDecimal monthlyRate;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal totalInterest;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal capitalizedPrincipal;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal totalDue;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amountReceived;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal remainingBalance;

    @Lob
    @Column(columnDefinition = "LONGTEXT", nullable = false)
    private String breakdownJson;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant calculatedAt;

    @CreatedBy
    @Column(length = 80, updatable = false)
    private String calculatedBy;
}
