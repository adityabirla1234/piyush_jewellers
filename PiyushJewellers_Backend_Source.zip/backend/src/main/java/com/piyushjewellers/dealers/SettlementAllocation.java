package com.piyushjewellers.dealers;

import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

/** One part of a settlement: an MR Biscuit bar allocation or a money payment, with its rate/value snapshot. */
@Getter
@Setter
@Entity
@Table(name = "dealer_settlement_allocations")
public class SettlementAllocation {

    public enum Kind { BAR, MONEY }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "settlement_id")
    private DealerSettlement settlement;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 6)
    private Kind kind;

    private Long barLotId;

    @Column(length = 40)
    private String barLotCode;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private Enums.Metal barMetal;

    @Column(precision = 19, scale = 4)
    private BigDecimal weight;

    @Column(precision = 19, scale = 2)
    private BigDecimal rate;

    @Column(name = "allocation_value", nullable = false, precision = 19, scale = 2)
    private BigDecimal value;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal weightEquivalent;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private Enums.PaymentMethod method;

    @Column(length = 120)
    private String reference;

    private Long transactionId;
}
