package com.piyushjewellers.dealers;

import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.enums.Enums;

import java.math.BigDecimal;

/**
 * Binding dealer formulas.
 * Gold:   final weight = net weight × (carat % + labour %) / 100   e.g. 1.440 × (84 + 4) / 100 = 1.2672 g
 * Silver: final weight = net weight × (100 + labour %) / 100       e.g. 980 × 104 / 100 = 1019.2 g
 * Valuation assumption (configurable policy): amount = final calculated weight × metal rate.
 */
public final class MetalCalculator {

    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);

    private MetalCalculator() {
    }

    public static BigDecimal netWeight(BigDecimal gross, BigDecimal less) {
        return Money.weight(Money.nz(gross).subtract(Money.nz(less)));
    }

    public static BigDecimal goldFinalWeight(BigDecimal net, Enums.Carat carat, BigDecimal labourPercent) {
        if (carat == null) throw new IllegalArgumentException("Carat is required for gold");
        BigDecimal factor = BigDecimal.valueOf(carat.percent()).add(Money.nz(labourPercent));
        return Money.weight(Money.nz(net).multiply(factor).divide(HUNDRED, Money.CALC_SCALE, Money.ROUNDING));
    }

    public static BigDecimal silverFinalWeight(BigDecimal net, BigDecimal labourPercent) {
        BigDecimal factor = HUNDRED.add(Money.nz(labourPercent));
        return Money.weight(Money.nz(net).multiply(factor).divide(HUNDRED, Money.CALC_SCALE, Money.ROUNDING));
    }

    public static BigDecimal finalWeight(Enums.Metal metal, BigDecimal net, Enums.Carat carat, BigDecimal labourPercent) {
        return metal == Enums.Metal.GOLD ? goldFinalWeight(net, carat, labourPercent) : silverFinalWeight(net, labourPercent);
    }

    public static BigDecimal amount(BigDecimal finalWeight, BigDecimal rate) {
        return Money.money(Money.nz(finalWeight).multiply(Money.nz(rate)));
    }
}
