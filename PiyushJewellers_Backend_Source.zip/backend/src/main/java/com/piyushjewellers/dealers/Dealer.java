package com.piyushjewellers.dealers;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.people.Person;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "dealers", indexes = @Index(name = "idx_dealer_name", columnList = "name"))
public class Dealer extends BaseEntity {

    @Column(nullable = false, length = 150)
    private String name;

    @Column(length = 30)
    private String phone;

    @Column(length = 400)
    private String address;

    @Column(length = 1000)
    private String notes;

    /** Stable shared identity so dealer balances appear in Due Management under one person account. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(nullable = false)
    private boolean active = true;
}
