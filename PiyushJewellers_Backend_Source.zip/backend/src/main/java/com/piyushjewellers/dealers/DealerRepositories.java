package com.piyushjewellers.dealers;

import com.piyushjewellers.common.enums.Enums;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DealerRepositories {

    interface DealerRepository extends JpaRepository<Dealer, Long> {
        @Query("""
                select d from Dealer d where d.active = true
                  and (:q is null or lower(d.name) like lower(concat('%', :q, '%')) or d.phone like concat('%', :q, '%'))
                """)
        Page<Dealer> search(String q, Pageable pageable);

        List<Dealer> findByPersonId(Long personId);
    }

    interface DealerShopRepository extends JpaRepository<DealerShop, Long> {
        List<DealerShop> findByDealerIdOrderByNameAsc(Long dealerId);

        long countByDealerId(Long dealerId);
    }

    interface DealerBillRepository extends JpaRepository<DealerBill, Long> {
        @Query("""
                select b from DealerBill b
                where (:dealerId is null or b.dealer.id = :dealerId)
                  and (:shopId is null or b.shop.id = :shopId)
                  and (:metal is null or b.metal = :metal)
                  and (:status is null or b.status = :status)
                  and (:q is null or lower(b.billNumber) like lower(concat('%', :q, '%'))
                       or lower(b.dealer.name) like lower(concat('%', :q, '%')))
                """)
        Page<DealerBill> search(Long dealerId, Long shopId, Enums.Metal metal, DealerBill.Status status, String q, Pageable pageable);

        List<DealerBill> findByDealerIdOrderByDealDateAscIdAsc(Long dealerId);

        List<DealerBill> findByStatusIn(List<DealerBill.Status> statuses);

        List<DealerBill> findByDealerPersonIdAndStatusIn(Long personId, List<DealerBill.Status> statuses);
    }

    interface DealerSettlementRepository extends JpaRepository<DealerSettlement, Long> {
    }
}
