package com.piyushjewellers.dealers;

import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.reports.PdfBuilder;
import com.piyushjewellers.settings.SettingsModule;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

import static com.piyushjewellers.reports.PdfBuilder.g;
import static com.piyushjewellers.reports.PdfBuilder.rs;
import static com.piyushjewellers.reports.PdfBuilder.s;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class DealerController {

    private final DealerService service;
    private final SettingsModule.SettingsService settingsService;

    public record ReasonRequest(String reason) {
    }

    @GetMapping("/dealers")
    public PageResponse<DealerService.DealerDto> search(@RequestParam(required = false) String q,
                                                        @RequestParam(defaultValue = "0") int page,
                                                        @RequestParam(defaultValue = "30") int size) {
        return service.search(q, page, size);
    }

    @GetMapping("/dealers/{id}")
    public DealerService.DealerDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping("/dealers")
    @ResponseStatus(HttpStatus.CREATED)
    public DealerService.DealerDto create(@Valid @RequestBody DealerService.DealerRequest request) {
        return service.create(request);
    }

    @PutMapping("/dealers/{id}")
    public DealerService.DealerDto update(@PathVariable Long id, @Valid @RequestBody DealerService.DealerRequest request) {
        return service.update(id, request);
    }

    @GetMapping("/dealers/{id}/shops")
    public List<DealerService.ShopDto> shops(@PathVariable Long id) {
        return service.shops(id);
    }

    @PostMapping("/dealers/{id}/shops")
    @ResponseStatus(HttpStatus.CREATED)
    public DealerService.ShopDto addShop(@PathVariable Long id, @Valid @RequestBody DealerService.ShopRequest request) {
        return service.addShop(id, request);
    }

    @PutMapping("/dealers/{id}/shops/{shopId}")
    public DealerService.ShopDto updateShop(@PathVariable Long id, @PathVariable Long shopId,
                                            @Valid @RequestBody DealerService.ShopRequest request) {
        return service.updateShop(id, shopId, request);
    }

    @GetMapping("/dealers/{id}/ledger")
    public DealerService.DealerLedger ledger(@PathVariable Long id, @RequestParam(required = false) Long shopId) {
        return service.ledger(id, shopId);
    }

    @GetMapping("/dealer-bills")
    public PageResponse<DealerService.DealerBillDto> bills(@RequestParam(required = false) Long dealerId,
                                                           @RequestParam(required = false) Long shopId,
                                                           @RequestParam(required = false) Enums.Metal metal,
                                                           @RequestParam(required = false) DealerBill.Status status,
                                                           @RequestParam(required = false) String q,
                                                           @RequestParam(defaultValue = "0") int page,
                                                           @RequestParam(defaultValue = "30") int size) {
        return service.searchBills(dealerId, shopId, metal, status, q, page, size);
    }

    @GetMapping("/dealer-bills/{id}")
    public DealerService.DealerBillDto bill(@PathVariable Long id) {
        return service.getBill(id);
    }

    @PostMapping("/dealer-bills")
    @ResponseStatus(HttpStatus.CREATED)
    public DealerService.DealerBillDto createBill(@Valid @RequestBody DealerService.DealerBillRequest request) {
        return service.createBill(request);
    }

    @PostMapping("/dealer-bills/{id}/settlements")
    public DealerService.DealerBillDto settle(@PathVariable Long id, @Valid @RequestBody DealerService.SettlementRequest request) {
        return service.settle(id, request);
    }

    @PostMapping("/dealer-bills/{id}/settlements/{settlementId}/reverse")
    public DealerService.DealerBillDto reverseSettlement(@PathVariable Long id, @PathVariable Long settlementId,
                                                         @RequestBody ReasonRequest request) {
        return service.reverseSettlement(id, settlementId, request.reason());
    }

    @PostMapping("/dealer-bills/{id}/reverse")
    public DealerService.DealerBillDto reverse(@PathVariable Long id, @RequestBody ReasonRequest request) {
        return service.reverseBill(id, request.reason());
    }

    @GetMapping(value = "/dealer-bills/{id}/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> billPdf(@PathVariable Long id) {
        DealerService.DealerBillDto b = service.getBill(id);
        var settings = settingsService.current();
        String title = "Dealer " + b.type().name().toLowerCase() + " bill " + b.billNumber();
        PdfBuilder pdf = new PdfBuilder(settings.getShopName(), title, false);
        if (settings.getShopAddress() != null) {
            pdf.meta("Address", settings.getShopAddress());
        }
        pdf.meta("Deal date", s(b.dealDate()))
                .meta("Dealer / shop", b.dealerName() + " / " + b.shopName())
                .meta("Metal", b.metal().name())
                .meta("Status", b.status().name());
        pdf.generatedNow();
        if (b.status() == DealerBill.Status.REVERSED) {
            pdf.warning("REVERSED: " + s(b.reversalReason()));
        }
        List<List<String>> rows = new ArrayList<>();
        for (DealerService.LineDto l : b.lines()) {
            rows.add(List.of(String.valueOf(l.lineNo()), s(l.description()),
                    g(l.grossWeight()), g(l.lessWeight()), g(l.netWeight()), g(l.finalWeight()),
                    l.carat() == null ? "" : l.carat().name(), l.caratPercent() == null ? "" : l.caratPercent() + "%",
                    l.labourPercent() == null ? "" : l.labourPercent().toPlainString() + "%"));
        }
        pdf.section("Lines").table(List.of("#", "Description", "Gross", "Less", "Net", "Final", "Carat", "Carat %", "Labour %"),
                rows, new float[]{3, 16, 8, 8, 8, 8, 8, 8, 8}, new int[]{2, 3, 4, 5, 6}, null);
        List<String[]> totals = new ArrayList<>();
        totals.add(new String[]{"Total final weight", g(b.totalFinalWeight())});
        totals.add(new String[]{"Amount", b.amount() == null ? "—" : rs(b.amount())});
        totals.add(new String[]{"Settled", g(b.settledWeight()) + " · " + rs(b.settledValue())});
        totals.add(new String[]{"Outstanding", g(b.outstandingWeight()) + (b.outstandingAmount() == null ? "" : " · " + rs(b.outstandingAmount()))});
        pdf.keyValues(totals);
        byte[] bytes = pdf.build();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + b.billNumber() + ".pdf\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(bytes);
    }
}
