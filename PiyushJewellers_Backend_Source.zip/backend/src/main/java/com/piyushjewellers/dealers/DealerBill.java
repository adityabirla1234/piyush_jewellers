package com.piyushjewellers.dealers;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Dealer gold/silver bill. Deal date (business date) is kept separate from enteredAt so historical paper
 * deals can be entered later. Rate and calculated values are stored as historical snapshots.
 */
@Getter
@Setter
@Entity
@Table(name = "dealer_bills", indexes = {
        @Index(name = "idx_dbill_dealer", columnList = "dealer_id,shop_id"),
        @Index(name = "idx_dbill_date", columnList = "dealDate")
})
public class DealerBill extends BaseEntity {

    public enum Type { PURCHASE, SALES }

    public enum Status { OPEN, PARTIALLY_SETTLED, SETTLED, REVERSED }

    @Column(nullable = false, length = 40)
    private String billNumber;

    @Column(nullable = false)
    private LocalDate dealDate;

    @Column(nullable = false)
    private Instant enteredAt;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "dealer_id")
    private Dealer dealer;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "shop_id")
    private DealerShop shop;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Type billType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.Metal metal;

    @Column(length = 500)
    private String description;

    @Column(precision = 19, scale = 2)
    private BigDecimal rate;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal totalNetWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal totalFinalWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal settledValue = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal settledWeight = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Status status = Status.OPEN;

    @Column(length = 300)
    private String reversalReason;

    @OneToMany(mappedBy = "bill", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("lineNo ASC")
    private List<DealerBillLine> lines = new ArrayList<>();

    @OneToMany(mappedBy = "bill", cascade = CascadeType.ALL)
    @OrderBy("id ASC")
    private List<DealerSettlement> settlements = new ArrayList<>();
}
