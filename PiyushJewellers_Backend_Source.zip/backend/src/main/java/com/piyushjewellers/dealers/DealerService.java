package com.piyushjewellers.dealers;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.common.enums.Enums.Direction;
import com.piyushjewellers.common.enums.Enums.SourceType;
import com.piyushjewellers.inventory.BarLot;
import com.piyushjewellers.inventory.BarLotService;
import com.piyushjewellers.people.Person;
import com.piyushjewellers.people.PersonService;
import com.piyushjewellers.settings.SettingsModule;
import com.piyushjewellers.transactions.DailyTransaction;
import com.piyushjewellers.transactions.TransactionService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class DealerService {

    private static final String SOURCE = "DEALER_SETTLEMENT";
    private static final BigDecimal WEIGHT_TOLERANCE = new BigDecimal("0.0005");

    private final DealerRepositories.DealerRepository dealerRepo;
    private final DealerRepositories.DealerShopRepository shopRepo;
    private final DealerRepositories.DealerBillRepository billRepo;
    private final DealerRepositories.DealerSettlementRepository settlementRepo;
    private final PersonService personService;
    private final BarLotService barLotService;
    private final TransactionService transactionService;
    private final SettingsModule.SettingsService settingsService;
    private final AuditService auditService;

    // ---------- DTOs ----------

    public record DealerRequest(@NotBlank @Size(max = 150) String name, @Size(max = 30) String phone,
                                @Size(max = 400) String address, @Size(max = 1000) String notes, Long version) {
    }

    public record ShopRequest(@NotBlank @Size(max = 150) String name, @Size(max = 300) String location,
                              @Size(max = 30) String phone) {
    }

    public record DealerDto(Long id, String name, String phone, String address, String notes, Long personId,
                            long shopCount, Long version) {
    }

    public record ShopDto(Long id, Long dealerId, String name, String location, String phone) {
        static ShopDto from(DealerShop s) {
            return new ShopDto(s.getId(), s.getDealer().getId(), s.getName(), s.getLocation(), s.getPhone());
        }
    }

    public record LineRequest(@Size(max = 300) String description, @NotNull @DecimalMin("0") BigDecimal grossWeight,
                              @DecimalMin("0") BigDecimal lessWeight, @Min(0) Integer pieces, Enums.Carat carat,
                              @NotNull @DecimalMin("0") BigDecimal labourPercent, @Min(0) Integer pairs) {
    }

    public record BarAllocationRequest(Long barLotId, @NotNull @DecimalMin("0.0001") BigDecimal weight,
                                       @DecimalMin("0") BigDecimal rate, @Size(max = 40) String newLotCode,
                                       @Size(max = 20) String purity, Enums.Metal barMetal) {
    }

    public record MoneyAllocationRequest(@NotNull Enums.PaymentMethod method, @NotNull @DecimalMin("0.01") BigDecimal amount,
                                         @Size(max = 120) String reference, @DecimalMin("0") BigDecimal rate) {
    }

    public record SettlementRequest(LocalDate settlementDate, @Size(max = 500) String notes,
                                    List<@Valid BarAllocationRequest> bars, List<@Valid MoneyAllocationRequest> money,
                                    boolean crossMetalAuthorized) {
    }

    public record DealerBillRequest(@NotNull Long dealerId, @NotNull Long shopId, @NotBlank @Size(max = 40) String billNumber,
                                    @NotNull LocalDate dealDate, @NotNull DealerBill.Type type, @NotNull Enums.Metal metal,
                                    @Size(max = 500) String description, @DecimalMin("0") BigDecimal rate,
                                    @NotEmpty List<@Valid LineRequest> lines, @Valid SettlementRequest settlement) {
    }

    public record LineDto(Long id, int lineNo, String description, BigDecimal grossWeight, BigDecimal lessWeight,
                          BigDecimal netWeight, int pieces, Enums.Carat carat, Integer caratPercent,
                          BigDecimal labourPercent, BigDecimal finalWeight, Integer pairs) {
    }

    public record AllocationDto(Long id, SettlementAllocation.Kind kind, Long barLotId, String barLotCode,
                                String barLabel, BigDecimal weight, BigDecimal rate, BigDecimal value,
                                BigDecimal weightEquivalent, Enums.PaymentMethod method, String reference,
                                Long transactionId) {
    }

    public record SettlementDto(Long id, LocalDate settlementDate, BigDecimal totalValue,
                                BigDecimal totalWeightEquivalent, String notes, DealerSettlement.Status status,
                                String reversalReason, List<AllocationDto> allocations, Instant createdAt) {
    }

    public record DealerBillDto(Long id, String billNumber, LocalDate dealDate, Instant enteredAt, Long dealerId,
                                String dealerName, Long shopId, String shopName, DealerBill.Type type,
                                Enums.Metal metal, String description, BigDecimal rate, List<LineDto> lines,
                                BigDecimal totalNetWeight, BigDecimal totalFinalWeight, BigDecimal amount,
                                BigDecimal settledValue, BigDecimal settledWeight, BigDecimal outstandingAmount,
                                BigDecimal outstandingWeight, DealerBill.Status status, String reversalReason,
                                List<SettlementDto> settlements, Long version, String dealerPhone,
                                String shopPhone) {
    }

    public record LedgerEntry(LocalDate date, String kind, String reference, Long billId, Long shopId, String shopName,
                              Enums.Metal metal, String description, BigDecimal weight, BigDecimal amount,
                              String direction) {
    }

    public record MetalBalance(Enums.Metal metal, BigDecimal receivableWeight, BigDecimal payableWeight,
                               BigDecimal receivableAmount, BigDecimal payableAmount) {
    }

    public record DealerLedger(Long dealerId, String dealerName, Long shopId, List<MetalBalance> balances,
                               BigDecimal totalReceivableAmount, BigDecimal totalPayableAmount,
                               List<LedgerEntry> entries) {
    }

    // ---------- Dealers & shops ----------

    @Transactional(readOnly = true)
    public PageResponse<DealerDto> search(String q, int page, int size) {
        return PageResponse.of(dealerRepo.search((q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by("name"))), this::toDealerDto);
    }

    @Transactional(readOnly = true)
    public DealerDto get(Long id) {
        return toDealerDto(requireDealer(id));
    }

    @Transactional
    public DealerDto create(DealerRequest r) {
        Person person = personService.createInternal(r.name(), r.phone(), r.address(), null, true);
        Dealer d = new Dealer();
        d.setName(r.name().trim());
        d.setPhone(r.phone());
        d.setAddress(r.address());
        d.setNotes(r.notes());
        d.setPerson(person);
        dealerRepo.save(d);
        DealerShop main = new DealerShop();
        main.setDealer(d);
        main.setName("Main shop");
        main.setPhone(r.phone());
        shopRepo.save(main);
        auditService.record("DEALER_CREATED", "Dealer", d.getId(), null, d.getName());
        return toDealerDto(d);
    }

    @Transactional
    public DealerDto update(Long id, DealerRequest r) {
        Dealer d = requireDealer(id);
        if (r.version() != null && !r.version().equals(d.getVersion())) {
            throw ApiException.conflict("VERSION_CONFLICT", "This dealer was changed elsewhere. Reload and retry.", null);
        }
        d.setName(r.name().trim());
        d.setPhone(r.phone());
        d.setAddress(r.address());
        d.setNotes(r.notes());
        dealerRepo.saveAndFlush(d);
        auditService.record("DEALER_UPDATED", "Dealer", d.getId(), null, d.getName());
        return toDealerDto(d);
    }

    @Transactional(readOnly = true)
    public List<ShopDto> shops(Long dealerId) {
        requireDealer(dealerId);
        return shopRepo.findByDealerIdOrderByNameAsc(dealerId).stream().map(ShopDto::from).toList();
    }

    @Transactional
    public ShopDto addShop(Long dealerId, ShopRequest r) {
        DealerShop s = new DealerShop();
        s.setDealer(requireDealer(dealerId));
        s.setName(r.name().trim());
        s.setLocation(r.location());
        s.setPhone(r.phone());
        shopRepo.save(s);
        auditService.record("DEALER_SHOP_CREATED", "DealerShop", s.getId(), null, s.getName());
        return ShopDto.from(s);
    }

    @Transactional
    public ShopDto updateShop(Long dealerId, Long shopId, ShopRequest r) {
        DealerShop s = requireShop(dealerId, shopId);
        s.setName(r.name().trim());
        s.setLocation(r.location());
        s.setPhone(r.phone());
        auditService.record("DEALER_SHOP_UPDATED", "DealerShop", s.getId(), null, s.getName());
        return ShopDto.from(s);
    }

    // ---------- Bills ----------

    @Transactional(readOnly = true)
    public PageResponse<DealerBillDto> searchBills(Long dealerId, Long shopId, Enums.Metal metal, DealerBill.Status status,
                                                   String q, int page, int size) {
        return PageResponse.of(billRepo.search(dealerId, shopId, metal, status, (q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "dealDate", "id"))), this::toBillDto);
    }

    @Transactional(readOnly = true)
    public DealerBillDto getBill(Long id) {
        return toBillDto(requireBill(id));
    }

    @Transactional
    public DealerBillDto createBill(DealerBillRequest r) {
        if (r.metal() == Enums.Metal.OTHER) throw ApiException.validation("Dealer bills are Gold or Silver");
        Dealer dealer = requireDealer(r.dealerId());
        DealerShop shop = requireShop(dealer.getId(), r.shopId());
        DealerBill bill = new DealerBill();
        bill.setBillNumber(r.billNumber().trim());
        bill.setDealDate(r.dealDate());
        bill.setEnteredAt(Instant.now());
        bill.setDealer(dealer);
        bill.setShop(shop);
        bill.setBillType(r.type());
        bill.setMetal(r.metal());
        bill.setDescription(r.description());
        bill.setRate(r.rate() == null ? null : Money.money(r.rate()));

        BigDecimal totalNet = BigDecimal.ZERO;
        BigDecimal totalFinal = BigDecimal.ZERO;
        int n = 1;
        for (LineRequest lr : r.lines()) {
            if (r.metal() == Enums.Metal.GOLD && lr.carat() == null) {
                throw ApiException.validation("Select the gold carat on line " + n);
            }
            DealerBillLine line = new DealerBillLine();
            line.setBill(bill);
            line.setLineNo(n++);
            line.setDescription(lr.description());
            line.setGrossWeight(Money.weight(lr.grossWeight()));
            line.setLessWeight(Money.weight(lr.lessWeight()));
            line.setNetWeight(MetalCalculator.netWeight(lr.grossWeight(), lr.lessWeight()));
            if (line.getNetWeight().signum() < 0) throw ApiException.validation("Less weight exceeds gross weight on line " + line.getLineNo());
            line.setPieces(lr.pieces() == null ? 0 : lr.pieces());
            line.setPairs(lr.pairs() == null || lr.pairs() == 0 ? null : lr.pairs());
            line.setCarat(r.metal() == Enums.Metal.GOLD ? lr.carat() : null);
            line.setCaratPercent(r.metal() == Enums.Metal.GOLD ? lr.carat().percent() : null);
            line.setLabourPercent(lr.labourPercent().setScale(4, Money.ROUNDING));
            line.setFinalWeight(MetalCalculator.finalWeight(r.metal(), line.getNetWeight(), lr.carat(), lr.labourPercent()));
            totalNet = totalNet.add(line.getNetWeight());
            totalFinal = totalFinal.add(line.getFinalWeight());
            bill.getLines().add(line);
        }
        bill.setTotalNetWeight(Money.weight(totalNet));
        bill.setTotalFinalWeight(Money.weight(totalFinal));
        bill.setAmount(MetalCalculator.amount(bill.getTotalFinalWeight(), bill.getRate()));
        billRepo.save(bill);
        auditService.record("DEALER_BILL_CREATED", "DealerBill", bill.getId(), null,
                bill.getBillNumber() + " " + bill.getMetal() + " final " + bill.getTotalFinalWeight() + " g, amount " + bill.getAmount());
        if (r.settlement() != null && (notEmpty(r.settlement().bars()) || notEmpty(r.settlement().money()))) {
            settleInternal(bill, r.settlement());
        }
        return toBillDto(bill);
    }

    @Transactional
    public DealerBillDto settle(Long billId, SettlementRequest r) {
        return toBillDto(settleInternal(requireBill(billId), r));
    }

    /**
     * Settlement allocations: matching-metal MR Biscuit bars and/or money, partial or full.
     * Each allocation stores a rate/value snapshot and a weight equivalent (bar weight, or money ÷ rate).
     * Purchase bill (shop owes dealer): bars are issued from our lots, money goes OUT.
     * Sales bill (dealer owes shop): bars received become a new lot, money comes IN.
     */
    private DealerBill settleInternal(DealerBill bill, SettlementRequest r) {
        if (bill.getStatus() == DealerBill.Status.REVERSED || bill.getStatus() == DealerBill.Status.SETTLED) {
            throw ApiException.state("This bill is already " + bill.getStatus());
        }
        if (!notEmpty(r.bars()) && !notEmpty(r.money())) {
            throw ApiException.validation("Add at least one MR Biscuit or money allocation");
        }
        boolean purchase = bill.getBillType() == DealerBill.Type.PURCHASE;
        LocalDate date = r.settlementDate() == null ? LocalDate.now() : r.settlementDate();
        boolean crossAllowed = settingsService.current().isCrossMetalSettlementAllowed() && r.crossMetalAuthorized();

        DealerSettlement s = new DealerSettlement();
        s.setBill(bill);
        s.setSettlementDate(date);
        s.setNotes(r.notes());
        s.setTotalValue(BigDecimal.ZERO);
        s.setTotalWeightEquivalent(BigDecimal.ZERO);
        settlementRepo.save(s);

        BigDecimal totalValue = BigDecimal.ZERO;
        BigDecimal totalWeq = BigDecimal.ZERO;
        if (r.bars() != null) {
            for (BarAllocationRequest b : r.bars()) {
                BigDecimal rate = b.rate() != null ? b.rate() : Money.nz(bill.getRate());
                BarLot lot;
                if (purchase) {
                    if (b.barLotId() == null) throw ApiException.validation("Select the MR Biscuit lot to issue");
                    lot = barLotService.issue(b.barLotId(), b.weight(), rate, SOURCE, s.getId(),
                            "Dealer bill " + bill.getBillNumber(), date);
                } else {
                    Enums.Metal metal = b.barMetal() == null ? bill.getMetal() : b.barMetal();
                    lot = barLotService.receive(metal, b.newLotCode(), b.weight(), b.purity(), rate, date,
                            "Dealer " + bill.getDealer().getName() + " bill " + bill.getBillNumber(), SOURCE, s.getId());
                }
                if (lot.getMetal() != bill.getMetal() && !crossAllowed) {
                    throw ApiException.validation(BarLot.label(lot.getMetal()) + " cannot settle a " + bill.getMetal()
                            + " bill without explicit cross-metal authorization");
                }
                SettlementAllocation a = new SettlementAllocation();
                a.setSettlement(s);
                a.setKind(SettlementAllocation.Kind.BAR);
                a.setBarLotId(lot.getId());
                a.setBarLotCode(lot.getLotCode());
                a.setBarMetal(lot.getMetal());
                a.setWeight(Money.weight(b.weight()));
                a.setRate(Money.money(rate));
                a.setValue(Money.money(b.weight().multiply(rate)));
                a.setWeightEquivalent(Money.weight(b.weight()));
                s.getAllocations().add(a);
                totalValue = totalValue.add(a.getValue());
                totalWeq = totalWeq.add(a.getWeightEquivalent());
            }
        }
        if (r.money() != null) {
            for (MoneyAllocationRequest m : r.money()) {
                BigDecimal rate = m.rate() != null ? m.rate() : bill.getRate();
                if (!Money.isPositive(rate)) {
                    throw ApiException.validation("Enter a metal rate to convert the money settlement into weight");
                }
                DailyTransaction t = transactionService.postLinked(new TransactionService.LinkedPayment(
                        purchase ? Direction.OUT : Direction.IN, m.amount(), m.method(), m.reference(),
                        date.atTime(java.time.LocalTime.now()), bill.getDealer().getPerson(), "Dealer settlement",
                        "Dealer " + bill.getDealer().getName() + " — bill " + bill.getBillNumber(),
                        SourceType.DEALER_SETTLEMENT, s.getId(), m.method() == Enums.PaymentMethod.CHEQUE ? m.reference() : null,
                        null, null));
                SettlementAllocation a = new SettlementAllocation();
                a.setSettlement(s);
                a.setKind(SettlementAllocation.Kind.MONEY);
                a.setMethod(m.method());
                a.setReference(m.reference());
                a.setRate(Money.money(rate));
                a.setValue(Money.money(m.amount()));
                a.setWeightEquivalent(Money.weight(m.amount().divide(rate, Money.CALC_SCALE, Money.ROUNDING)));
                a.setTransactionId(t.getId());
                s.getAllocations().add(a);
                totalValue = totalValue.add(a.getValue());
                totalWeq = totalWeq.add(a.getWeightEquivalent());
            }
        }
        BigDecimal outstandingWeight = bill.getTotalFinalWeight().subtract(bill.getSettledWeight());
        if (totalWeq.compareTo(outstandingWeight.add(WEIGHT_TOLERANCE)) > 0) {
            throw ApiException.validation("Settlement (" + totalWeq.stripTrailingZeros().toPlainString()
                    + " g equivalent) exceeds the outstanding " + outstandingWeight.stripTrailingZeros().toPlainString() + " g");
        }
        s.setTotalValue(Money.money(totalValue));
        s.setTotalWeightEquivalent(Money.weight(totalWeq));
        bill.getSettlements().add(s);
        bill.setSettledValue(Money.money(bill.getSettledValue().add(totalValue)));
        bill.setSettledWeight(Money.weight(bill.getSettledWeight().add(totalWeq)));
        refreshStatus(bill);
        auditService.record("DEALER_SETTLEMENT", "DealerBill", bill.getId(), null,
                "settlement #" + s.getId() + " value " + s.getTotalValue() + ", weq " + s.getTotalWeightEquivalent());
        return bill;
    }

    @Transactional
    public DealerBillDto reverseSettlement(Long billId, Long settlementId, String reason) {
        DealerBill bill = requireBill(billId);
        DealerSettlement s = bill.getSettlements().stream().filter(x -> x.getId().equals(settlementId)).findFirst()
                .orElseThrow(() -> ApiException.notFound("Settlement", settlementId));
        reverseSettlementInternal(bill, s, reason);
        refreshStatus(bill);
        return toBillDto(bill);
    }

    @Transactional
    public DealerBillDto reverseBill(Long billId, String reason) {
        if (reason == null || reason.isBlank()) throw ApiException.validation("A reason is required");
        DealerBill bill = requireBill(billId);
        if (bill.getStatus() == DealerBill.Status.REVERSED) throw ApiException.state("Bill is already reversed");
        for (DealerSettlement s : bill.getSettlements()) {
            if (s.getStatus() == DealerSettlement.Status.ACTIVE) reverseSettlementInternal(bill, s, reason);
        }
        bill.setStatus(DealerBill.Status.REVERSED);
        bill.setReversalReason(reason.trim());
        auditService.record("DEALER_BILL_REVERSED", "DealerBill", bill.getId(), reason, bill.getBillNumber());
        return toBillDto(bill);
    }

    private void reverseSettlementInternal(DealerBill bill, DealerSettlement s, String reason) {
        if (reason == null || reason.isBlank()) throw ApiException.validation("A reason is required");
        if (s.getStatus() == DealerSettlement.Status.REVERSED) throw ApiException.state("Settlement is already reversed");
        barLotService.reverseFor(SOURCE, s.getId(), reason);
        for (SettlementAllocation a : s.getAllocations()) {
            if (a.getTransactionId() != null && transactionService.isEffective(a.getTransactionId())) {
                transactionService.reverse(transactionService.require(a.getTransactionId()), "Settlement reversed: " + reason);
            }
        }
        s.setStatus(DealerSettlement.Status.REVERSED);
        s.setReversalReason(reason.trim());
        bill.setSettledValue(Money.money(bill.getSettledValue().subtract(s.getTotalValue())));
        bill.setSettledWeight(Money.weight(bill.getSettledWeight().subtract(s.getTotalWeightEquivalent())));
        auditService.record("DEALER_SETTLEMENT_REVERSED", "DealerBill", bill.getId(), reason, "settlement #" + s.getId());
    }

    private void refreshStatus(DealerBill bill) {
        if (bill.getStatus() == DealerBill.Status.REVERSED) return;
        BigDecimal outstanding = bill.getTotalFinalWeight().subtract(bill.getSettledWeight());
        if (outstanding.compareTo(WEIGHT_TOLERANCE) <= 0) bill.setStatus(DealerBill.Status.SETTLED);
        else if (bill.getSettledWeight().signum() > 0) bill.setStatus(DealerBill.Status.PARTIALLY_SETTLED);
        else bill.setStatus(DealerBill.Status.OPEN);
    }

    // ---------- Ledger ----------

    @Transactional(readOnly = true)
    public DealerLedger ledger(Long dealerId, Long shopId) {
        Dealer dealer = requireDealer(dealerId);
        List<LedgerEntry> entries = new ArrayList<>();
        BigDecimal[] gold = new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO};
        BigDecimal[] silver = new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO};
        for (DealerBill b : billRepo.findByDealerIdOrderByDealDateAscIdAsc(dealerId)) {
            if (shopId != null && !b.getShop().getId().equals(shopId)) continue;
            boolean purchase = b.getBillType() == DealerBill.Type.PURCHASE;
            entries.add(new LedgerEntry(b.getDealDate(), purchase ? "PURCHASE_BILL" : "SALES_BILL", b.getBillNumber(),
                    b.getId(), b.getShop().getId(), b.getShop().getName(), b.getMetal(),
                    (b.getStatus() == DealerBill.Status.REVERSED ? "[REVERSED] " : "") + (b.getDescription() == null ? "" : b.getDescription()),
                    b.getTotalFinalWeight(), b.getAmount(), purchase ? "PAYABLE" : "RECEIVABLE"));
            for (DealerSettlement s : b.getSettlements()) {
                for (SettlementAllocation a : s.getAllocations()) {
                    String desc = a.getKind() == SettlementAllocation.Kind.BAR
                            ? BarLot.label(a.getBarMetal()) + " " + a.getBarLotCode()
                            : a.getMethod() + (a.getReference() == null ? "" : " " + a.getReference());
                    entries.add(new LedgerEntry(s.getSettlementDate(),
                            a.getKind() == SettlementAllocation.Kind.BAR ? "BAR_SETTLEMENT" : "MONEY_SETTLEMENT",
                            b.getBillNumber(), b.getId(), b.getShop().getId(), b.getShop().getName(), b.getMetal(),
                            (s.getStatus() == DealerSettlement.Status.REVERSED ? "[REVERSED] " : "") + desc,
                            a.getWeightEquivalent(), a.getValue(), purchase ? "PAID_TO_DEALER" : "RECEIVED_FROM_DEALER"));
                }
            }
            if (b.getStatus() == DealerBill.Status.REVERSED) continue;
            BigDecimal[] acc = b.getMetal() == Enums.Metal.GOLD ? gold : silver;
            BigDecimal ow = b.getTotalFinalWeight().subtract(b.getSettledWeight()).max(BigDecimal.ZERO);
            BigDecimal oa = b.getAmount().subtract(b.getSettledValue()).max(BigDecimal.ZERO);
            if (purchase) {
                acc[1] = acc[1].add(ow);
                acc[3] = acc[3].add(oa);
            } else {
                acc[0] = acc[0].add(ow);
                acc[2] = acc[2].add(oa);
            }
        }
        entries.sort((a, c) -> a.date().compareTo(c.date()));
        List<MetalBalance> balances = List.of(
                new MetalBalance(Enums.Metal.GOLD, Money.weight(gold[0]), Money.weight(gold[1]), Money.money(gold[2]), Money.money(gold[3])),
                new MetalBalance(Enums.Metal.SILVER, Money.weight(silver[0]), Money.weight(silver[1]), Money.money(silver[2]), Money.money(silver[3])));
        return new DealerLedger(dealer.getId(), dealer.getName(), shopId, balances,
                Money.money(gold[2].add(silver[2])), Money.money(gold[3].add(silver[3])), entries);
    }

    // ---------- Helpers ----------

    public Dealer requireDealer(Long id) {
        return dealerRepo.findById(id).orElseThrow(() -> ApiException.notFound("Dealer", id));
    }

    private DealerShop requireShop(Long dealerId, Long shopId) {
        DealerShop s = shopRepo.findById(shopId).orElseThrow(() -> ApiException.notFound("Shop", shopId));
        if (!s.getDealer().getId().equals(dealerId)) throw ApiException.validation("Shop does not belong to this dealer");
        return s;
    }

    private DealerBill requireBill(Long id) {
        return billRepo.findById(id).orElseThrow(() -> ApiException.notFound("Dealer bill", id));
    }

    private static boolean notEmpty(List<?> list) {
        return list != null && !list.isEmpty();
    }

    private DealerDto toDealerDto(Dealer d) {
        return new DealerDto(d.getId(), d.getName(), d.getPhone(), d.getAddress(), d.getNotes(), d.getPerson().getId(),
                shopRepo.countByDealerId(d.getId()), d.getVersion());
    }

    public DealerBillDto toBillDto(DealerBill b) {
        List<LineDto> lines = b.getLines().stream().map(l -> new LineDto(l.getId(), l.getLineNo(), l.getDescription(),
                l.getGrossWeight(), l.getLessWeight(), l.getNetWeight(), l.getPieces(), l.getCarat(), l.getCaratPercent(),
                l.getLabourPercent(), l.getFinalWeight(), l.getPairs())).toList();
        List<SettlementDto> settlements = b.getSettlements().stream().map(s -> new SettlementDto(s.getId(),
                s.getSettlementDate(), s.getTotalValue(), s.getTotalWeightEquivalent(), s.getNotes(), s.getStatus(),
                s.getReversalReason(), s.getAllocations().stream().map(a -> new AllocationDto(a.getId(), a.getKind(),
                a.getBarLotId(), a.getBarLotCode(), a.getBarMetal() == null ? null : BarLot.label(a.getBarMetal()),
                a.getWeight(), a.getRate(), a.getValue(), a.getWeightEquivalent(), a.getMethod(), a.getReference(),
                a.getTransactionId())).toList(), s.getCreatedAt())).toList();
        boolean reversed = b.getStatus() == DealerBill.Status.REVERSED;
        BigDecimal ow = reversed ? BigDecimal.ZERO : b.getTotalFinalWeight().subtract(b.getSettledWeight()).max(BigDecimal.ZERO);
        BigDecimal oa = reversed ? BigDecimal.ZERO : b.getAmount().subtract(b.getSettledValue()).max(BigDecimal.ZERO);
        return new DealerBillDto(b.getId(), b.getBillNumber(), b.getDealDate(), b.getEnteredAt(), b.getDealer().getId(),
                b.getDealer().getName(), b.getShop().getId(), b.getShop().getName(), b.getBillType(), b.getMetal(),
                b.getDescription(), b.getRate(), lines, b.getTotalNetWeight(), b.getTotalFinalWeight(), b.getAmount(),
                b.getSettledValue(), b.getSettledWeight(), Money.money(oa), Money.weight(ow), b.getStatus(),
                b.getReversalReason(), settlements, b.getVersion(), b.getDealer().getPhone(), b.getShop().getPhone());
    }
}
