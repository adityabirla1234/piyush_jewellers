package com.piyushjewellers.dealers;

import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "dealer_bill_lines")
public class DealerBillLine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bill_id")
    private DealerBill bill;

    @Column(nullable = false)
    private int lineNo;

    @Column(length = 300)
    private String description;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal grossWeight;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal lessWeight;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal netWeight;

    @Column(nullable = false)
    private int pieces;

    @Enumerated(EnumType.STRING)
    @Column(length = 5)
    private Enums.Carat carat;

    /** Snapshot of the configured carat percentage at entry time. */
    private Integer caratPercent;

    @Column(nullable = false, precision = 9, scale = 4)
    private BigDecimal labourPercent;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal finalWeight;
}
