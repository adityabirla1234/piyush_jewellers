package com.piyushjewellers.dealers;

import com.piyushjewellers.common.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "dealer_shops")
public class DealerShop extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "dealer_id")
    private Dealer dealer;

    @Column(nullable = false, length = 150)
    private String name;

    @Column(length = 300)
    private String location;

    @Column(length = 30)
    private String phone;

    @Column(nullable = false)
    private boolean active = true;
}
