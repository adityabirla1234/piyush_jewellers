package com.piyushjewellers.sellpurchase;

import com.piyushjewellers.billing.BillLine;
import com.piyushjewellers.billing.BillRepository;
import com.piyushjewellers.billing.BillService;
import com.piyushjewellers.billing.CustomerBill;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.dealers.DealerBill;
import com.piyushjewellers.dealers.DealerRepositories;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * Combined view of finalized customer bills and active dealer bills for a period, filterable by metal.
 * Customer bills may mix metals; with a metal filter only the matching lines count toward amount and weight.
 */
@Service
@RequiredArgsConstructor
public class SellPurchaseService {

    public enum Kind { SALES, PURCHASE }

    public enum Source { CUSTOMER, DEALER }

    private final BillRepository billRepo;
    private final BillService billService;
    private final DealerRepositories.DealerBillRepository dealerBillRepo;

    public record Row(Source source, Long id, String billNumber, LocalDate date, Kind kind, String partyName,
                      String partyPhone, String metal, BigDecimal netWeight, BigDecimal fineWeight, BigDecimal amount,
                      BigDecimal outstanding, String status) {
    }

    public record Bucket(int count, BigDecimal amount, BigDecimal netWeight, BigDecimal fineWeight) {
        static Bucket of(List<Row> rows) {
            BigDecimal a = BigDecimal.ZERO, w = BigDecimal.ZERO, f = BigDecimal.ZERO;
            for (Row r : rows) {
                a = a.add(Money.nz(r.amount()));
                w = w.add(Money.nz(r.netWeight()));
                f = f.add(Money.nz(r.fineWeight()));
            }
            return new Bucket(rows.size(), Money.money(a), Money.weight(w), Money.weight(f));
        }
    }

    public record MetalTotals(Enums.Metal metal, Bucket sales, Bucket purchase) {
    }

    public record Result(LocalDate from, LocalDate to, Enums.Metal metal, Kind kind, Source source, Bucket sales,
                         Bucket purchase, BigDecimal net, BigDecimal totalAmount, List<MetalTotals> byMetal,
                         List<Row> rows) {
    }

    @Transactional(readOnly = true)
    public Result query(Enums.Metal metal, LocalDate from, LocalDate to, Kind kind, Source source) {
        if (from == null) from = LocalDate.now().withDayOfMonth(1);
        if (to == null) to = LocalDate.now();
        if (to.isBefore(from)) throw ApiException.validation("End date is before start date");
        List<Row> all = new ArrayList<>();
        all.addAll(customerRows(null, from, to));
        all.addAll(dealerRows(null, from, to));

        List<MetalTotals> byMetal = new ArrayList<>();
        for (Enums.Metal m : List.of(Enums.Metal.GOLD, Enums.Metal.SILVER)) {
            List<Row> rows = new ArrayList<>(customerRows(m, from, to));
            rows.addAll(dealerRows(m, from, to));
            List<Row> scoped = filter(rows, kind, source);
            byMetal.add(new MetalTotals(m, Bucket.of(only(scoped, Kind.SALES)), Bucket.of(only(scoped, Kind.PURCHASE))));
        }

        List<Row> rows = metal == null ? all : new ArrayList<>(customerRows(metal, from, to));
        if (metal != null) rows.addAll(dealerRows(metal, from, to));
        rows = new ArrayList<>(filter(rows, kind, source));
        rows.sort(Comparator.comparing(Row::date).thenComparing(Row::billNumber, Comparator.nullsLast(String::compareTo)));
        Bucket sales = Bucket.of(only(rows, Kind.SALES));
        Bucket purchase = Bucket.of(only(rows, Kind.PURCHASE));
        return new Result(from, to, metal, kind, source, sales, purchase,
                Money.money(sales.amount().subtract(purchase.amount())),
                Money.money(sales.amount().add(purchase.amount())), byMetal, rows);
    }

    private static List<Row> filter(List<Row> rows, Kind kind, Source source) {
        return rows.stream().filter(r -> (kind == null || r.kind() == kind) && (source == null || r.source() == source)).toList();
    }

    private static List<Row> only(List<Row> rows, Kind kind) {
        return rows.stream().filter(r -> r.kind() == kind).toList();
    }

    private List<Row> customerRows(Enums.Metal metal, LocalDate from, LocalDate to) {
        List<Row> out = new ArrayList<>();
        for (CustomerBill b : billRepo.findByStatusAndBillDateBetweenOrderByBillDateAscIdAsc(CustomerBill.Status.FINALIZED, from, to)) {
            Set<Enums.Metal> metals = EnumSet.noneOf(Enums.Metal.class);
            BigDecimal amount = BigDecimal.ZERO;
            BigDecimal weight = BigDecimal.ZERO;
            for (BillLine l : b.getLines()) {
                Enums.Metal m = l.resolvedMetal();
                if (metal != null && m != metal) continue;
                metals.add(m);
                amount = amount.add(Money.nz(l.getLineTotal()));
                weight = weight.add(Money.nz(l.getNetWeight()));
            }
            if (metals.isEmpty()) continue;
            String label = metals.size() == 1 ? metals.iterator().next().name() : "MIXED";
            BigDecimal outstanding = billService.outstanding(b);
            out.add(new Row(Source.CUSTOMER, b.getId(), b.getBillNumber(), b.getBillDate(),
                    b.getBillType() == CustomerBill.Type.SALES ? Kind.SALES : Kind.PURCHASE,
                    b.getCustomerName() == null ? "Walk-in" : b.getCustomerName(), b.getCustomerContact(), label,
                    Money.weight(weight), null, Money.money(amount), outstanding, b.getStatus().name()));
        }
        return out;
    }

    private List<Row> dealerRows(Enums.Metal metal, LocalDate from, LocalDate to) {
        List<Row> out = new ArrayList<>();
        for (DealerBill b : dealerBillRepo.findInRange(metal, from, to)) {
            BigDecimal outstanding = Money.nz(b.getAmount()).subtract(Money.nz(b.getSettledValue()));
            String phone = b.getShop().getPhone() != null ? b.getShop().getPhone() : b.getDealer().getPhone();
            out.add(new Row(Source.DEALER, b.getId(), b.getBillNumber(), b.getDealDate(),
                    b.getBillType() == DealerBill.Type.SALES ? Kind.SALES : Kind.PURCHASE,
                    b.getDealer().getName() + " · " + b.getShop().getName(), phone, b.getMetal().name(),
                    b.getTotalNetWeight(), b.getTotalFinalWeight(), Money.money(Money.nz(b.getAmount())),
                    Money.money(outstanding.max(BigDecimal.ZERO)), b.getStatus().name()));
        }
        return out;
    }
}
