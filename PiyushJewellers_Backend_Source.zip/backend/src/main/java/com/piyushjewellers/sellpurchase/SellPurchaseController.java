package com.piyushjewellers.sellpurchase;

import com.piyushjewellers.common.enums.Enums;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

@RestController
@RequestMapping("/api/v1/sell-purchase")
@RequiredArgsConstructor
public class SellPurchaseController {

    private final SellPurchaseService service;

    @GetMapping
    public SellPurchaseService.Result query(@RequestParam(required = false) Enums.Metal metal,
                                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                                            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
                                            @RequestParam(required = false) SellPurchaseService.Kind kind,
                                            @RequestParam(required = false) SellPurchaseService.Source source) {
        return service.query(metal, from, to, kind, source);
    }
}
