package com.piyushjewellers.transactions;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.people.Person;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Canonical money movement. Bills, settlements, mortgages, loans and exchanges link to exactly one
 * transaction per money movement (sourceType + sourceId), so nothing is double counted and Due
 * Management reads the same rows.
 */
@Getter
@Setter
@Entity
@Table(name = "daily_transactions", indexes = {
        @Index(name = "idx_txn_date", columnList = "businessDate"),
        @Index(name = "idx_txn_person", columnList = "person_id"),
        @Index(name = "idx_txn_source", columnList = "sourceType,sourceId"),
        @Index(name = "idx_txn_transfer", columnList = "transferGroup")
})
public class DailyTransaction extends BaseEntity {

    public enum Status { ACTIVE, REVERSED }

    @Column(nullable = false)
    private LocalDateTime businessDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 5)
    private Enums.Direction direction;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(length = 80)
    private String category;

    @Column(length = 300)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.PaymentMethod method;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(length = 120)
    private String reference;

    @Column(length = 1000)
    private String notes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private Enums.SourceType sourceType = Enums.SourceType.MANUAL;

    private Long sourceId;

    @Column(length = 40)
    private String transferGroup;

    private LocalDate approxReturnDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Status status = Status.ACTIVE;

    private Long reversalOfId;

    @Column(length = 300)
    private String reversalReason;
}
