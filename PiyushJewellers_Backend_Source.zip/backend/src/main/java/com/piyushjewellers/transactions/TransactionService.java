package com.piyushjewellers.transactions;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.common.enums.Enums.Direction;
import com.piyushjewellers.common.enums.Enums.PaymentMethod;
import com.piyushjewellers.common.enums.Enums.SourceType;
import com.piyushjewellers.people.Person;
import com.piyushjewellers.people.PersonService;
import com.piyushjewellers.settings.SettingsModule;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepositories.DailyTransactionRepository txnRepo;
    private final TransactionRepositories.ChequeRecordRepository chequeRepo;
    private final PersonService personService;
    private final SettingsModule.SettingsService settingsService;
    private final AuditService auditService;

    // ---------- DTOs ----------

    public record ChequeDto(Long id, String chequeNumber, String bankName, LocalDate chequeDate, Direction direction,
                            ChequeRecord.Status status, LocalDate clearedDate, LocalDate bouncedDate,
                            String bounceReason, Long bounceReversalTransactionId, Long transactionId,
                            BigDecimal amount, String personName, LocalDateTime businessDate) {
    }

    public record TransactionDto(Long id, LocalDateTime businessDate, Direction direction, BigDecimal amount,
                                 String category, String description, PaymentMethod method, Long personId,
                                 String personName, String reference, String notes, SourceType sourceType,
                                 Long sourceId, String transferGroup, LocalDate approxReturnDate,
                                 DailyTransaction.Status status, Long reversalOfId, String reversalReason,
                                 ChequeDto cheque, Instant createdAt, String createdBy) {
    }

    public record TransactionRequest(@NotNull LocalDateTime businessDate, @NotNull Direction direction,
                                     @NotNull @DecimalMin(value = "0.01") BigDecimal amount,
                                     @Size(max = 80) String category, @Size(max = 300) String description,
                                     @NotNull PaymentMethod method, Long personId, @Size(max = 120) String reference,
                                     @Size(max = 1000) String notes, LocalDate approxReturnDate,
                                     @Size(max = 40) String chequeNumber, @Size(max = 100) String chequeBank,
                                     LocalDate chequeDate) {
    }

    public record TransferRequest(@NotNull PaymentMethod fromMethod, @NotNull PaymentMethod toMethod,
                                  @NotNull @DecimalMin("0.01") BigDecimal amount, @NotNull LocalDateTime businessDate,
                                  @Size(max = 300) String notes) {
    }

    public record MethodSummary(PaymentMethod method, BigDecimal moneyIn, BigDecimal moneyOut, BigDecimal net) {
    }

    public record Summary(LocalDate from, LocalDate to, BigDecimal openingBalance, BigDecimal moneyIn,
                          BigDecimal moneyOut, BigDecimal combinedBalance, BigDecimal availableBalance,
                          BigDecimal pendingChequesIn, BigDecimal pendingChequesOut, List<MethodSummary> byMethod) {
    }

    /** Parameters used by other modules to post a linked money movement. */
    public record LinkedPayment(Direction direction, BigDecimal amount, PaymentMethod method, String reference,
                                LocalDateTime businessDate, Person person, String category, String description,
                                SourceType sourceType, Long sourceId, String chequeNumber, String chequeBank,
                                LocalDate approxReturnDate) {
    }

    // ---------- Queries ----------

    @Transactional(readOnly = true)
    public PageResponse<TransactionDto> search(LocalDate from, LocalDate to, Direction direction, PaymentMethod method,
                                               Long personId, SourceType sourceType, String q, int page, int size) {
        Page<DailyTransaction> result = txnRepo.search(
                from == null ? null : from.atStartOfDay(), to == null ? null : to.plusDays(1).atStartOfDay(),
                direction, method, personId, sourceType, (q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "businessDate", "id")));
        Map<Long, ChequeRecord> cheques = chequesFor(result.getContent());
        return PageResponse.of(result, t -> toDto(t, cheques.get(t.getId())));
    }

    @Transactional(readOnly = true)
    public TransactionDto get(Long id) {
        DailyTransaction t = require(id);
        return toDto(t, chequeRepo.findByTransactionId(id).orElse(null));
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> recent() {
        List<DailyTransaction> list = txnRepo.findTop8ByOrderByBusinessDateDescIdDesc();
        Map<Long, ChequeRecord> cheques = chequesFor(list);
        return list.stream().map(t -> toDto(t, cheques.get(t.getId()))).toList();
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> forPerson(Long personId) {
        List<DailyTransaction> list = txnRepo.findByPersonIdOrderByBusinessDateDesc(personId);
        Map<Long, ChequeRecord> cheques = chequesFor(list);
        return list.stream().map(t -> toDto(t, cheques.get(t.getId()))).toList();
    }

    @Transactional(readOnly = true)
    public List<TransactionDto> forSource(SourceType type, Long sourceId) {
        List<DailyTransaction> list = txnRepo.findBySourceTypeAndSourceId(type, sourceId);
        Map<Long, ChequeRecord> cheques = chequesFor(list);
        return list.stream().map(t -> toDto(t, cheques.get(t.getId()))).toList();
    }

    @Transactional(readOnly = true)
    public List<ChequeDto> cheques(ChequeRecord.Status status) {
        return chequeRepo.findByStatusFetch(status).stream().map(this::toChequeDto).toList();
    }

    /**
     * Combined closing balance = opening balance + money in − money out (transfers net to zero).
     * Available/cleared = combined − signed value of cheques that are not cleared.
     */
    @Transactional
    public Summary summary(LocalDate from, LocalDate to) {
        BigDecimal configuredOpening = settingsService.current().getOpeningBalance();
        LocalDateTime fromTs = from == null ? null : from.atStartOfDay();
        LocalDateTime toTs = to == null ? null : to.plusDays(1).atStartOfDay();
        BigDecimal opening = configuredOpening.add(fromTs == null ? BigDecimal.ZERO : txnRepo.signedTotalBefore(fromTs));

        Map<PaymentMethod, BigDecimal[]> perMethod = new EnumMap<>(PaymentMethod.class);
        BigDecimal in = BigDecimal.ZERO;
        BigDecimal out = BigDecimal.ZERO;
        for (Object[] row : txnRepo.sumByMethodAndDirection(fromTs, toTs)) {
            PaymentMethod m = (PaymentMethod) row[0];
            Direction d = (Direction) row[1];
            SourceType s = (SourceType) row[2];
            BigDecimal amt = (BigDecimal) row[3];
            BigDecimal[] acc = perMethod.computeIfAbsent(m, k -> new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO});
            if (d == Direction.IN) acc[0] = acc[0].add(amt); else acc[1] = acc[1].add(amt);
            if (s != SourceType.TRANSFER) {
                if (d == Direction.IN) in = in.add(amt); else out = out.add(amt);
            }
        }
        BigDecimal combined = opening.add(in).subtract(out);
        BigDecimal notCleared = txnRepo.signedNotClearedCheques(toTs);
        BigDecimal available = combined.subtract(notCleared);
        List<MethodSummary> methods = new ArrayList<>();
        perMethod.forEach((m, v) -> methods.add(new MethodSummary(m, Money.money(v[0]), Money.money(v[1]),
                Money.money(v[0].subtract(v[1])))));
        return new Summary(from, to, Money.money(opening), Money.money(in), Money.money(out), Money.money(combined),
                Money.money(available), Money.money(chequeRepo.pendingTotal(Direction.IN)),
                Money.money(chequeRepo.pendingTotal(Direction.OUT)), methods);
    }

    // ---------- Commands ----------

    @Transactional
    public TransactionDto create(TransactionRequest r) {
        Person person = r.personId() == null ? null : personService.require(r.personId());
        if (r.method() == PaymentMethod.CHEQUE && (r.chequeNumber() == null || r.chequeNumber().isBlank())) {
            throw ApiException.validation("Cheque number is required for cheque transactions");
        }
        DailyTransaction t = postLinked(new LinkedPayment(r.direction(), r.amount(), r.method(), r.reference(),
                r.businessDate(), person, r.category(), r.description(), SourceType.MANUAL, null,
                r.chequeNumber(), r.chequeBank(), r.approxReturnDate()));
        t.setNotes(trim(r.notes()));
        if (t.getMethod() == PaymentMethod.CHEQUE) {
            chequeRepo.findByTransactionId(t.getId()).ifPresent(c -> c.setChequeDate(r.chequeDate()));
        }
        return get(t.getId());
    }

    /** Posts one canonical money movement for another module, inside the caller's transaction. */
    @Transactional(propagation = Propagation.MANDATORY)
    public DailyTransaction postLinked(LinkedPayment p) {
        if (!Money.isPositive(p.amount())) {
            throw ApiException.validation("Amount must be greater than zero");
        }
        DailyTransaction t = new DailyTransaction();
        t.setBusinessDate(p.businessDate() == null ? LocalDateTime.now() : p.businessDate());
        t.setDirection(p.direction());
        t.setAmount(Money.money(p.amount()));
        t.setMethod(p.method());
        t.setReference(trim(p.reference()));
        t.setPerson(p.person());
        t.setCategory(trim(p.category()));
        t.setDescription(trim(p.description()));
        t.setSourceType(p.sourceType());
        t.setSourceId(p.sourceId());
        t.setApproxReturnDate(p.approxReturnDate());
        txnRepo.save(t);
        if (p.method() == PaymentMethod.CHEQUE) {
            ChequeRecord c = new ChequeRecord();
            c.setTransaction(t);
            c.setChequeNumber(trim(p.chequeNumber() != null ? p.chequeNumber() : p.reference()));
            c.setBankName(trim(p.chequeBank()));
            c.setDirection(p.direction());
            chequeRepo.save(c);
        }
        auditService.record("TRANSACTION_POSTED", "DailyTransaction", t.getId(), null,
                p.sourceType() + (p.sourceId() == null ? "" : "#" + p.sourceId()) + " " + p.direction() + " " + t.getAmount());
        return t;
    }

    @Transactional
    public List<TransactionDto> transfer(TransferRequest r) {
        if (r.fromMethod() == r.toMethod()) {
            throw ApiException.validation("Choose two different payment methods for a transfer");
        }
        if (r.fromMethod() == PaymentMethod.CHEQUE || r.toMethod() == PaymentMethod.CHEQUE) {
            throw ApiException.validation("Record cheques as transactions, not as internal transfers");
        }
        String group = UUID.randomUUID().toString();
        DailyTransaction out = transferLeg(r, Direction.OUT, r.fromMethod(), group);
        DailyTransaction in = transferLeg(r, Direction.IN, r.toMethod(), group);
        return List.of(get(out.getId()), get(in.getId()));
    }

    private DailyTransaction transferLeg(TransferRequest r, Direction d, PaymentMethod m, String group) {
        DailyTransaction t = new DailyTransaction();
        t.setBusinessDate(r.businessDate());
        t.setDirection(d);
        t.setAmount(Money.money(r.amount()));
        t.setMethod(m);
        t.setCategory("Internal transfer");
        t.setDescription("Transfer " + r.fromMethod() + " → " + r.toMethod());
        t.setNotes(trim(r.notes()));
        t.setSourceType(SourceType.TRANSFER);
        t.setTransferGroup(group);
        txnRepo.save(t);
        auditService.record("TRANSFER_POSTED", "DailyTransaction", t.getId(), null, group);
        return t;
    }

    /** Reverses a manual transaction with an opposite auditable entry. Linked entries are reversed via their source. */
    @Transactional
    public TransactionDto reverseManual(Long id, String reason) {
        DailyTransaction t = require(id);
        if (t.getSourceType() != SourceType.MANUAL && t.getSourceType() != SourceType.TRANSFER) {
            throw ApiException.state("This entry belongs to a " + t.getSourceType()
                    + " record. Reverse or adjust it from the original record.");
        }
        if (t.getSourceType() == SourceType.TRANSFER) {
            List<DailyTransaction> legs = txnRepo.findByTransferGroup(t.getTransferGroup()).stream()
                    .filter(x -> x.getStatus() == DailyTransaction.Status.ACTIVE && x.getReversalOfId() == null)
                    .toList();
            legs.forEach(leg -> reverse(leg, reason));
            return get(id);
        }
        reverse(t, reason);
        return get(id);
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public DailyTransaction reverse(DailyTransaction t, String reason) {
        if (reason == null || reason.isBlank()) {
            throw ApiException.validation("A reason is required to reverse a financial entry");
        }
        if (t.getStatus() == DailyTransaction.Status.REVERSED) {
            throw ApiException.state("This entry is already reversed");
        }
        chequeRepo.findByTransactionId(t.getId()).ifPresent(c -> {
            if (c.getStatus() == ChequeRecord.Status.BOUNCED) {
                throw ApiException.state("A bounced cheque is already reversed");
            }
        });
        DailyTransaction rev = new DailyTransaction();
        rev.setBusinessDate(LocalDateTime.now());
        rev.setDirection(t.getDirection() == Direction.IN ? Direction.OUT : Direction.IN);
        rev.setAmount(t.getAmount());
        rev.setMethod(t.getMethod() == PaymentMethod.CHEQUE ? PaymentMethod.CHEQUE : t.getMethod());
        rev.setPerson(t.getPerson());
        rev.setCategory("Reversal");
        rev.setDescription("Reversal of #" + t.getId() + (t.getDescription() == null ? "" : " — " + t.getDescription()));
        rev.setSourceType(t.getSourceType() == SourceType.TRANSFER ? SourceType.TRANSFER : SourceType.REVERSAL);
        rev.setSourceId(t.getId());
        rev.setTransferGroup(t.getTransferGroup());
        rev.setReversalOfId(t.getId());
        rev.setReversalReason(reason.trim());
        txnRepo.save(rev);
        t.setStatus(DailyTransaction.Status.REVERSED);
        t.setReversalReason(reason.trim());
        chequeRepo.findByTransactionId(t.getId()).ifPresent(c -> {
            // Treat a reversed cheque like a bounced one so neither leg is counted in available funds.
            c.setStatus(ChequeRecord.Status.BOUNCED);
            c.setBouncedDate(LocalDate.now());
            c.setBounceReason("Reversed: " + reason.trim());
            c.setBounceReversalTransactionId(rev.getId());
        });
        auditService.record("TRANSACTION_REVERSED", "DailyTransaction", t.getId(), reason, "reversal #" + rev.getId());
        return rev;
    }

    @Transactional
    public ChequeDto clearCheque(Long chequeId, LocalDate date) {
        ChequeRecord c = chequeRepo.findById(chequeId).orElseThrow(() -> ApiException.notFound("Cheque", chequeId));
        if (c.getStatus() != ChequeRecord.Status.PENDING) {
            throw ApiException.state("Only a pending cheque can be cleared (current: " + c.getStatus() + ")");
        }
        c.setStatus(ChequeRecord.Status.CLEARED);
        c.setClearedDate(date == null ? LocalDate.now() : date);
        auditService.record("CHEQUE_CLEARED", "ChequeRecord", c.getId(), null, "txn #" + c.getTransaction().getId());
        return toChequeDto(c);
    }

    /** Bouncing reverses the original money effect exactly once through an auditable reversal entry. */
    @Transactional
    public ChequeDto bounceCheque(Long chequeId, LocalDate date, String reason) {
        ChequeRecord c = chequeRepo.findById(chequeId).orElseThrow(() -> ApiException.notFound("Cheque", chequeId));
        if (c.getStatus() == ChequeRecord.Status.BOUNCED) {
            throw ApiException.state("This cheque is already marked bounced");
        }
        DailyTransaction original = c.getTransaction();
        DailyTransaction rev = new DailyTransaction();
        rev.setBusinessDate(LocalDateTime.now());
        rev.setDirection(original.getDirection() == Direction.IN ? Direction.OUT : Direction.IN);
        rev.setAmount(original.getAmount());
        rev.setMethod(PaymentMethod.CHEQUE);
        rev.setPerson(original.getPerson());
        rev.setCategory("Cheque bounced");
        rev.setDescription("Bounced cheque " + (c.getChequeNumber() == null ? "" : c.getChequeNumber()) + " (txn #" + original.getId() + ")");
        rev.setSourceType(SourceType.CHEQUE_BOUNCE);
        rev.setSourceId(c.getId());
        rev.setReversalOfId(original.getId());
        rev.setReversalReason(reason);
        txnRepo.save(rev);
        original.setStatus(DailyTransaction.Status.REVERSED);
        original.setReversalReason("Cheque bounced" + (reason == null ? "" : ": " + reason));
        c.setStatus(ChequeRecord.Status.BOUNCED);
        c.setBouncedDate(date == null ? LocalDate.now() : date);
        c.setBounceReason(reason);
        c.setBounceReversalTransactionId(rev.getId());
        auditService.record("CHEQUE_BOUNCED", "ChequeRecord", c.getId(), reason, "reversal txn #" + rev.getId());
        return toChequeDto(c);
    }

    /** Whether a linked movement has been reversed or bounced, so callers can restore the outstanding balance. */
    @Transactional(readOnly = true)
    public boolean isEffective(Long transactionId) {
        return transactionId != null && txnRepo.findById(transactionId)
                .map(t -> t.getStatus() == DailyTransaction.Status.ACTIVE).orElse(false);
    }

    public DailyTransaction require(Long id) {
        return txnRepo.findById(id).orElseThrow(() -> ApiException.notFound("Transaction", id));
    }

    // ---------- Mapping ----------

    private Map<Long, ChequeRecord> chequesFor(List<DailyTransaction> list) {
        List<Long> ids = list.stream().filter(t -> t.getMethod() == PaymentMethod.CHEQUE).map(DailyTransaction::getId).toList();
        if (ids.isEmpty()) return Map.of();
        return chequeRepo.findByTransactionIdIn(ids).stream()
                .collect(Collectors.toMap(c -> c.getTransaction().getId(), Function.identity()));
    }

    TransactionDto toDto(DailyTransaction t, ChequeRecord c) {
        return new TransactionDto(t.getId(), t.getBusinessDate(), t.getDirection(), t.getAmount(), t.getCategory(),
                t.getDescription(), t.getMethod(), t.getPerson() == null ? null : t.getPerson().getId(),
                t.getPerson() == null ? null : t.getPerson().getName(), t.getReference(), t.getNotes(),
                t.getSourceType(), t.getSourceId(), t.getTransferGroup(), t.getApproxReturnDate(), t.getStatus(),
                t.getReversalOfId(), t.getReversalReason(), c == null ? null : toChequeDto(c), t.getCreatedAt(),
                t.getCreatedBy());
    }

    private ChequeDto toChequeDto(ChequeRecord c) {
        DailyTransaction t = c.getTransaction();
        return new ChequeDto(c.getId(), c.getChequeNumber(), c.getBankName(), c.getChequeDate(), c.getDirection(),
                c.getStatus(), c.getClearedDate(), c.getBouncedDate(), c.getBounceReason(),
                c.getBounceReversalTransactionId(), t.getId(), t.getAmount(),
                t.getPerson() == null ? null : t.getPerson().getName(), t.getBusinessDate());
    }

    private static String trim(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }

    public static Enums.Direction opposite(Enums.Direction d) {
        return d == Direction.IN ? Direction.OUT : Direction.IN;
    }
}
