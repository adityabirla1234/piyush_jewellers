package com.piyushjewellers.transactions;

import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService service;

    public record ReasonRequest(String reason) {
    }

    public record ChequeActionRequest(LocalDate date, String reason) {
    }

    @GetMapping("/transactions")
    public PageResponse<TransactionService.TransactionDto> search(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(required = false) Enums.Direction direction,
            @RequestParam(required = false) Enums.PaymentMethod method,
            @RequestParam(required = false) Long personId,
            @RequestParam(required = false) Enums.SourceType sourceType,
            @RequestParam(required = false) String q,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "30") int size) {
        return service.search(from, to, direction, method, personId, sourceType, q, page, size);
    }

    @GetMapping("/transactions/summary")
    public TransactionService.Summary summary(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return service.summary(from, to);
    }

    @GetMapping("/transactions/{id}")
    public TransactionService.TransactionDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping("/transactions")
    @ResponseStatus(HttpStatus.CREATED)
    public TransactionService.TransactionDto create(@Valid @RequestBody TransactionService.TransactionRequest request) {
        return service.create(request);
    }

    @PostMapping("/transactions/{id}/reverse")
    public TransactionService.TransactionDto reverse(@PathVariable Long id, @RequestBody ReasonRequest request) {
        return service.reverseManual(id, request.reason());
    }

    @PostMapping("/transfers")
    @ResponseStatus(HttpStatus.CREATED)
    public List<TransactionService.TransactionDto> transfer(@Valid @RequestBody TransactionService.TransferRequest request) {
        return service.transfer(request);
    }

    @GetMapping("/cheques")
    public List<TransactionService.ChequeDto> cheques(@RequestParam(required = false) ChequeRecord.Status status) {
        return service.cheques(status);
    }

    @PostMapping("/cheques/{id}/clear")
    public TransactionService.ChequeDto clear(@PathVariable Long id, @RequestBody(required = false) ChequeActionRequest request) {
        return service.clearCheque(id, request == null ? null : request.date());
    }

    @PostMapping("/cheques/{id}/bounce")
    public TransactionService.ChequeDto bounce(@PathVariable Long id, @RequestBody(required = false) ChequeActionRequest request) {
        return service.bounceCheque(id, request == null ? null : request.date(), request == null ? null : request.reason());
    }
}
