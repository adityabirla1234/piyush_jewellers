package com.piyushjewellers.transactions;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

/**
 * Cheque lifecycle. Pending cheques count in the combined ledger balance but never in cleared/available funds.
 * Clearing affects available funds once; bouncing creates one auditable reversal transaction.
 */
@Getter
@Setter
@Entity
@Table(name = "cheque_records", indexes = @Index(name = "idx_cheque_status", columnList = "status"))
public class ChequeRecord extends BaseEntity {

    public enum Status { PENDING, CLEARED, BOUNCED }

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "transaction_id", unique = true)
    private DailyTransaction transaction;

    @Column(length = 40)
    private String chequeNumber;

    @Column(length = 100)
    private String bankName;

    private LocalDate chequeDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 5)
    private Enums.Direction direction;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Status status = Status.PENDING;

    private LocalDate clearedDate;

    private LocalDate bouncedDate;

    @Column(length = 300)
    private String bounceReason;

    private Long bounceReversalTransactionId;
}
