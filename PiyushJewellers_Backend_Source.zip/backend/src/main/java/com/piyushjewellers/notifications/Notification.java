package com.piyushjewellers.notifications;

import com.piyushjewellers.common.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDateTime;

/**
 * In-app notification generated from due reminders, overdue loans, mortgage reminder dates and cheques whose
 * date has arrived. {@code notificationKey} includes the due date so a rescheduled item notifies again.
 * Category is a plain string so new categories never need a column change.
 */
@Getter
@Setter
@Entity
@Table(name = "notifications", indexes = @Index(name = "idx_notification_read", columnList = "readAt,dueAt"))
public class Notification extends BaseEntity {

    @Column(nullable = false, unique = true, length = 100)
    private String notificationKey;

    @Column(nullable = false, length = 20)
    private String category;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(length = 500)
    private String body;

    @Column(length = 30)
    private String sourceType;

    private Long sourceId;

    private Long personId;

    private LocalDateTime dueAt;

    private Instant readAt;
}
