package com.piyushjewellers.notifications;

import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.loans.Loan;
import com.piyushjewellers.loans.LoanService;
import com.piyushjewellers.mortgages.Mortgage;
import com.piyushjewellers.mortgages.MortgageService;
import com.piyushjewellers.people.Person;
import com.piyushjewellers.reminders.Reminder;
import com.piyushjewellers.reminders.ReminderController;
import com.piyushjewellers.transactions.ChequeRecord;
import com.piyushjewellers.transactions.TransactionRepositories;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class NotificationService {

    public interface NotificationRepository extends JpaRepository<Notification, Long> {
        boolean existsByNotificationKey(String key);

        long countByReadAtIsNull();

        List<Notification> findByReadAtIsNull();

        @Query("select n from Notification n where (:unreadOnly = false or n.readAt is null)")
        Page<Notification> list(boolean unreadOnly, Pageable pageable);

        @Modifying
        @Query("update Notification n set n.readAt = :at where n.readAt is null")
        int markAllRead(Instant at);
    }

    public record NotificationDto(Long id, String category, String title, String body, String sourceType, Long sourceId,
                                  Long personId, LocalDateTime dueAt, boolean read, Instant readAt, Instant createdAt) {
        static NotificationDto from(Notification n) {
            return new NotificationDto(n.getId(), n.getCategory(), n.getTitle(), n.getBody(), n.getSourceType(),
                    n.getSourceId(), n.getPersonId(), n.getDueAt(), n.getReadAt() != null, n.getReadAt(), n.getCreatedAt());
        }
    }

    private final NotificationRepository repo;
    private final ReminderController.ReminderRepository reminderRepo;
    private final LoanService.LoanRepository loanRepo;
    private final LoanService loanService;
    private final MortgageService.MortgageRepository mortgageRepo;
    private final TransactionRepositories.ChequeRecordRepository chequeRepo;

    @Transactional(readOnly = true)
    public PageResponse<NotificationDto> list(boolean unreadOnly, int page, int size) {
        return PageResponse.of(repo.list(unreadOnly, PageResponse.pageable(page, size,
                Sort.by(Sort.Direction.DESC, "dueAt", "id"))), NotificationDto::from);
    }

    @Transactional(readOnly = true)
    public long unreadCount() {
        return repo.countByReadAtIsNull();
    }

    @Transactional
    public NotificationDto markRead(Long id) {
        Notification n = repo.findById(id).orElseThrow(() -> ApiException.notFound("Notification", id));
        if (n.getReadAt() == null) n.setReadAt(Instant.now());
        return NotificationDto.from(n);
    }

    @Transactional
    public int markAllRead() {
        return repo.markAllRead(Instant.now());
    }

    /**
     * Creates notifications for everything that has become due and auto-reads unread ones whose source is no
     * longer pending (loan settled, cheque cleared, reminder disabled). Idempotent through the unique key.
     */
    @Transactional
    public synchronized int refresh() {
        LocalDateTime now = LocalDateTime.now();
        LocalDate today = now.toLocalDate();
        Set<String> live = new HashSet<>();
        int created = 0;

        for (Reminder r : reminderRepo.findAllByOrderByRemindAtAsc()) {
            if (!r.isEnabled() || r.getRemindAt().isAfter(now)) continue;
            String key = "REMINDER:" + r.getId() + ":" + r.getRemindAt();
            live.add(key);
            created += create(key, "REMINDER", r.getTitle(), r.getNotes(), r.getSourceType(), r.getSourceId(),
                    r.getPersonId(), r.getRemindAt());
        }
        for (Loan l : loanRepo.findByStatus(Loan.Status.ACTIVE)) {
            if (l.getExpectedReturnDate() == null || l.getExpectedReturnDate().isAfter(today)) continue;
            BigDecimal outstanding = loanService.outstanding(l);
            if (outstanding.signum() <= 0) continue;
            String key = "LOAN:" + l.getId() + ":" + l.getExpectedReturnDate();
            live.add(key);
            boolean lent = l.getKind() == Loan.Kind.LENT;
            created += create(key, "LOAN", (lent ? "Collect from " : "Repay ") + name(l.getPerson()),
                    "Rs. " + outstanding.toPlainString() + (lent ? " to receive" : " to pay") + " · due " + l.getExpectedReturnDate(),
                    "LOAN", l.getId(), l.getPerson().getId(), l.getExpectedReturnDate().atStartOfDay());
        }
        for (Mortgage m : mortgageRepo.findByStatus(Mortgage.Status.ACTIVE)) {
            if (m.getApproxReminderDate() == null || m.getApproxReminderDate().isAfter(today)) continue;
            String key = "MORTGAGE:" + m.getId() + ":" + m.getApproxReminderDate();
            live.add(key);
            Person p = m.getAccount().getPerson();
            created += create(key, "MORTGAGE", "Mortgage " + m.getSerial() + " · " + name(p),
                    "Reminder date " + m.getApproxReminderDate() + ". Review interest and follow up.",
                    "MORTGAGE", m.getId(), p.getId(), m.getApproxReminderDate().atStartOfDay());
        }
        for (ChequeRecord c : chequeRepo.findByStatusFetch(ChequeRecord.Status.PENDING)) {
            if (c.getChequeDate() == null || c.getChequeDate().isAfter(today)) continue;
            String key = "CHEQUE:" + c.getId() + ":" + c.getChequeDate();
            live.add(key);
            boolean in = c.getDirection() == Enums.Direction.IN;
            var t = c.getTransaction();
            created += create(key, "CHEQUE", (in ? "Deposit cheque " : "Cheque to be debited ") + c.getChequeNumber(),
                    "Rs. " + t.getAmount().toPlainString() + (t.getPerson() == null ? "" : " · " + name(t.getPerson()))
                            + " · dated " + c.getChequeDate() + ". Mark it cleared or bounced.",
                    "CHEQUE", c.getId(), t.getPerson() == null ? null : t.getPerson().getId(), c.getChequeDate().atStartOfDay());
        }

        Instant at = Instant.now();
        for (Notification n : repo.findByReadAtIsNull()) {
            if (!live.contains(n.getNotificationKey())) n.setReadAt(at);
        }
        return created;
    }

    private int create(String key, String category, String title, String body, String sourceType, Long sourceId,
                       Long personId, LocalDateTime dueAt) {
        if (repo.existsByNotificationKey(key)) return 0;
        Notification n = new Notification();
        n.setNotificationKey(key);
        n.setCategory(category);
        n.setTitle(trim(title, 200));
        n.setBody(trim(body, 500));
        n.setSourceType(sourceType);
        n.setSourceId(sourceId);
        n.setPersonId(personId);
        n.setDueAt(dueAt);
        repo.save(n);
        return 1;
    }

    private static String name(Person p) {
        return p == null ? "" : p.getName();
    }

    private static String trim(String s, int max) {
        if (s == null) return null;
        return s.length() <= max ? s : s.substring(0, max);
    }
}
