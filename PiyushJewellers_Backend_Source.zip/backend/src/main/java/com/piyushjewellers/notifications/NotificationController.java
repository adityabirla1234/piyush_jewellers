package com.piyushjewellers.notifications;

import com.piyushjewellers.common.PageResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/v1/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private static final long REFRESH_INTERVAL_MS = 60_000;

    private final NotificationService service;
    private volatile long lastRefresh;

    @GetMapping
    public PageResponse<NotificationService.NotificationDto> list(@RequestParam(defaultValue = "false") boolean unreadOnly,
                                                                  @RequestParam(defaultValue = "0") int page,
                                                                  @RequestParam(defaultValue = "50") int size) {
        refreshIfStale();
        return service.list(unreadOnly, page, size);
    }

    @GetMapping("/unread-count")
    public Map<String, Long> unreadCount() {
        refreshIfStale();
        return Map.of("count", service.unreadCount());
    }

    @PostMapping("/{id}/read")
    public NotificationService.NotificationDto markRead(@PathVariable Long id) {
        return service.markRead(id);
    }

    @PostMapping("/read-all")
    public Map<String, Integer> markAllRead() {
        return Map.of("updated", service.markAllRead());
    }

    @PostMapping("/refresh")
    public Map<String, Integer> refresh() {
        return Map.of("created", runRefresh());
    }

    @Scheduled(fixedDelayString = "${pj.notifications.refresh-ms:900000}", initialDelay = 60_000)
    public void scheduledRefresh() {
        runRefresh();
    }

    private void refreshIfStale() {
        if (System.currentTimeMillis() - lastRefresh > REFRESH_INTERVAL_MS) runRefresh();
    }

    private int runRefresh() {
        lastRefresh = System.currentTimeMillis();
        try {
            return service.refresh();
        } catch (DataIntegrityViolationException e) {
            log.debug("Concurrent notification refresh; skipped", e);
            return 0;
        } catch (RuntimeException e) {
            log.warn("Notification refresh failed", e);
            return 0;
        }
    }
}
