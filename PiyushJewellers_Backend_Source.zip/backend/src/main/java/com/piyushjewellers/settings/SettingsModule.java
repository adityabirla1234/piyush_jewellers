package com.piyushjewellers.settings;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/** Shop-level configuration persisted as a single settings row. */
public final class SettingsModule {

    private SettingsModule() {
    }

    @Getter
    @Setter
    @Entity
    @Table(name = "shop_settings")
    public static class ShopSettings extends BaseEntity {
        @Column(nullable = false, precision = 19, scale = 2)
        private BigDecimal openingBalance = BigDecimal.ZERO;

        @Column(nullable = false)
        private boolean crossMetalSettlementAllowed = false;

        @Column(length = 120)
        private String shopName = "Piyush Jewellers";

        @Column(length = 300)
        private String shopAddress;

        @Column(length = 40)
        private String shopPhone;
    }

    public interface ShopSettingsRepository extends JpaRepository<ShopSettings, Long> {
        Optional<ShopSettings> findFirstByOrderByIdAsc();
    }

    public record PurityDto(String carat, int percent) {
    }

    public record SettingsDto(BigDecimal openingBalance, boolean crossMetalSettlementAllowed, String shopName,
                              String shopAddress, String shopPhone, int maxPhotosPerProduct, long maxPhotoBytes,
                              List<PurityDto> purities, Long version) {
    }

    public record UpdateSettingsRequest(@DecimalMin("0.00") BigDecimal openingBalance, Boolean crossMetalSettlementAllowed,
                                        String shopName, String shopAddress, String shopPhone) {
    }

    @Service
    @RequiredArgsConstructor
    public static class SettingsService {
        private final ShopSettingsRepository repository;
        private final AuditService auditService;

        @Value("${pj.photos.max-per-product:12}")
        private int maxPhotos;
        @Value("${pj.photos.max-bytes:10485760}")
        private long maxPhotoBytes;

        @Transactional
        public ShopSettings current() {
            return repository.findFirstByOrderByIdAsc().orElseGet(() -> repository.save(new ShopSettings()));
        }

        @Transactional
        public SettingsDto get() {
            return toDto(current());
        }

        @Transactional
        public SettingsDto update(UpdateSettingsRequest request) {
            ShopSettings s = current();
            if (request.openingBalance() != null) s.setOpeningBalance(Money.money(request.openingBalance()));
            if (request.crossMetalSettlementAllowed() != null) s.setCrossMetalSettlementAllowed(request.crossMetalSettlementAllowed());
            if (request.shopName() != null && !request.shopName().isBlank()) s.setShopName(request.shopName().trim());
            if (request.shopAddress() != null) s.setShopAddress(request.shopAddress().trim());
            if (request.shopPhone() != null) s.setShopPhone(request.shopPhone().trim());
            repository.saveAndFlush(s);
            auditService.record("SETTINGS_UPDATED", "ShopSettings", s.getId(), null,
                    "openingBalance=" + s.getOpeningBalance() + ", crossMetal=" + s.isCrossMetalSettlementAllowed());
            return toDto(s);
        }

        private SettingsDto toDto(ShopSettings s) {
            List<PurityDto> purities = Arrays.stream(Enums.Carat.values())
                    .map(c -> new PurityDto(c.name(), c.percent())).toList();
            return new SettingsDto(s.getOpeningBalance(), s.isCrossMetalSettlementAllowed(), s.getShopName(),
                    s.getShopAddress(), s.getShopPhone(), maxPhotos, maxPhotoBytes, purities, s.getVersion());
        }
    }

    @RestController
    @RequestMapping("/api/v1/settings")
    @RequiredArgsConstructor
    public static class SettingsController {
        private final SettingsService service;

        @GetMapping
        public SettingsDto get() {
            return service.get();
        }

        @PutMapping
        @PreAuthorize("hasRole('OWNER')")
        public SettingsDto update(@RequestBody UpdateSettingsRequest request) {
            return service.update(request);
        }
    }
}
