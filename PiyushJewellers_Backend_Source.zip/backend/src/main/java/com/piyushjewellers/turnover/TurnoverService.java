package com.piyushjewellers.turnover;

import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.enums.Enums.Direction;
import com.piyushjewellers.common.enums.Enums.SourceType;
import com.piyushjewellers.sellpurchase.SellPurchaseService;
import com.piyushjewellers.transactions.TransactionRepositories;
import com.piyushjewellers.transactions.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Shop turnover for a period: every ledger source that moved money in or out (transfers between own accounts
 * excluded), the payment-method split, opening/closing balances and sales/purchase turnover per metal.
 */
@Service
@RequiredArgsConstructor
public class TurnoverService {

    private final TransactionRepositories.DailyTransactionRepository txnRepo;
    private final TransactionService transactionService;
    private final SellPurchaseService sellPurchaseService;

    public record Line(String category, BigDecimal moneyIn, BigDecimal moneyOut, long count) {
    }

    public record Component(SourceType source, String label, BigDecimal moneyIn, BigDecimal moneyOut, BigDecimal net,
                            long count, List<Line> lines) {
    }

    public record Result(LocalDate from, LocalDate to, BigDecimal openingBalance, BigDecimal moneyIn,
                         BigDecimal moneyOut, BigDecimal net, BigDecimal closingBalance, BigDecimal availableBalance,
                         BigDecimal pendingChequesIn, BigDecimal pendingChequesOut, BigDecimal transfersMoved,
                         List<Component> components, List<TransactionService.MethodSummary> byMethod,
                         BigDecimal salesTurnover, BigDecimal purchaseTurnover, BigDecimal grossTurnover,
                         List<SellPurchaseService.MetalTotals> byMetal, SellPurchaseService.Bucket sales,
                         SellPurchaseService.Bucket purchase) {
    }

    @Transactional(readOnly = true)
    public Result compute(LocalDate from, LocalDate to) {
        if (from == null) from = LocalDate.now().withDayOfMonth(1);
        if (to == null) to = LocalDate.now();
        if (to.isBefore(from)) throw ApiException.validation("End date is before start date");
        TransactionService.Summary sm = transactionService.summary(from, to);

        Map<SourceType, Map<String, BigDecimal[]>> grouped = new EnumMap<>(SourceType.class);
        Map<SourceType, long[]> counts = new EnumMap<>(SourceType.class);
        BigDecimal transfers = BigDecimal.ZERO;
        for (Object[] row : txnRepo.sumBySourceAndCategory(from.atStartOfDay(), to.plusDays(1).atStartOfDay())) {
            SourceType src = (SourceType) row[0];
            String category = row[1] == null || row[1].toString().isBlank() ? "Other" : row[1].toString();
            Direction dir = (Direction) row[2];
            BigDecimal amt = (BigDecimal) row[3];
            long n = ((Number) row[4]).longValue();
            if (src == SourceType.TRANSFER) {
                if (dir == Direction.OUT) transfers = transfers.add(amt);
                continue;
            }
            BigDecimal[] acc = grouped.computeIfAbsent(src, k -> new LinkedHashMap<>())
                    .computeIfAbsent(category, k -> new BigDecimal[]{BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO});
            if (dir == Direction.IN) acc[0] = acc[0].add(amt); else acc[1] = acc[1].add(amt);
            acc[2] = acc[2].add(BigDecimal.valueOf(n));
            counts.computeIfAbsent(src, k -> new long[1])[0] += n;
        }
        List<Component> components = new ArrayList<>();
        grouped.forEach((src, cats) -> {
            BigDecimal in = BigDecimal.ZERO, out = BigDecimal.ZERO;
            List<Line> lines = new ArrayList<>();
            for (Map.Entry<String, BigDecimal[]> e : cats.entrySet()) {
                BigDecimal[] v = e.getValue();
                in = in.add(v[0]);
                out = out.add(v[1]);
                lines.add(new Line(e.getKey(), Money.money(v[0]), Money.money(v[1]), v[2].longValue()));
            }
            lines.sort(Comparator.comparing((Line l) -> l.moneyIn().add(l.moneyOut())).reversed());
            components.add(new Component(src, label(src), Money.money(in), Money.money(out), Money.money(in.subtract(out)),
                    counts.get(src)[0], lines));
        });
        components.sort(Comparator.comparing((Component c) -> c.moneyIn().add(c.moneyOut())).reversed());

        SellPurchaseService.Result sp = sellPurchaseService.query(null, from, to, null, null);
        BigDecimal net = sm.moneyIn().subtract(sm.moneyOut());
        return new Result(from, to, sm.openingBalance(), sm.moneyIn(), sm.moneyOut(), Money.money(net),
                sm.combinedBalance(), sm.availableBalance(), sm.pendingChequesIn(), sm.pendingChequesOut(),
                Money.money(transfers), components, sm.byMethod(), sp.sales().amount(), sp.purchase().amount(),
                Money.money(sp.sales().amount().add(sp.purchase().amount())), sp.byMetal(), sp.sales(), sp.purchase());
    }

    public static String label(SourceType s) {
        return switch (s) {
            case MANUAL -> "Manual entries";
            case TRANSFER -> "Transfers";
            case CUSTOMER_BILL -> "Customer bills";
            case DEALER_SETTLEMENT -> "Dealer settlements";
            case LOAN -> "Loans given / taken";
            case LOAN_REPAYMENT -> "Loan repayments";
            case MORTGAGE_ISSUE -> "Mortgage issued";
            case MORTGAGE_PAYMENT -> "Mortgage payments & interest";
            case EXCHANGE -> "Jewellery exchange";
            case CHEQUE_BOUNCE -> "Cheque bounces";
            case REVERSAL -> "Reversals / corrections";
        };
    }
}
