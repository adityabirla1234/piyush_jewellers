package com.piyushjewellers.exchange;

import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.inventory.Product;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "exchange_lines")
public class ExchangeLine {

    public enum Side { RECEIVED, ISSUED }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "exchange_id")
    private Exchange exchange;

    @Column(nullable = false)
    private int lineNo;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Side side;

    @Column(nullable = false, length = 300)
    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id")
    private Product product;

    /** For received items without a product: inventory category to add them to, or null to not stock them. */
    @Enumerated(EnumType.STRING)
    @Column(length = 30)
    private Product.Category newProductCategory;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.Metal metal;

    @Column(length = 20)
    private String purity;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal grossWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal lessWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal netWeight = BigDecimal.ZERO;

    @Column(nullable = false)
    private int pieces;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal rate = BigDecimal.ZERO;

    @Column(name = "line_value", nullable = false, precision = 19, scale = 2)
    private BigDecimal value = BigDecimal.ZERO;
}
