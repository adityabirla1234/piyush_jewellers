package com.piyushjewellers.exchange;

import com.piyushjewellers.common.PageResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/exchanges")
@RequiredArgsConstructor
public class ExchangeController {

    private final ExchangeService service;

    public record ReasonRequest(String reason) {
    }

    @GetMapping
    public PageResponse<ExchangeService.ExchangeDto> search(@RequestParam(required = false) Exchange.Status status,
                                                            @RequestParam(required = false) Long personId,
                                                            @RequestParam(required = false) String q,
                                                            @RequestParam(defaultValue = "0") int page,
                                                            @RequestParam(defaultValue = "30") int size) {
        return service.search(status, personId, q, page, size);
    }

    @GetMapping("/{id}")
    public ExchangeService.ExchangeDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ExchangeService.ExchangeDto create(@Valid @RequestBody ExchangeService.ExchangeRequest request) {
        return service.createDraft(request);
    }

    @PutMapping("/{id}")
    public ExchangeService.ExchangeDto update(@PathVariable Long id, @Valid @RequestBody ExchangeService.ExchangeRequest request) {
        return service.updateDraft(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteDraft(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/finalize")
    public ExchangeService.ExchangeDto finalizeExchange(@PathVariable Long id) {
        return service.finalizeExchange(id);
    }

    @PostMapping("/{id}/reverse")
    public ExchangeService.ExchangeDto reverse(@PathVariable Long id, @RequestBody ReasonRequest request) {
        return service.reverse(id, request.reason());
    }
}
