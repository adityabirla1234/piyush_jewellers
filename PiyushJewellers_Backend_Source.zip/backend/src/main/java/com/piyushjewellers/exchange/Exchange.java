package com.piyushjewellers.exchange;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.people.Person;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "exchanges")
public class Exchange extends BaseEntity {

    public enum Status { DRAFT, FINALIZED, REVERSED }

    @Column(nullable = false, unique = true, length = 30)
    private String exchangeNumber;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(length = 150)
    private String partyName;

    @Column(nullable = false)
    private LocalDate exchangeDate;

    @Column(length = 1000)
    private String notes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Status status = Status.DRAFT;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal receivedValue = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal issuedValue = BigDecimal.ZERO;

    @Enumerated(EnumType.STRING)
    @Column(length = 10)
    private Enums.PaymentMethod differenceMethod;

    @Column(length = 120)
    private String differenceReference;

    private Long transactionId;

    private Instant finalizedAt;

    @Column(length = 300)
    private String reversalReason;

    @OneToMany(mappedBy = "exchange", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("lineNo ASC")
    private List<ExchangeLine> lines = new ArrayList<>();
}
