package com.piyushjewellers.dashboard;

import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.dues.DueService;
import com.piyushjewellers.inventory.InventoryRepositories;
import com.piyushjewellers.loans.Loan;
import com.piyushjewellers.loans.LoanService;
import com.piyushjewellers.mortgages.MortgageService;
import com.piyushjewellers.transactions.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

/** Aggregates computed with indexed queries; no full-ledger downloads. */
@RestController
@RequestMapping("/api/v1/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final TransactionService transactionService;
    private final DueService dueService;
    private final MortgageService.MortgageRepository mortgageRepo;
    private final LoanService.LoanRepository loanRepo;
    private final LoanService loanService;
    private final InventoryRepositories.ProductRepository productRepo;
    private final InventoryRepositories.BarLotRepository barLotRepo;

    public record CountAmount(long count, BigDecimal amount) {
    }

    public record InventorySummary(long productCount, long outOfStockCount, BigDecimal goldNetWeight,
                                   BigDecimal silverNetWeight, BigDecimal goldBarWeight, BigDecimal silverBarWeight) {
    }

    public record Dashboard(TransactionService.Summary allTime, TransactionService.Summary today,
                            BigDecimal totalReceivable, BigDecimal totalPayable, CountAmount activeMortgages,
                            CountAmount activeLent, CountAmount activeBorrowed, InventorySummary inventory,
                            List<TransactionService.TransactionDto> recentTransactions, Instant generatedAt) {
    }

    @GetMapping
    @Transactional
    public Dashboard get() {
        LocalDate today = LocalDate.now(ZoneId.of("Asia/Kolkata"));
        TransactionService.Summary all = transactionService.summary(null, null);
        TransactionService.Summary day = transactionService.summary(today, today);
        DueService.DueOverview dues = dueService.overview(null, null, null, "ACTIVE", null, null, null, 0, 1);
        Object[] m = mortgageRepo.activeTotals().get(0);
        long lentCount = 0;
        long borrowedCount = 0;
        BigDecimal lent = BigDecimal.ZERO;
        BigDecimal borrowed = BigDecimal.ZERO;
        for (Loan l : loanRepo.findByStatus(Loan.Status.ACTIVE)) {
            BigDecimal o = loanService.outstanding(l);
            if (l.getKind() == Loan.Kind.LENT) {
                lentCount++;
                lent = lent.add(o);
            } else {
                borrowedCount++;
                borrowed = borrowed.add(o);
            }
        }
        InventorySummary inv = new InventorySummary(productRepo.countByActiveTrue(), productRepo.countOutOfStock(),
                Money.weight(productRepo.totalNetWeight(Enums.Metal.GOLD)), Money.weight(productRepo.totalNetWeight(Enums.Metal.SILVER)),
                Money.weight(barLotRepo.totalRemaining(Enums.Metal.GOLD)), Money.weight(barLotRepo.totalRemaining(Enums.Metal.SILVER)));
        return new Dashboard(all, day, dues.totalReceivable(), dues.totalPayable(),
                new CountAmount((Long) m[0], Money.money((BigDecimal) m[1])),
                new CountAmount(lentCount, Money.money(lent)), new CountAmount(borrowedCount, Money.money(borrowed)),
                inv, transactionService.recent(), Instant.now());
    }
}
