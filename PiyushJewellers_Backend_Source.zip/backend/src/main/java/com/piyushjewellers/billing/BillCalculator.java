package com.piyushjewellers.billing;

import com.piyushjewellers.common.Money;

import java.math.BigDecimal;

/**
 * Customer bill line valuation policy: line total = net weight × rate + making charges.
 * A blank making charge contributes zero only after the user explicitly confirms "no making charges".
 */
public final class BillCalculator {

    private BillCalculator() {
    }

    public static BigDecimal net(BigDecimal gross, BigDecimal less, BigDecimal explicitNet) {
        if (explicitNet != null) return Money.weight(explicitNet);
        return Money.weight(Money.nz(gross).subtract(Money.nz(less)));
    }

    public static BigDecimal metalValue(BigDecimal netWeight, BigDecimal rate) {
        return Money.money(Money.nz(netWeight).multiply(Money.nz(rate)));
    }

    public static BigDecimal lineTotal(BigDecimal netWeight, BigDecimal rate, BigDecimal makingCharges) {
        return Money.money(metalValue(netWeight, rate).add(Money.nz(makingCharges)));
    }
}
