package com.piyushjewellers.billing;

import com.piyushjewellers.inventory.Product;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Entity
@Table(name = "customer_bill_lines")
public class BillLine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bill_id")
    private CustomerBill bill;

    @Column(nullable = false)
    private int lineNo;

    @Column(nullable = false, length = 300)
    private String description;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id")
    private Product product;

    /** For purchase lines without an existing product: category to add the item to inventory, or null to skip. */
    @Enumerated(EnumType.STRING)
    @Column(length = 30)
    private Product.Category newProductCategory;

    @Column(length = 20)
    private String purity;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal grossWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal lessWeight = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 4)
    private BigDecimal netWeight = BigDecimal.ZERO;

    @Column(nullable = false)
    private int pieces;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal rate = BigDecimal.ZERO;

    /** Intentionally nullable: making charges start blank and must be entered or explicitly confirmed as zero. */
    @Column(precision = 19, scale = 2)
    private BigDecimal makingCharges;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal lineTotal = BigDecimal.ZERO;
}
