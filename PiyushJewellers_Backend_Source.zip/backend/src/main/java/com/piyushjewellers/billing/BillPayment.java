package com.piyushjewellers.billing;

import com.piyushjewellers.common.enums.Enums;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Settlement allocation for a bill. Money allocations link to exactly one canonical DailyTransaction once posted.
 * Weight allocations move MR Biscuit metal instead: received into a new lot on sales, issued from a lot on purchases.
 */
@Getter
@Setter
@Entity
@Table(name = "customer_bill_payments")
public class BillPayment {

    public enum Kind { MONEY, WEIGHT }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "bill_id")
    private CustomerBill bill;

    /** Null on rows saved before weight settlement existed; those are money payments. */
    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(length = 10)
    private Kind kind;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Enums.PaymentMethod method;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(length = 120)
    private String reference;

    @Column(length = 40)
    private String chequeNumber;

    @Column(length = 100)
    private String chequeBank;

    private LocalDateTime paidAt;

    private Long transactionId;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(length = 10)
    private Enums.Metal metal;

    @Column(precision = 19, scale = 4)
    private BigDecimal weight;

    @Column(precision = 19, scale = 2)
    private BigDecimal rate;

    @Column(length = 20)
    private String purity;

    private Long barLotId;

    @Column(length = 40)
    private String barLotCode;

    private Boolean metalPosted;

    private Boolean metalReversed;

    public boolean isWeight() {
        return kind == Kind.WEIGHT;
    }

    public boolean isMetalEffective() {
        return isWeight() && Boolean.TRUE.equals(metalPosted) && !Boolean.TRUE.equals(metalReversed);
    }
}
