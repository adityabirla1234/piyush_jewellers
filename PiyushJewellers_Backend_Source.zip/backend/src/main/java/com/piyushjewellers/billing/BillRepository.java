package com.piyushjewellers.billing;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDate;
import java.util.List;

public interface BillRepository extends JpaRepository<CustomerBill, Long> {

    @Query("""
            select b from CustomerBill b left join b.person p
            where (:type is null or b.billType = :type)
              and (:status is null or b.status = :status)
              and (:personId is null or p.id = :personId)
              and (:from is null or b.billDate >= :from)
              and (:to is null or b.billDate <= :to)
              and (:q is null or lower(b.billNumber) like lower(concat('%', :q, '%'))
                   or lower(b.customerName) like lower(concat('%', :q, '%'))
                   or lower(p.name) like lower(concat('%', :q, '%'))
                   or b.customerContact like concat('%', :q, '%'))
            """)
    Page<CustomerBill> search(CustomerBill.Type type, CustomerBill.Status status, Long personId, LocalDate from,
                              LocalDate to, String q, Pageable pageable);

    boolean existsByBillTypeAndBillNumber(CustomerBill.Type type, String billNumber);

    long countByBillType(CustomerBill.Type type);

    List<CustomerBill> findByPersonIdAndStatus(Long personId, CustomerBill.Status status);

    List<CustomerBill> findByStatus(CustomerBill.Status status);

    List<CustomerBill> findByPersonIdOrderByBillDateDesc(Long personId);

    List<CustomerBill> findByStatusAndBillDateBetweenOrderByBillDateAscIdAsc(CustomerBill.Status status, LocalDate from, LocalDate to);
}
