package com.piyushjewellers.billing;

import com.piyushjewellers.common.BaseEntity;
import com.piyushjewellers.people.Person;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "customer_bills",
        uniqueConstraints = @UniqueConstraint(name = "uk_bill_type_number", columnNames = {"billType", "billNumber"}),
        indexes = {
                @Index(name = "idx_bill_date", columnList = "billDate"),
                @Index(name = "idx_bill_person", columnList = "person_id")
        })
public class CustomerBill extends BaseEntity {

    public enum Type { SALES, PURCHASE }

    public enum Status { DRAFT, FINALIZED, REVERSED }

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Type billType;

    @Column(nullable = false, length = 40)
    private String billNumber;

    @Column(nullable = false)
    private LocalDate billDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "person_id")
    private Person person;

    @Column(length = 150)
    private String customerName;

    @Column(length = 30)
    private String customerContact;

    @Column(length = 1000)
    private String notes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Status status = Status.DRAFT;

    @Column(nullable = false)
    private boolean makingChargesZeroConfirmed;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal subtotal = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal makingChargesTotal = BigDecimal.ZERO;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal grandTotal = BigDecimal.ZERO;

    private Instant finalizedAt;

    @Column(length = 300)
    private String reversalReason;

    private Instant reversedAt;

    @OneToMany(mappedBy = "bill", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("lineNo ASC")
    private List<BillLine> lines = new ArrayList<>();

    @OneToMany(mappedBy = "bill", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("id ASC")
    private List<BillPayment> payments = new ArrayList<>();
}
