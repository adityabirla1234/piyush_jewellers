package com.piyushjewellers.billing;

import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.reports.PdfBuilder;
import com.piyushjewellers.settings.SettingsModule;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static com.piyushjewellers.reports.PdfBuilder.g;
import static com.piyushjewellers.reports.PdfBuilder.rs;
import static com.piyushjewellers.reports.PdfBuilder.s;

@RestController
@RequestMapping("/api/v1/customer-bills")
@RequiredArgsConstructor
public class BillController {

    private final BillService service;
    private final SettingsModule.SettingsService settingsService;

    public record ReasonRequest(String reason) {
    }

    @GetMapping
    public PageResponse<BillService.BillDto> search(@RequestParam(required = false) CustomerBill.Type type,
                                                    @RequestParam(required = false) CustomerBill.Status status,
                                                    @RequestParam(required = false) Long personId,
                                                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
                                                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
                                                    @RequestParam(required = false) String q,
                                                    @RequestParam(defaultValue = "0") int page,
                                                    @RequestParam(defaultValue = "30") int size) {
        return service.search(type, status, personId, from, to, q, page, size);
    }

    @GetMapping("/{id}")
    public BillService.BillDto get(@PathVariable Long id) {
        return service.get(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public BillService.BillDto create(@Valid @RequestBody BillService.BillRequest request) {
        return service.createDraft(request);
    }

    @PutMapping("/{id}")
    public BillService.BillDto update(@PathVariable Long id, @Valid @RequestBody BillService.BillRequest request) {
        return service.updateDraft(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDraft(@PathVariable Long id) {
        service.deleteDraft(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/finalize")
    public BillService.BillDto finalizeBill(@PathVariable Long id) {
        return service.finalizeBill(id);
    }

    @PostMapping("/{id}/payments")
    public BillService.BillDto addPayment(@PathVariable Long id, @Valid @RequestBody BillService.PaymentRequest request) {
        return service.addPayment(id, request);
    }

    @PostMapping("/{id}/reverse")
    public BillService.BillDto reverse(@PathVariable Long id, @RequestBody ReasonRequest request) {
        return service.reverse(id, request.reason());
    }

    @GetMapping(value = "/{id}/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> pdf(@PathVariable Long id) {
        BillService.BillDto b = service.get(id);
        var settings = settingsService.current();
        String title = (b.type() == CustomerBill.Type.SALES ? "Sales Bill " : "Purchase Bill ") + b.billNumber();
        PdfBuilder pdf = new PdfBuilder(settings.getShopName(), title, false);
        if (settings.getShopAddress() != null) pdf.meta("Address", settings.getShopAddress());
        pdf.meta("Bill date", s(b.billDate()))
                .meta("Customer", b.customerName() == null ? "Walk-in" : b.customerName() + (b.customerContact() == null ? "" : " (" + b.customerContact() + ")"))
                .meta("Status", b.status().name() + " / " + b.paymentState())
                .generatedNow();
        if (b.status() == CustomerBill.Status.DRAFT) pdf.warning("DRAFT — NOT A FINALIZED BILL");
        if (b.status() == CustomerBill.Status.REVERSED) pdf.warning("REVERSED: " + s(b.reversalReason()));
        List<List<String>> rows = new ArrayList<>();
        for (BillService.LineDto l : b.lines()) {
            rows.add(List.of(String.valueOf(l.lineNo()), l.description() + (l.purity() == null ? "" : " (" + l.purity() + ")"),
                    g(l.grossWeight()), g(l.lessWeight()), g(l.netWeight()), String.valueOf(l.pieces()),
                    l.pairs() == null ? "-" : String.valueOf(l.pairs()), rs(l.rate()),
                    l.makingCharges() == null ? "None" : rs(l.makingCharges()), rs(l.lineTotal())));
        }
        pdf.section("Items").table(List.of("#", "Description", "Gross", "Less", "Net", "Pcs", "Pairs", "Rate/g", "Making", "Total"),
                rows, new float[]{3, 20, 9, 8, 9, 5, 5, 10, 10, 12}, new int[]{2, 3, 4, 5, 6, 7, 8, 9}, null);
        List<String[]> totals = new ArrayList<>();
        totals.add(new String[]{"Metal value", rs(b.subtotal())});
        totals.add(new String[]{"Making charges", rs(b.makingChargesTotal())});
        totals.add(new String[]{"Grand total", rs(b.grandTotal())});
        totals.add(new String[]{"Paid", rs(b.paidAmount())});
        totals.add(new String[]{"Outstanding", rs(b.outstandingAmount())});
        pdf.keyValues(totals);
        if (!b.payments().isEmpty()) {
            List<List<String>> pay = new ArrayList<>();
            for (BillService.PaymentDto p : b.payments()) {
                boolean weight = p.kind() == BillPayment.Kind.WEIGHT;
                String method = weight ? "WEIGHT · " + p.metal().name() : p.method().name();
                String detail = weight
                        ? g(p.weight()) + " @ " + rs(p.rate()) + "/g" + (p.purity() == null ? "" : " (" + p.purity() + ")")
                        + (p.barLotCode() == null ? "" : " · Lot " + p.barLotCode())
                        : s(p.reference()) + (p.chequeNumber() == null ? "" : " Chq " + p.chequeNumber());
                pay.add(List.of(method, rs(p.amount()), detail, p.posted() ? (p.effective() ? "Posted" : "Reversed") : "Planned"));
            }
            pdf.section("Settlement").table(List.of("Method", "Value", "Details", "State"), pay, new float[]{12, 12, 25, 10}, new int[]{1}, null);
        }
        byte[] bytes = pdf.build();
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + b.billNumber() + ".pdf\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(bytes);
    }
}
