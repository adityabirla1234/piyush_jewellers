package com.piyushjewellers.billing;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.common.enums.Enums.Direction;
import com.piyushjewellers.common.enums.Enums.SourceType;
import com.piyushjewellers.inventory.InventoryService;
import com.piyushjewellers.inventory.Product;
import com.piyushjewellers.inventory.StockMovement;
import com.piyushjewellers.people.Person;
import com.piyushjewellers.people.PersonService;
import com.piyushjewellers.transactions.DailyTransaction;
import com.piyushjewellers.transactions.TransactionService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BillService {

    private static final String SOURCE = "CUSTOMER_BILL";

    private final BillRepository billRepo;
    private final jakarta.persistence.EntityManager entityManager;
    private final PersonService personService;
    private final InventoryService inventoryService;
    private final TransactionService transactionService;
    private final AuditService auditService;

    // ---------- DTOs ----------

    public record LineRequest(@NotBlank @Size(max = 300) String description, Long productId,
                              Product.Category newProductCategory, @Size(max = 20) String purity,
                              @DecimalMin("0") BigDecimal grossWeight, @DecimalMin("0") BigDecimal lessWeight,
                              @DecimalMin("0") BigDecimal netWeight, @Min(0) Integer pieces,
                              @NotNull @DecimalMin("0") BigDecimal rate, @DecimalMin("0") BigDecimal makingCharges) {
    }

    public record PaymentRequest(@NotNull Enums.PaymentMethod method, @NotNull @DecimalMin("0.01") BigDecimal amount,
                                 @Size(max = 120) String reference, @Size(max = 40) String chequeNumber,
                                 @Size(max = 100) String chequeBank, LocalDateTime paidAt) {
    }

    public record BillRequest(@NotNull CustomerBill.Type type, @Size(max = 40) String billNumber,
                              @NotNull LocalDate billDate, Long personId, @Size(max = 150) String customerName,
                              @Size(max = 30) String customerContact, @Size(max = 1000) String notes,
                              @NotEmpty List<@Valid LineRequest> lines, boolean makingChargesZeroConfirmed,
                              List<@Valid PaymentRequest> payments, Long version) {
    }

    public record LineDto(Long id, int lineNo, String description, Long productId, String productCode,
                          Product.Category newProductCategory, String purity, BigDecimal grossWeight,
                          BigDecimal lessWeight, BigDecimal netWeight, int pieces, BigDecimal rate,
                          BigDecimal makingCharges, BigDecimal metalValue, BigDecimal lineTotal) {
    }

    public record PaymentDto(Long id, Enums.PaymentMethod method, BigDecimal amount, String reference,
                             String chequeNumber, String chequeBank, LocalDateTime paidAt, Long transactionId,
                             boolean posted, boolean effective) {
    }

    public record BillDto(Long id, CustomerBill.Type type, String billNumber, LocalDate billDate, Long personId,
                          String personName, String customerName, String customerContact, String notes,
                          CustomerBill.Status status, boolean makingChargesZeroConfirmed, List<LineDto> lines,
                          BigDecimal subtotal, BigDecimal makingChargesTotal, BigDecimal grandTotal,
                          BigDecimal paidAmount, BigDecimal outstandingAmount, String paymentState,
                          List<PaymentDto> payments, Instant finalizedAt, String reversalReason, Instant reversedAt,
                          Long version, Instant createdAt, String createdBy) {
    }

    // ---------- Queries ----------

    @Transactional(readOnly = true)
    public PageResponse<BillDto> search(CustomerBill.Type type, CustomerBill.Status status, Long personId,
                                        LocalDate from, LocalDate to, String q, int page, int size) {
        return PageResponse.of(billRepo.search(type, status, personId, from, to, (q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "billDate", "id"))), this::toDto);
    }

    @Transactional(readOnly = true)
    public BillDto get(Long id) {
        return toDto(require(id));
    }

    public CustomerBill require(Long id) {
        return billRepo.findById(id).orElseThrow(() -> ApiException.notFound("Bill", id));
    }

    // ---------- Commands ----------

    @Transactional
    public BillDto createDraft(BillRequest r) {
        CustomerBill bill = new CustomerBill();
        bill.setBillType(r.type());
        String number = blank(r.billNumber());
        if (number == null) {
            number = nextNumber(r.type(), r.billDate());
        } else if (billRepo.existsByBillTypeAndBillNumber(r.type(), number)) {
            throw ApiException.conflict("DUPLICATE_BILL_NUMBER", "Bill number " + number + " already exists", null);
        }
        bill.setBillNumber(number);
        apply(bill, r);
        billRepo.save(bill);
        auditService.record("BILL_DRAFT_CREATED", "CustomerBill", bill.getId(), null, bill.getBillNumber());
        return toDto(bill);
    }

    @Transactional
    public BillDto updateDraft(Long id, BillRequest r) {
        CustomerBill bill = require(id);
        if (bill.getStatus() != CustomerBill.Status.DRAFT) {
            throw ApiException.state("Finalized bills cannot be edited. Reverse the bill and create a corrected one.");
        }
        if (r.version() != null && !r.version().equals(bill.getVersion())) {
            throw ApiException.conflict("VERSION_CONFLICT", "This draft was changed elsewhere. Reload and retry.", null);
        }
        if (r.type() != bill.getBillType()) {
            throw ApiException.validation("Bill type cannot be changed");
        }
        String number = blank(r.billNumber());
        if (number != null && !number.equals(bill.getBillNumber())) {
            if (billRepo.existsByBillTypeAndBillNumber(bill.getBillType(), number)) {
                throw ApiException.conflict("DUPLICATE_BILL_NUMBER", "Bill number " + number + " already exists", null);
            }
            bill.setBillNumber(number);
        }
        apply(bill, r);
        billRepo.flush();
        auditService.record("BILL_DRAFT_UPDATED", "CustomerBill", bill.getId(), null, bill.getBillNumber());
        return toDto(bill);
    }

    @Transactional
    public void deleteDraft(Long id) {
        CustomerBill bill = require(id);
        if (bill.getStatus() != CustomerBill.Status.DRAFT) {
            throw ApiException.state("Only drafts can be deleted. Finalized bills must be reversed.");
        }
        auditService.record("BILL_DRAFT_DELETED", "CustomerBill", bill.getId(), null, bill.getBillNumber());
        billRepo.delete(bill);
    }

    /**
     * Finalizes atomically: validates making charges, writes stock movements and posts payment transactions
     * in one database transaction.
     */
    @Transactional
    public BillDto finalizeBill(Long id) {
        CustomerBill bill = require(id);
        if (bill.getStatus() != CustomerBill.Status.DRAFT) {
            throw ApiException.state("This bill is already " + bill.getStatus());
        }
        boolean blankMaking = bill.getLines().stream().anyMatch(l -> l.getMakingCharges() == null);
        if (blankMaking && !bill.isMakingChargesZeroConfirmed()) {
            throw ApiException.conflict("MAKING_CHARGES_UNCONFIRMED",
                    "Making charges are blank on one or more lines. Enter them or confirm there are no making charges.", null);
        }
        recalc(bill);
        BigDecimal planned = bill.getPayments().stream().map(BillPayment::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        if (planned.compareTo(bill.getGrandTotal()) > 0) {
            throw ApiException.validation("Payments (" + planned + ") exceed the bill total (" + bill.getGrandTotal() + ")");
        }

        boolean sales = bill.getBillType() == CustomerBill.Type.SALES;
        for (BillLine line : bill.getLines()) {
            Product product = line.getProduct();
            if (product == null && !sales && line.getNewProductCategory() != null) {
                Enums.Metal metal = switch (line.getNewProductCategory()) {
                    case SILVER -> Enums.Metal.SILVER;
                    case GOLD -> Enums.Metal.GOLD;
                    default -> Enums.Metal.GOLD;
                };
                product = inventoryService.createFromDocument(line.getDescription(), line.getNewProductCategory(), metal,
                        line.getPurity(), "Purchased on bill " + bill.getBillNumber());
                line.setProduct(product);
            }
            if (product != null) {
                InventoryService.StockDelta delta = new InventoryService.StockDelta(line.getGrossWeight(),
                        line.getLessWeight(), line.getNetWeight(), line.getPieces());
                inventoryService.applyMovement(product, sales ? StockMovement.Type.SALE : StockMovement.Type.PURCHASE,
                        sales ? delta.negate() : delta, SOURCE, bill.getId(),
                        (sales ? "Sales bill " : "Purchase bill ") + bill.getBillNumber(), bill.getBillDate());
            }
        }
        for (BillPayment payment : bill.getPayments()) {
            post(bill, payment);
        }
        bill.setStatus(CustomerBill.Status.FINALIZED);
        bill.setFinalizedAt(Instant.now());
        billRepo.flush();
        auditService.record("BILL_FINALIZED", "CustomerBill", bill.getId(), null,
                bill.getBillNumber() + " total " + bill.getGrandTotal());
        return toDto(bill);
    }

    @Transactional
    public BillDto addPayment(Long id, PaymentRequest r) {
        CustomerBill bill = require(id);
        if (bill.getStatus() != CustomerBill.Status.FINALIZED) {
            throw ApiException.state("Payments can be recorded on finalized bills only. Add planned payments to the draft.");
        }
        BigDecimal outstanding = bill.getGrandTotal().subtract(paid(bill));
        if (r.amount().compareTo(outstanding) > 0) {
            throw ApiException.validation("Payment exceeds the outstanding balance of " + outstanding);
        }
        BillPayment payment = toPayment(bill, r);
        bill.getPayments().add(payment);
        entityManager.persist(payment);
        post(bill, payment);
        auditService.record("BILL_PAYMENT", "CustomerBill", bill.getId(), null, payment.getMethod() + " " + payment.getAmount());
        return toDto(bill);
    }

    /** Correction of a finalized bill: reverses stock movements and payment transactions; nothing is deleted. */
    @Transactional
    public BillDto reverse(Long id, String reason) {
        if (reason == null || reason.isBlank()) throw ApiException.validation("A reason is required to reverse a bill");
        CustomerBill bill = require(id);
        if (bill.getStatus() != CustomerBill.Status.FINALIZED) {
            throw ApiException.state("Only finalized bills can be reversed");
        }
        inventoryService.reverseMovementsFor(SOURCE, bill.getId(), reason);
        for (BillPayment p : bill.getPayments()) {
            if (transactionService.isEffective(p.getTransactionId())) {
                transactionService.reverse(transactionService.require(p.getTransactionId()), "Bill reversed: " + reason);
            }
        }
        bill.setStatus(CustomerBill.Status.REVERSED);
        bill.setReversalReason(reason.trim());
        bill.setReversedAt(Instant.now());
        auditService.record("BILL_REVERSED", "CustomerBill", bill.getId(), reason, bill.getBillNumber());
        return toDto(bill);
    }

    // ---------- Helpers ----------

    private void post(CustomerBill bill, BillPayment payment) {
        boolean sales = bill.getBillType() == CustomerBill.Type.SALES;
        DailyTransaction t = transactionService.postLinked(new TransactionService.LinkedPayment(
                sales ? Direction.IN : Direction.OUT, payment.getAmount(), payment.getMethod(), payment.getReference(),
                payment.getPaidAt() == null ? LocalDateTime.now() : payment.getPaidAt(), bill.getPerson(),
                sales ? "Sales bill" : "Purchase bill",
                (sales ? "Sales bill " : "Purchase bill ") + bill.getBillNumber() + displayName(bill),
                SourceType.CUSTOMER_BILL, bill.getId(), payment.getChequeNumber(), payment.getChequeBank(), null));
        payment.setTransactionId(t.getId());
    }

    private void apply(CustomerBill bill, BillRequest r) {
        Person person = r.personId() == null ? null : personService.require(r.personId());
        bill.setPerson(person);
        bill.setBillDate(r.billDate());
        bill.setCustomerName(blank(r.customerName()) != null ? r.customerName().trim() : person == null ? null : person.getName());
        bill.setCustomerContact(blank(r.customerContact()) != null ? r.customerContact().trim() : person == null ? null : person.getPhone());
        bill.setNotes(blank(r.notes()));
        bill.setMakingChargesZeroConfirmed(r.makingChargesZeroConfirmed());

        bill.getLines().clear();
        int n = 1;
        for (LineRequest lr : r.lines()) {
            BillLine line = new BillLine();
            line.setBill(bill);
            line.setLineNo(n++);
            line.setDescription(lr.description().trim());
            line.setProduct(lr.productId() == null ? null : inventoryService.require(lr.productId()));
            line.setNewProductCategory(lr.productId() == null && r.type() == CustomerBill.Type.PURCHASE ? lr.newProductCategory() : null);
            line.setPurity(blank(lr.purity()));
            line.setGrossWeight(Money.weight(lr.grossWeight()));
            line.setLessWeight(Money.weight(lr.lessWeight()));
            line.setNetWeight(BillCalculator.net(lr.grossWeight(), lr.lessWeight(), lr.netWeight()));
            if (line.getNetWeight().signum() < 0) throw ApiException.validation("Less weight cannot exceed gross weight on line " + line.getLineNo());
            line.setPieces(lr.pieces() == null ? 0 : lr.pieces());
            line.setRate(Money.money(lr.rate()));
            line.setMakingCharges(lr.makingCharges() == null ? null : Money.money(lr.makingCharges()));
            bill.getLines().add(line);
        }
        bill.getPayments().clear();
        if (r.payments() != null) {
            for (PaymentRequest pr : r.payments()) {
                bill.getPayments().add(toPayment(bill, pr));
            }
        }
        recalc(bill);
    }

    private BillPayment toPayment(CustomerBill bill, PaymentRequest pr) {
        if (pr.method() == Enums.PaymentMethod.CHEQUE && blank(pr.chequeNumber()) == null) {
            throw ApiException.validation("Cheque number is required for cheque payments");
        }
        BillPayment p = new BillPayment();
        p.setBill(bill);
        p.setMethod(pr.method());
        p.setAmount(Money.money(pr.amount()));
        p.setReference(blank(pr.reference()));
        p.setChequeNumber(blank(pr.chequeNumber()));
        p.setChequeBank(blank(pr.chequeBank()));
        p.setPaidAt(pr.paidAt());
        return p;
    }

    private void recalc(CustomerBill bill) {
        BigDecimal subtotal = BigDecimal.ZERO;
        BigDecimal making = BigDecimal.ZERO;
        for (BillLine l : bill.getLines()) {
            l.setLineTotal(BillCalculator.lineTotal(l.getNetWeight(), l.getRate(), l.getMakingCharges()));
            subtotal = subtotal.add(BillCalculator.metalValue(l.getNetWeight(), l.getRate()));
            making = making.add(Money.nz(l.getMakingCharges()));
        }
        bill.setSubtotal(Money.money(subtotal));
        bill.setMakingChargesTotal(Money.money(making));
        bill.setGrandTotal(Money.money(subtotal.add(making)));
    }

    /** Paid amount counts only payments whose canonical transaction is still effective (not reversed/bounced). */
    BigDecimal paid(CustomerBill bill) {
        if (bill.getStatus() == CustomerBill.Status.DRAFT) {
            return BigDecimal.ZERO;
        }
        return bill.getPayments().stream()
                .filter(p -> transactionService.isEffective(p.getTransactionId()))
                .map(BillPayment::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public BigDecimal outstanding(CustomerBill bill) {
        if (bill.getStatus() != CustomerBill.Status.FINALIZED) return BigDecimal.ZERO;
        return Money.money(bill.getGrandTotal().subtract(paid(bill)));
    }

    private String nextNumber(CustomerBill.Type type, LocalDate date) {
        String prefix = (type == CustomerBill.Type.SALES ? "S-" : "P-") + date.getYear() + "-";
        long n = billRepo.countByBillType(type) + 1;
        String number;
        do {
            number = prefix + String.format("%05d", n++);
        } while (billRepo.existsByBillTypeAndBillNumber(type, number));
        return number;
    }

    private static String displayName(CustomerBill bill) {
        return bill.getCustomerName() == null ? "" : " — " + bill.getCustomerName();
    }

    public BillDto toDto(CustomerBill b) {
        List<LineDto> lines = new ArrayList<>();
        for (BillLine l : b.getLines()) {
            lines.add(new LineDto(l.getId(), l.getLineNo(), l.getDescription(),
                    l.getProduct() == null ? null : l.getProduct().getId(),
                    l.getProduct() == null ? null : l.getProduct().getCode(), l.getNewProductCategory(), l.getPurity(),
                    l.getGrossWeight(), l.getLessWeight(), l.getNetWeight(), l.getPieces(), l.getRate(),
                    l.getMakingCharges(), BillCalculator.metalValue(l.getNetWeight(), l.getRate()), l.getLineTotal()));
        }
        List<PaymentDto> payments = b.getPayments().stream().map(p -> new PaymentDto(p.getId(), p.getMethod(),
                p.getAmount(), p.getReference(), p.getChequeNumber(), p.getChequeBank(), p.getPaidAt(),
                p.getTransactionId(), p.getTransactionId() != null, transactionService.isEffective(p.getTransactionId()))).toList();
        BigDecimal paid = Money.money(paid(b));
        BigDecimal outstanding = b.getStatus() == CustomerBill.Status.FINALIZED ? Money.money(b.getGrandTotal().subtract(paid)) : b.getGrandTotal();
        String state = b.getStatus() == CustomerBill.Status.REVERSED ? "REVERSED"
                : paid.signum() == 0 ? "UNPAID" : outstanding.signum() <= 0 ? "PAID" : "PARTIAL";
        return new BillDto(b.getId(), b.getBillType(), b.getBillNumber(), b.getBillDate(),
                b.getPerson() == null ? null : b.getPerson().getId(), b.getPerson() == null ? null : b.getPerson().getName(),
                b.getCustomerName(), b.getCustomerContact(), b.getNotes(), b.getStatus(), b.isMakingChargesZeroConfirmed(),
                lines, b.getSubtotal(), b.getMakingChargesTotal(), b.getGrandTotal(), paid, outstanding, state, payments,
                b.getFinalizedAt(), b.getReversalReason(), b.getReversedAt(), b.getVersion(), b.getCreatedAt(), b.getCreatedBy());
    }

    private static String blank(String s) {
        return (s == null || s.isBlank()) ? null : s.trim();
    }
}
