package com.piyushjewellers.reminders;

import com.piyushjewellers.common.BaseEntity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Reminder metadata with a stable client-generated key. Notifications are scheduled locally on the device;
 * the backend copy lets reminders survive reinstall and appear on other devices.
 */
@Getter
@Setter
@Entity
@Table(name = "reminders", indexes = @Index(name = "idx_reminder_source", columnList = "sourceType,sourceId"))
public class Reminder extends BaseEntity {

    @Column(nullable = false, unique = true, length = 60)
    private String reminderKey;

    @Column(nullable = false, length = 30)
    private String sourceType;

    private Long sourceId;

    private Long personId;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(length = 500)
    private String notes;

    @Column(nullable = false)
    private LocalDateTime remindAt;

    @Column(nullable = false)
    private boolean enabled = true;
}
