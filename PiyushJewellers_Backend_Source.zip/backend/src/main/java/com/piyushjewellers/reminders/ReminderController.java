package com.piyushjewellers.reminders;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/reminders")
@RequiredArgsConstructor
public class ReminderController {

    public interface ReminderRepository extends JpaRepository<Reminder, Long> {
        Optional<Reminder> findByReminderKey(String key);

        List<Reminder> findAllByOrderByRemindAtAsc();
    }

    private final ReminderRepository repo;
    private final AuditService auditService;

    public record ReminderRequest(@NotBlank @Size(max = 30) String sourceType, Long sourceId, Long personId,
                                  @NotBlank @Size(max = 200) String title, @Size(max = 500) String notes,
                                  @NotNull LocalDateTime remindAt, boolean enabled) {
    }

    public record ReminderDto(String key, String sourceType, Long sourceId, Long personId, String title, String notes,
                              LocalDateTime remindAt, boolean enabled, Instant updatedAt) {
        static ReminderDto from(Reminder r) {
            return new ReminderDto(r.getReminderKey(), r.getSourceType(), r.getSourceId(), r.getPersonId(), r.getTitle(),
                    r.getNotes(), r.getRemindAt(), r.isEnabled(), r.getUpdatedAt());
        }
    }

    @GetMapping
    @Transactional(readOnly = true)
    public List<ReminderDto> list() {
        return repo.findAllByOrderByRemindAtAsc().stream().map(ReminderDto::from).toList();
    }

    /** Idempotent upsert by stable key so replays from the offline outbox never create duplicates. */
    @PutMapping("/{key}")
    @Transactional
    public ReminderDto upsert(@PathVariable String key, @Valid @RequestBody ReminderRequest r) {
        if (key.length() > 60) throw ApiException.validation("Reminder key is too long");
        Reminder reminder = repo.findByReminderKey(key).orElseGet(() -> {
            Reminder n = new Reminder();
            n.setReminderKey(key);
            return n;
        });
        reminder.setSourceType(r.sourceType());
        reminder.setSourceId(r.sourceId());
        reminder.setPersonId(r.personId());
        reminder.setTitle(r.title());
        reminder.setNotes(r.notes());
        reminder.setRemindAt(r.remindAt());
        reminder.setEnabled(r.enabled());
        repo.saveAndFlush(reminder);
        auditService.record("REMINDER_SAVED", "Reminder", reminder.getId(), null, key + " " + r.remindAt() + (r.enabled() ? "" : " (disabled)"));
        return ReminderDto.from(reminder);
    }

    @DeleteMapping("/{key}")
    @Transactional
    public ResponseEntity<Void> delete(@PathVariable String key) {
        repo.findByReminderKey(key).ifPresent(r -> {
            auditService.record("REMINDER_DELETED", "Reminder", r.getId(), null, key);
            repo.delete(r);
        });
        return ResponseEntity.noContent().build();
    }
}
