package com.piyushjewellers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class WorkflowIntegrationTest {

    @Autowired
    MockMvc mvc;
    @Autowired
    ObjectMapper om;

    String token;

    @BeforeEach
    void login() throws Exception {
        JsonNode r = call(post("/api/v1/auth/login").content("{\"username\":\"owner\",\"password\":\"owner-pass-123\"}"), null, 200);
        token = r.get("accessToken").asText();
    }

    private JsonNode call(MockHttpServletRequestBuilder req, String idemKey, int expectedStatus) throws Exception {
        req.contentType(MediaType.APPLICATION_JSON);
        if (token != null) req.header("Authorization", "Bearer " + token);
        if (idemKey != null) req.header("Idempotency-Key", idemKey);
        MvcResult res = mvc.perform(req).andReturn();
        assertThat(res.getResponse().getStatus()).as(res.getResponse().getContentAsString()).isEqualTo(expectedStatus);
        String body = res.getResponse().getContentAsString();
        return body.isEmpty() ? null : om.readTree(body);
    }

    private long person(String name, String phone) throws Exception {
        return call(post("/api/v1/people").content("{\"name\":\"" + name + "\",\"phone\":\"" + phone + "\",\"customer\":true}"), null, 201)
                .get("id").asLong();
    }

    private BigDecimal combined() throws Exception {
        return new BigDecimal(call(get("/api/v1/transactions/summary"), null, 200).get("combinedBalance").asText());
    }

    private BigDecimal available() throws Exception {
        return new BigDecimal(call(get("/api/v1/transactions/summary"), null, 200).get("availableBalance").asText());
    }

    @Test
    void unauthenticatedRequestsAreRejected() throws Exception {
        token = null;
        call(get("/api/v1/people"), null, 401);
    }

    @Test
    void internalTransferDoesNotChangeCombinedBalance() throws Exception {
        BigDecimal before = combined();
        call(post("/api/v1/transfers").content("{\"fromMethod\":\"CASH\",\"toMethod\":\"BANK\",\"amount\":5000,\"businessDate\":\"2026-01-05T10:00:00\"}"), null, 201);
        assertThat(combined()).isEqualByComparingTo(before);
    }

    @Test
    void pendingChequeExcludedFromAvailable_andBounceReversesOnce() throws Exception {
        BigDecimal availBefore = available();
        BigDecimal combBefore = combined();
        JsonNode t = call(post("/api/v1/transactions").content("""
                {"businessDate":"2026-02-01T10:00:00","direction":"IN","amount":10000,"method":"CHEQUE","chequeNumber":"000123","category":"Sale"}
                """), null, 201);
        long chequeId = t.get("cheque").get("id").asLong();
        assertThat(available()).isEqualByComparingTo(availBefore);
        assertThat(combined()).isEqualByComparingTo(combBefore.add(new BigDecimal("10000")));
        call(post("/api/v1/cheques/" + chequeId + "/bounce").content("{\"reason\":\"Insufficient funds\"}"), null, 200);
        call(post("/api/v1/cheques/" + chequeId + "/bounce").content("{}"), null, 409);
        assertThat(combined()).isEqualByComparingTo(combBefore);
        assertThat(available()).isEqualByComparingTo(availBefore);
    }

    @Test
    void replayedPaymentWithSameIdempotencyKeyIsNotDuplicated() throws Exception {
        long p = person("Replay Customer", "9811100001");
        JsonNode loan = call(post("/api/v1/loans").content("{\"personId\":" + p + ",\"kind\":\"LENT\",\"principal\":10000,\"loanDate\":\"2026-03-01\",\"method\":\"CASH\",\"expectedReturnDate\":\"2026-06-01\"}"), null, 201);
        long loanId = loan.get("id").asLong();
        String key = UUID.randomUUID().toString();
        String body = "{\"amount\":4000,\"repaymentDate\":\"2026-03-15\",\"method\":\"UPI\"}";
        call(post("/api/v1/loans/" + loanId + "/repayments").content(body), key, 200);
        JsonNode replay = call(post("/api/v1/loans/" + loanId + "/repayments").content(body), key, 200);
        assertThat(new BigDecimal(replay.get("outstanding").asText())).isEqualByComparingTo("6000");
        JsonNode fresh = call(get("/api/v1/loans/" + loanId), null, 200);
        assertThat(fresh.get("repayments").size()).isEqualTo(1);
        assertThat(new BigDecimal(fresh.get("outstanding").asText())).isEqualByComparingTo("6000");

        JsonNode dues = call(get("/api/v1/dues/persons/" + p), null, 200);
        assertThat(new BigDecimal(dues.get("receivable").asText())).isEqualByComparingTo("6000");
        long txnCount = 0;
        for (JsonNode e : dues.get("timeline")) if (e.get("kind").asText().equals("TRANSACTION")) txnCount++;
        assertThat(txnCount).isEqualTo(2);
    }

    @Test
    void salesBillRequiresMakingChargeConfirmation_andDeductsStockAtomically() throws Exception {
        JsonNode product = call(post("/api/v1/products").content("""
                {"name":"Gold ring","category":"FINISHED_JEWELLERY","metal":"GOLD","purity":"22K","openingGrossWeight":20,"openingNetWeight":20,"openingPieces":4}
                """), null, 201);
        long productId = product.get("id").asLong();
        String bill = """
                {"type":"SALES","billDate":"%s","customerName":"Walk-in","lines":[{"description":"Ring","productId":%d,"grossWeight":5,"netWeight":5,"pieces":1,"rate":6000}],
                 "makingChargesZeroConfirmed":false,"payments":[{"method":"CASH","amount":10000}]}
                """.formatted(LocalDate.now(), productId);
        long billId = call(post("/api/v1/customer-bills").content(bill), null, 201).get("id").asLong();
        call(post("/api/v1/customer-bills/" + billId + "/finalize"), null, 409);
        assertThat(new BigDecimal(call(get("/api/v1/products/" + productId), null, 200).get("netWeight").asText())).isEqualByComparingTo("20");

        call(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put("/api/v1/customer-bills/" + billId)
                .content(bill.replace("\"makingChargesZeroConfirmed\":false", "\"makingChargesZeroConfirmed\":true")), null, 200);
        JsonNode finalized = call(post("/api/v1/customer-bills/" + billId + "/finalize"), null, 200);
        assertThat(new BigDecimal(finalized.get("outstandingAmount").asText())).isEqualByComparingTo("20000");
        JsonNode p = call(get("/api/v1/products/" + productId), null, 200);
        assertThat(new BigDecimal(p.get("netWeight").asText())).isEqualByComparingTo("15");
        assertThat(p.get("pieces").asInt()).isEqualTo(3);
    }

    @Test
    void dealerSettlementExample_5gBiscuitPlusCash_settlesFully() throws Exception {
        call(post("/api/v1/bar-lots").content("{\"metal\":\"GOLD\",\"weight\":20,\"rate\":7000,\"lotCode\":\"MRG-T1\"}"), null, 201);
        long lotId = call(get("/api/v1/bar-lots?metal=GOLD"), null, 200).get(0).get("id").asLong();
        JsonNode dealer = call(post("/api/v1/dealers").content("{\"name\":\"Shree Gold\",\"phone\":\"9822200002\"}"), null, 201);
        long dealerId = dealer.get("id").asLong();
        long shopId = call(get("/api/v1/dealers/" + dealerId + "/shops"), null, 200).get(0).get("id").asLong();
        JsonNode bill = call(post("/api/v1/dealer-bills").content("""
                {"dealerId":%d,"shopId":%d,"billNumber":"D-1","dealDate":"2026-04-01","type":"PURCHASE","metal":"GOLD","rate":7000,
                 "lines":[{"grossWeight":10,"lessWeight":0,"pieces":1,"carat":"K20","labourPercent":4}]}
                """.formatted(dealerId, shopId)), null, 201);
        assertThat(new BigDecimal(bill.get("totalFinalWeight").asText())).isEqualByComparingTo("8.8");
        assertThat(new BigDecimal(bill.get("amount").asText())).isEqualByComparingTo("61600");
        JsonNode settled = call(post("/api/v1/dealer-bills/" + bill.get("id").asLong() + "/settlements").content("""
                {"settlementDate":"2026-04-02","bars":[{"barLotId":%d,"weight":5,"rate":7000}],"money":[{"method":"CASH","amount":26600}]}
                """.formatted(lotId)), null, 200);
        assertThat(settled.get("status").asText()).isEqualTo("SETTLED");
        assertThat(new BigDecimal(settled.get("outstandingAmount").asText())).isEqualByComparingTo("0");
        JsonNode lots = call(get("/api/v1/bar-lots?metal=GOLD"), null, 200);
        assertThat(new BigDecimal(lots.get(0).get("remainingWeight").asText())).isEqualByComparingTo("15");
    }

    @Test
    void fullAndFinal_doesNotAutoCalculate_andPledgesAreIndependent() throws Exception {
        JsonNode account = call(post("/api/v1/mortgage-accounts").content("{\"name\":\"Mortgage Customer\",\"phone\":\"9833300003\"}"), null, 201);
        long accountId = account.get("id").asLong();
        String pledge = """
                {"accountId":%d,"kind":"JEWELLERY","issueDate":"2025-01-10","principal":10000,"monthlyRate":2,"jewelleryName":"%s","netWeight":12.5,"pieces":1,"metal":"GOLD","issueMethod":"CASH"}
                """;
        long m1 = call(post("/api/v1/mortgages").content(pledge.formatted(accountId, "Chain")), null, 201).get("id").asLong();
        long m2 = call(post("/api/v1/mortgages").content(pledge.formatted(accountId, "Bangle")), null, 201).get("id").asLong();

        JsonNode no = call(post("/api/v1/mortgages/" + m1 + "/full-final").content("{\"fullAmountReceived\":false}"), null, 200);
        assertThat(no.get("outcome").asText()).isEqualTo("KEPT_ACTIVE");
        assertThat(no.get("mortgage").get("status").asText()).isEqualTo("ACTIVE");

        JsonNode yes = call(post("/api/v1/mortgages/" + m1 + "/full-final").content(
                "{\"fullAmountReceived\":true,\"amount\":12400,\"paymentDate\":\"2026-01-10\",\"method\":\"CASH\"}"), null, 200);
        assertThat(yes.get("outcome").asText()).isEqualTo("AWAITING_JEWELLERY_RETURN");
        assertThat(yes.get("mortgage").get("calculations").size()).isZero();

        JsonNode returned = call(post("/api/v1/mortgages/" + m1 + "/jewellery-return").content("{\"returnDate\":\"2026-01-10\",\"returnedTo\":\"Customer\"}"), null, 200);
        assertThat(returned.get("status").asText()).isEqualTo("PAID");
        assertThat(call(get("/api/v1/mortgages/" + m2), null, 200).get("status").asText()).isEqualTo("ACTIVE");

        JsonNode calc = call(post("/api/v1/mortgages/" + m2 + "/calculate-interest").content("{\"effectiveThrough\":\"2027-01-10\"}"), null, 200);
        assertThat(new BigDecimal(calc.get("totalDue").asText())).isEqualByComparingTo("15376");
        assertThat(call(get("/api/v1/mortgages/" + m2), null, 200).get("status").asText()).isEqualTo("ACTIVE");
    }

    @Test
    void duplicatePhoneIsFlaggedNotMerged() throws Exception {
        person("First Person", "+91 98444-00004");
        call(post("/api/v1/people").content("{\"name\":\"Second Person\",\"phone\":\"09844400004\"}"), null, 409);
    }
}
