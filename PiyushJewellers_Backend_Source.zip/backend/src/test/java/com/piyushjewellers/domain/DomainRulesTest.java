package com.piyushjewellers.domain;

import com.piyushjewellers.billing.BillCalculator;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.dealers.MetalCalculator;
import com.piyushjewellers.mortgages.InterestEngine;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

class DomainRulesTest {

    @Test
    void goldFormula_1440g_20K_4pctLabour_is_1_2672g() {
        BigDecimal result = MetalCalculator.goldFinalWeight(new BigDecimal("1.440"), Enums.Carat.K20, new BigDecimal("4"));
        assertThat(result).isEqualByComparingTo("1.2672");
    }

    @Test
    void silverFormula_1000minus20_4pctLabour_is_1019_2g() {
        BigDecimal net = MetalCalculator.netWeight(new BigDecimal("1000"), new BigDecimal("20"));
        assertThat(net).isEqualByComparingTo("980");
        assertThat(MetalCalculator.silverFinalWeight(net, new BigDecimal("4"))).isEqualByComparingTo("1019.2");
    }

    @Test
    void caratTableMatchesConfiguredPercentages() {
        assertThat(Enums.Carat.K18.percent()).isEqualTo(78);
        assertThat(Enums.Carat.K20.percent()).isEqualTo(84);
        assertThat(Enums.Carat.K22.percent()).isEqualTo(92);
        assertThat(Enums.Carat.K23.percent()).isEqualTo(97);
        assertThat(Enums.Carat.K24.percent()).isEqualTo(99);
    }

    @Test
    void dealerBillAmountFollowsFinalWeightTimesRate() {
        BigDecimal finalWeight = MetalCalculator.goldFinalWeight(new BigDecimal("10"), Enums.Carat.K20, new BigDecimal("4"));
        assertThat(finalWeight).isEqualByComparingTo("8.8");
        assertThat(MetalCalculator.amount(finalWeight, new BigDecimal("7000"))).isEqualByComparingTo("61600");
    }

    @Test
    void mortgageExample_10000_at_2pct_two_full_years() {
        LocalDate issue = LocalDate.of(2024, 1, 10);
        InterestEngine.Result oneYear = InterestEngine.calculate(new BigDecimal("10000"), new BigDecimal("2"), issue, issue.plusYears(1));
        assertThat(oneYear.totalInterest()).isEqualByComparingTo("2400");
        assertThat(oneYear.capitalizedPrincipal()).isEqualByComparingTo("12400");

        InterestEngine.Result twoYears = InterestEngine.calculate(new BigDecimal("10000"), new BigDecimal("2"), issue, issue.plusYears(2));
        assertThat(twoYears.periods().get(1).interest()).isEqualByComparingTo("2976");
        assertThat(twoYears.totalDue()).isEqualByComparingTo("15376");
    }

    @Test
    void partialMonthIsProratedByActualCalendarDays() {
        // 15 days inside February 2025 (28 days): 10000 × 2% × 15/28 = 107.14
        InterestEngine.Result r = InterestEngine.calculate(new BigDecimal("10000"), new BigDecimal("2"),
                LocalDate.of(2025, 2, 1), LocalDate.of(2025, 2, 16));
        assertThat(r.totalInterest()).isEqualByComparingTo("107.14");
        // Leap-year February (29 days): 15/29 → 103.45
        InterestEngine.Result leap = InterestEngine.calculate(new BigDecimal("10000"), new BigDecimal("2"),
                LocalDate.of(2024, 2, 1), LocalDate.of(2024, 2, 16));
        assertThat(leap.totalInterest()).isEqualByComparingTo("103.45");
    }

    @Test
    void sameDayHasNoInterestAndRecalculationIsDeterministic() {
        LocalDate d = LocalDate.of(2025, 5, 5);
        assertThat(InterestEngine.calculate(new BigDecimal("5000"), new BigDecimal("2"), d, d).totalInterest()).isEqualByComparingTo("0");
        InterestEngine.Result a = InterestEngine.calculate(new BigDecimal("10000"), new BigDecimal("2"), d, d.plusYears(3).plusDays(20));
        InterestEngine.Result b = InterestEngine.calculate(new BigDecimal("10000"), new BigDecimal("2"), d, d.plusYears(3).plusDays(20));
        assertThat(a.totalDue()).isEqualByComparingTo(b.totalDue());
        assertThat(a.periods().stream().filter(InterestEngine.Period::completedYear).count()).isEqualTo(3);
    }

    @Test
    void customerBillLineTotal_blankMakingCountsAsZeroOnlyAfterConfirmation() {
        assertThat(BillCalculator.lineTotal(new BigDecimal("10"), new BigDecimal("6000"), null)).isEqualByComparingTo("60000");
        assertThat(BillCalculator.lineTotal(new BigDecimal("10"), new BigDecimal("6000"), new BigDecimal("1500"))).isEqualByComparingTo("61500");
    }
}
