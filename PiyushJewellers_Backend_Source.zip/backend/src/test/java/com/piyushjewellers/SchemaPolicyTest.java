package com.piyushjewellers;

import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/** Guards the binding schema decision: Hibernate ddl-auto=update only, no migration/SQL init mechanism. */
class SchemaPolicyTest {

    @Test
    void ddlAutoUpdateAndSqlInitDisabled() throws IOException {
        Properties p = new Properties();
        try (InputStream in = getClass().getResourceAsStream("/application.properties")) {
            p.load(in);
        }
        assertThat(p.getProperty("spring.jpa.hibernate.ddl-auto")).isEqualTo("update");
        assertThat(p.getProperty("spring.sql.init.mode")).isEqualTo("never");
    }

    @Test
    void noMigrationToolsOrSqlScripts() throws IOException {
        String pom = Files.readString(Path.of("pom.xml"));
        assertThat(pom).doesNotContain("flyway").doesNotContain("liquibase");
        try (Stream<Path> files = Files.walk(Path.of("src/main/resources"))) {
            assertThat(files.map(f -> f.getFileName().toString()))
                    .noneMatch(n -> n.equals("schema.sql") || n.equals("data.sql") || n.endsWith(".sql"));
        }
        assertThat(Path.of("src/main/resources/db/migration")).doesNotExist();
    }
}
