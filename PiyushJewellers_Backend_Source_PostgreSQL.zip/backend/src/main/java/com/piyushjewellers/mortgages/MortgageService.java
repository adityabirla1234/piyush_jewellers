package com.piyushjewellers.mortgages;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.common.enums.Enums.Direction;
import com.piyushjewellers.common.enums.Enums.SourceType;
import com.piyushjewellers.people.Person;
import com.piyushjewellers.people.PersonService;
import com.piyushjewellers.transactions.DailyTransaction;
import com.piyushjewellers.transactions.TransactionService;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MortgageService {

    public interface MortgageAccountRepository extends JpaRepository<MortgageAccount, Long> {
        @Query("""
                select a from MortgageAccount a join a.person p
                where (:q is null or lower(a.serial) like lower(concat('%', cast(:q as String), '%'))
                       or lower(p.name) like lower(concat('%', cast(:q as String), '%')) or p.normalizedPhone like concat('%', cast(:q as String), '%'))
                """)
        Page<MortgageAccount> search(String q, Pageable pageable);

        Optional<MortgageAccount> findByPersonId(Long personId);

        boolean existsBySerial(String serial);
    }

    public interface MortgageRepository extends JpaRepository<Mortgage, Long> {
        @Query("""
                select m from Mortgage m join m.account a join a.person p
                where (:kind is null or m.kind = :kind)
                  and (:status is null or m.status = :status)
                  and (:accountId is null or a.id = :accountId)
                  and (:personId is null or p.id = :personId)
                  and (:q is null or lower(m.serial) like lower(concat('%', cast(:q as String), '%'))
                       or lower(p.name) like lower(concat('%', cast(:q as String), '%'))
                       or lower(m.jewelleryName) like lower(concat('%', cast(:q as String), '%'))
                       or p.normalizedPhone like concat('%', cast(:q as String), '%'))
                """)
        Page<Mortgage> search(Mortgage.Kind kind, Mortgage.Status status, Long accountId, Long personId, String q, Pageable pageable);

        List<Mortgage> findByAccountIdOrderByIssueDateDesc(Long accountId);

        List<Mortgage> findByStatus(Mortgage.Status status);

        long countByAccountId(Long accountId);

        boolean existsBySerial(String serial);

        @Query("select count(m), coalesce(sum(m.principal), 0) from Mortgage m where m.status = com.piyushjewellers.mortgages.Mortgage.Status.ACTIVE")
        List<Object[]> activeTotals();
    }

    private static final ZoneId ZONE = ZoneId.of("Asia/Kolkata");

    private final MortgageAccountRepository accountRepo;
    private final MortgageRepository mortgageRepo;
    private final jakarta.persistence.EntityManager entityManager;
    private final PersonService personService;
    private final TransactionService transactionService;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;

    // ---------- DTOs ----------

    public record AccountRequest(Long personId, @Size(max = 150) String name, @Size(max = 30) String phone,
                                 @Size(max = 400) String address, @Size(max = 120) String idReference,
                                 @Size(max = 300) String reference) {
    }

    public record AccountDto(Long id, String serial, Long personId, String name, String phone, String address,
                             String idReference, String reference, long activeCount, long totalCount,
                             BigDecimal activePrincipal, Long version) {
    }

    public record MortgageRequest(@NotNull Long accountId, @NotNull Mortgage.Kind kind, @NotNull LocalDate issueDate,
                                  @NotNull @DecimalMin("0.01") BigDecimal principal,
                                  @NotNull @DecimalMin("0") BigDecimal monthlyRate, LocalDate approxReminderDate,
                                  @Size(max = 200) String jewelleryName, @DecimalMin("0") BigDecimal netWeight,
                                  @Min(0) Integer pieces, Enums.Metal metal, @NotNull Enums.PaymentMethod issueMethod,
                                  @Size(max = 1000) String notes) {
    }

    public record CalculateRequest(LocalDate effectiveThrough) {
    }

    public record PaymentRequest(@NotNull @DecimalMin("0.01") BigDecimal amount, @NotNull LocalDate paymentDate,
                                 @NotNull Enums.PaymentMethod method, @Size(max = 120) String reference,
                                 @Size(max = 500) String notes) {
    }

    public record FullFinalRequest(@NotNull Boolean fullAmountReceived, @DecimalMin("0") BigDecimal amount,
                                   LocalDate paymentDate, Enums.PaymentMethod method, @Size(max = 120) String reference,
                                   @Size(max = 500) String notes) {
    }

    public record JewelleryReturnRequest(@NotNull LocalDate returnDate, @Size(max = 150) String returnedTo,
                                         @Size(max = 500) String notes) {
    }

    public record ReminderDateRequest(LocalDate approxReminderDate) {
    }

    public record PaymentDto(Long id, BigDecimal amount, LocalDate paymentDate, Enums.PaymentMethod method,
                             String reference, String notes, boolean finalSettlement, Long transactionId,
                             boolean effective, Instant createdAt) {
    }

    public record CalculationDto(Long id, LocalDate effectiveThrough, Instant calculatedAt, String calculatedBy,
                                 BigDecimal principal, BigDecimal monthlyRate, BigDecimal totalInterest,
                                 BigDecimal capitalizedPrincipal, BigDecimal totalDue, BigDecimal amountReceived,
                                 BigDecimal remainingBalance, List<InterestEngine.Period> periods,
                                 List<String> policyNotes) {
    }

    public record MortgageDto(Long id, String serial, Long accountId, String accountSerial, Long personId,
                              String personName, String personPhone, Mortgage.Kind kind, LocalDate issueDate,
                              BigDecimal principal, BigDecimal monthlyRate, LocalDate approxReminderDate,
                              Mortgage.Status status, String jewelleryName, BigDecimal netWeight, Integer pieces,
                              Enums.Metal metal, Enums.PaymentMethod issueMethod, String notes,
                              BigDecimal amountReceived, boolean fullPaymentConfirmed, LocalDate settledDate,
                              boolean jewelleryReturned, LocalDate jewelleryReturnDate, String jewelleryReturnedTo,
                              String jewelleryReturnNotes, String completionState, CalculationDto lastCalculation,
                              List<PaymentDto> payments, List<CalculationDto> calculations, Long version) {
    }

    public record FullFinalResult(String outcome, String message, MortgageDto mortgage) {
    }

    // ---------- Accounts ----------

    @Transactional(readOnly = true)
    public PageResponse<AccountDto> searchAccounts(String q, int page, int size) {
        return PageResponse.of(accountRepo.search((q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "id"))), this::toAccountDto);
    }

    @Transactional(readOnly = true)
    public AccountDto getAccount(Long id) {
        return toAccountDto(requireAccount(id));
    }

    @Transactional
    public AccountDto createAccount(AccountRequest r) {
        Person person;
        if (r.personId() != null) {
            person = personService.require(r.personId());
        } else {
            if (r.name() == null || r.name().isBlank()) throw ApiException.validation("Customer name is required");
            person = personService.createInternal(r.name(), r.phone(), r.address(), r.idReference(), false);
        }
        accountRepo.findByPersonId(person.getId()).ifPresent(existing -> {
            throw ApiException.conflict("ACCOUNT_EXISTS", person.getName() + " already has mortgage account " + existing.getSerial(),
                    java.util.Map.of("accountId", existing.getId(), "serial", existing.getSerial()));
        });
        MortgageAccount a = new MortgageAccount();
        a.setPerson(person);
        a.setReference(r.reference());
        long n = accountRepo.count() + 1;
        String serial;
        do {
            serial = String.format("PJM-%05d", n++);
        } while (accountRepo.existsBySerial(serial));
        a.setSerial(serial);
        accountRepo.save(a);
        auditService.record("MORTGAGE_ACCOUNT_CREATED", "MortgageAccount", a.getId(), null, serial + " " + person.getName());
        return toAccountDto(a);
    }

    // ---------- Mortgages ----------

    @Transactional(readOnly = true)
    public PageResponse<MortgageDto> search(Mortgage.Kind kind, Mortgage.Status status, Long accountId, Long personId,
                                            String q, int page, int size) {
        return PageResponse.of(mortgageRepo.search(kind, status, accountId, personId, (q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "issueDate", "id"))), m -> toDto(m, false));
    }

    @Transactional(readOnly = true)
    public MortgageDto get(Long id) {
        return toDto(require(id), true);
    }

    @Transactional
    public MortgageDto create(MortgageRequest r) {
        MortgageAccount account = requireAccount(r.accountId());
        if (r.kind() == Mortgage.Kind.JEWELLERY) {
            if (r.jewelleryName() == null || r.jewelleryName().isBlank()) throw ApiException.validation("Jewellery name is required");
            if (r.netWeight() == null || r.netWeight().signum() <= 0) throw ApiException.validation("Net weight is required");
            if (r.pieces() == null || r.pieces() < 1) throw ApiException.validation("Pieces is required");
            if (r.metal() != Enums.Metal.GOLD && r.metal() != Enums.Metal.SILVER) throw ApiException.validation("Select Gold or Silver");
        }
        Mortgage m = new Mortgage();
        m.setAccount(account);
        m.setKind(r.kind());
        long n = mortgageRepo.countByAccountId(account.getId()) + 1;
        String serial;
        do {
            serial = account.getSerial() + "-" + String.format("%02d", n++);
        } while (mortgageRepo.existsBySerial(serial));
        m.setSerial(serial);
        m.setIssueDate(r.issueDate());
        m.setPrincipal(Money.money(r.principal()));
        m.setMonthlyRate(r.monthlyRate().setScale(4, Money.ROUNDING));
        m.setApproxReminderDate(r.approxReminderDate());
        if (r.kind() == Mortgage.Kind.JEWELLERY) {
            m.setJewelleryName(r.jewelleryName().trim());
            m.setNetWeight(Money.weight(r.netWeight()));
            m.setPieces(r.pieces());
            m.setMetal(r.metal());
        }
        m.setIssueMethod(r.issueMethod());
        m.setNotes(r.notes());
        mortgageRepo.save(m);
        DailyTransaction t = transactionService.postLinked(new TransactionService.LinkedPayment(Direction.OUT, m.getPrincipal(),
                r.issueMethod(), serial, r.issueDate().atTime(LocalTime.now(ZONE)), account.getPerson(),
                r.kind() == Mortgage.Kind.JEWELLERY ? "Jewellery mortgage issued" : "Cash mortgage issued",
                "Mortgage " + serial + " — " + account.getPerson().getName(), SourceType.MORTGAGE_ISSUE, m.getId(),
                r.issueMethod() == Enums.PaymentMethod.CHEQUE ? serial : null, null, r.approxReminderDate()));
        m.setIssueTransactionId(t.getId());
        auditService.record("MORTGAGE_CREATED", "Mortgage", m.getId(), null, serial + " principal " + m.getPrincipal() + " @ " + m.getMonthlyRate() + "%/month");
        return toDto(m, true);
    }

    /** Explicit, separate action. Stores inputs, breakdown and result; never changes mortgage status. */
    @Transactional
    public CalculationDto calculateInterest(Long id, LocalDate effectiveThrough) {
        Mortgage m = require(id);
        LocalDate through = effectiveThrough == null ? LocalDate.now(ZONE) : effectiveThrough;
        if (through.isBefore(m.getIssueDate())) throw ApiException.validation("Effective date cannot be before the issue date");
        InterestEngine.Result result = InterestEngine.calculate(m.getPrincipal(), m.getMonthlyRate(), m.getIssueDate(), through);
        BigDecimal received = received(m);
        InterestCalculation c = new InterestCalculation();
        c.setMortgage(m);
        c.setEffectiveThrough(through);
        c.setPrincipal(m.getPrincipal());
        c.setMonthlyRate(m.getMonthlyRate());
        c.setTotalInterest(result.totalInterest());
        c.setCapitalizedPrincipal(result.capitalizedPrincipal());
        c.setTotalDue(result.totalDue());
        c.setAmountReceived(received);
        c.setRemainingBalance(Money.money(result.totalDue().subtract(received)));
        try {
            c.setBreakdownJson(objectMapper.writeValueAsString(result.periods()));
        } catch (JsonProcessingException e) {
            throw new IllegalStateException(e);
        }
        m.getCalculations().add(0, c);
        entityManager.persist(c);
        auditService.record("INTEREST_CALCULATED", "Mortgage", m.getId(), null,
                "through " + through + ": interest " + c.getTotalInterest() + ", due " + c.getTotalDue());
        return toCalcDto(c);
    }

    @Transactional
    public MortgageDto addPayment(Long id, PaymentRequest r) {
        Mortgage m = require(id);
        if (m.getStatus() != Mortgage.Status.ACTIVE) throw ApiException.state("This mortgage is already " + m.getStatus());
        recordPayment(m, r.amount(), r.paymentDate(), r.method(), r.reference(), r.notes(), false);
        return toDto(m, true);
    }

    /**
     * Full & Final Settlement. Never auto-calculates interest. If the full amount was not received the mortgage stays
     * Active. Otherwise the payment is persisted first; jewellery mortgages also need the jewellery return recorded.
     */
    @Transactional
    public FullFinalResult fullAndFinal(Long id, FullFinalRequest r) {
        Mortgage m = require(id);
        if (m.getStatus() != Mortgage.Status.ACTIVE) throw ApiException.state("This mortgage is already " + m.getStatus());
        if (!Boolean.TRUE.equals(r.fullAmountReceived())) {
            auditService.record("FULL_FINAL_DECLINED", "Mortgage", m.getId(), null, "Full amount not received; kept Active");
            return new FullFinalResult("KEPT_ACTIVE", "Full amount not received. The mortgage remains Active.", toDto(m, true));
        }
        if (m.isFullPaymentConfirmed()) {
            throw ApiException.state("Full payment is already recorded. Record the jewellery return to complete.");
        }
        if (r.amount() == null || r.amount().signum() <= 0 || r.method() == null) {
            throw ApiException.validation("Enter the amount received and the payment method");
        }
        recordPayment(m, r.amount(), r.paymentDate() == null ? LocalDate.now(ZONE) : r.paymentDate(), r.method(),
                r.reference(), r.notes(), true);
        m.setFullPaymentConfirmed(true);
        m.setSettledDate(r.paymentDate() == null ? LocalDate.now(ZONE) : r.paymentDate());
        String outcome;
        String message;
        if (m.getKind() == Mortgage.Kind.CASH || m.isJewelleryReturned()) {
            m.setStatus(Mortgage.Status.PAID);
            outcome = "PAID";
            message = "Payment recorded. Mortgage marked Paid.";
        } else {
            outcome = "AWAITING_JEWELLERY_RETURN";
            message = "Payment recorded. Record the jewellery return to complete the settlement.";
        }
        mortgageRepo.saveAndFlush(m);
        auditService.record("FULL_FINAL_SETTLEMENT", "Mortgage", m.getId(), null, outcome + " amount " + r.amount());
        return new FullFinalResult(outcome, message, toDto(m, true));
    }

    @Transactional
    public MortgageDto recordJewelleryReturn(Long id, JewelleryReturnRequest r) {
        Mortgage m = require(id);
        if (m.getKind() != Mortgage.Kind.JEWELLERY) throw ApiException.validation("Only jewellery mortgages have a return");
        if (m.isJewelleryReturned()) throw ApiException.state("Jewellery return is already recorded");
        if (!m.isFullPaymentConfirmed()) {
            throw ApiException.state("Confirm full payment through Full & Final Settlement before returning the jewellery");
        }
        m.setJewelleryReturned(true);
        m.setJewelleryReturnDate(r.returnDate());
        m.setJewelleryReturnedTo(r.returnedTo());
        m.setJewelleryReturnNotes(r.notes());
        m.setStatus(Mortgage.Status.PAID);
        mortgageRepo.saveAndFlush(m);
        auditService.record("JEWELLERY_RETURNED", "Mortgage", m.getId(), null, "returned " + r.returnDate());
        return toDto(m, true);
    }

    @Transactional
    public MortgageDto updateReminderDate(Long id, LocalDate date) {
        Mortgage m = require(id);
        m.setApproxReminderDate(date);
        auditService.record("MORTGAGE_REMINDER_DATE", "Mortgage", m.getId(), null, String.valueOf(date));
        return toDto(m, true);
    }

    private void recordPayment(Mortgage m, BigDecimal amount, LocalDate date, Enums.PaymentMethod method, String reference,
                               String notes, boolean finalSettlement) {
        MortgagePayment p = new MortgagePayment();
        p.setMortgage(m);
        p.setAmount(Money.money(amount));
        p.setPaymentDate(date);
        p.setMethod(method);
        p.setReference(reference);
        p.setNotes(notes);
        p.setFinalSettlement(finalSettlement);
        m.getPayments().add(p);
        entityManager.persist(p);
        DailyTransaction t = transactionService.postLinked(new TransactionService.LinkedPayment(Direction.IN, p.getAmount(),
                method, reference, date.atTime(LocalTime.now(ZONE)), m.getAccount().getPerson(),
                finalSettlement ? "Mortgage full & final" : "Mortgage payment",
                "Mortgage " + m.getSerial() + " — " + m.getAccount().getPerson().getName(), SourceType.MORTGAGE_PAYMENT,
                m.getId(), method == Enums.PaymentMethod.CHEQUE ? reference : null, null, null));
        p.setTransactionId(t.getId());
        auditService.record("MORTGAGE_PAYMENT", "Mortgage", m.getId(), null, p.getAmount() + (finalSettlement ? " (final)" : ""));
    }

    public BigDecimal received(Mortgage m) {
        return Money.money(m.getPayments().stream().filter(p -> transactionService.isEffective(p.getTransactionId()))
                .map(MortgagePayment::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add));
    }

    public Mortgage require(Long id) {
        return mortgageRepo.findById(id).orElseThrow(() -> ApiException.notFound("Mortgage", id));
    }

    private MortgageAccount requireAccount(Long id) {
        return accountRepo.findById(id).orElseThrow(() -> ApiException.notFound("Mortgage account", id));
    }

    // ---------- Mapping ----------

    private AccountDto toAccountDto(MortgageAccount a) {
        List<Mortgage> list = mortgageRepo.findByAccountIdOrderByIssueDateDesc(a.getId());
        long active = list.stream().filter(m -> m.getStatus() == Mortgage.Status.ACTIVE).count();
        BigDecimal activePrincipal = list.stream().filter(m -> m.getStatus() == Mortgage.Status.ACTIVE)
                .map(Mortgage::getPrincipal).reduce(BigDecimal.ZERO, BigDecimal::add);
        Person p = a.getPerson();
        return new AccountDto(a.getId(), a.getSerial(), p.getId(), p.getName(), p.getPhone(), p.getAddress(),
                p.getIdReference(), a.getReference(), active, list.size(), Money.money(activePrincipal), a.getVersion());
    }

    private CalculationDto toCalcDto(InterestCalculation c) {
        List<InterestEngine.Period> periods;
        try {
            periods = objectMapper.readValue(c.getBreakdownJson(), new TypeReference<>() {
            });
        } catch (JsonProcessingException e) {
            periods = List.of();
        }
        return new CalculationDto(c.getId(), c.getEffectiveThrough(), c.getCalculatedAt(), c.getCalculatedBy(),
                c.getPrincipal(), c.getMonthlyRate(), c.getTotalInterest(), c.getCapitalizedPrincipal(), c.getTotalDue(),
                c.getAmountReceived(), c.getRemainingBalance(), periods, InterestEngine.POLICY_NOTES);
    }

    public MortgageDto toDto(Mortgage m, boolean detail) {
        Person p = m.getAccount().getPerson();
        String completion;
        if (m.getStatus() == Mortgage.Status.PAID) completion = "COMPLETED";
        else if (m.isFullPaymentConfirmed()) completion = "AWAITING_JEWELLERY_RETURN";
        else completion = "ACTIVE";
        List<PaymentDto> payments = detail ? m.getPayments().stream().map(x -> new PaymentDto(x.getId(), x.getAmount(),
                x.getPaymentDate(), x.getMethod(), x.getReference(), x.getNotes(), x.isFinalSettlement(), x.getTransactionId(),
                transactionService.isEffective(x.getTransactionId()), x.getCreatedAt())).toList() : List.of();
        List<CalculationDto> calcs = detail ? m.getCalculations().stream().map(this::toCalcDto).toList() : List.of();
        CalculationDto last = m.getCalculations().isEmpty() ? null : toCalcDto(m.getCalculations().get(0));
        return new MortgageDto(m.getId(), m.getSerial(), m.getAccount().getId(), m.getAccount().getSerial(), p.getId(),
                p.getName(), p.getPhone(), m.getKind(), m.getIssueDate(), m.getPrincipal(), m.getMonthlyRate(),
                m.getApproxReminderDate(), m.getStatus(), m.getJewelleryName(), m.getNetWeight(), m.getPieces(), m.getMetal(),
                m.getIssueMethod(), m.getNotes(), received(m), m.isFullPaymentConfirmed(), m.getSettledDate(),
                m.isJewelleryReturned(), m.getJewelleryReturnDate(), m.getJewelleryReturnedTo(), m.getJewelleryReturnNotes(),
                completion, last, payments, calcs, m.getVersion());
    }
}
