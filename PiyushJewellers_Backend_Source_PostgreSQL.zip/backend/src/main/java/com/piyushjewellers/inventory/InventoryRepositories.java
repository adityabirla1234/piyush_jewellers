package com.piyushjewellers.inventory;

import com.piyushjewellers.common.enums.Enums;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;

public interface InventoryRepositories {

    interface ProductRepository extends JpaRepository<Product, Long> {

        @Query("""
                select p from Product p
                where p.active = true
                  and (:q is null or lower(p.name) like lower(concat('%', cast(:q as String), '%'))
                       or lower(p.code) like lower(concat('%', cast(:q as String), '%'))
                       or lower(p.description) like lower(concat('%', cast(:q as String), '%')))
                  and (:category is null or p.category = :category)
                  and (:metal is null or p.metal = :metal)
                  and (:purity is null or lower(p.purity) = lower(cast(:purity as String)))
                  and (:availability is null
                       or (:availability = 'IN_STOCK' and (p.pieces > 0 or p.netWeight > 0))
                       or (:availability = 'OUT_OF_STOCK' and p.pieces <= 0 and p.netWeight <= 0))
                """)
        Page<Product> search(String q, Product.Category category, Enums.Metal metal, String purity,
                             String availability, Pageable pageable);

        boolean existsByCode(String code);

        @Query("select coalesce(sum(p.netWeight), 0) from Product p where p.active = true and p.metal = :metal")
        BigDecimal totalNetWeight(Enums.Metal metal);

        @Query("select count(p) from Product p where p.active = true and p.pieces <= 0 and p.netWeight <= 0")
        long countOutOfStock();

        long countByActiveTrue();
    }

    interface StockMovementRepository extends JpaRepository<StockMovement, Long> {
        Page<StockMovement> findByProductIdOrderByIdDesc(Long productId, Pageable pageable);

        List<StockMovement> findBySourceTypeAndSourceId(String sourceType, Long sourceId);

        @Query("select m from StockMovement m join fetch m.product where m.businessDate between :from and :to order by m.businessDate asc, m.id asc")
        List<StockMovement> findInRange(java.time.LocalDate from, java.time.LocalDate to);
    }

    interface ProductImageRepository extends JpaRepository<ProductImage, Long> {
        List<ProductImage> findByProductIdOrderByDisplayOrderAscIdAsc(Long productId);

        List<ProductImage> findByProductIdInAndPrimaryImageTrue(Collection<Long> productIds);

        long countByProductId(Long productId);

        @Query("select i.productId, count(i) from ProductImage i where i.productId in :ids group by i.productId")
        List<Object[]> countByProductIds(Collection<Long> ids);
    }

    interface BarLotRepository extends JpaRepository<BarLot, Long> {
        List<BarLot> findByMetalOrderByReceivedDateDesc(Enums.Metal metal);

        List<BarLot> findAllByOrderByReceivedDateDesc();

        List<BarLot> findByMetalAndStatusOrderByReceivedDateAsc(Enums.Metal metal, BarLot.Status status);

        boolean existsByLotCode(String lotCode);

        @Query("select coalesce(sum(b.remainingWeight), 0) from BarLot b where b.metal = :metal")
        BigDecimal totalRemaining(Enums.Metal metal);
    }

    interface BarMovementRepository extends JpaRepository<BarMovement, Long> {
        List<BarMovement> findByBarLotIdOrderByIdDesc(Long barLotId);

        List<BarMovement> findBySourceTypeAndSourceId(String sourceType, Long sourceId);
    }
}
