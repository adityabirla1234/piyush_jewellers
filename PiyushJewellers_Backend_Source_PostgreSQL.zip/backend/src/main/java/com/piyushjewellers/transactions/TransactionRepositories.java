package com.piyushjewellers.transactions;

import com.piyushjewellers.common.enums.Enums;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface TransactionRepositories {

    interface DailyTransactionRepository extends JpaRepository<DailyTransaction, Long> {

        @Query("""
                select t from DailyTransaction t left join t.person p
                where (cast(:from as LocalDate) is null or t.businessDate >= :from)
                  and (cast(:to as LocalDate) is null or t.businessDate < :to)
                  and (:direction is null or t.direction = :direction)
                  and (:method is null or t.method = :method)
                  and (:personId is null or p.id = :personId)
                  and (:sourceType is null or t.sourceType = :sourceType)
                  and (:q is null or lower(t.description) like lower(concat('%', cast(:q as String), '%'))
                       or lower(t.category) like lower(concat('%', cast(:q as String), '%'))
                       or lower(t.reference) like lower(concat('%', cast(:q as String), '%'))
                       or lower(p.name) like lower(concat('%', cast(:q as String), '%')))
                """)
        Page<DailyTransaction> search(LocalDateTime from, LocalDateTime to, Enums.Direction direction,
                                      Enums.PaymentMethod method, Long personId, Enums.SourceType sourceType,
                                      String q, Pageable pageable);

        List<DailyTransaction> findBySourceTypeAndSourceId(Enums.SourceType sourceType, Long sourceId);

        List<DailyTransaction> findByTransferGroup(String transferGroup);

        List<DailyTransaction> findByPersonIdOrderByBusinessDateDesc(Long personId);

        List<DailyTransaction> findTop8ByOrderByBusinessDateDescIdDesc();

        /** Sum by method, direction and source; cheque rows are included (combined ledger). */
        @Query("""
                select t.method, t.direction, t.sourceType, coalesce(sum(t.amount), 0) from DailyTransaction t
                where (cast(:from as LocalDate) is null or t.businessDate >= :from) and (cast(:to as LocalDate) is null or t.businessDate < :to)
                group by t.method, t.direction, t.sourceType
                """)
        List<Object[]> sumByMethodAndDirection(LocalDateTime from, LocalDateTime to);

        /** Per source, category and direction: amount and row count, used by the turnover module. */
        @Query("""
                select t.sourceType, t.category, t.direction, coalesce(sum(t.amount), 0), count(t) from DailyTransaction t
                where (cast(:from as LocalDate) is null or t.businessDate >= :from) and (cast(:to as LocalDate) is null or t.businessDate < :to)
                group by t.sourceType, t.category, t.direction
                """)
        List<Object[]> sumBySourceAndCategory(LocalDateTime from, LocalDateTime to);

        /** Signed totals of cheque-linked rows that are not cleared (pending or bounced + its reversal). */
        @Query("""
                select coalesce(sum(case when t.direction = com.piyushjewellers.common.enums.Enums.Direction.IN
                                         then t.amount else -t.amount end), 0)
                from DailyTransaction t
                where (cast(:to as LocalDate) is null or t.businessDate < :to)
                  and (t.id in (select c.transaction.id from ChequeRecord c where c.status <> com.piyushjewellers.transactions.ChequeRecord.Status.CLEARED)
                       or t.id in (select c.bounceReversalTransactionId from ChequeRecord c where c.bounceReversalTransactionId is not null))
                """)
        BigDecimal signedNotClearedCheques(LocalDateTime to);

        @Query("""
                select coalesce(sum(case when t.direction = com.piyushjewellers.common.enums.Enums.Direction.IN
                                         then t.amount else -t.amount end), 0)
                from DailyTransaction t where t.businessDate < :before
                """)
        BigDecimal signedTotalBefore(LocalDateTime before);
    }

    interface ChequeRecordRepository extends JpaRepository<ChequeRecord, Long> {
        Optional<ChequeRecord> findByTransactionId(Long transactionId);

        List<ChequeRecord> findByTransactionIdIn(List<Long> ids);

        @Query("select c from ChequeRecord c join fetch c.transaction t where (:status is null or c.status = :status) order by t.businessDate desc")
        List<ChequeRecord> findByStatusFetch(ChequeRecord.Status status);

        @Query("select coalesce(sum(t.amount), 0) from ChequeRecord c join c.transaction t where c.status = com.piyushjewellers.transactions.ChequeRecord.Status.PENDING and c.direction = :direction")
        BigDecimal pendingTotal(Enums.Direction direction);
    }
}
