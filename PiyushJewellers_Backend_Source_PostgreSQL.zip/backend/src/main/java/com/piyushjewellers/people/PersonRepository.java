package com.piyushjewellers.people;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PersonRepository extends JpaRepository<Person, Long> {

    List<Person> findByNormalizedPhone(String normalizedPhone);

    @Query("""
            select p from Person p
            where p.active = true
              and (:q is null or lower(p.name) like lower(concat('%', cast(:q as String), '%'))
                   or p.normalizedPhone like concat('%', cast(:q as String), '%')
                   or lower(p.idReference) like lower(concat('%', cast(:q as String), '%')))
              and (:type is null
                   or (:type = 'CUSTOMER' and p.customer = true)
                   or (:type = 'SUPPLIER' and p.supplier = true)
                   or (:type = 'DEALER' and p.dealer = true))
            """)
    Page<Person> search(String q, String type, Pageable pageable);
}
