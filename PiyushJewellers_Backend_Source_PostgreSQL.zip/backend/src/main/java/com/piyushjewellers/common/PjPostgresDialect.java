package com.piyushjewellers.common;

import org.hibernate.dialect.PostgreSQLDialect;

/**
 * PostgreSQL dialect without column check constraints. Hibernate otherwise writes every enum column as
 * {@code check (col in (...))}, and ddl-auto=update never widens that list, so a newly added enum value would be
 * rejected by existing databases. Enum validity is enforced by the application instead.
 */
public class PjPostgresDialect extends PostgreSQLDialect {

    @Override
    public boolean supportsColumnCheck() {
        return false;
    }
}
