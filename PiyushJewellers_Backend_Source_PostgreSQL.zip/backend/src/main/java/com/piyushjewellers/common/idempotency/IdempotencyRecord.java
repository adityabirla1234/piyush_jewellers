package com.piyushjewellers.common.idempotency;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.Length;

import java.time.Instant;

@Getter
@Setter
@Entity
@Table(name = "idempotency_records")
public class IdempotencyRecord {

    public enum State { IN_PROGRESS, COMPLETED }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "idem_key", nullable = false, unique = true, length = 100)
    private String key;

    @Column(nullable = false, length = 80)
    private String username;

    @Column(nullable = false, length = 10)
    private String method;

    @Column(nullable = false, length = 300)
    private String path;

    @Column(nullable = false, length = 20)
    private State state;

    private Integer responseStatus;

    @Column(length = Length.LONG32)
    private String responseBody;

    @Column(nullable = false)
    private Instant createdAt;
}
