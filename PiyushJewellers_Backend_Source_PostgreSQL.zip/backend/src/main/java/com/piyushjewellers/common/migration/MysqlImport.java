package com.piyushjewellers.common.migration;

import jakarta.persistence.EntityManagerFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.SmartInitializingSingleton;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * One-time copy of the earlier MySQL (Aiven) data into this PostgreSQL database. Does nothing unless
 * {@code PJ_IMPORT_MYSQL_URL} is set. Runs after Hibernate has created the schema and before the web server,
 * schedulers and owner bootstrap start. Copies only into a completely empty database, in a single transaction,
 * so a failure leaves nothing behind and a later restart with the variables still set does nothing.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MysqlImport implements SmartInitializingSingleton {

    private static final int BATCH = 500;

    private final DataSource dataSource;
    private final EntityManagerFactory schemaReady;

    @Value("${pj.import.mysql-url}")
    private String url;
    @Value("${pj.import.mysql-username:}")
    private String username;
    @Value("${pj.import.mysql-password:}")
    private String password;

    @Override
    public void afterSingletonsInstantiated() {
        if (url == null || url.isBlank()) return;
        try (Connection target = dataSource.getConnection();
             Connection source = DriverManager.getConnection(utcSession(url), username, password)) {
            Map<String, Integer> copied = copyAll(source, target);
            if (copied != null) {
                log.info("MySQL import finished: {} rows in {} tables {}. Remove PJ_IMPORT_MYSQL_* now.",
                        copied.values().stream().mapToInt(Integer::intValue).sum(), copied.size(), copied);
            }
        } catch (SQLException e) {
            throw new IllegalStateException("MySQL import failed and nothing was copied: " + e.getMessage(), e);
        }
    }

    /** MySQL TIMESTAMP values are converted using the session zone; pinning it to UTC keeps instants exact. */
    static String utcSession(String jdbcUrl) {
        return jdbcUrl + (jdbcUrl.contains("?") ? "&" : "?") + "connectionTimeZone=UTC&forceConnectionTimeZoneToSession=true";
    }

    /** Returns rows copied per table, or {@code null} when the target already holds data. */
    public static Map<String, Integer> copyAll(Connection source, Connection target) throws SQLException {
        List<String> tables = tablesInDependencyOrder(target);
        for (String t : tables) {
            if (count(target, t) > 0) {
                log.warn("MySQL import skipped: table {} already has rows. Import only runs into an empty database.", t);
                return null;
            }
        }
        Set<String> sourceTables = sourceTables(source);
        Map<String, Integer> copied = new LinkedHashMap<>();
        boolean autoCommit = target.getAutoCommit();
        target.setAutoCommit(false);
        try {
            for (String t : tables) {
                if (sourceTables.contains(t)) {
                    copied.put(t, copyTable(source, target, t));
                }
            }
            resetIdentities(target);
            target.commit();
        } catch (SQLException | RuntimeException e) {
            target.rollback();
            throw e;
        } finally {
            target.setAutoCommit(autoCommit);
        }
        return copied;
    }

    private static List<String> tablesInDependencyOrder(Connection pg) throws SQLException {
        Set<String> tables = new TreeSet<>();
        try (Statement st = pg.createStatement(); ResultSet rs = st.executeQuery("""
                select table_name from information_schema.tables
                where table_schema = current_schema() and table_type = 'BASE TABLE'
                """)) {
            while (rs.next()) tables.add(rs.getString(1));
        }
        Map<String, Set<String>> parents = new HashMap<>();
        try (Statement st = pg.createStatement(); ResultSet rs = st.executeQuery("""
                select tc.table_name, ccu.table_name
                from information_schema.table_constraints tc
                join information_schema.constraint_column_usage ccu
                  on ccu.constraint_name = tc.constraint_name and ccu.constraint_schema = tc.constraint_schema
                where tc.constraint_type = 'FOREIGN KEY' and tc.table_schema = current_schema()
                """)) {
            while (rs.next()) {
                if (!rs.getString(1).equals(rs.getString(2))) {
                    parents.computeIfAbsent(rs.getString(1), k -> new HashSet<>()).add(rs.getString(2));
                }
            }
        }
        List<String> ordered = new ArrayList<>();
        Set<String> remaining = new LinkedHashSet<>(tables);
        while (!remaining.isEmpty()) {
            String next = remaining.stream()
                    .filter(t -> parents.getOrDefault(t, Set.of()).stream().noneMatch(remaining::contains))
                    .findFirst()
                    .orElseThrow(() -> new IllegalStateException("Circular foreign keys between " + remaining));
            ordered.add(next);
            remaining.remove(next);
        }
        return ordered;
    }

    private static Set<String> sourceTables(Connection source) throws SQLException {
        Set<String> names = new HashSet<>();
        try (ResultSet rs = source.getMetaData().getTables(source.getCatalog(), source.getSchema(), "%", new String[]{"TABLE"})) {
            while (rs.next()) names.add(rs.getString("TABLE_NAME").toLowerCase(Locale.ROOT));
        }
        return names;
    }

    private static int copyTable(Connection source, Connection target, String table) throws SQLException {
        Map<String, String> targetTypes = new LinkedHashMap<>();
        try (PreparedStatement ps = target.prepareStatement("""
                select column_name, data_type from information_schema.columns
                where table_schema = current_schema() and table_name = ? order by ordinal_position
                """)) {
            ps.setString(1, table);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) targetTypes.put(rs.getString(1), rs.getString(2));
            }
        }
        DatabaseMetaData meta = source.getMetaData();
        Set<String> sourceColumns = new HashSet<>();
        try (ResultSet rs = meta.getColumns(source.getCatalog(), source.getSchema(), table, "%")) {
            while (rs.next()) sourceColumns.add(rs.getString("COLUMN_NAME").toLowerCase(Locale.ROOT));
        }
        List<String> columns = targetTypes.keySet().stream().filter(sourceColumns::contains).toList();
        if (columns.isEmpty()) return 0;

        String q = meta.getIdentifierQuoteString().trim();
        String select = "select " + String.join(", ", columns.stream().map(c -> q + c + q).toList())
                + " from " + q + table + q + (columns.contains("id") ? " order by " + q + "id" + q : "");
        String insert = "insert into \"" + table + "\" (" + String.join(", ", columns.stream().map(c -> "\"" + c + "\"").toList())
                + ") values (" + String.join(", ", columns.stream().map(c -> "?").toList()) + ")";

        int rows = 0;
        try (Statement st = source.createStatement(); ResultSet rs = st.executeQuery(select);
             PreparedStatement ins = target.prepareStatement(insert)) {
            while (rs.next()) {
                for (int i = 0; i < columns.size(); i++) {
                    ins.setObject(i + 1, read(rs, i + 1, targetTypes.get(columns.get(i))));
                }
                ins.addBatch();
                if (++rows % BATCH == 0) ins.executeBatch();
            }
            ins.executeBatch();
        }
        return rows;
    }

    private static Object read(ResultSet rs, int i, String targetType) throws SQLException {
        Object v = switch (targetType) {
            case "timestamp with time zone" -> rs.getObject(i, OffsetDateTime.class);
            case "timestamp without time zone" -> rs.getObject(i, LocalDateTime.class);
            case "date" -> rs.getObject(i, LocalDate.class);
            case "time without time zone" -> rs.getObject(i, LocalTime.class);
            case "boolean" -> rs.getBoolean(i);
            case "numeric" -> rs.getBigDecimal(i);
            case "bigint" -> rs.getLong(i);
            case "integer", "smallint" -> rs.getInt(i);
            case "double precision", "real" -> rs.getDouble(i);
            case "bytea" -> rs.getBytes(i);
            default -> rs.getString(i);
        };
        return rs.wasNull() ? null : v;
    }

    private static void resetIdentities(Connection pg) throws SQLException {
        List<String[]> identities = new ArrayList<>();
        try (Statement st = pg.createStatement(); ResultSet rs = st.executeQuery("""
                select table_name, column_name from information_schema.columns
                where table_schema = current_schema() and is_identity = 'YES'
                """)) {
            while (rs.next()) identities.add(new String[]{rs.getString(1), rs.getString(2)});
        }
        for (String[] idc : identities) {
            try (PreparedStatement ps = pg.prepareStatement("select setval(pg_get_serial_sequence(?, ?), "
                    + "coalesce((select max(\"" + idc[1] + "\") from \"" + idc[0] + "\"), 0) + 1, false)")) {
                ps.setString(1, "\"" + idc[0] + "\"");
                ps.setString(2, idc[1]);
                ps.execute();
            }
        }
    }

    private static long count(Connection pg, String table) throws SQLException {
        try (Statement st = pg.createStatement(); ResultSet rs = st.executeQuery("select count(*) from \"" + table + "\"")) {
            rs.next();
            return rs.getLong(1);
        }
    }
}
