package com.piyushjewellers.exchange;

import com.piyushjewellers.audit.AuditService;
import com.piyushjewellers.billing.BillCalculator;
import com.piyushjewellers.common.ApiException;
import com.piyushjewellers.common.Money;
import com.piyushjewellers.common.PageResponse;
import com.piyushjewellers.common.enums.Enums;
import com.piyushjewellers.common.enums.Enums.Direction;
import com.piyushjewellers.common.enums.Enums.SourceType;
import com.piyushjewellers.inventory.InventoryService;
import com.piyushjewellers.inventory.Product;
import com.piyushjewellers.inventory.StockMovement;
import com.piyushjewellers.people.PersonService;
import com.piyushjewellers.transactions.DailyTransaction;
import com.piyushjewellers.transactions.TransactionService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * Jewellery exchange. Each line value = net weight × user-entered rate (same valuation policy as customer bills);
 * no purity-based valuation is inferred. Cash difference = issued value − received value:
 * positive → customer pays the shop (IN), negative → shop pays the customer (OUT).
 */
@Service
@RequiredArgsConstructor
public class ExchangeService {

    public interface ExchangeRepository extends JpaRepository<Exchange, Long> {
        @Query("""
                select e from Exchange e left join e.person p
                where (:status is null or e.status = :status)
                  and (:personId is null or p.id = :personId)
                  and (:q is null or lower(e.exchangeNumber) like lower(concat('%', cast(:q as String), '%'))
                       or lower(e.partyName) like lower(concat('%', cast(:q as String), '%')) or lower(p.name) like lower(concat('%', cast(:q as String), '%')))
                """)
        Page<Exchange> search(Exchange.Status status, Long personId, String q, Pageable pageable);

        boolean existsByExchangeNumber(String number);

        List<Exchange> findByPersonIdOrderByExchangeDateDesc(Long personId);
    }

    private static final String SOURCE = "EXCHANGE";

    private final ExchangeRepository repo;
    private final PersonService personService;
    private final InventoryService inventoryService;
    private final TransactionService transactionService;
    private final AuditService auditService;

    public record LineRequest(@NotNull ExchangeLine.Side side, @NotBlank @Size(max = 300) String description,
                              Long productId, Product.Category newProductCategory, @NotNull Enums.Metal metal,
                              @Size(max = 20) String purity, @DecimalMin("0") BigDecimal grossWeight,
                              @DecimalMin("0") BigDecimal lessWeight, @DecimalMin("0") BigDecimal netWeight,
                              @Min(0) Integer pieces, @NotNull @DecimalMin("0") BigDecimal rate) {
    }

    public record ExchangeRequest(Long personId, @Size(max = 150) String partyName, @NotNull LocalDate exchangeDate,
                                  @Size(max = 1000) String notes, Enums.PaymentMethod differenceMethod,
                                  @Size(max = 120) String differenceReference, @NotEmpty List<@Valid LineRequest> lines,
                                  Long version) {
    }

    public record LineDto(Long id, int lineNo, ExchangeLine.Side side, String description, Long productId,
                          String productCode, Product.Category newProductCategory, Enums.Metal metal, String purity,
                          BigDecimal grossWeight, BigDecimal lessWeight, BigDecimal netWeight, int pieces,
                          BigDecimal rate, BigDecimal value) {
    }

    public record ExchangeDto(Long id, String exchangeNumber, Long personId, String personName, String partyName,
                              LocalDate exchangeDate, String notes, Exchange.Status status, List<LineDto> lines,
                              BigDecimal receivedValue, BigDecimal issuedValue, BigDecimal cashDifference,
                              String cashDirection, Enums.PaymentMethod differenceMethod, String differenceReference,
                              Long transactionId, Instant finalizedAt, String reversalReason, Long version) {
    }

    @Transactional(readOnly = true)
    public PageResponse<ExchangeDto> search(Exchange.Status status, Long personId, String q, int page, int size) {
        return PageResponse.of(repo.search(status, personId, (q == null || q.isBlank()) ? null : q.trim(),
                PageResponse.pageable(page, size, Sort.by(Sort.Direction.DESC, "exchangeDate", "id"))), this::toDto);
    }

    @Transactional(readOnly = true)
    public ExchangeDto get(Long id) {
        return toDto(require(id));
    }

    @Transactional
    public ExchangeDto createDraft(ExchangeRequest r) {
        Exchange e = new Exchange();
        long n = repo.count() + 1;
        String number;
        do {
            number = String.format("EX-%05d", n++);
        } while (repo.existsByExchangeNumber(number));
        e.setExchangeNumber(number);
        apply(e, r);
        repo.save(e);
        auditService.record("EXCHANGE_DRAFT_CREATED", "Exchange", e.getId(), null, number);
        return toDto(e);
    }

    @Transactional
    public ExchangeDto updateDraft(Long id, ExchangeRequest r) {
        Exchange e = require(id);
        if (e.getStatus() != Exchange.Status.DRAFT) throw ApiException.state("Only drafts can be edited");
        if (r.version() != null && !r.version().equals(e.getVersion())) {
            throw ApiException.conflict("VERSION_CONFLICT", "This exchange was changed elsewhere. Reload and retry.", null);
        }
        apply(e, r);
        repo.flush();
        return toDto(e);
    }

    /** Atomic: stock movements for both sides and one linked money movement for the difference. */
    @Transactional
    public ExchangeDto finalizeExchange(Long id) {
        Exchange e = require(id);
        if (e.getStatus() != Exchange.Status.DRAFT) throw ApiException.state("This exchange is already " + e.getStatus());
        recalc(e);
        BigDecimal diff = e.getIssuedValue().subtract(e.getReceivedValue());
        if (diff.signum() != 0 && e.getDifferenceMethod() == null) {
            throw ApiException.validation("Select how the cash difference of " + diff.abs() + " is paid");
        }
        for (ExchangeLine l : e.getLines()) {
            Product product = l.getProduct();
            if (product == null && l.getSide() == ExchangeLine.Side.RECEIVED && l.getNewProductCategory() != null) {
                product = inventoryService.createFromDocument(l.getDescription(), l.getNewProductCategory(), l.getMetal(),
                        l.getPurity(), "Received in exchange " + e.getExchangeNumber());
                l.setProduct(product);
            }
            if (product == null) continue;
            InventoryService.StockDelta delta = new InventoryService.StockDelta(l.getGrossWeight(), l.getLessWeight(),
                    l.getNetWeight(), l.getPieces());
            boolean in = l.getSide() == ExchangeLine.Side.RECEIVED;
            inventoryService.applyMovement(product, in ? StockMovement.Type.EXCHANGE_IN : StockMovement.Type.EXCHANGE_OUT,
                    in ? delta : delta.negate(), SOURCE, e.getId(), "Exchange " + e.getExchangeNumber(), e.getExchangeDate());
        }
        if (diff.signum() != 0) {
            DailyTransaction t = transactionService.postLinked(new TransactionService.LinkedPayment(
                    diff.signum() > 0 ? Direction.IN : Direction.OUT, diff.abs(), e.getDifferenceMethod(),
                    e.getDifferenceReference(), e.getExchangeDate().atTime(LocalTime.now()), e.getPerson(),
                    "Jewellery exchange", "Exchange " + e.getExchangeNumber() + (e.getPartyName() == null ? "" : " — " + e.getPartyName()),
                    SourceType.EXCHANGE, e.getId(), e.getDifferenceMethod() == Enums.PaymentMethod.CHEQUE ? e.getDifferenceReference() : null,
                    null, null));
            e.setTransactionId(t.getId());
        }
        e.setStatus(Exchange.Status.FINALIZED);
        e.setFinalizedAt(Instant.now());
        auditService.record("EXCHANGE_FINALIZED", "Exchange", e.getId(), null,
                e.getExchangeNumber() + " received " + e.getReceivedValue() + " issued " + e.getIssuedValue());
        return toDto(e);
    }

    @Transactional
    public ExchangeDto reverse(Long id, String reason) {
        if (reason == null || reason.isBlank()) throw ApiException.validation("A reason is required");
        Exchange e = require(id);
        if (e.getStatus() != Exchange.Status.FINALIZED) throw ApiException.state("Only finalized exchanges can be reversed");
        inventoryService.reverseMovementsFor(SOURCE, e.getId(), reason);
        if (transactionService.isEffective(e.getTransactionId())) {
            transactionService.reverse(transactionService.require(e.getTransactionId()), "Exchange reversed: " + reason);
        }
        e.setStatus(Exchange.Status.REVERSED);
        e.setReversalReason(reason.trim());
        auditService.record("EXCHANGE_REVERSED", "Exchange", e.getId(), reason, e.getExchangeNumber());
        return toDto(e);
    }

    @Transactional
    public void deleteDraft(Long id) {
        Exchange e = require(id);
        if (e.getStatus() != Exchange.Status.DRAFT) throw ApiException.state("Only drafts can be deleted");
        auditService.record("EXCHANGE_DRAFT_DELETED", "Exchange", e.getId(), null, e.getExchangeNumber());
        repo.delete(e);
    }

    private void apply(Exchange e, ExchangeRequest r) {
        e.setPerson(r.personId() == null ? null : personService.require(r.personId()));
        e.setPartyName(r.partyName() != null && !r.partyName().isBlank() ? r.partyName().trim()
                : e.getPerson() == null ? null : e.getPerson().getName());
        e.setExchangeDate(r.exchangeDate());
        e.setNotes(r.notes());
        e.setDifferenceMethod(r.differenceMethod());
        e.setDifferenceReference(r.differenceReference());
        e.getLines().clear();
        int n = 1;
        for (LineRequest lr : r.lines()) {
            ExchangeLine l = new ExchangeLine();
            l.setExchange(e);
            l.setLineNo(n++);
            l.setSide(lr.side());
            l.setDescription(lr.description().trim());
            l.setProduct(lr.productId() == null ? null : inventoryService.require(lr.productId()));
            l.setNewProductCategory(lr.productId() == null && lr.side() == ExchangeLine.Side.RECEIVED ? lr.newProductCategory() : null);
            l.setMetal(lr.metal());
            l.setPurity(lr.purity());
            l.setGrossWeight(Money.weight(lr.grossWeight()));
            l.setLessWeight(Money.weight(lr.lessWeight()));
            l.setNetWeight(BillCalculator.net(lr.grossWeight(), lr.lessWeight(), lr.netWeight()));
            if (l.getNetWeight().signum() < 0) throw ApiException.validation("Less weight exceeds gross weight on line " + l.getLineNo());
            l.setPieces(lr.pieces() == null ? 0 : lr.pieces());
            l.setRate(Money.money(lr.rate()));
            e.getLines().add(l);
        }
        if (e.getLines().stream().noneMatch(l -> l.getSide() == ExchangeLine.Side.RECEIVED)
                || e.getLines().stream().noneMatch(l -> l.getSide() == ExchangeLine.Side.ISSUED)) {
            throw ApiException.validation("An exchange needs at least one received and one issued item");
        }
        recalc(e);
    }

    private void recalc(Exchange e) {
        BigDecimal received = BigDecimal.ZERO;
        BigDecimal issued = BigDecimal.ZERO;
        for (ExchangeLine l : e.getLines()) {
            l.setValue(BillCalculator.metalValue(l.getNetWeight(), l.getRate()));
            if (l.getSide() == ExchangeLine.Side.RECEIVED) received = received.add(l.getValue());
            else issued = issued.add(l.getValue());
        }
        e.setReceivedValue(Money.money(received));
        e.setIssuedValue(Money.money(issued));
    }

    private Exchange require(Long id) {
        return repo.findById(id).orElseThrow(() -> ApiException.notFound("Exchange", id));
    }

    public ExchangeDto toDto(Exchange e) {
        List<LineDto> lines = e.getLines().stream().map(l -> new LineDto(l.getId(), l.getLineNo(), l.getSide(),
                l.getDescription(), l.getProduct() == null ? null : l.getProduct().getId(),
                l.getProduct() == null ? null : l.getProduct().getCode(), l.getNewProductCategory(), l.getMetal(),
                l.getPurity(), l.getGrossWeight(), l.getLessWeight(), l.getNetWeight(), l.getPieces(), l.getRate(),
                l.getValue())).toList();
        BigDecimal diff = e.getIssuedValue().subtract(e.getReceivedValue());
        String direction = diff.signum() > 0 ? "CUSTOMER_PAYS" : diff.signum() < 0 ? "SHOP_PAYS" : "NONE";
        return new ExchangeDto(e.getId(), e.getExchangeNumber(), e.getPerson() == null ? null : e.getPerson().getId(),
                e.getPerson() == null ? null : e.getPerson().getName(), e.getPartyName(), e.getExchangeDate(), e.getNotes(),
                e.getStatus(), lines, e.getReceivedValue(), e.getIssuedValue(), Money.money(diff.abs()), direction,
                e.getDifferenceMethod(), e.getDifferenceReference(), e.getTransactionId(), e.getFinalizedAt(),
                e.getReversalReason(), e.getVersion());
    }
}
