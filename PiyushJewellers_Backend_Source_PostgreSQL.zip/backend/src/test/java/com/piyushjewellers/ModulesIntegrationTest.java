package com.piyushjewellers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.piyushjewellers.common.migration.MysqlImport;
import com.piyushjewellers.reports.ReportGenerator;
import com.piyushjewellers.reports.ReportJob;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureEmbeddedDatabase(type = AutoConfigureEmbeddedDatabase.DatabaseType.POSTGRES, provider = AutoConfigureEmbeddedDatabase.DatabaseProvider.ZONKY)
@ActiveProfiles("test")
class ModulesIntegrationTest {

    @Autowired
    MockMvc mvc;
    @Autowired
    ObjectMapper om;
    @Autowired
    ReportGenerator generator;
    @Autowired
    JdbcTemplate jdbc;
    @Autowired
    DataSource dataSource;

    String token;

    @Test
    void everyListEndpointWorksWithAndWithoutFilters() throws Exception {
        String[] paths = {"/api/v1/audit", "/api/v1/reminders", "/api/v1/turnover", "/api/v1/loans", "/api/v1/sell-purchase",
                "/api/v1/dealers", "/api/v1/dealer-bills", "/api/v1/exchanges", "/api/v1/notifications", "/api/v1/dues",
                "/api/v1/reports", "/api/v1/customer-bills", "/api/v1/transactions", "/api/v1/transactions/summary",
                "/api/v1/cheques", "/api/v1/products", "/api/v1/bar-lots", "/api/v1/dashboard", "/api/v1/mortgage-accounts",
                "/api/v1/mortgages", "/api/v1/people"};
        for (String path : paths) {
            call(get(path), 200);
            call(get(path + "?q=ab&from=2026-01-01&to=2026-12-31&metal=GOLD&purity=22K"), 200);
        }
    }

    @Test
    void importCopiesEveryTableIntoAnEmptyDatabaseOnce() throws Exception {
        call(post("/api/v1/people").content("{\"name\":\"Import Check\",\"phone\":\"9811122233\",\"customer\":true}"), 201);
        List<String> tables = jdbc.queryForList("""
                select table_name from information_schema.tables where table_schema = 'public' and table_type = 'BASE TABLE'
                """, String.class);
        jdbc.execute("drop schema if exists import_target cascade");
        jdbc.execute("create schema import_target");
        for (String t : tables) {
            jdbc.execute("create table import_target.\"" + t + "\" (like public.\"" + t + "\" including all)");
        }
        try (Connection source = dataSource.getConnection(); Connection target = dataSource.getConnection()) {
            try (Statement st = target.createStatement()) {
                st.execute("set search_path to import_target");
            }
            try {
                Map<String, Integer> copied = MysqlImport.copyAll(source, target);
                assertThat(copied).isNotNull().containsOnlyKeys(tables);
                for (String t : tables) {
                    assertThat(copied.get(t)).as(t).isEqualTo(jdbc.queryForObject("select count(*) from public.\"" + t + "\"", Integer.class));
                }
                assertThat(copied.get("persons")).isPositive();
                assertThat(MysqlImport.copyAll(source, target)).isNull();
            } finally {
                try (Statement st = target.createStatement()) {
                    st.execute("set search_path to public");
                }
            }
        }
        Long maxId = jdbc.queryForObject("select max(id) from import_target.persons", Long.class);
        Long next = jdbc.queryForObject("select nextval(pg_get_serial_sequence('import_target.persons', 'id'))", Long.class);
        assertThat(next).isGreaterThan(maxId);
        jdbc.execute("drop schema import_target cascade");
    }

    @Test
    void postgresSchemaHasNoEnumChecksAndUsesTextForLongColumns() {
        Integer checks = jdbc.queryForObject("""
                select count(*) from information_schema.table_constraints
                where constraint_type = 'CHECK' and table_schema = current_schema() and constraint_name not like '%_not_null'
                """, Integer.class);
        assertThat(checks).isZero();
        String type = jdbc.queryForObject("""
                select data_type from information_schema.columns
                where table_schema = current_schema() and table_name = 'interest_calculations' and column_name = 'breakdown_json'
                """, String.class);
        assertThat(type).isEqualTo("text");
    }

    @BeforeEach
    void login() throws Exception {
        token = call(post("/api/v1/auth/login").content("{\"username\":\"owner\",\"password\":\"owner-pass-123\"}"), 200)
                .get("accessToken").asText();
    }

    private JsonNode call(MockHttpServletRequestBuilder req, int expectedStatus) throws Exception {
        req.contentType(MediaType.APPLICATION_JSON);
        if (token != null) req.header("Authorization", "Bearer " + token);
        MvcResult res = mvc.perform(req).andReturn();
        assertThat(res.getResponse().getStatus()).as(res.getResponse().getContentAsString()).isEqualTo(expectedStatus);
        String body = res.getResponse().getContentAsString();
        return body.isEmpty() ? null : om.readTree(body);
    }

    private static BigDecimal dec(JsonNode n) {
        return new BigDecimal(n.asText());
    }

    private BigDecimal lotRemaining(String code) throws Exception {
        for (JsonNode lot : call(get("/api/v1/bar-lots"), 200)) {
            if (lot.get("lotCode").asText().equals(code)) return dec(lot.get("remainingWeight"));
        }
        throw new AssertionError("Lot " + code + " not found");
    }

    @Test
    void customerSalesBill_settledByWeightAndCash_receivesLot_andReversalUndoesIt() throws Exception {
        String bill = """
                {"type":"SALES","billDate":"2024-05-10","customerName":"Weight Customer","customerContact":"9876500011",
                 "lines":[{"description":"Silver payal","purity":"925","grossWeight":100,"netWeight":100,"pieces":2,"pairs":1,
                           "rate":80,"metal":"SILVER"}],
                 "makingChargesZeroConfirmed":true,
                 "payments":[{"kind":"WEIGHT","metal":"SILVER","weight":50,"rate":80,"purity":"999"},{"method":"CASH","amount":4000}]}
                """;
        long id = call(post("/api/v1/customer-bills").content(bill), 201).get("id").asLong();
        JsonNode fin = call(post("/api/v1/customer-bills/" + id + "/finalize"), 200);
        assertThat(fin.get("paymentState").asText()).isEqualTo("PAID");
        assertThat(fin.get("lines").get(0).get("pairs").asInt()).isEqualTo(1);
        assertThat(fin.get("lines").get(0).get("metal").asText()).isEqualTo("SILVER");
        assertThat(dec(fin.get("settledWeight"))).isEqualByComparingTo("50");
        JsonNode weightPay = fin.get("payments").get(0);
        assertThat(weightPay.get("kind").asText()).isEqualTo("WEIGHT");
        assertThat(dec(weightPay.get("amount"))).isEqualByComparingTo("4000");
        String lotCode = weightPay.get("barLotCode").asText();
        assertThat(lotRemaining(lotCode)).isEqualByComparingTo("50");

        JsonNode sp = call(get("/api/v1/sell-purchase?metal=SILVER&from=2024-05-01&to=2024-05-31"), 200);
        assertThat(sp.get("sales").get("count").asInt()).isEqualTo(1);
        assertThat(dec(sp.get("sales").get("amount"))).isEqualByComparingTo("8000");
        assertThat(dec(sp.get("sales").get("netWeight"))).isEqualByComparingTo("100");
        assertThat(sp.get("rows").get(0).get("partyPhone").asText()).isEqualTo("9876500011");
        assertThat(call(get("/api/v1/sell-purchase?metal=GOLD&from=2024-05-01&to=2024-05-31"), 200).get("rows").size()).isZero();

        JsonNode reversed = call(post("/api/v1/customer-bills/" + id + "/reverse").content("{\"reason\":\"Wrong entry\"}"), 200);
        assertThat(reversed.get("status").asText()).isEqualTo("REVERSED");
        assertThat(lotRemaining(lotCode)).isEqualByComparingTo("0");
        assertThat(call(get("/api/v1/sell-purchase?metal=SILVER&from=2024-05-01&to=2024-05-31"), 200).get("rows").size()).isZero();
    }

    @Test
    void customerPurchaseBill_paidInMetalFromLot_reducesLot() throws Exception {
        call(post("/api/v1/bar-lots").content("{\"metal\":\"SILVER\",\"weight\":10,\"rate\":7000,\"lotCode\":\"MRS-CP1\"}"), 201);
        long lotId = 0;
        for (JsonNode lot : call(get("/api/v1/bar-lots?metal=SILVER"), 200)) {
            if (lot.get("lotCode").asText().equals("MRS-CP1")) lotId = lot.get("id").asLong();
        }
        String bill = """
                {"type":"PURCHASE","billDate":"2024-06-05","customerName":"Old Silver Seller",
                 "lines":[{"description":"Old bowl","newProductCategory":"SILVER","purity":"925","grossWeight":2,"netWeight":2,"rate":7000,"makingCharges":0}],
                 "makingChargesZeroConfirmed":true,"payments":[{"kind":"WEIGHT","metal":"SILVER","weight":1,"rate":7000,"barLotId":%d}]}
                """.formatted(lotId);
        long id = call(post("/api/v1/customer-bills").content(bill), 201).get("id").asLong();
        JsonNode fin = call(post("/api/v1/customer-bills/" + id + "/finalize"), 200);
        assertThat(dec(fin.get("outstandingAmount"))).isEqualByComparingTo("7000");
        assertThat(lotRemaining("MRS-CP1")).isEqualByComparingTo("9");

        String noLot = bill.replace(",\"barLotId\":" + lotId, "");
        call(post("/api/v1/customer-bills").content(noLot), 422);

        JsonNode sp = call(get("/api/v1/sell-purchase?from=2024-06-01&to=2024-06-30&kind=PURCHASE"), 200);
        assertThat(sp.get("purchase").get("count").asInt()).isEqualTo(1);
        assertThat(dec(sp.get("purchase").get("amount"))).isEqualByComparingTo("14000");
    }

    @Test
    void turnoverGroupsMoneyBySource_excludingTransfers() throws Exception {
        LocalDate today = LocalDate.now();
        call(post("/api/v1/transactions").content("""
                {"businessDate":"%sT10:00:00","direction":"OUT","amount":1500,"method":"CASH","category":"Shop rent"}
                """.formatted(today)), 201);
        call(post("/api/v1/transfers").content("{\"fromMethod\":\"CASH\",\"toMethod\":\"BANK\",\"amount\":700,\"businessDate\":\"" + today + "T11:00:00\"}"), 201);
        JsonNode t = call(get("/api/v1/turnover?from=" + today + "&to=" + today), 200);
        boolean manualRent = false;
        for (JsonNode c : t.get("components")) {
            assertThat(c.get("source").asText()).isNotEqualTo("TRANSFER");
            if (c.get("source").asText().equals("MANUAL")) {
                for (JsonNode l : c.get("lines")) {
                    if (l.get("category").asText().equals("Shop rent")) manualRent = dec(l.get("moneyOut")).compareTo(new BigDecimal("1500")) >= 0;
                }
            }
        }
        assertThat(manualRent).isTrue();
        assertThat(dec(t.get("transfersMoved"))).isGreaterThanOrEqualTo(new BigDecimal("700"));
        assertThat(dec(t.get("closingBalance"))).isEqualByComparingTo(dec(t.get("openingBalance")).add(dec(t.get("net"))));
    }

    @Test
    void newReportKindsPersistAndRender() throws Exception {
        JsonNode job = call(post("/api/v1/reports").content("{\"type\":\"SELL_PURCHASE\",\"from\":\"2024-05-01\",\"to\":\"2024-06-30\",\"metal\":\"GOLD\"}"), 202);
        assertThat(job.get("type").asText()).isEqualTo("SELL_PURCHASE");
        assertThat(call(get("/api/v1/reports/" + job.get("id").asLong()), 200).get("type").asText()).isEqualTo("SELL_PURCHASE");
        JsonNode turnover = call(post("/api/v1/reports").content("{\"type\":\"TURNOVER\"}"), 202);
        assertThat(turnover.get("title").asText()).isEqualTo("Shop Turnover Report");

        for (ReportJob.Type type : new ReportJob.Type[]{ReportJob.Type.SELL_PURCHASE, ReportJob.Type.TURNOVER}) {
            ReportJob j = new ReportJob();
            j.setType(type);
            j.setTitle(type.name());
            assertThat(j.getReportType()).isEqualTo(ReportJob.Type.FINANCIAL);
            assertThat(j.getType()).isEqualTo(type);
            byte[] pdf = generator.build(j);
            assertThat(new String(pdf, 0, 4)).isEqualTo("%PDF");
        }
    }

    @Test
    void overdueLoanCreatesNotification_andReadAllClearsUnread() throws Exception {
        long p = call(post("/api/v1/people").content("{\"name\":\"Late Borrower\",\"phone\":\"9811100077\",\"customer\":true}"), 201)
                .get("id").asLong();
        call(post("/api/v1/loans").content("{\"personId\":" + p + ",\"kind\":\"LENT\",\"principal\":2500,\"loanDate\":\"2024-01-01\",\"method\":\"CASH\",\"expectedReturnDate\":\"2024-02-01\"}"), 201);
        call(post("/api/v1/notifications/refresh"), 200);
        assertThat(call(get("/api/v1/notifications/unread-count"), 200).get("count").asLong()).isPositive();
        boolean found = false;
        for (JsonNode n : call(get("/api/v1/notifications?unreadOnly=true"), 200).get("content")) {
            if (n.get("category").asText().equals("LOAN") && n.get("title").asText().contains("Late Borrower")) found = true;
        }
        assertThat(found).isTrue();
        call(post("/api/v1/notifications/refresh"), 200);
        call(post("/api/v1/notifications/read-all"), 200);
        assertThat(call(get("/api/v1/notifications/unread-count"), 200).get("count").asLong()).isZero();
    }
}
