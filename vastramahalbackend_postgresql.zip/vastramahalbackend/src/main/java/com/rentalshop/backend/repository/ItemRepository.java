package com.rentalshop.backend.repository;

import com.rentalshop.backend.entity.Item;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ItemRepository extends JpaRepository<Item, Long> {

    /**
     * IgnoreCase keeps the behaviour the shop had on MySQL, whose default
     * collation treated "dress-001" and "DRESS-001" as the same item_code.
     * PostgreSQL compares strings case-sensitively.
     */
    Optional<Item> findByItemCodeIgnoreCase(String itemCode);

    boolean existsByItemCodeIgnoreCase(String itemCode);

    Optional<Item> findByIdempotencyKey(String idempotencyKey);

    /**
     * Row-level lock on the item being booked. Every booking-creation
     * transaction acquires this lock FIRST, before checking for date overlaps.
     * This is what actually prevents the race condition where two concurrent
     * requests both read "no conflict" and both insert a booking for the
     * same overlapping range — PostgreSQL's default READ COMMITTED isolation
     * does NOT prevent that on its own for a read-then-insert pattern.
     *
     * Because every booking transaction for a given item always takes this
     * lock first, concurrent booking attempts on the SAME item are serialized;
     * attempts on DIFFERENT items are unaffected and run fully in parallel.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select i from Item i where i.id = :id")
    Optional<Item> findByIdForUpdate(@Param("id") Long id);

    List<Item> findByStatus(Item.ItemStatus status);

    /**
     * Section 3.6: returns only items with NO overlapping active booking for
     * the ENTIRE requested range (not partial availability). category is
     * optional — pass null to search across all categories.
     *
     * NOT EXISTS is used rather than a NOT IN subquery so it behaves
     * correctly even if the booking subquery could return NULLs, and so the
     * query planner can use the idx_booking_item_dates index for the
     * correlated lookup per item.
     */
    default List<Item> findAvailableInRange(LocalDateTime requestedStart, LocalDateTime requestedEnd,
                                            String category) {
        return findAvailableInRangeParts(
                requestedStart.toLocalDate(), requestedStart.toLocalTime(),
                requestedEnd.toLocalDate(), requestedEnd.toLocalTime(),
                category);
    }

    /**
     * Date + time version of the overlap test (see BookingRepository.findOverlapping):
     * a booking blocks the item when it starts at or before the requested end
     * AND ends at or after the requested start, compared down to the minute.
     */
    @Query("""
           select i from Item i
           where i.status = 'ACTIVE'
             and (:category is null or lower(i.category) = lower(:category))
             and not exists (
                 select 1 from Booking b
                 where b.item = i
                   and b.status in ('PENDING', 'CONFIRMED', 'PICKED_UP')
                   and (b.pickupDate < :endDate or (b.pickupDate = :endDate and b.pickupTime <= :endTime))
                   and (b.returnDate > :startDate or (b.returnDate = :startDate and b.returnTime >= :startTime))
             )
           order by lower(i.name), i.name
           """)
    List<Item> findAvailableInRangeParts(@Param("startDate") LocalDate startDate,
                                         @Param("startTime") LocalTime startTime,
                                         @Param("endDate") LocalDate endDate,
                                         @Param("endTime") LocalTime endTime,
                                         @Param("category") String category);

    /**
     * Backs the inventory list screen. category and status are both
     * optional (pass null to not filter on them).
     */
    @Query("""
           select i from Item i
           where (:category is null or lower(i.category) = lower(:category))
             and (:status is null or i.status = :status)
           order by lower(i.name), i.name
           """)
    List<Item> search(@Param("category") String category,
                       @Param("status") Item.ItemStatus status);

    /**
     * Backs the New Booking form's "Add accessory" picker: every bookable
     * item filed under one accessory bucket (pant / jewellery / dupatta).
     *
     * [matchTerms] is the bucket's set of accepted lower-case spellings --
     * see AccessoryCategory.matchTerms() for why a bucket maps to several.
     * An item qualifies on EITHER its category or its sub-category, because
     * shops file accessories both ways ("Jewellery" as the category, or
     * "Bridal / Jewellery" as category / sub-category) and forcing one
     * convention would silently hide half the inventory from the picker.
     * Both sides are lower-cased and trimmed so casing and stray spaces in
     * hand-typed inventory rows don't decide whether an item shows up.
     *
     * Deliberately no date-range availability filter, unlike
     * findAvailableInRange above: attaching an accessory to a booking does
     * not book it (see BookingAccessory's class doc), so there is no
     * occupied/free state to filter on. Non-ACTIVE items are still excluded
     * -- a damaged or lost accessory shouldn't be offered.
     *
     * No name/code filter here either: the picker loads the bucket once and
     * filters locally as staff type, so searching costs no round trip --
     * same pattern the "Add another item" search on the same form already
     * uses.
     */
    @Query("""
           select i from Item i
           where i.status = 'ACTIVE'
             and (lower(trim(i.category)) in :matchTerms
                  or lower(trim(i.subCategory)) in :matchTerms)
           order by lower(i.name), i.name
           """)
    List<Item> findAccessoryCandidates(@Param("matchTerms") Collection<String> matchTerms);
}
