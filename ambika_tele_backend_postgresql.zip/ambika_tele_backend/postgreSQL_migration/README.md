# Ambika Rewards: Aiven MySQL to Supabase PostgreSQL

This folder moves the Ambika Telecom rewards backend from the Aiven MySQL free tier to the Supabase free tier
(PostgreSQL 17). The application code was already plain JPA, so the code change is small; most of the work is moving
the data safely.

There are two ways to move the data:

- **Option A (automatic, recommended):** the app does it on its first start on Supabase. Hibernate creates the tables,
  then `MysqlImportRunner` copies every row from Aiven, and only then does the app start serving requests. You only
  set a few environment variables on Render and deploy.
- **Option B (manual):** run `migrate_data.py` from this folder on your own computer.

## What changed in the code

| File | Change |
| --- | --- |
| `pom.xml` | `mysql-connector-j` replaced by the PostgreSQL JDBC driver (`org.postgresql:postgresql`). |
| `src/main/resources/application.yml` | Comment on which Supabase connection string to use. `DB_URL` / `DB_USER` / `DB_PASSWORD` keep their names. |
| `src/main/resources/application-dev.yml` | Example `.env` values for Supabase. |
| `.github/workflows/db-backup.yml` | `mysqldump` replaced by `pg_dump` 17 (schema `public` only), still gzipped and `age`-encrypted. |
| `.github/workflows/db-keepalive.yml` | `mysql` ping replaced by `psql`. The Aiven power-on fallback is removed (Supabase has no equivalent). |
| `STAFF_LOGIN_CHANGES.md` | `.env` example and `active = false` (PostgreSQL boolean) updated. |
| `migration/MysqlImportRunner.java`, `migration/MysqlImportGateFilter.java` (new) | The one-time startup import (Option A). It does nothing unless `MYSQL_IMPORT_ENABLED=true`. |
| `pom.xml`, `application.yml` | `mysql-connector-j` kept (runtime only) for the import, and the `app.mysql-import.*` settings. |

Apart from the import, nothing in the Java code needed to change. It was checked for MySQL-only behaviour:

- **Native SQL:** the two `nativeQuery` updates are portable.
- **Locking:** `SELECT ... FOR UPDATE` comes from JPA `@Lock`, which works on PostgreSQL.
- **Case sensitivity:** PostgreSQL compares text case-sensitively, MySQL did not. Every lookup key is already normalised
  in code: SKU and invoice upper-cased, email lower-cased, phone in E.164 form. All searches use `lower(...)`.
- **Schema:** Hibernate (`ddl-auto=update`) creates the PostgreSQL types itself: `boolean`, `timestamptz`, `numeric`,
  identity columns, and check constraints for enums.

## Before you start

- **Supabase free tier:** 500 MB database, 2 active free projects per account, and a project is paused after
  7 days without activity. The keep-alive workflow (every 6 hours) prevents the pause.
- **Aiven must be running** (powered on) during the move. It is only read, never changed.
- **Option B only:** Python 3.9+ and Java 21 with Maven on your computer.

## Steps

### 1. Create the Supabase project

1. In [supabase.com](https://supabase.com), create a new project. Pick the region closest to your Render service
   (for example *South Asia (Mumbai)*) and save the database password.
2. Open **Connect** (top bar) and choose **Session pooler**. Copy the host (`aws-0-<region>.pooler.supabase.com`),
   the port (`5432`), the database (`postgres`) and the user (`postgres.<project-ref>`).

Two connection options do **not** work for this app:

- **Direct connection** (`db.<ref>.supabase.co`) is IPv6 only, and Render cannot reach IPv6.
- **Transaction pooler** (port `6543`) breaks the prepared statements and row locks this app uses.

The JDBC URL for the app is:

```
jdbc:postgresql://aws-0-<region>.pooler.supabase.com:5432/postgres?sslmode=require
```

### 2. Back up MySQL

Run the **DB backup** workflow one last time (Actions > DB backup > Run workflow), or run `mysqldump` yourself.
Do the move at a quiet time, when nobody is submitting claims or working in the admin screens.

### 3. Move the data

#### Option A: automatic, on the first start (recommended)

1. **Render > Environment.** Set the new database:
   - `DB_URL` to the JDBC URL from step 1.
   - `DB_USER` to `postgres.<project-ref>`.
   - `DB_PASSWORD` to the Supabase database password.

   And, for this one deploy, the old one (from the Aiven console, service overview):
   - `MYSQL_IMPORT_ENABLED` = `true`
   - `MYSQL_IMPORT_URL` = `jdbc:mysql://<aiven-host>:<aiven-port>/defaultdb?sslMode=REQUIRED`
   - `MYSQL_IMPORT_USER` = `avnadmin`
   - `MYSQL_IMPORT_PASSWORD` = the Aiven password
2. **Save and deploy.** On start the app:
   1. creates all tables in Supabase (Hibernate);
   2. connects to Aiven over TLS and reads one consistent snapshot;
   3. copies every table in one PostgreSQL transaction, parents before children (`bit(1)` becomes `boolean`;
      timestamps, enum text and encrypted values are copied unchanged);
   4. moves every id sequence past the highest copied id;
   5. compares the row count of every table and commits only if all match;
   6. records the import in a small table, `mysql_import_status`, so it never runs twice.

   While this runs, every request (the health check included) gets `503 Service Unavailable`, so Render keeps the
   old instance serving until the new one is ready. Staff accounts are created by `BOOTSTRAP_*` only after the import,
   and only if they do not exist yet.
3. **Check the Render log.** You should see one `MYSQL_IMPORT_TABLE` line per table, then:

   ```
   MYSQL_IMPORT_DONE tables=15 rows=... ms=... Remove MYSQL_IMPORT_ENABLED and the other MYSQL_IMPORT_* settings.
   ```

   If anything fails (Aiven unreachable, wrong password, a count mismatch), the log shows `Application run failed`
   with the reason, nothing is saved in Supabase, and the app does not start. Render keeps the old instance running.
   Fix the setting and deploy again. A `MYSQL_IMPORT_TABLE_SKIPPED` or `MYSQL_IMPORT_COLUMN_SKIPPED` warning means
   something exists only in MySQL and was not copied. Stop and check before going on.
4. **Delete the four `MYSQL_IMPORT_*` variables** on Render. Leaving them is harmless (later starts log
   `MYSQL_IMPORT_SKIPPED`), but the Aiven password should not stay around.

Two messages you may see:

- **`These PostgreSQL tables already have rows: [...]`**: the app already ran once on this Supabase database without
  the import (for example it created the `BOOTSTRAP_*` staff accounts). Add `MYSQL_IMPORT_REPLACE_EXISTING` = `true`,
  deploy, and delete it again afterwards. It empties those tables before importing.
- **`MYSQL_IMPORT_LATE_WRITES table=...`**: the old instance, still on MySQL, saved something (a claim, a review)
  in the few seconds the import took, and that row is not in Supabase. If nothing new has been saved on Supabase yet,
  run `delete from mysql_import_status;` in the Supabase SQL Editor, set `MYSQL_IMPORT_REPLACE_EXISTING` = `true`
  and deploy again. Otherwise re-enter the missing rows by hand.

#### Option B: manual, with `migrate_data.py`

1. Suspend the Render service (Render > service > Settings > Suspend), so no claim is submitted during the copy.
2. Create `.env` in the project root (next to `pom.xml`, where `application.yml` imports it) with the Supabase values:

   ```
   DB_URL=jdbc:postgresql://aws-0-<region>.pooler.supabase.com:5432/postgres?sslmode=require
   DB_USER=postgres.<project-ref>
   DB_PASSWORD=<supabase database password>
   ```

3. From the project root, run `mvn spring-boot:run` and wait for `Started RewardsApplication`, then press Ctrl+C.
   Hibernate has now created all 15 tables. If the `BOOTSTRAP_*_PASSWORD` settings are set, the app also created
   staff accounts. That is fine: the next step empties the tables before copying.
4. Copy the data:

   ```bash
   cd postgreSQL_migration
   python3 -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   cp migration.env.example .env       # fill in Aiven + Supabase values, download Aiven's ca.pem next to it
   python migrate_data.py --dry-run    # connects to both, shows the plan and row counts, changes nothing
   python migrate_data.py --truncate   # empties the Supabase tables, copies everything, checks counts
   ```

   The script does the same as Option A (snapshot, one transaction, type conversion, order, sequences, count check)
   and must print `Done. All row counts match.` If it prints `warn ... only in MySQL` for a column, stop and check.
   That column's data would not be copied.
5. On Render, set `DB_URL`, `DB_USER` and `DB_PASSWORD` as in Option A step 1 (without the `MYSQL_IMPORT_*`
   variables), deploy and resume the service.

### 4. Lock down Supabase's public API

Open the Supabase **SQL Editor**, paste [`supabase_hardening.sql`](supabase_hardening.sql) and click Run. Supabase
otherwise exposes every table in `public` through its REST API to anyone holding the project's anon key. The backend
is not affected because it connects as the table owner. You can also turn the API off entirely in
Project Settings > Data API.

### 5. Check production and update GitHub

1. **Check:** `/actuator/health` returns `UP`. Sign in as staff, open a few claims (the device numbers must show,
   which proves the encrypted values were copied intact), and look one claim up on the public status page.
2. **GitHub > Settings > Secrets and variables > Actions.** Update `DB_HOST`, `DB_PORT` (5432), `DB_NAME`
   (`postgres`), `DB_USER` and `DB_PASSWORD` to the Session pooler values. Delete `AIVEN_TOKEN`, `AIVEN_PROJECT`
   and `AIVEN_SERVICE`. `AGE_PUBLIC_KEY` stays.
3. **Test the workflows:** run **DB keep-alive** and **DB backup** once by hand.

### 6. Retire Aiven

Keep the Aiven service (powered off is fine) for about a week. Once you are confident, delete it. Its password
appeared in an old zip (see `STAFF_LOGIN_CHANGES.md`), so do not leave it running.

Afterwards you may delete `src/main/java/com/ambikatelecom/rewards/migration/MysqlImport*.java`, the `mysql-import`
block in `application.yml` and the `mysql-connector-j` dependency. Keeping them does no harm.

## Rolling back

Until step 6 the old database is intact (the import only reads it). To go back, set the three `DB_*` variables on Render back to the Aiven
values and deploy the previous commit, which still has the MySQL driver. Claims submitted on Supabase in the
meantime are not in MySQL.

## Restoring a backup (new format)

```bash
age -d -i key.txt ambika-<stamp>.sql.gz.age | gunzip | psql "postgresql://postgres.<ref>:<password>@aws-0-<region>.pooler.supabase.com:5432/postgres?sslmode=require"
```

## Tested

Before delivery, both options were run locally against MySQL 8.4 and PostgreSQL 17.

Option A (automatic import):

1. The original app ran on MySQL and created claims, reviews, rewards, products, price rules, staff accounts with
   changed passwords, sessions, audit logs and idempotency records.
2. The new app started on an empty PostgreSQL database with `MYSQL_IMPORT_*` set. It created the schema and imported
   15 tables. Every value in every table was compared with MySQL and found identical, and all the checks listed under
   Option B below passed.
3. A second start with the settings still present logged `MYSQL_IMPORT_SKIPPED`.
4. On a database where the app had already created staff accounts, the import refused to start. With
   `MYSQL_IMPORT_REPLACE_EXISTING=true` it imported, again with identical values.
5. With an unreachable MySQL host, the health check and the API answered 503 while the import was waiting, then the
   app stopped with an error and left nothing in PostgreSQL.

Option B (`migrate_data.py`):

1. The original app ran on MySQL and created claims, reviews, rewards, products, price rules, staff accounts with
   changed passwords, sessions, audit logs and idempotency records.
2. The new app started on an empty PostgreSQL database and created the schema.
3. `migrate_data.py --truncate` copied the data over TLS. Every value in every table was compared and found identical.
4. The new app then worked on the copied data:
   - staff login with the passwords set on MySQL;
   - device numbers decrypted;
   - search, the public status lookup, and the filters;
   - a new product and claim (sequences continue after the copied ids);
   - a duplicate device refused;
   - approval through the `SELECT ... FOR UPDATE` path.
